﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Constants;

/// <summary>
/// Holds the configuration defaults, user messages and log messages used by the session refresh flow.
/// </summary>
public static class SessionRefreshConstants
{
    #region Member Variables

    /// <summary>Configuration section in appsettings.json that holds the session refresh settings.</summary>
    public const string SESSION_REFRESH_SECTION = "CertificateHandler:SessionRefresh";

    /// <summary>Seconds before the session expires at which the refresh is started, when nothing is configured.</summary>
    public const int DEFAULT_REFRESH_BEFORE_EXPIRY_SECONDS = 60;

    /// <summary>Seconds to wait before the first retry after a failed refresh, when nothing is configured.</summary>
    public const int DEFAULT_RETRY_INITIAL_DELAY_SECONDS = 2;

    /// <summary>Longest wait in seconds between two retries, when nothing is configured.</summary>
    public const int DEFAULT_RETRY_MAX_DELAY_SECONDS = 30;

    /// <summary>Seconds a refresh request may take before it is cancelled, when nothing is configured.</summary>
    public const int DEFAULT_REQUEST_TIMEOUT_SECONDS = 15;

    /// <summary>Seconds a session notification stays visible to the user, when nothing is configured.</summary>
    public const int DEFAULT_NOTIFICATION_DISPLAY_SECONDS = 5;

    /// <summary>Factor by which the wait between retries grows after each failed attempt, up to the longest wait.</summary>
    public const int RETRY_BACKOFF_MULTIPLIER = 2;

    /// <summary>Content type of the refresh request and response body.</summary>
    public const string JSON_MEDIA_TYPE = "application/json";

    /// <summary>Name of the JSON field that holds the refresh token.</summary>
    public const string REFRESH_TOKEN_FIELD = "refreshToken";

    /// <summary>Name of the JSON field that holds the new access token.</summary>
    public const string ACCESS_TOKEN_FIELD = "accessToken";

    /// <summary>Name of the JSON field that holds the lifetime of the new access token in seconds.</summary>
    public const string EXPIRES_IN_FIELD = "expiresIn";

    /// <summary>Shown to the user when the refresh failed but the session is kept while the app retries.</summary>
    public const string REFRESH_FAILED_NOTIFICATION = "Connection to the server was lost. You are still signed in; reconnecting...";

    /// <summary>Shown to the user when a retry succeeded and the current view was reloaded.</summary>
    public const string REFRESH_RECOVERED_NOTIFICATION = "Connection restored. Your session is active and the view has been refreshed.";

    /// <summary>Logged when a refresh starts; the argument is the user name.</summary>
    public const string LOG_REFRESH_STARTED = "Session refresh started for user %s.";

    /// <summary>Logged when a refresh succeeds; the arguments are the user name and the new expiry time.</summary>
    public const string LOG_REFRESH_SUCCEEDED = "Session refresh succeeded for user %s. New expiry: %s.";

    /// <summary>Logged as an error when the connection to the server is lost during a refresh; the arguments are the user name and the error.</summary>
    public const string LOG_REFRESH_NETWORK_FAILURE = "Connection to the server was lost for user %s. The user stays signed in and the application keeps retrying. Reason: %s";

    /// <summary>Logged when a refresh fails with an unexpected error; the arguments are the user name and the error.</summary>
    public const string LOG_REFRESH_UNEXPECTED_FAILURE = "Session refresh failed for user %s with an unexpected error. Session kept. Reason: %s";

    /// <summary>Logged when the server rejects the refresh and the user must sign in again; the argument is the user name.</summary>
    public const string LOG_REFRESH_REJECTED = "Session refresh was rejected by the server for user %s. The user must sign in again.";

    /// <summary>Logged when a refresh result is ignored because the session changed meanwhile; the argument is the user name.</summary>
    public const string LOG_REFRESH_STALE = "The session refresh result for user %s was ignored because the session changed while the request was running.";

    /// <summary>Logged when the retries start after a failed refresh; the argument is the wait before the first retry in seconds.</summary>
    public const string LOG_RECOVERY_STARTED = "Session refresh recovery started. First retry in %s seconds.";

    /// <summary>Logged before each retry; the argument is the attempt number.</summary>
    public const string LOG_RECOVERY_ATTEMPT = "Session refresh retry attempt %s.";

    /// <summary>Logged when a retry fails; the arguments are the attempt number, the wait before the next retry in seconds and the error.</summary>
    public const string LOG_RECOVERY_ATTEMPT_FAILED = "Session refresh retry attempt %s failed. Next retry in %s seconds. Reason: %s";

    /// <summary>Logged when the connection to the server is back after retrying; the arguments are the number of attempts and the user name.</summary>
    public const string LOG_RECOVERY_SUCCEEDED = "Connection to the server was restored after %s retry attempt(s) for user %s. Reloading the current view.";

    /// <summary>Logged when the network comes back and the refresh is retried at once.</summary>
    public const string LOG_NETWORK_AVAILABLE = "Network became available. Retrying the session refresh now.";

    /// <summary>Logged when the retries stop, for example after sign out or a successful refresh.</summary>
    public const string LOG_RECOVERY_STOPPED = "Session refresh recovery stopped.";

    /// <summary>Logged when a notification or an event handler of the refresh flow throws; the argument is the error.</summary>
    public const string LOG_CALLBACK_FAILED = "A session refresh notification or event handler failed: %s";

    /// <summary>Error text when the refreshed token belongs to another user; {0} is the token user and {1} the session user.</summary>
    public const string SESSION_USER_MISMATCH_MESSAGE = "Refreshed token belongs to user {0} but the session belongs to user {1}.";

    /// <summary>Error text when no refresh endpoint is set in the configuration.</summary>
    public const string REFRESH_ENDPOINT_MISSING_MESSAGE = "The session refresh endpoint is not configured (CertificateHandler:SessionRefresh:RefreshEndpoint).";

    /// <summary>Error text when the server rejects the refresh; {0} is the HTTP status code.</summary>
    public const string REFRESH_REJECTED_MESSAGE = "The server rejected the session refresh with status code {0}.";

    /// <summary>Error text when the server answers with an error; {0} is the HTTP status code.</summary>
    public const string REFRESH_SERVER_ERROR_MESSAGE = "The session refresh failed with status code {0}.";

    /// <summary>Error text when the refresh response holds no valid token.</summary>
    public const string REFRESH_RESPONSE_INVALID_MESSAGE = "The session refresh response did not contain a valid token.";

    /// <summary>Error text when the response has a success status but an empty body; {0} is the HTTP status code.</summary>
    public const string REFRESH_RESPONSE_EMPTY_MESSAGE = "The session refresh answered with status code {0} but no token in the response body.";

    #endregion

    #region Server And Session Log Texts

    /// <summary>Information: the refresh request is sent to the server; the argument is the endpoint.</summary>
    public const string LOG_SERVER_REQUEST_SENT = "Session refresh request sent to the server %s.";

    /// <summary>Information: the server answered; the arguments are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_ANSWERED = "The server %s answered the session refresh with status code %s.";

    /// <summary>Warning: the server refused the refresh; the arguments are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_REFUSED = "The server %s refused the session refresh with status code %s.";

    /// <summary>Error: the server returned an error; the arguments are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_ERROR = "The server %s returned an error for the session refresh, status code %s.";

    /// <summary>Error: the server could not be reached; the arguments are the endpoint and the error.</summary>
    public const string LOG_SERVER_UNREACHABLE = "The server %s could not be reached for the session refresh: %s";

    /// <summary>Warning: the server did not answer in time; the arguments are the endpoint and the timeout in seconds.</summary>
    public const string LOG_SERVER_TIMEOUT = "The server %s did not answer the session refresh within %s second(s).";

    /// <summary>Error: the server answer could not be read; the arguments are the endpoint and the error.</summary>
    public const string LOG_SERVER_INVALID_RESPONSE = "The session refresh answer from the server %s could not be read: %s";

    /// <summary>Error: no refresh endpoint is configured.</summary>
    public const string LOG_SERVER_ENDPOINT_MISSING = "No server address is configured for the session refresh.";

    /// <summary>Information: a session was started; the argument is the user name.</summary>
    public const string LOG_SESSION_STARTED = "Session started for user %s.";

    /// <summary>Information: the session tokens were replaced; the argument is the user name.</summary>
    public const string LOG_SESSION_TOKENS_REPLACED = "Session tokens renewed for user %s.";

    /// <summary>Information: the session was ended; the argument is the user name.</summary>
    public const string LOG_SESSION_ENDED = "Session ended for user %s.";

    /// <summary>Information: the network came back after the retry wait had already finished, so there was nothing to wake up.</summary>
    public const string LOG_RETRY_WAIT_ALREADY_FINISHED = "The network is back, but the session retry wait had already finished.";

    /// <summary>Information: the retry wait was ended early because the network is back.</summary>
    public const string LOG_RETRY_WAIT_ENDED_EARLY = "The session retry wait was ended early because the network is back.";

    /// <summary>Information: the automatic session refresh stopped because the application is closing or the user signed out.</summary>
    public const string LOG_AUTO_REFRESH_STOPPED = "Automatic session refresh stopped.";

    #endregion
}
