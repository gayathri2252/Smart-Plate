using System.Net;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Runtime options for the MAXUM Connection Manager (inbound listener + outbound connector).
/// </summary>
public sealed class MaxumConnectionManagerOptions
{
    #region Public Properties

    public bool ListenEnabled { get; init; } = true;

    public IPAddress BindAddress { get; init; } = IPAddress.Loopback;

    public int ListenPort { get; init; } = 8858;

    public int DefaultPeerPort { get; init; } = 8858;

    public string DeviceCertThumbprintSha256 { get; init; } = string.Empty;

    public StoreLocationName StoreLocation { get; init; } = StoreLocationName.LocalMachine;

    public int MaxConcurrentConnections { get; init; } = 32;

    public bool CheckCertificateRevocation { get; init; } = true;

    public TimeSpan ConnectTimeout { get; init; } = TimeSpan.FromSeconds(30);

    #endregion

    #region Public Methods

    public static MaxumConnectionManagerOptions FromEnvironment()
    {
        bool listenEnabled = !string.Equals(
            Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_LISTEN"),
            "0",
            StringComparison.Ordinal);

        string? portRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_PORT")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_PORT");
        int listenPort = 8858;
        if (!string.IsNullOrWhiteSpace(portRaw) && int.TryParse(portRaw, out int parsed) && parsed is > 0 and < 65536)
        {
            listenPort = parsed;
        }

        int defaultPeerPort = listenPort;
        string? peerPortRaw = Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_PEER_PORT");
        if (!string.IsNullOrWhiteSpace(peerPortRaw) && int.TryParse(peerPortRaw, out int peerPort) && peerPort is > 0 and < 65536)
        {
            defaultPeerPort = peerPort;
        }

        IPAddress bindAddress = IPAddress.Loopback;
        string? bind = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_BIND")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_BIND");
        if (string.Equals(bind, "any", StringComparison.OrdinalIgnoreCase))
        {
            bindAddress = IPAddress.Any;
        }
        else if (!string.IsNullOrWhiteSpace(bind)
                 && IPAddress.TryParse(bind.Trim(), out IPAddress? parsedBind)
                 && parsedBind is not null)
        {
            bindAddress = parsedBind;
        }

        string thumbprint = Environment.GetEnvironmentVariable("CH_DEVICE_CERT_THUMBPRINT")?.Trim()
            ?? Environment.GetEnvironmentVariable("CH_PEER_LISTENER_SERVER_THUMBPRINT")?.Trim()
            ?? string.Empty;

        StoreLocationName location = StoreLocationName.LocalMachine;
        string? locationRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_STORE_LOCATION")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_STORE_LOCATION");
        if (string.Equals(locationRaw, "CurrentUser", StringComparison.OrdinalIgnoreCase))
        {
            location = StoreLocationName.CurrentUser;
        }

        int maxConnections = 32;
        string? maxRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_MAX_CONNECTIONS")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_MAX_CONNECTIONS");
        if (!string.IsNullOrWhiteSpace(maxRaw) && int.TryParse(maxRaw, out int maxParsed) && maxParsed > 0)
        {
            maxConnections = Math.Min(maxParsed, 256);
        }

        bool checkRevocation = !string.Equals(
            Environment.GetEnvironmentVariable("CH_PEER_LISTENER_CHECK_REVOCATION")
                ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_CHECK_REVOCATION"),
            "0",
            StringComparison.Ordinal);

        int connectTimeoutSeconds = 30;
        string? timeoutRaw = Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_CONNECT_TIMEOUT_SEC");
        if (!string.IsNullOrWhiteSpace(timeoutRaw) && int.TryParse(timeoutRaw, out int seconds) && seconds > 0)
        {
            connectTimeoutSeconds = Math.Min(seconds, 300);
        }

        return new MaxumConnectionManagerOptions
        {
            ListenEnabled = listenEnabled,
            BindAddress = bindAddress,
            ListenPort = listenPort,
            DefaultPeerPort = defaultPeerPort,
            DeviceCertThumbprintSha256 = thumbprint,
            StoreLocation = location,
            MaxConcurrentConnections = maxConnections,
            CheckCertificateRevocation = checkRevocation,
            ConnectTimeout = TimeSpan.FromSeconds(connectTimeoutSeconds)
        };
    }

    /// <summary>Maps legacy dev listener env keys to connection manager options.</summary>
    public static MaxumConnectionManagerOptions FromLegacyDevListenerEnvironment() => FromEnvironment();

    #endregion
}
