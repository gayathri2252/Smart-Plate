using System.Net;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Legacy env keys for the peer listener; maps to <see cref="MaxumConnectionManagerOptions"/>.
/// </summary>
public sealed class DevPeerTlsListenerOptions
{
    #region Public Properties

    public IPAddress BindAddress { get; init; } = IPAddress.Loopback;

    public int Port { get; init; } = 8858;

    public string ServerThumbprintSha256 { get; init; } = string.Empty;

    public StoreLocationName StoreLocation { get; init; } = StoreLocationName.LocalMachine;

    public int MaxConcurrentConnections { get; init; } = 32;

    public bool CheckCertificateRevocation { get; init; }

    #endregion

    #region Public Methods

    public static DevPeerTlsListenerOptions FromEnvironment()
    {
        MaxumConnectionManagerOptions options = MaxumConnectionManagerOptions.FromEnvironment();
        return new DevPeerTlsListenerOptions
        {
            BindAddress = options.BindAddress,
            Port = options.ListenPort,
            ServerThumbprintSha256 = options.DeviceCertThumbprintSha256,
            StoreLocation = options.StoreLocation,
            MaxConcurrentConnections = options.MaxConcurrentConnections,
            CheckCertificateRevocation = options.CheckCertificateRevocation
        };
    }

    internal MaxumConnectionManagerOptions ToConnectionManagerOptions() =>
        new()
        {
            ListenEnabled = true,
            BindAddress = BindAddress,
            ListenPort = Port,
            DefaultPeerPort = Port,
            DeviceCertThumbprintSha256 = ServerThumbprintSha256,
            StoreLocation = StoreLocation,
            MaxConcurrentConnections = MaxConcurrentConnections,
            CheckCertificateRevocation = CheckCertificateRevocation
        };

    #endregion
}

public enum StoreLocationName
{
    LocalMachine,
    CurrentUser
}
