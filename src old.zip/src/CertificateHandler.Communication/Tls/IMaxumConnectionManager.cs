namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Coordinates inbound listener and outbound connector for MAXUM-to-MAXUM TLS (RS_11).
/// </summary>
public interface IMaxumConnectionManager : IDisposable
{
    bool IsListening { get; }

    void StartListener();

    void StopListener();

    Task<PeerTlsConnection?> ConnectToPeerAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default);
}
