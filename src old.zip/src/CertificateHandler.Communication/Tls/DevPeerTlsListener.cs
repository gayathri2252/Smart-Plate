using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Back-compat name for <see cref="PeerTlsListener"/> (dev / legacy CLI).
/// </summary>
public sealed class DevPeerTlsListener : IDisposable
{
    #region Member Variables

    private readonly PeerTlsListener _inner;

    #endregion

    #region Constructor

    public DevPeerTlsListener(
        IPeerConnectionPipeline pipeline,
        DevPeerTlsListenerOptions options,
        X509Certificate2 serverCertificate)
    {
        _inner = new PeerTlsListener(pipeline, options.ToConnectionManagerOptions(), serverCertificate);
    }

    #endregion

    #region Public Methods

    public void Start() => _inner.Start();

    public void Stop() => _inner.Stop();

    public void Dispose() => _inner.Dispose();

    #endregion
}
