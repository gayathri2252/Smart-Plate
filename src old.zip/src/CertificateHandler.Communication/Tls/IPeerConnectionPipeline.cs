using CertificateHandler.DeviceTrust.Models;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Trust gate entry point for inbound and outbound MAXUM TLS sessions.
/// </summary>
public interface IPeerConnectionPipeline
{
    Task<PeerConnectionPipelineResult> ProcessAsync(
        CertificateRequest request,
        string? correlationId,
        CancellationToken cancellationToken = default);
}
