using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Legacy loader; use <see cref="PeerTlsCertificateProvider"/>.
/// </summary>
public static class DevPeerTlsServerCertificateProvider
{
    public static X509Certificate2 Load(DevPeerTlsListenerOptions options) =>
        PeerTlsCertificateProvider.LoadDeviceCertificate(options.ToConnectionManagerOptions());

    public static X509Certificate2 Load(MaxumConnectionManagerOptions options) =>
        PeerTlsCertificateProvider.LoadDeviceCertificate(options);
}
