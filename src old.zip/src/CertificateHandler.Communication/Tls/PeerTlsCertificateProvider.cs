using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Security;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Loads the local device certificate (SBC/MIB) used for mutual TLS in the Connection Manager.
/// </summary>
public static class PeerTlsCertificateProvider
{
    #region Public Methods

    public static X509Certificate2 LoadDeviceCertificate(MaxumConnectionManagerOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        if (!ThumbprintNormalizer.TryNormalizeRequired(options.DeviceCertThumbprintSha256, out string thumbprint))
        {
            throw new InvalidOperationException(
                "CH_DEVICE_CERT_THUMBPRINT (or CH_PEER_LISTENER_SERVER_THUMBPRINT) must be a 64-character SHA-256 thumbprint.");
        }

        StoreLocation location = options.StoreLocation == StoreLocationName.CurrentUser
            ? StoreLocation.CurrentUser
            : StoreLocation.LocalMachine;

        using var store = new X509Store(StoreName.My, location);
        store.Open(OpenFlags.ReadOnly);

        foreach (X509Certificate2 candidate in store.Certificates)
        {
            try
            {
                string sha256 = candidate.GetCertHashString(HashAlgorithmName.SHA256);
                if (!ThumbprintNormalizer.TryNormalizeRequired(sha256, out string normalized))
                {
                    continue;
                }

                if (!string.Equals(normalized, thumbprint, StringComparison.Ordinal))
                {
                    continue;
                }

                if (!candidate.HasPrivateKey)
                {
                    throw new InvalidOperationException(
                        $"Certificate {thumbprint} in {location}\\My does not have an associated private key.");
                }

                return new X509Certificate2(candidate);
            }
            catch (CryptographicException)
            {
            }
        }

        throw new InvalidOperationException(
            $"No certificate with SHA-256 thumbprint {thumbprint} was found in {location}\\My.");
    }

    #endregion
}
