using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using PeerCertificateRequest = CertificateHandler.DeviceTrust.Models.CertificateRequest;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Runs an authenticated TLS session through <see cref="PeerConnectionPipeline"/> after mutual TLS completes.
/// </summary>
public static class PeerTlsSessionProcessor
{
    #region Public Methods

    public static async Task<PeerTlsGateOutcome> ProcessInboundAsync(
        SslStream sslStream,
        IPeerConnectionPipeline pipeline,
        string? remoteIp,
        string correlationId,
        bool sendStatusLine,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);
        ArgumentNullException.ThrowIfNull(pipeline);

        if (sslStream.RemoteCertificate is null)
        {
            return PeerTlsGateOutcome.Denied("No peer certificate presented.");
        }

        using var clientCertificate = new X509Certificate2(sslStream.RemoteCertificate);
        PeerCertificateRequest request = DevPeerTlsRequestFactory.FromClientCertificate(
            clientCertificate,
            remoteIp,
            sslStream.IsMutuallyAuthenticated);

        PeerConnectionPipelineResult result = await pipeline
            .ProcessAsync(request, correlationId, cancellationToken)
            .ConfigureAwait(false);

        if (sendStatusLine)
        {
            string line = result.TlsAllowed ? "CH-OK" : "CH-DENY";
            byte[] payload = Encoding.ASCII.GetBytes(line + "\r\n");
            await sslStream.WriteAsync(payload, cancellationToken).ConfigureAwait(false);
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Peer TLS gate %s from %s thumbprint %s decision %s tls=%s",
            correlationId,
            remoteIp ?? "?",
            request.Peer?.ThumbprintSha256 ?? "?",
            result.Authorization.Decision.ToString(),
            result.TlsAllowed.ToString());

        return new PeerTlsGateOutcome
        {
            Allowed = result.TlsAllowed,
            PipelineResult = result,
            ThumbprintSha256 = request.Peer?.ThumbprintSha256 ?? string.Empty
        };
    }

    public static async Task<PeerTlsGateOutcome> ProcessOutboundPeerAsync(
        SslStream sslStream,
        IPeerConnectionPipeline pipeline,
        string peerHost,
        string correlationId,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);
        ArgumentNullException.ThrowIfNull(pipeline);

        if (sslStream.RemoteCertificate is null)
        {
            return PeerTlsGateOutcome.Denied("No peer certificate in TLS handshake.");
        }

        using var peerCertificate = new X509Certificate2(sslStream.RemoteCertificate);
        PeerCertificateRequest request = DevPeerTlsRequestFactory.FromClientCertificate(
            peerCertificate,
            peerHost,
            sslStream.IsMutuallyAuthenticated);

        PeerConnectionPipelineResult result = await pipeline
            .ProcessAsync(request, correlationId, cancellationToken)
            .ConfigureAwait(false);

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Outbound peer TLS gate %s to %s thumbprint %s decision %s tls=%s",
            correlationId,
            peerHost,
            request.Peer?.ThumbprintSha256 ?? "?",
            result.Authorization.Decision.ToString(),
            result.TlsAllowed.ToString());

        return new PeerTlsGateOutcome
        {
            Allowed = result.TlsAllowed,
            PipelineResult = result,
            ThumbprintSha256 = request.Peer?.ThumbprintSha256 ?? string.Empty
        };
    }

    #endregion
}

public sealed class PeerTlsGateOutcome
{
    public bool Allowed { get; init; }

    public PeerConnectionPipelineResult? PipelineResult { get; init; }

    public string ThumbprintSha256 { get; init; } = string.Empty;

    public string? DenyReason { get; init; }

    public static PeerTlsGateOutcome Denied(string reason) =>
        new() { Allowed = false, DenyReason = reason };
}
