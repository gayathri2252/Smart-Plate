using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.DeviceTrust.Tls;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Applies admission, handshake suspension, and blacklist blocking at connection time (RS_11).
/// </summary>
public sealed class TlsConnectionManager
{
    #region Member Variables

    private readonly ConnectionAdmissionService _admission;

    private readonly ITlsHandshakeCoordinator _handshakes;

    #endregion

    #region Constructor

    public TlsConnectionManager(ConnectionAdmissionService admission, ITlsHandshakeCoordinator handshakes)
    {
        _admission = admission ?? throw new ArgumentNullException(nameof(admission));
        _handshakes = handshakes ?? throw new ArgumentNullException(nameof(handshakes));
    }

    #endregion

    #region Public Methods

    public async Task<bool> MayStartTlsAsync(string thumbprintSha256, string? correlationId, CancellationToken cancellationToken = default)
    {
        if (!await _admission.IsConnectionAllowedAsync(thumbprintSha256, cancellationToken))
        {
            return false;
        }

        if (!string.IsNullOrWhiteSpace(correlationId) && _handshakes.IsSuspended(correlationId))
        {
            return false;
        }

        return true;
    }

    public bool SuspendPendingHandshake(string correlationId, string thumbprintSha256) =>
        _handshakes.TrySuspend(correlationId, thumbprintSha256);

    #endregion
}
