using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Models;
namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Maps an authenticated TLS client certificate to a <see cref="CertificateRequest"/> for the peer pipeline.
/// </summary>
public static class DevPeerTlsRequestFactory
{
    #region Public Methods

    public static DeviceTrust.Models.CertificateRequest FromClientCertificate(
        X509Certificate2 clientCertificate,
        string? remoteIp,
        bool isMutuallyAuthenticated)
    {
        ArgumentNullException.ThrowIfNull(clientCertificate);

        string deviceCode = ResolveDeviceCode(clientCertificate);
        PeerOnboardingRequest peer = PeerOnboardingRequest.FromCertificate(clientCertificate, deviceCode, remoteIp);

        return new DeviceTrust.Models.CertificateRequest
        {
            Peer = peer,
            IsAuthenticated = isMutuallyAuthenticated,
            PresentedCertificateDer = clientCertificate.RawData
        };
    }

    #endregion

    #region Private Methods

    private static string ResolveDeviceCode(X509Certificate2 certificate)
    {
#if DEBUG
        string? fromEnv = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_DEVICE_CODE");
        if (!string.IsNullOrWhiteSpace(fromEnv))
        {
            return fromEnv.Trim();
        }
#endif

        string subject = certificate.Subject;
        const string prefix = "CN=";
        int index = subject.IndexOf(prefix, StringComparison.OrdinalIgnoreCase);
        if (index >= 0)
        {
            int start = index + prefix.Length;
            int comma = subject.IndexOf(',', start);
            string commonName = comma < 0 ? subject[start..] : subject[start..comma];
            if (!string.IsNullOrWhiteSpace(commonName))
            {
                return commonName.Trim();
            }
        }

        return certificate.GetCertHashString(HashAlgorithmName.SHA256)[..16];
    }

    #endregion
}
