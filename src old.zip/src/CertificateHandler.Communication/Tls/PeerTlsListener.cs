using System.Collections.Concurrent;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Inbound MAXUM TCP/TLS listener: mutual TLS 1.3 only, then trust gate via <see cref="PeerConnectionPipeline"/>.
/// </summary>
public sealed class PeerTlsListener : IDisposable
{
    #region Member Variables

    private readonly IPeerConnectionPipeline _pipeline;

    private readonly MaxumConnectionManagerOptions _options;

    private readonly X509Certificate2 _serverCertificate;

    private readonly SemaphoreSlim _connectionLimit;

    private readonly ConcurrentBag<Task> _connectionTasks = new();

    private readonly object _gate = new();

    private TcpListener? _listener;

    private CancellationTokenSource? _cts;

    private Task? _acceptLoop;

    #endregion

    #region Constructor

    public PeerTlsListener(
        IPeerConnectionPipeline pipeline,
        MaxumConnectionManagerOptions options,
        X509Certificate2 serverCertificate)
    {
        _pipeline = pipeline ?? throw new ArgumentNullException(nameof(pipeline));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _serverCertificate = serverCertificate ?? throw new ArgumentNullException(nameof(serverCertificate));
        _connectionLimit = new SemaphoreSlim(_options.MaxConcurrentConnections, _options.MaxConcurrentConnections);
    }

    #endregion

    #region Public Methods

    public void Start()
    {
        lock (_gate)
        {
            if (_listener is not null)
            {
                return;
            }

            _cts = new CancellationTokenSource();
            _listener = new TcpListener(_options.BindAddress, _options.ListenPort);
            _listener.Start();
            _acceptLoop = AcceptConnectionsAsync(_cts.Token);
        }

        CertificateHandlerLogger.Success(
            MessageIdGenerator.Next(),
            "Peer TLS listener started on %s.",
            $"{_options.BindAddress}:{_options.ListenPort}");
    }

    public void Stop()
    {
        lock (_gate)
        {
            _cts?.Cancel();
            _listener?.Stop();
        }

        try
        {
            _acceptLoop?.GetAwaiter().GetResult();
        }
        catch (OperationCanceledException)
        {
        }
        catch (AggregateException ex) when (ex.InnerException is OperationCanceledException)
        {
        }

        try
        {
            Task[] pending = _connectionTasks.Where(t => !t.IsCompleted).ToArray();
            if (pending.Length > 0)
            {
                Task.WaitAll(pending, TimeSpan.FromSeconds(30));
            }
        }
        catch (AggregateException)
        {
        }

        lock (_gate)
        {
            _acceptLoop = null;
            _listener = null;
            _cts?.Dispose();
            _cts = null;
        }
    }

    public void Dispose()
    {
        Stop();
        _connectionLimit.Dispose();
    }

    #endregion

    #region Private Methods

    private async Task AcceptConnectionsAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            TcpListener listener;
            lock (_gate)
            {
                listener = _listener!;
            }

            try
            {
                TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);
                if (!await _connectionLimit.WaitAsync(TimeSpan.FromSeconds(5), cancellationToken).ConfigureAwait(false))
                {
                    client.Dispose();
                    CertificateHandlerLogger.Warning(
                        MessageIdGenerator.Next(),
                        "Peer listener rejected connection (limit %s).",
                        _options.MaxConcurrentConnections.ToString());
                    continue;
                }

                Task handle = HandleClientAsync(client, cancellationToken);
                _connectionTasks.Add(handle);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (Exception ex)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Peer listener accept failed: %s",
                    ex.Message);
            }
        }
    }

    private async Task HandleClientAsync(TcpClient client, CancellationToken cancellationToken)
    {
        string? remoteIp = (client.Client.RemoteEndPoint as IPEndPoint)?.Address.ToString();
        string correlationId = Guid.NewGuid().ToString();

        try
        {
            using (client)
            await using (NetworkStream networkStream = client.GetStream())
            await using (var sslStream = new SslStream(networkStream, leaveInnerStreamOpen: false))
            {
                await Tls13ProtocolGuard.AuthenticateServerAsync(
                    sslStream,
                    _serverCertificate,
                    _options.CheckCertificateRevocation,
                    cancellationToken).ConfigureAwait(false);

                _ = await PeerTlsSessionProcessor.ProcessInboundAsync(
                    sslStream,
                    _pipeline,
                    remoteIp,
                    correlationId,
                    sendStatusLine: true,
                    cancellationToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (AuthenticationException ex)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Inbound peer TLS auth failed from %s: %s",
                remoteIp ?? "?",
                ex.Message);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Inbound peer connection %s failed: %s",
                correlationId,
                ex.Message);
        }
        finally
        {
            _connectionLimit.Release();
        }
    }

    #endregion
}
