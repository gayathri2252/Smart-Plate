using System.Net.Security;
using System.Net.Sockets;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// An outbound mutual-TLS session that passed the trust gate and may carry application data.
/// </summary>
public sealed class PeerTlsConnection : IAsyncDisposable
{
    #region Member Variables

    private readonly TcpClient _tcpClient;

    #endregion

    #region Constructor

    internal PeerTlsConnection(
        TcpClient tcpClient,
        SslStream sslStream,
        PeerTlsGateOutcome gateOutcome,
        string peerHost)
    {
        _tcpClient = tcpClient ?? throw new ArgumentNullException(nameof(tcpClient));
        Stream = sslStream ?? throw new ArgumentNullException(nameof(sslStream));
        GateOutcome = gateOutcome ?? throw new ArgumentNullException(nameof(gateOutcome));
        PeerHost = peerHost ?? throw new ArgumentNullException(nameof(peerHost));
    }

    #endregion

    #region Public Properties

    public SslStream Stream { get; }

    public PeerTlsGateOutcome GateOutcome { get; }

    public string PeerHost { get; }

    #endregion

    #region Public Methods

    public async ValueTask DisposeAsync()
    {
        await Stream.DisposeAsync().ConfigureAwait(false);
        _tcpClient.Dispose();
    }

    #endregion
}
