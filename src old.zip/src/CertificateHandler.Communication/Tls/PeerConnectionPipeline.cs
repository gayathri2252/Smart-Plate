using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.Shared.Trust;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Entry point for MAXUM listener: validate, authorize, and gate TLS (RS_03, RS_11).
/// </summary>
public sealed class PeerConnectionPipeline : IPeerConnectionPipeline
{
    #region Member Variables

    private readonly CertificateValidationEngine _validationEngine;

    private readonly CertificateRequestAuthorizationService _authorizationService;

    private readonly TlsConnectionManager _tlsConnectionManager;

    #endregion

    #region Constructor

    public PeerConnectionPipeline(
        CertificateValidationEngine validationEngine,
        CertificateRequestAuthorizationService authorizationService,
        TlsConnectionManager tlsConnectionManager)
    {
        _validationEngine = validationEngine ?? throw new ArgumentNullException(nameof(validationEngine));
        _authorizationService = authorizationService ?? throw new ArgumentNullException(nameof(authorizationService));
        _tlsConnectionManager = tlsConnectionManager ?? throw new ArgumentNullException(nameof(tlsConnectionManager));
    }

    #endregion

    #region Public Methods

    public async Task<PeerConnectionPipelineResult> ProcessAsync(
        CertificateRequest request,
        string? correlationId,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        string thumbprint = request.Peer?.ThumbprintSha256 ?? request.ValidationResult?.ThumbprintSha256 ?? string.Empty;
        TrustValidationResult validation = request.ValidationResult ?? await RunValidationAsync(request, thumbprint, cancellationToken);

        var enriched = new CertificateRequest
        {
            Peer = request.Peer,
            IsAuthenticated = request.IsAuthenticated,
            ValidationResult = validation,
            PresentedCertificateDer = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer
        };

        CertificateRequestAuthorizationResult auth = await _authorizationService.AuthorizeAsync(enriched, cancellationToken);
        bool tlsAllowed = await _tlsConnectionManager.MayStartTlsAsync(thumbprint, correlationId, cancellationToken);
        bool admitted = tlsAllowed && auth.Decision == CertificateRequestDecision.Allowed;
        if (admitted)
        {
            ProtectedServiceGate.Shared.Allow(thumbprint);
        }
        else if (!string.IsNullOrWhiteSpace(thumbprint))
        {
            ProtectedServiceGate.Shared.Deny(thumbprint);
        }

        return new PeerConnectionPipelineResult
        {
            Validation = validation,
            Authorization = auth,
            TlsAllowed = admitted && ProtectedServiceGate.Shared.IsAllowed(thumbprint)
        };
    }

    private Task<TrustValidationResult> RunValidationAsync(
        CertificateRequest request,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        byte[]? der = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer;
        if (der is { Length: > 0 })
        {
            return _validationEngine.ValidatePresentedCertificateAsync(der, expectedThumbprintSha256: thumbprint, deviceId: null, cancellationToken);
        }

        return _validationEngine.ValidateAsync(thumbprint, null, cancellationToken);
    }

    #endregion
}

public sealed class PeerConnectionPipelineResult
{
    public TrustValidationResult Validation { get; init; } = new();

    public CertificateRequestAuthorizationResult Authorization { get; init; } = new();

    public bool TlsAllowed { get; init; }
}
