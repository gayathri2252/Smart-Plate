using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// MAXUM Connection Manager: TCP listener + TLS connector wired to <see cref="PeerConnectionHostResources"/>.
/// </summary>
public sealed class MaxumConnectionManager : IMaxumConnectionManager
{
    #region Member Variables

    private readonly PeerConnectionHostResources _host;

    private readonly MaxumConnectionManagerOptions _options;

    private readonly X509Certificate2 _deviceCertificate;

    private PeerTlsListener? _listener;

    private PeerTlsConnector? _connector;

    private bool _disposed;

    #endregion

    #region Constructor

    public MaxumConnectionManager(
        PeerConnectionHostResources host,
        MaxumConnectionManagerOptions options,
        X509Certificate2 deviceCertificate)
    {
        _host = host ?? throw new ArgumentNullException(nameof(host));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _deviceCertificate = deviceCertificate ?? throw new ArgumentNullException(nameof(deviceCertificate));
        _connector = new PeerTlsConnector(_host.Pipeline, _options, _deviceCertificate);
    }

    public static MaxumConnectionManager Create(
        PeerConnectionHostResources host,
        MaxumConnectionManagerOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(host);
        MaxumConnectionManagerOptions resolved = options ?? MaxumConnectionManagerOptions.FromEnvironment();
        X509Certificate2 certificate = PeerTlsCertificateProvider.LoadDeviceCertificate(resolved);
        return new MaxumConnectionManager(host, resolved, certificate);
    }

    #endregion

    #region Public Properties

    public bool IsListening => _listener is not null;

    #endregion

    #region Public Methods

    public void StartListener()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        _host.StartBlacklistReceiver();

        if (!_options.ListenEnabled)
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                "Connection Manager listener disabled (CH_CONNECTION_MANAGER_LISTEN=0).");
            return;
        }

        if (_listener is not null)
        {
            return;
        }

        _listener = new PeerTlsListener(_host.Pipeline, _options, _deviceCertificate);
        _listener.Start();
    }

    public void StopListener()
    {
        _listener?.Dispose();
        _listener = null;
        _host.StopBlacklistReceiver();
    }

    public Task<PeerTlsConnection?> ConnectToPeerAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        PeerTlsConnector connector = _connector ?? throw new InvalidOperationException("Connector is not available.");
        return connector.ConnectAsync(host, port, cancellationToken);
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        StopListener();
        _connector = null;
        _deviceCertificate.Dispose();
        _disposed = true;
    }

    #endregion
}
