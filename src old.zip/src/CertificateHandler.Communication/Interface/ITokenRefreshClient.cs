﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Communication.Session;

namespace CertificateHandler.Communication.Interface;

/// <summary>
/// Calls the service that exchanges a refresh token for a new access token.
/// </summary>
public interface ITokenRefreshClient
{
    /// <summary>
    /// Requests new tokens for the given session.
    /// Throws SessionRejectedException when the server refuses the refresh,
    /// and a network exception (HttpRequestException, SocketException, timeout) when the server cannot be reached.
    /// </summary>
    Task<SessionToken> RefreshAsync(SessionToken current, CancellationToken cancellationToken);
}
