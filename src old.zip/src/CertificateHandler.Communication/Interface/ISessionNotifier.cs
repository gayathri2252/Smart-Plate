﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Interface;

/// <summary>
/// Shows session refresh notifications to the user. The UI layer provides the implementation.
/// </summary>
public interface ISessionNotifier
{
    /// <summary>
    /// Shows that the refresh failed because the network was lost and the session is kept.
    /// </summary>
    void NotifyRefreshFailed(string message);

    /// <summary>
    /// Shows that the refresh succeeded after the network came back.
    /// </summary>
    void NotifyRefreshRecovered(string message);
}
