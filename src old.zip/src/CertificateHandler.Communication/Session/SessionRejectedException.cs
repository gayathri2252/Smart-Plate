﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Thrown when the server answers the refresh call and refuses it (for example 401 or 403).
/// Only this failure ends the session and sends the user to the login page.
/// </summary>
public sealed class SessionRejectedException : Exception
{
    #region Constructor

    /// <summary>
    /// Creates the exception with the reason returned by the server.
    /// </summary>
    public SessionRejectedException(string message) : base(message)
    {
    }

    #endregion
}
