﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Holds the tokens of the signed-in user and the time the access token expires.
/// </summary>
/// <param name="UserName">Name of the signed-in user.</param>
/// <param name="AccessToken">Token sent with service calls.</param>
/// <param name="RefreshToken">Token used to get a new access token.</param>
/// <param name="ExpiresAtUtc">UTC time when the access token expires.</param>
public sealed record SessionToken(string UserName,string AccessToken,string RefreshToken,DateTimeOffset ExpiresAtUtc);
