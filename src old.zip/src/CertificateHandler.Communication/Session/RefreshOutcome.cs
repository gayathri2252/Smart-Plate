﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Result of one session refresh request.
/// </summary>
public enum RefreshOutcome
{
    /// <summary>The tokens were refreshed.</summary>
    Succeeded,

    /// <summary>The network was lost; the session is kept and recovery has started.</summary>
    NetworkFailure,

    /// <summary>A recovery is already running; this request was not sent.</summary>
    RecoveryInProgress,

    /// <summary>The server refused the refresh; the session has ended.</summary>
    SessionRejected,

    /// <summary>An unexpected error occurred; the session is kept.</summary>
    Failed,

    /// <summary>No user is signed in.</summary>
    NoSession,

    /// <summary>The user signed out or signed in again while the request ran; the result was ignored.</summary>
    SessionChanged
}
