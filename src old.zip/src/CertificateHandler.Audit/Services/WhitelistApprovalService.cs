﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Audit.Models;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Audit.Constants;
using CertificateHandler.Logger;

namespace CertificateHandler.Audit.Services;

/// <summary>
/// Handles whitelist approval and rejection actions and creates
/// corresponding audit log entries.
/// </summary>
public class WhitelistApprovalService
{
    #region Member Variables

    /// <summary>
    /// Service used to create and retrieve audit logs.
    /// </summary>
    private readonly AuditLogService _auditLogService;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes the whitelist approval service.
    /// </summary>
    public WhitelistApprovalService()
    {
        _auditLogService = new AuditLogService();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates an audit log entry for an approved whitelist request.
    /// </summary>
    /// <param name="decision">Request, device, certificate and approver details.</param>
    public void ApproveRequest(WhitelistDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);

        try
        {
            _auditLogService.CreateAuditLog(new AuditLog
            {
                AuditId = decision.AuditId,
                RequestId = decision.RequestId,
                DeviceId = decision.DeviceId,
                DeviceName = decision.DeviceName,
                CertificateThumbprint = decision.Thumbprint,
                ApproverName = decision.ApproverName,
                Reason = decision.Reason,
                ActionType = RequestStatusConstants.WHITELIST_APPROVAL,
                CertificateSubject = decision.CertificateSubject,
                ActionStatus = RequestStatusConstants.APPROVED,
                Comments = RequestStatusConstants.REQUEST_APPROVED
            });

            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), AuditServiceLogConstants.WHITELIST_APPROVED, decision.RequestId, decision.DeviceName, decision.ApproverName);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), AuditServiceLogConstants.WHITELIST_DECISION_FAILED, AuditServiceLogConstants.DECISION_APPROVAL, decision.RequestId, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Creates an audit log entry for a rejected whitelist request.
    /// </summary>
    /// <param name="decision">Request, device, certificate and approver details.</param>
    public void RejectRequest(WhitelistDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);

        try
        {
            _auditLogService.CreateAuditLog(new AuditLog
            {
                AuditId = decision.AuditId,
                RequestId = decision.RequestId,
                DeviceId = decision.DeviceId,
                DeviceName = decision.DeviceName,
                CertificateThumbprint = decision.Thumbprint,
                ApproverName = decision.ApproverName,
                Reason = decision.Reason,
                ActionType = RequestStatusConstants.WHITELIST_REJECTION,
                CertificateSubject = decision.CertificateSubject,
                ActionStatus = RequestStatusConstants.REJECTED,
                Comments = RequestStatusConstants.REQUEST_REJECTED
            });

            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), AuditServiceLogConstants.WHITELIST_REJECTED, decision.RequestId, decision.DeviceName, decision.ApproverName);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), AuditServiceLogConstants.WHITELIST_DECISION_FAILED, AuditServiceLogConstants.DECISION_REJECTION, decision.RequestId, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Retrieves audit history for whitelist actions.
    /// </summary>
    /// <returns>
    /// Collection of audit log records.
    /// </returns>
    public IEnumerable<AuditLog> GetAuditHistory()
    {
        return _auditLogService.GetAuditHistory();
    }

    #endregion
}