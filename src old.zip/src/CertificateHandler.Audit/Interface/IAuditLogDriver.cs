// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Audit.Interface;
/// <summary>
/// Defines operations for audit log storage and retrieval.
/// </summary>
public interface IAuditLogDriver
{
    /// <summary>
    /// Writes an audit log entry.
    /// </summary>
    /// <param name="message">
    /// Audit log message to store.
    /// </param>
    void WriteLog(string message);

    /// <summary>
    /// Reads all audit log entries.
    /// </summary>
    /// <returns>
    /// Collection of log records.
    /// </returns>
    IEnumerable<string> ReadLogs();
}