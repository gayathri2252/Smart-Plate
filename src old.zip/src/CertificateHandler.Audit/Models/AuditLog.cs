// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Audit.Models;

/// <summary>
/// Represents an audit record for whitelist approval and rejection actions.
/// </summary>
public class AuditLog
{
    #region Public Properties

    /// <summary>
    /// Unique identifier of the audit record.
    /// </summary>
    public int AuditId { get; set; }

    /// <summary>
    /// Identifier of the associated request.
    /// </summary>
    public string? RequestId { get; set; }

    /// <summary>
    /// Identifier of the device.
    /// </summary>
    public string DeviceId { get; set; } = string.Empty;

    /// <summary>
    /// Name of the device.
    /// </summary>
    public string? DeviceName { get; set; } = string.Empty;

    /// <summary>
    /// Thumbprint of the certificate.
    /// </summary>
    public string? CertificateThumbprint { get; set; } = string.Empty;

    /// <summary>
    /// Name of the approver.
    /// </summary>
    public string? ApproverName { get; set; } = string.Empty;

    /// <summary>
    /// Timestamp of the performed action.
    /// </summary>
    public DateTime ActionTimestamp { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Reason associated with the action.
    /// </summary>
    public string Reason { get; set; } = string.Empty;

    /// <summary>
    /// Type of action performed.
    /// </summary>
    public string ActionType { get; set; } = string.Empty;

    /// <summary>
    /// Status of the action.
    /// </summary>
    public string ActionStatus { get; set; } = string.Empty;

    /// <summary>
    /// Subject information of the certificate.
    /// </summary>
    public string CertificateSubject { get; set; } = string.Empty;

    /// <summary>
    /// Additional comments related to the audit record.
    /// </summary>
    public string Comments { get; set; } = string.Empty;

    #endregion
}