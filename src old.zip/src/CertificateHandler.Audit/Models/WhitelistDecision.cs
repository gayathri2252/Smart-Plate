﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Audit.Models;

/// <summary>
/// Details of a whitelist request that an administrator approves or rejects.
/// Passed as one object so the approve and reject methods do not need a long parameter list.
/// </summary>
public class WhitelistDecision
{
    #region Public Properties

    /// <summary>
    /// Identifier of the audit record.
    /// </summary>
    public int AuditId { get; set; }

    /// <summary>
    /// Identifier of the whitelist request.
    /// </summary>
    public string RequestId { get; set; } = string.Empty;

    /// <summary>
    /// Identifier of the device.
    /// </summary>
    public string DeviceId { get; set; } = string.Empty;

    /// <summary>
    /// Name of the device.
    /// </summary>
    public string DeviceName { get; set; } = string.Empty;

    /// <summary>
    /// Thumbprint of the device certificate.
    /// </summary>
    public string Thumbprint { get; set; } = string.Empty;

    /// <summary>
    /// Subject of the device certificate.
    /// </summary>
    public string CertificateSubject { get; set; } = string.Empty;

    /// <summary>
    /// Name of the administrator who made the decision.
    /// </summary>
    public string ApproverName { get; set; } = string.Empty;

    /// <summary>
    /// Reason given for the decision.
    /// </summary>
    public string Reason { get; set; } = string.Empty;

    #endregion
}
