namespace CertificateHandler.Shared.Constants;

/// <summary>
/// How a whitelist row was created. MCC actions are allowed only after an HMI_LOCAL workstation whitelist.
/// </summary>
public static class TrustApprovalChannels
{
    public const string HmiLocal = "HMI_LOCAL";

    public const string Mcc = "MCC";

    public const string MaxumAuto = "MAXUM_AUTO";
}
