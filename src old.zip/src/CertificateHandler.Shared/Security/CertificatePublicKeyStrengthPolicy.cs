using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Shared.Security;

/// <summary>
/// RS_03 minimum public key strength for X.509 certificates.
/// </summary>
public static class CertificatePublicKeyStrengthPolicy
{
    public const int MinimumRsaKeyBits = 2048;

    public const int MinimumEcdsaKeyBits = 256;

    public static void ValidateOrThrow(X509Certificate2 certificate)
    {
        ArgumentNullException.ThrowIfNull(certificate);

        using RSA? rsa = certificate.GetRSAPublicKey();
        if (rsa is not null)
        {
            EnsureRsa(rsa.KeySize);
            return;
        }

        using ECDsa? ecdsa = certificate.GetECDsaPublicKey();
        if (ecdsa is not null)
        {
            EnsureEcdsa(ecdsa.KeySize);
            return;
        }

        throw new ArgumentException("Unsupported public key algorithm.");
    }

    private static void EnsureRsa(int keyBits)
    {
        if (keyBits < MinimumRsaKeyBits)
        {
            throw new ArgumentException($"RSA key must be at least {MinimumRsaKeyBits} bits.");
        }
    }

    private static void EnsureEcdsa(int keyBits)
    {
        if (keyBits < MinimumEcdsaKeyBits)
        {
            throw new ArgumentException($"ECDSA key must be at least {MinimumEcdsaKeyBits} bits.");
        }
    }
}
