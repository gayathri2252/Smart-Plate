// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// How the trust engine's validation of one certificate ended.
/// </summary>
public enum TrustValidationOutcome
{
    /// <summary>
    /// All checks passed.
    /// </summary>
    Passed = 0,

    /// <summary>
    /// The signature is not valid. Blacklists the thumbprint.
    /// </summary>
    BadSignature = 1,

    /// <summary>
    /// The certificate is revoked. Blacklists the thumbprint.
    /// </summary>
    Revoked = 2,

    /// <summary>
    /// The chain to a trusted root is broken. Blacklists the thumbprint.
    /// </summary>
    BrokenChain = 3,

    /// <summary>
    /// A security incident was raised for the certificate. Blacklists the thumbprint.
    /// </summary>
    SecurityIncident = 4,

    /// <summary>
    /// The certificate has expired. Does not blacklist.
    /// </summary>
    Expired = 5,

    /// <summary>
    /// The certificate is not valid yet. Does not blacklist.
    /// </summary>
    NotYetValid = 6,

    /// <summary>
    /// The time could not be verified, so validity could not be judged. Does not blacklist.
    /// </summary>
    TimeUnverified = 7
}
