// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// What the trust engine reports when it finishes validating a certificate.
/// </summary>
public sealed class TrustValidationResult
{
    #region Public Properties

    /// <summary>
    /// SHA-256 thumbprint of the validated certificate.
    /// </summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>
    /// How the validation ended.
    /// </summary>
    public TrustValidationOutcome Outcome { get; set; }

    /// <summary>
    /// Readable detail of the failure; used as the reason in the audit row.
    /// </summary>
    public string FailureReason { get; set; } = string.Empty;

    /// <summary>
    /// When the trust engine finished (UTC).
    /// </summary>
    public DateTimeOffset EvaluatedAt { get; set; } = DateTimeOffset.UtcNow;

    #endregion
}
