// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models;

/// <summary>
/// Public key details extracted from a certificate. Never holds
/// private key material.
/// </summary>
public sealed class CertificatePublicKeyInfo
{
    #region Public Properties

    /// <summary>
    /// Key algorithm, e.g. "RSA" or "ECDSA".
    /// </summary>
    public string Algorithm { get; set; } = string.Empty;

    /// <summary>
    /// Key size in bits, e.g. 2048 for a typical RSA key. Reflects
    /// cryptographic strength, not the byte length of KeyData.
    /// </summary>
    public int KeyBits { get; set; }

    /// <summary>
    /// Raw public key bytes (the RSA modulus, or the raw EC/other
    /// public key encoding). Public key material only — never a
    /// private key.
    /// </summary>
    public byte[] KeyData { get; set; } = Array.Empty<byte>();

    #endregion
}
