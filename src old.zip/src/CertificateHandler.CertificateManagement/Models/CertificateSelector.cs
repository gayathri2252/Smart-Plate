// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Input parameters for locating a single certificate: thumbprint,
/// device, and which Windows store location/name to search.
/// </summary>
public sealed class CertificateSelector
{
    #region Public Properties

    public string Thumbprint { get; set; } = string.Empty;

    public DeviceScope DeviceScope { get; set; }

    public WindowsStoreLocation StoreScope { get; set; }

    // Added: previously WindowsCertificateStoreConfiguration.StoreName
    // existed as a model but was never consulted — the adapter always
    // searched "My" regardless. This makes store name selectable per call.
    public WindowsStoreName StoreName { get; set; } = WindowsStoreName.My;

    #endregion
}
