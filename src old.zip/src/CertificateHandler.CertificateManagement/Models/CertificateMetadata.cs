// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Metadata extracted from a single X.509 certificate, returned by the
/// certificate store adapters. Never carries private key material.
/// </summary>
public sealed class CertificateMetadata
{
    #region Public Properties

    public string Thumbprint { get; set; } = string.Empty;

    // Added: previously CreateMetadata() accepted a DeviceScope parameter
    // but had nowhere to store it, so it was silently discarded. Now it's
    // actually recorded on the metadata.
    public DeviceScope Owner { get; set; }

    public string Subject { get; set; } = string.Empty;

    public string Issuer { get; set; } = string.Empty;

    public string SerialNumber { get; set; } = string.Empty;

    public DateTime ValidFromUtc { get; set; }

    public DateTime ValidToUtc { get; set; }

    public CertificatePublicKeyInfo PublicKey { get; set; } = new();

    public bool HasPrivateKey { get; set; }

    public bool IsTpmBound { get; set; }

    #endregion

}
