// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Physical/logical medium where a certificate's private key is stored.
/// </summary>
public enum CertificateStorageMedium
{
    WindowsCertificateStore = 1,
    TPM = 2
}
