// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Outcome of a certificate lookup operation. Describes how the lookup
/// itself went, not the certificate's own validity or trust status.
/// </summary>
public enum CertLookupStatus
{
    Found = 1,
    CertificateNotFound = 2,
    MultipleMatches = 3,
    AccessDenied = 4,
    InvalidCertificate = 5,
    StoreUnavailable = 6,
    TPMUnavailable = 7,
    UnknownError = 99
}
