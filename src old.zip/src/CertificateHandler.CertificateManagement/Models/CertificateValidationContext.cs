// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// What every validation step receives: the raw certificate bytes (DER)
/// and, optionally, the public key of the issuer.
/// </summary>
public sealed class CertificateValidationContext
{
    #region Constructor

    /// <summary>
    /// Creates a context for one certificate.
    /// </summary>
    /// <param name="rawCertificate">The certificate exactly as received (DER).</param>
    /// <param name="issuerPublicKeyInfo">
    /// SubjectPublicKeyInfo (DER) of the issuer. Leave null for a self-signed certificate;
    /// the certificate's own public key is then used.
    /// </param>
    public CertificateValidationContext(byte[] rawCertificate, byte[]? issuerPublicKeyInfo = null)
    {
        RawCertificate = rawCertificate;
        IssuerPublicKeyInfo = issuerPublicKeyInfo;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// The certificate exactly as received (DER).
    /// </summary>
    public byte[] RawCertificate { get; }

    /// <summary>
    /// SubjectPublicKeyInfo (DER) of the issuer, or null to use the certificate's own key.
    /// </summary>
    public byte[]? IssuerPublicKeyInfo { get; }

    #endregion
}
