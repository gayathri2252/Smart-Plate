// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Result of a certificate chain lookup: leaf, intermediates, root,
/// and a status/error pair. Carries chain data only, no trust decision.
/// </summary>
public sealed class CertificateChainInfo
{
    #region Public Properties

    public CertLookupStatus Status { get; set; }

    public string ErrorDetail { get; set; } = string.Empty;

    public CertificateMetadata? LeafCertificate { get; set; }

    public List<CertificateMetadata> IntermediateCertificates { get; set; } = new();

    public CertificateMetadata? RootCertificate { get; set; }

    #endregion
}
