﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Constants;

/// <summary>
/// Constants for the audit rows written when an administrator approves or rejects a pending request.
/// </summary>
public static class PendingRequestAuditConstants
{
    #region Member Variables

    /// <summary>Event type of the audit row of an approval.</summary>
    public const string EVENT_APPROVED = "PENDING_REQUEST_APPROVED";

    /// <summary>Event type of the audit row of a rejection.</summary>
    public const string EVENT_REJECTED = "PENDING_REQUEST_REJECTED";

    /// <summary>Status the request had before the decision.</summary>
    public const string STATUS_PENDING = "PENDING";

    /// <summary>Status of an approved request.</summary>
    public const string STATUS_APPROVED = "APPROVED";

    /// <summary>Status of a rejected request.</summary>
    public const string STATUS_REJECTED = "REJECTED";

    /// <summary>Result of a decision that worked.</summary>
    public const string RESULT_SUCCESS = "SUCCESS";

    /// <summary>Result of a decision that failed.</summary>
    public const string RESULT_FAILURE = "FAILURE";

    /// <summary>Actor stored when nobody is logged in.</summary>
    public const string UNKNOWN_ACTOR = "Unknown";

    /// <summary>Component name stored in the audit row.</summary>
    public const string SOURCE_COMPONENT = "PendingRequestQueue";

    /// <summary>Longest error text stored in the audit row.</summary>
    public const int MAX_REASON_LENGTH = 500;

    /// <summary>Logged when the wrapper is created without the inner service.</summary>
    public const string INNER_SERVICE_IS_NULL = "The audited queue service cannot be created because no queue service was given.";

    /// <summary>Logged when the wrapper is created without an audit writer.</summary>
    public const string AUDIT_WRITER_IS_NULL = "The audited queue service cannot be created because no audit writer was given.";

    /// <summary>Logged when the audit writer is created without a database connection.</summary>
    public const string DATA_SOURCE_IS_NULL = "The pending request audit writer cannot be created because no database connection was given.";

    /// <summary>Logged when a request id is empty; the argument is the administrator.</summary>
    public const string REQUEST_ID_MISSING = "Administrator %s tried to decide a request without a request id.";

    /// <summary>Logged when an approval starts; the arguments are the administrator and the request id.</summary>
    public const string APPROVE_STARTED = "Administrator %s is approving request %s.";

    /// <summary>Logged when an approval worked; the arguments are the request id and the administrator.</summary>
    public const string APPROVE_SUCCEEDED = "Request %s was approved by administrator %s.";

    /// <summary>Logged when an approval failed; the arguments are the request id and the error.</summary>
    public const string APPROVE_FAILED = "Approving request %s failed: %s";

    /// <summary>Logged when a rejection starts; the arguments are the administrator and the request id.</summary>
    public const string REJECT_STARTED = "Administrator %s is rejecting request %s.";

    /// <summary>Logged when a rejection worked; the arguments are the request id and the administrator.</summary>
    public const string REJECT_SUCCEEDED = "Request %s was rejected by administrator %s.";

    /// <summary>Logged when a rejection failed; the arguments are the request id and the error.</summary>
    public const string REJECT_FAILED = "Rejecting request %s failed: %s";

    /// <summary>Logged when the audit row was written; the arguments are the event type and the request id.</summary>
    public const string AUDIT_WRITTEN = "Audit row %s was written for request %s.";

    /// <summary>Logged when no audit row could be written because the request does not exist; the argument is the request id.</summary>
    public const string AUDIT_REQUEST_NOT_FOUND = "No audit row was written because request %s was not found.";

    /// <summary>Logged when the audit row could not be written; the arguments are the request id and the error.</summary>
    public const string AUDIT_FAILED = "The audit row for request %s could not be written: %s";

    /// <summary>Logged when the name of the logged-in administrator cannot be read; the argument is the error. Unknown is used instead.</summary>
    public const string ACTOR_LOOKUP_FAILED = "The logged-in administrator could not be determined, so Unknown is used: %s";

    /// <summary>Message of the exception thrown when a decision is made without a request id.</summary>
    public const string REQUEST_ID_REQUIRED = "A request id is required.";

    /// <summary>SQL parameter of the audit insert: the event type.</summary>
    public const string PARAM_EVENT_TYPE = "eventType";

    /// <summary>SQL parameter of the audit insert: the user who made the decision.</summary>
    public const string PARAM_ACTOR = "actor";

    /// <summary>SQL parameter of the audit insert: the status before the decision.</summary>
    public const string PARAM_PREVIOUS_STATUS = "previousStatus";

    /// <summary>SQL parameter of the audit insert: the status after the decision.</summary>
    public const string PARAM_NEW_STATUS = "newStatus";

    /// <summary>SQL parameter of the audit insert: the reason for the decision.</summary>
    public const string PARAM_REASON = "reason";

    /// <summary>SQL parameter of the audit insert: the result of the action.</summary>
    public const string PARAM_RESULT = "result";

    /// <summary>SQL parameter of the audit insert: the component that wrote the row.</summary>
    public const string PARAM_SOURCE = "source";

    /// <summary>SQL parameter of the audit insert: the pending request id.</summary>
    public const string PARAM_REQUEST_ID = "requestId";

    #endregion
}
