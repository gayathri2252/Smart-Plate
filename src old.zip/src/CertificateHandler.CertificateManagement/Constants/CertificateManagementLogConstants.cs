﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Constants;

/// <summary>
/// Texts written to the Log Monitor by certificate management: the Request Queue data and the local
/// certificate store. %s is filled in by the logger, in the given order.
/// </summary>
public static class CertificateManagementLogConstants
{
    #region Request Queue

    /// <summary>Information: the Request Queue was loaded; the argument is the number of pending requests.</summary>
    public const string QUEUE_LOADED = "Request Queue loaded from the database: %s pending request(s).";

    /// <summary>Error: the Request Queue could not be loaded; the argument is the error.</summary>
    public const string QUEUE_LOAD_FAILED = "The Request Queue could not be loaded from the database: %s";

    /// <summary>Success: the request was set to Approved in the database; the argument is the request id.</summary>
    public const string REQUEST_APPROVED_SAVED = "Pending request %s was saved as Approved in the database.";

    /// <summary>Success: the request was set to Rejected in the database; the argument is the request id.</summary>
    public const string REQUEST_REJECTED_SAVED = "Pending request %s was saved as Rejected in the database.";

    /// <summary>Warning: no request with that id was found to update; the arguments are the request id and the decision.</summary>
    public const string REQUEST_NOT_FOUND_FOR_DECISION = "Pending request %s was not found in the database, so it could not be set to %s.";

    /// <summary>Error: the decision could not be saved; the arguments are the decision, the request id and the error.</summary>
    public const string REQUEST_DECISION_SAVE_FAILED = "The decision %s for pending request %s could not be saved in the database: %s";

    /// <summary>Decision name for the approve action.</summary>
    public const string DECISION_APPROVED = "Approved";

    /// <summary>Decision name for the reject action.</summary>
    public const string DECISION_REJECTED = "Rejected";

    #endregion

    #region Local Certificate Store

    /// <summary>Information: a local certificate was found; the arguments are the thumbprint and the store backend.</summary>
    public const string LOCAL_CERTIFICATE_FOUND = "Local certificate %s was found in the %s.";

    /// <summary>Warning: a local certificate lookup did not find a single certificate; the arguments are the thumbprint, the status and the detail.</summary>
    public const string LOCAL_CERTIFICATE_NOT_FOUND = "Local certificate %s could not be read (%s): %s";

    /// <summary>Error: the store adapter gave no result.</summary>
    public const string LOCAL_CERTIFICATE_NO_RESULT = "The certificate store returned no result for the certificate lookup.";

    /// <summary>Error: the certificate store could not be opened or read; the arguments are the operation and the error.</summary>
    public const string CERTIFICATE_STORE_FAILED = "The Windows certificate store could not be read during %s: %s";

    /// <summary>Warning: one certificate in the store could not be read; the arguments are the thumbprint and the error.</summary>
    public const string CERTIFICATE_MAPPING_FAILED = "Certificate %s in the Windows certificate store could not be read: %s";

    /// <summary>Information: the store was listed; the arguments are the number of certificates and the store location.</summary>
    public const string CERTIFICATE_STORE_LISTED = "%s certificate(s) were listed from the Windows certificate store (%s).";

    /// <summary>Information: a certificate chain was built; the arguments are the thumbprint and whether it is complete.</summary>
    public const string CERTIFICATE_CHAIN_BUILT = "Certificate chain built for %s: complete = %s.";

    /// <summary>Warning: the TPM store is not available yet; the argument is the operation.</summary>
    public const string TPM_NOT_AVAILABLE = "The TPM certificate store is not available yet (%s).";

    /// <summary>Error: an unsupported certificate store was configured; the argument is the backend.</summary>
    public const string UNSUPPORTED_BACKEND = "The configured certificate store %s is not supported.";

    /// <summary>Operation name: reading one certificate.</summary>
    public const string OPERATION_GET_CERTIFICATE = "reading a certificate";

    /// <summary>Operation name: listing certificates.</summary>
    public const string OPERATION_LIST_CERTIFICATES = "listing the certificates";

    /// <summary>Operation name: building a chain.</summary>
    public const string OPERATION_GET_CHAIN = "building a certificate chain";

    #endregion

    #region Certificate Validation

    /// <summary>Success: the certificate passed all validation steps; the argument is the thumbprint.</summary>
    public const string CERTIFICATE_VALIDATION_PASSED = "Certificate %s passed validation.";

    /// <summary>Warning: the certificate failed a validation step; the arguments are the thumbprint, the step, the outcome and the reason.</summary>
    public const string CERTIFICATE_VALIDATION_FAILED = "Certificate %s failed validation at step %s: %s (%s).";

    #endregion
}
