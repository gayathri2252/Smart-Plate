namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Dev bridge: treat TPM store as Windows store when hardware TPM is unavailable (RS_04).
/// </summary>
public static class SimulatedTpmStoreBridge
{
    public static bool IsEnabled =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SIMULATE_TPM");
}
