﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Interfaces;
using DashboardCH.Models;
using DashboardCH.Models.Enums;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.CertificateManagement.Constants;

namespace DashboardCH.Services;

/// <summary>
/// Resolves the configured adapter and delegates a certificate lookup
/// to it, logging non-success outcomes.
/// </summary>
public sealed class CertificateHandlerService
{
    #region Member Variables

    private readonly ICertificateStoreAdapterFactory _factory;

    #endregion

    #region Constructor

    public CertificateHandlerService(
        ICertificateStoreAdapterFactory factory)
    {
        _factory = factory;
    }

    #endregion

    #region Public Methods

    public CertificateResult HandleGetCertificateRequest(
        CertificateStorageMedium configuredBackend,
        CertificateSelector selector)
    {
        ICertificateStoreAdapter adapter = _factory.Create(configuredBackend);

        CertificateResult? result = adapter.GetLocalCertificate(selector);

        if (result is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.LOCAL_CERTIFICATE_NO_RESULT);

            return new CertificateResult
            {
                Status = CertLookupStatus.UnknownError,
                ErrorDetail = CertificateManagementLogConstants.LOCAL_CERTIFICATE_NO_RESULT
            };
        }

        if (result.Status is not CertLookupStatus.Found)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                CertificateManagementLogConstants.LOCAL_CERTIFICATE_NOT_FOUND,
                selector?.Thumbprint ?? string.Empty,
                result.Status.ToString(),
                result.ErrorDetail ?? string.Empty);
        }
        else
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                CertificateManagementLogConstants.LOCAL_CERTIFICATE_FOUND,
                selector?.Thumbprint ?? string.Empty,
                configuredBackend.ToString());
        }

        return result;
    }

    #endregion
}
