using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Windows TPM key storage provider (Microsoft Platform Crypto Provider).
/// </summary>
internal static class TpmPlatformCrypto
{
    public const string ProviderName = "Microsoft Platform Crypto Provider";

    public static bool IsAvailable()
    {
        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        int status = NCryptOpenStorageProvider(out IntPtr provider, ProviderName, 0);
        if (status != 0)
        {
            return false;
        }

        NCryptFreeObject(provider);
        return true;
    }

    public static bool IsTpmBacked(X509Certificate2 certificate)
    {
        try
        {
            if (!certificate.HasPrivateKey)
            {
                return false;
            }

            using RSA? rsa = certificate.GetRSAPrivateKey();
            if (rsa is RSACng rsaCng && rsaCng.Key.Provider is not null)
            {
                return string.Equals(rsaCng.Key.Provider.Provider, ProviderName, StringComparison.Ordinal);
            }

            using ECDsa? ecdsa = certificate.GetECDsaPrivateKey();
            if (ecdsa is ECDsaCng ecdsaCng && ecdsaCng.Key.Provider is not null)
            {
                return string.Equals(ecdsaCng.Key.Provider.Provider, ProviderName, StringComparison.Ordinal);
            }
        }
        catch (CryptographicException)
        {
            return false;
        }

        return false;
    }

    public static string CreateCsrPem(Guid keyId)
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new InvalidOperationException(Shared.Constants.RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE);
        }

        return CreateWindowsCsr(keyId);
    }

    [SupportedOSPlatform("windows")]
    private static string CreateWindowsCsr(Guid keyId)
    {
        if (!IsAvailable())
        {
            throw new InvalidOperationException(Shared.Constants.RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE);
        }

        var parameters = new CngKeyCreationParameters
        {
            Provider = new CngProvider(ProviderName),
            KeyCreationOptions = CngKeyCreationOptions.MachineKey | CngKeyCreationOptions.OverwriteExistingKey,
            KeyUsage = CngKeyUsages.Signing
        };
        parameters.Parameters.Add(new CngProperty("Length", BitConverter.GetBytes(2048), CngPropertyOptions.None));

        using CngKey key = CngKey.Create(CngAlgorithm.Rsa, "CH-RENEW-" + keyId.ToString("N"), parameters);
        using var rsa = new RSACng(key);
        var request = new CertificateRequest("CN=MAXUM-" + keyId.ToString("N"), rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        byte[] csr = request.CreateSigningRequest();
        return new string(PemEncoding.Write("CERTIFICATE REQUEST", csr));
    }

    [DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
    private static extern int NCryptOpenStorageProvider(out IntPtr phProvider, string pszProviderName, int dwFlags);

    [DllImport("ncrypt.dll")]
    private static extern int NCryptFreeObject(IntPtr hObject);
}
