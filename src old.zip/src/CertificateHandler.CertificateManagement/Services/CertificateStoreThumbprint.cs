using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace DashboardCH.Services;

/// <summary>
/// Matches store certificates to selector thumbprints (SHA-1 legacy or SHA-256).
/// </summary>
internal static class CertificateStoreThumbprint
{
    internal static bool Matches(X509Certificate2 certificate, string normalizedThumbprint)
    {
        if (string.IsNullOrEmpty(normalizedThumbprint))
        {
            return false;
        }

        string sha1 = Normalize(certificate.Thumbprint);
        if (string.Equals(sha1, normalizedThumbprint, StringComparison.Ordinal))
        {
            return true;
        }

        if (normalizedThumbprint.Length == 64)
        {
            string sha256 = Normalize(certificate.GetCertHashString(HashAlgorithmName.SHA256));
            return string.Equals(sha256, normalizedThumbprint, StringComparison.Ordinal);
        }

        return false;
    }

    private static string Normalize(string? thumbprint)
    {
        if (thumbprint is null)
        {
            return string.Empty;
        }

        return thumbprint
            .Replace(" ", string.Empty)
            .Replace(":", string.Empty)
            .ToUpperInvariant();
    }
}
