using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Exports a CSR whose key is created in the Windows TPM key storage provider (RS_26).
/// </summary>
public sealed class TpmCsrExportService : ITpmCsrExportService
{
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            return Task.FromResult(TpmPlatformCrypto.CreateCsrPem(keyId));
        }
        catch (Exception ex) when (ex is not InvalidOperationException and not OperationCanceledException)
        {
            throw new InvalidOperationException(RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE, ex);
        }
    }
}
