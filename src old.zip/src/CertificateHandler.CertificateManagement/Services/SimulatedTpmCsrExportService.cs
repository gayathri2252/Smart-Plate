using System.Text;
using CertificateHandler.CertificateManagement.Interfaces;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Dev/test CSR PEM export when <c>CH_SIMULATE_TPM_CSR=1</c> (RS_04/RS_26).
/// </summary>
public sealed class SimulatedTpmCsrExportService : ITpmCsrExportService
{
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        string payload = Convert.ToBase64String(Encoding.UTF8.GetBytes($"CSR-STUB-{keyId:N}"));
        string pem = $"-----BEGIN CERTIFICATE REQUEST-----\n{payload}\n-----END CERTIFICATE REQUEST-----";
        return Task.FromResult(pem);
    }

    public static bool IsEnabled =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SIMULATE_TPM_CSR");
}
