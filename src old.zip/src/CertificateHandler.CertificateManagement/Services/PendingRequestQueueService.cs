﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Services;

public class PendingRequestQueueService:IPendingRequestQueueService
{
    #region Member Variables

    private readonly IPendingRequestRepository _pendingRequestsRepository;

    private readonly IPendingOnboardingApprovalStore _onboardingApprovalStore;

    private readonly IReinstatementPendingApprovalStore? _reinstatementApprovalStore;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the
    /// PendingRequestQueueService class
    /// </summary>
    /// <param name="pendingRequestRepository">
    /// Repository used for retrieving and updating
    /// pending request information.
    /// </param>
    /// <param name="onboardingApprovalStore">
    /// Store that performs approve/reject with whitelist and notifications.
    /// </param>
    public PendingRequestQueueService(
        IPendingRequestRepository pendingRequestRepository,
        IPendingOnboardingApprovalStore onboardingApprovalStore,
        IReinstatementPendingApprovalStore? reinstatementApprovalStore = null)
    {
        _pendingRequestsRepository = pendingRequestRepository ?? throw new ArgumentNullException(nameof(pendingRequestRepository));
        _onboardingApprovalStore = onboardingApprovalStore ?? throw new ArgumentNullException(nameof(onboardingApprovalStore));
        _reinstatementApprovalStore = reinstatementApprovalStore;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Retrieves all pending requests from
    /// the repository.
    /// </summary>
    /// <returns>
    /// Collection of pending request items.
    /// </returns>
    public IEnumerable<PendingRequestItem> GetPendingRequests()
    {
        return _pendingRequestsRepository.GetPendingRequests();
    }

    /// <summary>
    /// Retrieves the certificate requests that have the given status.
    /// </summary>
    /// <param name="status">
    /// APPROVED, REJECTED or EXPIRED.
    /// </param>
    /// <returns>
    /// Collection of request items with that status.
    /// </returns>
    public IEnumerable<PendingRequestItem> GetRequestsByStatus(string status)
    {
        return _pendingRequestsRepository.GetRequestsByStatus(status);
    }

    /// <summary>
    /// Counts the certificate requests in each status.
    /// </summary>
    /// <returns>
    /// The number of pending, approved, rejected and expired requests.
    /// </returns>
    public RequestStatusCounts GetRequestStatusCounts()
    {
        return _pendingRequestsRepository.GetRequestStatusCounts();
    }

    /// <summary>
    /// Approves the specified pending request.
    /// </summary>
    /// <param name="requestId">
    /// Identifier of the request to approve.
    /// </param>
    public void ApproveRequest(PendingRequestDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);
        if (IsReinstatement(decision.RequestId))
        {
            if (_reinstatementApprovalStore is null)
            {
                throw new InvalidOperationException("Reinstatement approval store is not configured.");
            }

            _reinstatementApprovalStore.ApproveAsync(decision).GetAwaiter().GetResult();
            return;
        }

        _onboardingApprovalStore.ApproveAsync(decision).GetAwaiter().GetResult();
    }

    /// <summary>
    /// Rejects the specified pending request.
    /// </summary>
    /// <param name="requestId">
    /// Identifier of the request to reject.
    /// </param>
    public void RejectRequest(PendingRequestDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);
        if (IsReinstatement(decision.RequestId))
        {
            if (_reinstatementApprovalStore is null)
            {
                throw new InvalidOperationException("Reinstatement approval store is not configured.");
            }

            _reinstatementApprovalStore.RejectAsync(decision).GetAwaiter().GetResult();
            return;
        }

        _onboardingApprovalStore.RejectAsync(decision).GetAwaiter().GetResult();
    }

    private bool IsReinstatement(string requestId) =>
        _pendingRequestsRepository.GetRequestType(requestId)
            .Contains("REINSTATEMENT", StringComparison.OrdinalIgnoreCase);

    #endregion

}
