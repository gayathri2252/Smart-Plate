﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;
using DashboardCH.Interfaces;
using DashboardCH.Models;
using DashboardCH.Models.Enums;
using DashboardCH.Options;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Services;

namespace DashboardCH.Services;

/// <summary>
/// Reads certificate metadata from the Windows Certificate Store:
/// single lookup, full enumeration, and chain resolution.
/// </summary>
public sealed class WindowsCertificateStoreAdapter
    : ICertificateStoreAdapter
{
    #region Member Variables

    /// <summary>
    /// Revocation settings used when a certificate chain is built.
    /// </summary>
    private readonly RevocationPolicyOptions _revocationPolicy;

    /// <summary>
    /// Opens a certificate store of the given name and location.
    /// </summary>
    private readonly Func<StoreName, StoreLocation, X509Store> _storeFactory;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates an adapter that reads certificates from the Windows Certificate Store.
    /// </summary>
    /// <param name="revocationPolicy">Revocation settings; read from the environment when null.</param>
    public WindowsCertificateStoreAdapter(RevocationPolicyOptions? revocationPolicy = null)
        : this(static (name, location) => new X509Store(name, location), revocationPolicy)
    {
    }

    /// <summary>
    /// Creates an adapter that opens its certificate stores with the given factory. The default
    /// constructor uses the real Windows stores; a test can give a factory that fails, to check how
    /// the adapter reports a store that cannot be opened.
    /// </summary>
    /// <param name="storeFactory">Opens a certificate store of the given name and location.</param>
    /// <param name="revocationPolicy">Revocation settings; read from the environment when null.</param>
    /// <exception cref="ArgumentNullException">The factory is missing.</exception>
    public WindowsCertificateStoreAdapter(
        Func<StoreName, StoreLocation, X509Store> storeFactory,
        RevocationPolicyOptions? revocationPolicy = null)
    {
        ArgumentNullException.ThrowIfNull(storeFactory);
        _storeFactory = storeFactory;
        _revocationPolicy = revocationPolicy ?? RevocationPolicyOptions.FromEnvironment();
    }

    #endregion

    #region Public Properties

    public CertificateStorageMedium BackendType =>
        CertificateStorageMedium.WindowsCertificateStore;

    #endregion

    #region Public Methods

    /// <summary>
    /// Looks up one certificate by thumbprint in the store named by the selector.
    /// Returns a status for invalid input, no match, several matches or a store failure.
    /// </summary>
    public CertificateResult GetLocalCertificate(
        CertificateSelector selector)
    {
        if (selector is null)
        {
            return new CertificateResult
            {
                Status = CertLookupStatus.InvalidCertificate,
                ErrorDetail = RequestStatusConstants.SELECTOR_IS_NULL
            };
        }

        if (string.IsNullOrWhiteSpace(selector.Thumbprint))
        {
            return new CertificateResult
            {
                Status = CertLookupStatus.InvalidCertificate,
                ErrorDetail = RequestStatusConstants.THUMBPRINT_IS_REQUIRED
            };
        }

        try
        {
            var location = selector.StoreScope == WindowsStoreLocation.LocalMachine
                ? StoreLocation.LocalMachine
                : StoreLocation.CurrentUser;

            var storeName = MapStoreName(selector.StoreName);

            using var store = _storeFactory(storeName, location);
            store.Open(OpenFlags.ReadOnly);

            string normalizedThumbprint = NormalizeThumbprint(selector.Thumbprint);

            List<X509Certificate2> matchingCertificates = store.Certificates
                .Cast<X509Certificate2>()
                .Where(cert => CertificateStoreThumbprint.Matches(cert, normalizedThumbprint))
                .ToList();

            if (matchingCertificates.Count == 0)
            {
                return new CertificateResult
                {
                    Status = CertLookupStatus.CertificateNotFound,
                    ErrorDetail = $"Certificate with thumbprint '{selector.Thumbprint}' was not found."
                };
            }

            if (matchingCertificates.Count > 1)
            {
                return new CertificateResult
                {
                    Status = CertLookupStatus.MultipleMatches,
                    ErrorDetail = $"Multiple certificates found for thumbprint '{selector.Thumbprint}'."
                };
            }

            return new CertificateResult
            {
                Status = CertLookupStatus.Found,
                Metadata = CreateMetadata(matchingCertificates[0], selector.DeviceScope)
            };
        }
        catch (CryptographicException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_FAILED, CertificateManagementLogConstants.OPERATION_GET_CERTIFICATE, ex.Message);
            return new CertificateResult
            {
                Status = CertLookupStatus.AccessDenied,
                ErrorDetail = ex.Message
            };
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_FAILED, CertificateManagementLogConstants.OPERATION_GET_CERTIFICATE, ex.Message);
            return new CertificateResult
            {
                Status = CertLookupStatus.StoreUnavailable,
                ErrorDetail = ex.Message
            };
        }
    }

    /// <inheritdoc />
    public List<CertificateMetadata> ListCertificates(
        WindowsStoreLocation scope)
    {
        // NOTE: does not accept a WindowsStoreName parameter (matches the
        // existing ICertificateStoreAdapter signature). Listing
        // Root/CertificateAuthority as well as My would require an
        // interface change — flagged as a known follow-up.
        var result = new List<CertificateMetadata>();

        try
        {
            var location = scope == WindowsStoreLocation.LocalMachine
                ? StoreLocation.LocalMachine
                : StoreLocation.CurrentUser;

            using var store = _storeFactory(StoreName.My, location);
            store.Open(OpenFlags.ReadOnly);

            foreach (X509Certificate2 certificate in store.Certificates)
            {
                try
                {
                    // Owner is unset here: a raw store enumeration has no
                    // device-scope context to attach to each certificate.
                    result.Add(CreateMetadata(certificate, default));
                }
                catch (CryptographicException ex)
                {
                    LogMappingFailure(certificate, ex);
                }
            }
        }
        catch (Exception ex)
        {
            LogStoreEnumerationFailure(ex);
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_LISTED, result.Count.ToString(), scope.ToString());
        return result;
    }

    /// <inheritdoc />
    public CertificateChainInfo GetCertificateChain(
        string thumbprint)
    {
        if (string.IsNullOrWhiteSpace(thumbprint))
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.InvalidCertificate,
                ErrorDetail = RequestStatusConstants.CHAIN_THUMBPRINT_IS_REQUIRED
            };
        }

        try
        {
            var certificate = FindCertificateByThumbprint(thumbprint);

            if (certificate is null)
            {
                return new CertificateChainInfo
                {
                    Status = CertLookupStatus.CertificateNotFound,
                    ErrorDetail = $"Certificate '{thumbprint}' was not found."
                };
            }

            return BuildChainInfoFromCertificate(certificate);
        }
        catch (CryptographicException ex)
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.AccessDenied,
                ErrorDetail = ex.Message
            };
        }
        catch (Exception ex)
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.StoreUnavailable,
                ErrorDetail = ex.Message
            };
        }
    }

    /// <inheritdoc />
    public CertificateChainInfo GetCertificateChainFromCertificate(X509Certificate2 leafCertificate)
    {
        ArgumentNullException.ThrowIfNull(leafCertificate);

        try
        {
            return BuildChainInfoFromCertificate(leafCertificate);
        }
        catch (CryptographicException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_FAILED, CertificateManagementLogConstants.OPERATION_GET_CHAIN, ex.Message);
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.AccessDenied,
                ErrorDetail = ex.Message
            };
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_FAILED, CertificateManagementLogConstants.OPERATION_GET_CHAIN, ex.Message);
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.StoreUnavailable,
                ErrorDetail = ex.Message
            };
        }
    }

    #endregion

    #region Private Methods

    private CertificateChainInfo BuildChainInfoFromCertificate(X509Certificate2 certificate)
    {
        using var chain = new X509Chain();

        chain.ChainPolicy.RevocationMode = _revocationPolicy.RevocationCheckEnabled
            ? X509RevocationMode.Online
            : X509RevocationMode.NoCheck;

        if (_revocationPolicy.RevocationCheckEnabled && !_revocationPolicy.RevocationHardFail)
        {
            chain.ChainPolicy.VerificationFlags |= X509VerificationFlags.IgnoreCertificateAuthorityRevocationUnknown;
        }

        bool builtCompletely = chain.Build(certificate);

        string chainError = string.Empty;
        if (!builtCompletely)
        {
            X509ChainStatus? primary = chain.ChainStatus.FirstOrDefault();
            chainError = primary?.StatusInformation ?? RequestStatusConstants.CHAIN_INCOMPLETE;
            if (chain.ChainStatus.Any(static s => s.Status == X509ChainStatusFlags.Revoked))
            {
                chainError = "Certificate is revoked.";
            }
        }

        var chainInfo = new CertificateChainInfo
        {
            Status = CertLookupStatus.Found,
            ErrorDetail = chainError
        };

        for (int i = 0; i < chain.ChainElements.Count; i++)
        {
            var chainCertificate = chain.ChainElements[i].Certificate;
            var metadata = CreateMetadata(chainCertificate, default);

            if (i == 0)
            {
                chainInfo.LeafCertificate = metadata;
            }
            else if (i == chain.ChainElements.Count - 1)
            {
                chainInfo.RootCertificate = metadata;
            }
            else
            {
                chainInfo.IntermediateCertificates.Add(metadata);
            }
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_CHAIN_BUILT, certificate.Thumbprint, builtCompletely.ToString());
        return chainInfo;
    }

    /// <summary>
    /// Finds the certificate with the given thumbprint in the local machine personal store.
    /// Returns null when there is none.
    /// </summary>
    private X509Certificate2? FindCertificateByThumbprint(
        string thumbprint)
    {
        string normalizedThumbprint = NormalizeThumbprint(thumbprint);

        using var store = _storeFactory(StoreName.My, StoreLocation.LocalMachine);
        store.Open(OpenFlags.ReadOnly);

        return store.Certificates
            .Cast<X509Certificate2>()
            .FirstOrDefault(cert => CertificateStoreThumbprint.Matches(cert, normalizedThumbprint));
    }

    /// <summary>
    /// Removes spaces and colons from a thumbprint and converts it to upper case for comparison.
    /// </summary>
    private static string NormalizeThumbprint(string? thumbprint)
    {
        if (thumbprint is null)
        {
            return string.Empty;
        }

        return thumbprint
            .Replace(" ", string.Empty)
            .Replace(":", string.Empty)
            .ToUpperInvariant();
    }

    /// <summary>
    /// Converts the store name of the selector to the .NET store name. Unknown names map to the personal store.
    /// </summary>
    private static StoreName MapStoreName(WindowsStoreName storeName) =>
        storeName switch
        {
            WindowsStoreName.My => StoreName.My,
            WindowsStoreName.Root => StoreName.Root,
            WindowsStoreName.CertificateAuthority => StoreName.CertificateAuthority,
            _ => StoreName.My
        };

    /// <summary>
    /// Builds the certificate metadata with subject, issuer, validity dates and public key information.
    /// </summary>
    private static CertificateMetadata CreateMetadata(
        X509Certificate2 certificate,
        DeviceScope deviceScope)
    {
        return new CertificateMetadata
        {
            Thumbprint = certificate.Thumbprint ?? string.Empty,
            Owner = deviceScope,
            Subject = certificate.Subject,
            Issuer = certificate.Issuer,
            SerialNumber = certificate.SerialNumber,
            ValidFromUtc = certificate.NotBefore.ToUniversalTime(),
            ValidToUtc = certificate.NotAfter.ToUniversalTime(),
            PublicKey = CreateCertificatePublicKeyInfo(certificate),
            HasPrivateKey = certificate.HasPrivateKey,
            IsTpmBound = TpmPlatformCrypto.IsTpmBacked(certificate)
        };
    }

    /// <summary>
    /// Reads the public key algorithm, size and key data of a certificate (RSA, ECDSA or other).
    /// </summary>
    private static CertificatePublicKeyInfo CreateCertificatePublicKeyInfo(
        X509Certificate2 certificate)
    {
        using RSA? rsa = certificate.GetRSAPublicKey();

        if (rsa is not null)
        {
            RSAParameters parameters = rsa.ExportParameters(false);

            return new CertificatePublicKeyInfo
            {
                Algorithm = "RSA",
                KeyBits = rsa.KeySize,
                KeyData = parameters.Modulus ?? Array.Empty<byte>()
            };
        }

        using ECDsa? ecdsa = certificate.GetECDsaPublicKey();

        if (ecdsa is not null)
        {
            return new CertificatePublicKeyInfo
            {
                Algorithm = "ECDSA",
                KeyBits = ecdsa.KeySize,
                KeyData = certificate.GetPublicKey()
            };
        }

        return new CertificatePublicKeyInfo
        {
            Algorithm = certificate.PublicKey.Oid?.FriendlyName ?? "Unknown",
            KeyBits = 0,
            KeyData = certificate.GetPublicKey()
        };
    }

    /// <summary>
    /// Writes a debug message when the metadata of one certificate cannot be read.
    /// </summary>
    private static void LogMappingFailure(X509Certificate2 certificate, Exception ex)
    {
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_MAPPING_FAILED, certificate.Thumbprint, ex.Message);
    }

    /// <summary>
    /// Writes an Error to the Log Monitor when the certificate store cannot be listed.
    /// </summary>
    private static void LogStoreEnumerationFailure(Exception ex)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_STORE_FAILED, CertificateManagementLogConstants.OPERATION_LIST_CERTIFICATES, ex.Message);
    }

    #endregion
}
