using CertificateHandler.CertificateManagement.Interfaces;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Selects hardware or simulated TPM CSR export.
/// </summary>
public static class TpmCsrExportServiceFactory
{
    public static ITpmCsrExportService Create() =>
        SimulatedTpmCsrExportService.IsEnabled
            ? new SimulatedTpmCsrExportService()
            : new TpmCsrExportService();
}
