using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Drops exported CSR PEM files under <c>CH_MCC_EXPORT_PATH</c> for MCC collection.
/// </summary>
public sealed class MccRenewalExportWriter : IMccRenewalExportWriter
{
    public void ExportCsrPem(Guid keyId, string csrPem)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(csrPem);
        string? root = Environment.GetEnvironmentVariable("CH_MCC_EXPORT_PATH");
        if (string.IsNullOrWhiteSpace(root))
        {
            return;
        }

        Directory.CreateDirectory(root);
        string path = Path.Combine(root, $"renewal-{keyId:N}.csr.pem");
        File.WriteAllText(path, csrPem);
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), "MCC renewal CSR exported to {0}", path);
    }
}
