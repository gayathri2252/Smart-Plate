﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;
using DashboardCH.Interfaces;
using DashboardCH.Models;
using DashboardCH.Models.Enums;
using CertificateHandler.Logger;
using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Services;

namespace DashboardCH.Services;

/// <summary>
/// Reads certificates whose private key is stored in the Windows TPM key storage provider.
/// Returns TPMUnavailable when the provider or a TPM-backed certificate is not present.
/// </summary>
public sealed class TpmCertificateStoreAdapter
    : ICertificateStoreAdapter
{
    #region Member Variables

    private readonly WindowsCertificateStoreAdapter? _simulatedWindowsBacking;

    #endregion

    #region Constructor

    public TpmCertificateStoreAdapter()
    {
        if (SimulatedTpmStoreBridge.IsEnabled)
        {
            _simulatedWindowsBacking = new WindowsCertificateStoreAdapter();
        }
    }

    #endregion

    #region Public Properties

    public CertificateStorageMedium BackendType =>
        CertificateStorageMedium.TPM;

    #endregion

    #region Public Methods

    public CertificateResult GetLocalCertificate(
        CertificateSelector selector)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetLocalCertificate(selector);
        }

        if (selector is null || string.IsNullOrWhiteSpace(selector.Thumbprint) || !TpmPlatformCrypto.IsAvailable())
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, CertificateManagementLogConstants.OPERATION_GET_CERTIFICATE);
            return Unavailable(RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE);
        }

        CertificateResult found = new WindowsCertificateStoreAdapter().GetLocalCertificate(selector);
        if (found.Status == CertLookupStatus.Found && found.Metadata?.IsTpmBound == true)
        {
            return found;
        }

        if (found.Status == CertLookupStatus.Found)
        {
            return Unavailable(RequestStatusConstants.TPM_CERTIFICATE_NOT_BOUND);
        }

        return found.Status == CertLookupStatus.CertificateNotFound
            ? Unavailable(RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE)
            : found;
    }

    private static CertificateResult Unavailable(string detail) =>
        new()
        {
            Status = CertLookupStatus.TPMUnavailable,
            ErrorDetail = detail
        };

    public List<CertificateMetadata> ListCertificates(
        WindowsStoreLocation scope)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.ListCertificates(scope);
        }

        if (!TpmPlatformCrypto.IsAvailable())
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, RequestStatusConstants.TPM_LIST_NOT_APPLICABLE);
            return new List<CertificateMetadata>();
        }

        return new WindowsCertificateStoreAdapter()
            .ListCertificates(scope)
            .Where(certificate => certificate.IsTpmBound)
            .ToList();
    }

    public CertificateChainInfo GetCertificateChain(
        string thumbprint)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetCertificateChain(thumbprint);
        }

        CertificateResult certificate = GetLocalCertificate(new CertificateSelector { Thumbprint = thumbprint });
        if (certificate.Status != CertLookupStatus.Found)
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.TPMUnavailable,
                ErrorDetail = certificate.ErrorDetail
            };
        }

        return new WindowsCertificateStoreAdapter().GetCertificateChain(thumbprint);
    }

    public CertificateChainInfo GetCertificateChainFromCertificate(System.Security.Cryptography.X509Certificates.X509Certificate2 leafCertificate)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetCertificateChainFromCertificate(leafCertificate);
        }

        if (!TpmPlatformCrypto.IsAvailable())
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.TPMUnavailable,
                ErrorDetail = RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE
            };
        }

        if (!TpmPlatformCrypto.IsTpmBacked(leafCertificate))
        {
            return new CertificateChainInfo
            {
                Status = CertLookupStatus.TPMUnavailable,
                ErrorDetail = RequestStatusConstants.TPM_CERTIFICATE_NOT_BOUND
            };
        }

        return new WindowsCertificateStoreAdapter().GetCertificateChainFromCertificate(leafCertificate);
    }

    #endregion
}
