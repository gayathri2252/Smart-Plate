namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Writes renewal CSR PEM for MCC pickup (RS_26).
/// </summary>
public interface IMccRenewalExportWriter
{
    void ExportCsrPem(Guid keyId, string csrPem);
}
