﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Writes the audit row of an approval or rejection of a pending request.
/// </summary>
public interface IPendingRequestAuditWriter
{
    /// <summary>
    /// Inserts one audit row for the request. Returns the number of rows written:
    /// 0 when the request does not exist, otherwise 1.
    /// </summary>
    /// <param name="requestId">Identifier of the request.</param>
    /// <param name="eventType">Audit event type, approved or rejected.</param>
    /// <param name="newStatus">Status of the request after the decision.</param>
    /// <param name="actor">Administrator who decided.</param>
    /// <param name="result">SUCCESS or FAILURE.</param>
    /// <param name="reason">Error text for a failure; null for a success.</param>
    int WriteDecision(string requestId, string eventType, string newStatus, string actor, string result, string? reason);
}
