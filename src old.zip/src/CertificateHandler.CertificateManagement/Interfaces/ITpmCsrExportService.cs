namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Exports a CSR from TPM-backed key material (RS_26).
/// </summary>
public interface ITpmCsrExportService
{
    Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default);
}
