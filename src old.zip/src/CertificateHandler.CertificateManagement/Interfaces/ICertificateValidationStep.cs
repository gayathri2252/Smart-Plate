// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// One check in the certificate validation order (signature, chain, lifetime, revocation, trust list).
/// </summary>
public interface ICertificateValidationStep
{
    /// <summary>
    /// Runs the check and returns Pass or Rejected with a reason.
    /// </summary>
    ValidationStepResult Validate(CertificateValidationContext context);
}
