﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:
using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Defines repository operations for accessing and managing pending requests
/// in the underlying data store.
/// </summary>
public interface IPendingRequestRepository
{
    /// <summary>
    /// Retrieves all pending requests from the repository.
    /// </summary>
    /// <returns>A collection of pending request items.</returns>
    IEnumerable<PendingRequestItem> GetPendingRequests();

    /// <summary>
    /// Retrieves the certificate requests that have the given status: APPROVED, REJECTED or EXPIRED.
    /// </summary>
    /// <param name="status">Status of the requests to read.</param>
    /// <returns>The requests with that status, newest first.</returns>
    IEnumerable<PendingRequestItem> GetRequestsByStatus(string status);

    /// <summary>
    /// Counts the certificate requests in each status (pending, approved, rejected and expired).
    /// </summary>
    /// <returns>The number of requests in each status.</returns>
    RequestStatusCounts GetRequestStatusCounts();

    /// <summary>
    /// Returns the pending request type label for routing approve/reject.
    /// </summary>
    string GetRequestType(string requestId);

    /// <summary>
    /// Approves the specified pending request in the repository.
    /// </summary>
    /// <param name="requestId">
    /// The unique identifier of the request to approve.
    /// </param>
    void ApproveRequest(string requestId);

    /// <summary>
    /// Rejects the specified pending request in the repository.
    /// </summary>
    /// <param name="requestId">
    /// The unique identifier of the request to reject.
    /// </param>
    void RejectRequest(string requestId);
}