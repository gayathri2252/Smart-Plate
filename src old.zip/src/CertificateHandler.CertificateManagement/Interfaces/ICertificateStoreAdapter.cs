// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using DashboardCH.Models;
using DashboardCH.Models.Enums;

namespace DashboardCH.Interfaces;

/// <summary>
/// Contract implemented by each certificate storage medium adapter
/// (Windows Certificate Store, TPM).
/// </summary>
public interface ICertificateStoreAdapter
{
    /// <summary>
    /// The storage medium this adapter implements.
    /// </summary>
    CertificateStorageMedium BackendType { get; }

    /// <summary>
    /// Looks up a single certificate by thumbprint.
    /// </summary>
    CertificateResult GetLocalCertificate(CertificateSelector selector);

    /// <summary>
    /// Lists all certificates in the given store scope.
    /// </summary>
    List<CertificateMetadata> ListCertificates(WindowsStoreLocation scope);

    /// <summary>
    /// Resolves the certificate chain for the given thumbprint.
    /// </summary>
    CertificateChainInfo GetCertificateChain(string thumbprint);

    /// <summary>
    /// Builds a chain for a certificate presented by a peer (not a local store lookup).
    /// </summary>
    CertificateChainInfo GetCertificateChainFromCertificate(X509Certificate2 leafCertificate);
}
