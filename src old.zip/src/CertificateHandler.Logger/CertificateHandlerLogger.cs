﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:
using LogNet;

namespace CertificateHandler.Logger;
/// <summary>
/// Provides logging functionality for certificate handler operations.
/// </summary>
public static class CertificateHandlerLogger
{
    #region Member Variables

    /// <summary>
    /// Specifies the facility name used for logging entries
    /// </summary>
    private const string FACILITY_NAME = "CertificateHand";

    /// <summary>
    /// The log driver accepts at most 256 bytes for all message arguments together.
    /// Each argument also uses one extra byte.
    /// </summary>
    private const int MAX_PARAMETER_BLOCK_SIZE = 256;

    #endregion

    #region Public Methods

    /// <summary>
    /// Writes an information message to the log driver.
    /// </summary>
    public static void Information(int eventId, string message, params object[] args)
    {
        try
        {
            Log.Information(FACILITY_NAME, eventId, message, FitToParameterLimit(args));
        }
        catch (Exception ex) when (ex is DllNotFoundException or InvalidOperationException)
        {
            System.Console.WriteLine(ex.Message);
        }
    }

    /// <summary>
    /// Writes a success message to the log driver.
    /// </summary>
    public static void Success(int eventId, string message, params object[] args)
    {
        try
        {
            Log.Success(FACILITY_NAME, eventId, message, FitToParameterLimit(args));
        }
        catch (Exception ex) when (ex is DllNotFoundException or InvalidOperationException)
        {
            System.Console.WriteLine(ex.Message);
        }
    }

    /// <summary>
    /// Writes a warning message to the log driver.
    /// </summary>
    public static void Warning(int eventId, string message, params object[] args)
    {
        try
        {
            Log.Warning(FACILITY_NAME, eventId, message, FitToParameterLimit(args));
        }
        catch (Exception ex) when (ex is DllNotFoundException or InvalidOperationException)
        {
            System.Console.WriteLine(ex.Message);
        }
    }

    /// <summary>
    /// Writes an error message to the log driver.
    /// </summary>
    public static void Error(int eventId, string message, params object[] args)
    {
        try
        {
            Log.Error(FACILITY_NAME, eventId, message, FitToParameterLimit(args));
        }
        catch (Exception ex) when (ex is DllNotFoundException or InvalidOperationException)
        {
            System.Console.WriteLine(ex.Message);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Shortens the text of the arguments so that together they fit the log driver limit.
    /// Longer text, such as an exception message, would otherwise make the log call throw.
    /// </summary>
    private static object[] FitToParameterLimit(object[] args)
    {
        if (args is null || args.Length == 0)
        {
            return args ?? Array.Empty<object>();
        }

        int maxLength = Math.Max(4, (MAX_PARAMETER_BLOCK_SIZE / args.Length) - 1);
        var fitted = new object[args.Length];

        for (int i = 0; i < args.Length; i++)
        {
            string text = args[i]?.ToString() ?? string.Empty;
            fitted[i] = text.Length <= maxLength ? text : string.Concat(text.AsSpan(0, maxLength - 3), "...");
        }

        return fitted;
    }

    #endregion
}
