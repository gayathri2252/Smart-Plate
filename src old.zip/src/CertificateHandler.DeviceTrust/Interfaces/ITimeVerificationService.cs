namespace CertificateHandler.DeviceTrust.Interfaces;

/// <summary>
/// Reports whether system time is trusted for certificate validity checks (RS_03).
/// </summary>
public interface ITimeVerificationService
{
    bool IsTimeVerified();
}
