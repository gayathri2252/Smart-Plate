using CertificateHandler.DeviceTrust.Interfaces;
using CertificateHandler.Shared.Security;
using Microsoft.Win32;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Fail-closed when Windows time service is unavailable or test bypass is enabled (DEBUG only).
/// </summary>
public sealed class SystemTimeVerificationService : ITimeVerificationService
{
    private const string W32TimeParametersKey =
        @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time\Parameters";

    public bool IsTimeVerified()
    {
        if (DevelopmentBypassGuard.IsBypassEnabled("CH_TIME_UNVERIFIED"))
        {
            return false;
        }

        if (!OperatingSystem.IsWindows())
        {
            return true;
        }

        object? type = Registry.GetValue(W32TimeParametersKey, "Type", null);
        if (type is null)
        {
            return false;
        }

        string typeText = type.ToString()?.Trim() ?? string.Empty;
        return typeText is not ("NoSync" or "0");
    }
}
