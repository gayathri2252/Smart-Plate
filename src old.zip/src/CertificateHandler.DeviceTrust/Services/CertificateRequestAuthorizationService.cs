﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.DeviceTrust.Tls;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.Data.Enums;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Trust;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides whether a peer that sends a certificate request may communicate. The listener calls it for every
/// incoming peer. The checks run in this order:
/// 1. The request must hold the certificate details and a validation result for the same thumbprint.
/// 2. The certificate must pass validation; a security failure also blacklists it.
/// 3. The peer must be authenticated: the connection proved it holds the private key.
/// 4. A blacklisted certificate is refused.
/// 5. A whitelisted certificate is allowed. One that was removed from the blacklist before is allowed
///    only because it passed steps 1 to 4 again on this connection, never because of its removal alone.
/// 6. A validated MAXUM peer that was not removed from the blacklist is auto-whitelisted and allowed (RS_32).
/// 7. Any other unknown certificate is refused and added to the pending queue while the queue has room. When
///    the queue already holds the limit, the peer is refused before any pending row is created.
/// Any failure to read the lists or the queue refuses the peer.
/// </summary>
public class CertificateRequestAuthorizationService
{
    #region Member Variables

    private readonly TrustEngine _trustEngine;
    private readonly PendingQueueCapacityService _queueCapacity;
    private readonly IBlackListHistory _blackListHistory;

    private readonly ITlsHandshakeCoordinator? _handshakeCoordinator;

    private readonly IMaxumPeerAutoApprover? _autoApprover;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. None of the arguments may be null.
    /// </summary>
    /// <param name="trustEngine">Decides blacklisted, whitelisted or unknown.</param>
    /// <param name="queueCapacity">Adds unknown peers to the pending queue within its limit.</param>
    /// <param name="blackListHistory">Tells whether a certificate was removed from the blacklist.</param>
    public CertificateRequestAuthorizationService(
        TrustEngine trustEngine,
        PendingQueueCapacityService queueCapacity,
        IBlackListHistory blackListHistory,
        ITlsHandshakeCoordinator? handshakeCoordinator = null,
        IMaxumPeerAutoApprover? autoApprover = null)
    {
        ArgumentNullException.ThrowIfNull(trustEngine);
        ArgumentNullException.ThrowIfNull(queueCapacity);
        ArgumentNullException.ThrowIfNull(blackListHistory);

        _trustEngine = trustEngine;
        _queueCapacity = queueCapacity;
        _blackListHistory = blackListHistory;
        _handshakeCoordinator = handshakeCoordinator;
        _autoApprover = autoApprover;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns whether the certificate request of the peer is allowed, and why not when it may not.
    /// </summary>
    /// <param name="request">The peer and the result of validating its certificate.</param>
    /// <param name="cancellationToken">Cancels the lookups; a cancellation is passed on to the caller.</param>
    public async Task<CertificateRequestAuthorizationResult> AuthorizeAsync(
        CertificateRequest? request,
        CancellationToken cancellationToken = default)
    {
        if (!TryGetThumbprint(request, out string thumbprint))
        {
            return Refuse(CertificateRequestDecision.RefusedInvalidRequest, DeviceTrustConstants.CERTIFICATE_REQUEST_INVALID_REQUEST);
        }

        PeerOnboardingRequest peer = request!.Peer!;
        TrustValidationResult validationResult = request.ValidationResult!;

        try
        {
            if (validationResult.Outcome != TrustValidationOutcome.Passed)
            {
                // A security failure, such as a bad signature, also puts the certificate on the blacklist.
                ProtectedServiceGate.Shared.Deny(thumbprint);
                await _trustEngine.CompleteValidationAsync(validationResult, cancellationToken);
                return Refuse(CertificateRequestDecision.RefusedValidationFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_VALIDATION_FAILED,
                    peer.DeviceCode, validationResult.Outcome.ToString());
            }

            // An unauthenticated peer is neither trusted nor queued, so copied certificates cannot fill the queue.
            if (!request.IsAuthenticated)
            {
                ProtectedServiceGate.Shared.Deny(thumbprint);
                return Refuse(CertificateRequestDecision.RefusedAuthenticationFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_AUTHENTICATION_FAILED,
                    peer.DeviceCode);
            }

            TrustDecision decision = await _trustEngine.EvaluateAsync(thumbprint, cancellationToken);

            switch (decision)
            {
                case TrustDecision.BlackListed:
                    ProtectedServiceGate.Shared.Deny(thumbprint);
                    return Refuse(CertificateRequestDecision.RefusedBlackListed, DeviceTrustConstants.CERTIFICATE_REQUEST_BLACK_LISTED, peer.DeviceCode);

                case TrustDecision.Whitelisted:
                    ProtectedServiceGate.Shared.Allow(thumbprint);
                    return await AllowWhitelistedAsync(thumbprint, peer, cancellationToken);

                case TrustDecision.Unknown:
                    return await DecideUnknownPeerAsync(thumbprint, peer, cancellationToken);

                default:
                    return Refuse(CertificateRequestDecision.RefusedLookupFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_LOOKUP_FAILED, peer.DeviceCode);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The caller cancelled the certificate request. That is not a lookup failure, so it is passed on.
            throw;
        }
        catch (Exception ex)
        {
            // Fail closed: when the lists or the queue cannot be read, the peer is not trusted.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.CERTIFICATE_REQUEST_CHECK_FAILED,
                peer.DeviceCode,
                ex.Message);
            return new CertificateRequestAuthorizationResult
            {
                Decision = CertificateRequestDecision.RefusedLookupFailed,
                FailureReason = ex.GetBaseException().Message
            };
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Allows a whitelisted peer. When the certificate was removed from the blacklist before, this is
    /// logged as a revalidation: it got here only by passing validation and authentication again.
    /// </summary>
    private async Task<CertificateRequestAuthorizationResult> AllowWhitelistedAsync(
        string thumbprint,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        bool wasRemovedFromBlackList = await _blackListHistory.WasRemovedFromBlackListAsync(thumbprint, cancellationToken);

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            wasRemovedFromBlackList ? DeviceTrustConstants.CERTIFICATE_REQUEST_REVALIDATED_ALLOWED : DeviceTrustConstants.CERTIFICATE_REQUEST_ALLOWED,
            peer.DeviceCode);

        return new CertificateRequestAuthorizationResult
        {
            Decision = CertificateRequestDecision.Allowed,
            WasRevalidatedAfterBlackList = wasRemovedFromBlackList
        };
    }

    /// <summary>
    /// Auto-whitelists a validated MAXUM peer. Workstation, MCC, and GCP clients stay on the pending queue.
    /// A MAXUM peer that was removed from the blacklist also stays on the queue until an administrator decides.
    /// </summary>
    private async Task<CertificateRequestAuthorizationResult> DecideUnknownPeerAsync(
        string thumbprint,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        DeviceType profile = ClientProfileClassifier.Classify(peer);
        peer.ClientProfile = profile;
        bool wasRemovedFromBlackList = await _blackListHistory.WasRemovedFromBlackListAsync(thumbprint, cancellationToken);
        if (profile == DeviceType.MaxumPeer && !wasRemovedFromBlackList && _autoApprover is not null)
        {
            if (await _autoApprover.TryAutoApproveAsync(peer, cancellationToken))
            {
                ProtectedServiceGate.Shared.Allow(thumbprint);
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.CERTIFICATE_REQUEST_MAXUM_AUTO_APPROVED,
                    peer.DeviceCode);
                return new CertificateRequestAuthorizationResult { Decision = CertificateRequestDecision.Allowed };
            }
        }

        return await QueueUnknownPeerAsync(thumbprint, peer, cancellationToken);
    }

    /// <summary>
    /// Refuses an unknown peer and adds it to the pending queue while the queue has room. A certificate
    /// that was removed from the blacklist but is not whitelisted again also goes this way, so an
    /// administrator has to approve it before it may communicate.
    /// </summary>
    private async Task<CertificateRequestAuthorizationResult> QueueUnknownPeerAsync(
        string thumbprint,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        bool wasRemovedFromBlackList = await _blackListHistory.WasRemovedFromBlackListAsync(thumbprint, cancellationToken);

        peer.ThumbprintSha256 = thumbprint;
        PendingQueueAddResult result = await _queueCapacity.TryEnqueueAsync(peer, cancellationToken);
        ProtectedServiceGate.Shared.Deny(thumbprint);
        if (result.Outcome == PendingQueueAddOutcome.Added && result.RequestId is Guid requestId)
        {
            _handshakeCoordinator?.TrySuspend(requestId.ToString(), thumbprint);
        }

        CertificateRequestDecision decision = result.Outcome switch
        {
            PendingQueueAddOutcome.Added => CertificateRequestDecision.RefusedPendingApproval,
            PendingQueueAddOutcome.AlreadyPending => CertificateRequestDecision.RefusedAlreadyPending,
            _ => CertificateRequestDecision.RefusedQueueFull
        };

        return new CertificateRequestAuthorizationResult
        {
            Decision = decision,
            PendingRequestId = result.RequestId,
            WasRevalidatedAfterBlackList = wasRemovedFromBlackList
        };
    }

    /// <summary>
    /// Reads the thumbprint of the peer. It must be valid and the same as the thumbprint of the
    /// validation result, so a result for another certificate cannot authorize this peer.
    /// </summary>
    private static bool TryGetThumbprint(CertificateRequest? request, out string thumbprint)
    {
        thumbprint = string.Empty;

        if (request?.Peer is null || request.ValidationResult is null)
        {
            return false;
        }

        if (!ThumbprintNormalizer.TryNormalizeRequired(request.Peer.ThumbprintSha256, out string peerThumbprint)
            || !ThumbprintNormalizer.TryNormalizeRequired(request.ValidationResult.ThumbprintSha256, out string validatedThumbprint))
        {
            return false;
        }

        if (!string.Equals(peerThumbprint, validatedThumbprint, StringComparison.Ordinal))
        {
            return false;
        }

        thumbprint = peerThumbprint;
        return true;
    }

    /// <summary>
    /// Logs why the peer is refused and returns the refusal.
    /// </summary>
    private static CertificateRequestAuthorizationResult Refuse(CertificateRequestDecision decision, string message, params string[] arguments)
    {
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message, arguments);
        return new CertificateRequestAuthorizationResult { Decision = decision };
    }

    #endregion
}
