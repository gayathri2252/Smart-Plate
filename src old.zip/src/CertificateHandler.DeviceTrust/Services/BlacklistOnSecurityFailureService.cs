// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Called when the trust engine finishes. Blacklists the thumbprint when validation failed
/// for a bad signature, a revoked certificate, a broken chain or a security incident.
/// </summary>
public class BlackListOnSecurityFailureService
{
    #region Member Variables

    private readonly ICertificateBlackList _certificateBlackList;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service on top of the blacklist store. The store must not be null.
    /// </summary>
    public BlackListOnSecurityFailureService(ICertificateBlackList certificateBlackList)
    {
        ArgumentNullException.ThrowIfNull(certificateBlackList);

        _certificateBlackList = certificateBlackList;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Handles one validation result. Returns the blacklist outcome, or null when the result
    /// passed or does not blacklist the thumbprint.
    /// </summary>
    public async Task<CertificateBlackList?> HandleValidationResultAsync(
        TrustValidationResult validationResult,
        CancellationToken cancellationToken = default)
    {
        // Guard: without a validation result there is nothing to decide on.
        if (validationResult is null)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.VALIDATION_RESULT_IS_NULL);
            throw new ArgumentNullException(nameof(validationResult));
        }

        // Guard: a passed validation never blacklists the thumbprint.
        if (validationResult.Outcome == TrustValidationOutcome.Passed)
        {
            return null;
        }

        // Guard: expired, not-yet-valid and time-unverified results belong to a separate story.
        if (!TrustFailureClassifier.TryGetBlackListReason(validationResult.Outcome, out var reasonClass))
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.VALIDATION_FAILURE_NOT_BLACK_LISTED,
                validationResult.Outcome.ToString());
            return null;
        }

        BlackListResponse result;

        try
        {
            result = await _certificateBlackList.BlackListAsync(
                new BlackListRequest
                {
                    ThumbprintSha256 = validationResult.ThumbprintSha256,
                    ReasonClass = reasonClass,
                    Reason = BuildReason(validationResult),
                    EvaluatedAt = validationResult.EvaluatedAt
                },
                cancellationToken);
        }
        catch (Exception ex)
        {
            // A failure to blacklist must not be silent, so the error is logged and rethrown.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.BLACK_LIST_FAILED,
                ex.Message);
            throw;
        }

        LogOutcome(reasonClass.ToString(), result.Outcome);
        return result.Outcome;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds the reason stored with the blacklist row: the outcome name, followed by the
    /// failure detail from the trust engine when there is one.
    /// </summary>
    private static string BuildReason(TrustValidationResult validationResult)
    {
        string detail = validationResult.FailureReason?.Trim() ?? string.Empty;

        return detail.Length == 0
            ? validationResult.Outcome.ToString()
            : $"{validationResult.Outcome}: {detail}";
    }

    /// <summary>
    /// Logs the blacklist outcome: a warning when the thumbprint was blacklisted, information when it
    /// already was, and an error when the certificate is not known.
    /// </summary>
    private static void LogOutcome(string reasonClass, CertificateBlackList outcome)
    {
        switch (outcome)
        {
            case CertificateBlackList.Added:
            case CertificateBlackList.Reactivated:
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.THUMBPRINT_BLACK_LISTED,
                    reasonClass);
                break;

            case CertificateBlackList.AlreadyBlackListed:
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.THUMBPRINT_ALREADY_BLACK_LISTED);
                break;

            default:
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.BLACK_LIST_CERTIFICATE_NOT_FOUND);
                break;
        }
    }

    #endregion
}
