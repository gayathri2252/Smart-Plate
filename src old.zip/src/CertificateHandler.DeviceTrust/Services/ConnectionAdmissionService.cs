// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides whether a connection may start, by looking up the presented thumbprint on the blacklist.
/// </summary>
public class ConnectionAdmissionService
{
    #region Member Variables

    private readonly ICertificateBlackList _certificateBlackList;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service on top of the blacklist store. The store must not be null.
    /// </summary>
    public ConnectionAdmissionService(ICertificateBlackList certificateBlackList)
    {
        ArgumentNullException.ThrowIfNull(certificateBlackList);

        _certificateBlackList = certificateBlackList;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns false when the thumbprint is blacklisted. Also returns false when the
    /// thumbprint is invalid or the lookup fails: if the blacklist cannot be checked,
    /// the connection is denied rather than allowed.
    /// </summary>
    public async Task<bool> IsConnectionAllowedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        // Guard: a missing or malformed thumbprint cannot be checked, so the connection is denied.
        if (!ThumbprintNormalizer.TryNormalizeRequired(thumbprintSha256, out string thumbprint))
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.CONNECTION_DENIED_INVALID_THUMBPRINT);
            return false;
        }

        try
        {
            if (await _certificateBlackList.IsBlackListedAsync(thumbprint, cancellationToken))
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.CONNECTION_DENIED_BLACK_LISTED);
                return false;
            }

            return true;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The caller cancelled the lookup. That is not a lookup failure, so it is passed on.
            throw;
        }
        catch (Exception ex)
        {
            // Fail closed: if the blacklist cannot be read, the connection is not allowed.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.CONNECTION_DENIED_LOOKUP_FAILED,
                ex.Message);
            return false;
        }
    }

    #endregion
}
