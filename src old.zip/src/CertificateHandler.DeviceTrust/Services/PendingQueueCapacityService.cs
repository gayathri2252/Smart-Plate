﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Keeps the pending queue within the configured limit: an unknown peer is added only while the queue
/// has room, so many new certificates cannot fill the queue and exhaust the listener.
/// </summary>
public class PendingQueueCapacityService
{
    #region Member Variables

    private readonly IPendingQueueStore _store;
    private readonly TimeoutConfiguration _timeoutConfiguration;
    private readonly Func<DateTimeOffset> _clock;

    #endregion

    #region Public Properties

    /// <summary>Most open peer requests the queue holds.</summary>
    public int MaxPendingConnections { get; }

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. A limit below 1 is logged and replaced by the default of 10.
    /// </summary>
    /// <param name="store">Store of the open requests; must not be null.</param>
    /// <param name="options">Queue settings; must not be null.</param>
    /// <param name="timeoutConfiguration">Gives the hours after which a request expires; must not be null.</param>
    /// <param name="clock">Gives the current time; the system clock when null.</param>
    public PendingQueueCapacityService(
        IPendingQueueStore store,
        PendingQueueOptions options,
        TimeoutConfiguration timeoutConfiguration,
        Func<DateTimeOffset>? clock = null)
    {
        ArgumentNullException.ThrowIfNull(store);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(timeoutConfiguration);

        _store = store;
        _timeoutConfiguration = timeoutConfiguration;
        _clock = clock ?? (() => DateTimeOffset.UtcNow);

        if (!options.IsMaxPendingConnectionsValid)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.PENDING_QUEUE_LIMIT_INVALID,
                options.MaxPendingConnections.ToString(),
                PendingQueueOptions.DEFAULT_MAX_PENDING_CONNECTIONS.ToString());
        }

        MaxPendingConnections = options.EffectiveMaxPendingConnections;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns true when the queue holds the maximum number of open peer requests.
    /// </summary>
    public async Task<bool> IsQueueFullAsync(CancellationToken cancellationToken = default)
    {
        int openCount = await _store.CountOpenPeerRequestsAsync(cancellationToken);
        return openCount >= MaxPendingConnections;
    }

    /// <summary>
    /// Adds the unknown peer to the pending queue when the queue has room and the peer does not wait
    /// there already. The request expires after the configured timeout.
    /// </summary>
    /// <param name="peer">Peer to add; must not be null.</param>
    /// <param name="cancellationToken">Cancels the database work.</param>
    /// <returns>Whether the peer was added, already waits, or was refused because the queue is full.</returns>
    public async Task<PendingQueueAddResult> TryEnqueueAsync(
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(peer);

        peer.ExpiresAt = _clock().AddHours(_timeoutConfiguration.PendingRequestExpiryTimeout);

        PendingQueueAddResult result = await _store.TryAddPeerRequestAsync(peer, MaxPendingConnections, cancellationToken);

        switch (result.Outcome)
        {
            case PendingQueueAddOutcome.Added:
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.PENDING_QUEUE_PEER_ADDED,
                    peer.DeviceCode,
                    (result.OpenRequestCount + 1).ToString(),
                    MaxPendingConnections.ToString());
                break;

            case PendingQueueAddOutcome.AlreadyPending:
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.PENDING_QUEUE_PEER_ALREADY_WAITING,
                    peer.DeviceCode);
                break;

            default:
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.PENDING_QUEUE_FULL,
                    MaxPendingConnections.ToString(),
                    peer.DeviceCode);
                break;
        }

        return result;
    }

    #endregion
}
