// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides whether a presented thumbprint is blacklisted, whitelisted or unknown, and passes
/// a finished validation result on to the blacklist service. The blacklist is checked first.
/// </summary>
public class TrustEngine
{
    #region Member Variables

    private readonly ICertificateBlackList _certificateBlackList;
    private readonly ICertificateWhitelist _certificateWhitelist;
    private readonly BlackListOnSecurityFailureService _blacklistOnSecurityFailureService;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the engine on top of the blacklist and whitelist stores and the service that blacklists
    /// a thumbprint after a security failure. None of them may be null.
    /// </summary>
    public TrustEngine(
        ICertificateBlackList certificateBlackList,
        ICertificateWhitelist certificateWhitelist,
        BlackListOnSecurityFailureService blacklistOnSecurityFailureService)
    {
        ArgumentNullException.ThrowIfNull(certificateBlackList);
        ArgumentNullException.ThrowIfNull(certificateWhitelist);
        ArgumentNullException.ThrowIfNull(blacklistOnSecurityFailureService);

        _certificateBlackList = certificateBlackList;
        _certificateWhitelist = certificateWhitelist;
        _blacklistOnSecurityFailureService = blacklistOnSecurityFailureService;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Called when validation of a certificate is finished. Passes the result to the blacklist service,
    /// which blacklists the thumbprint after a security failure. Returns the blacklist outcome, or null
    /// when the result passed or does not blacklist the thumbprint.
    /// </summary>
    public Task<CertificateBlackList?> CompleteValidationAsync(
        TrustValidationResult validationResult,
        CancellationToken cancellationToken = default)
    {
        return _blacklistOnSecurityFailureService.HandleValidationResultAsync(validationResult, cancellationToken);
    }

    /// <summary>
    /// Returns the trust decision for the thumbprint. An invalid thumbprint, or a list that
    /// cannot be read, gives Rejected: if the lists cannot be checked, the certificate is not trusted.
    /// </summary>
    public async Task<TrustDecision> EvaluateAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        // Guard: a missing or malformed thumbprint cannot be looked up, so the certificate is rejected.
        if (!ThumbprintNormalizer.TryNormalizeRequired(thumbprintSha256, out string thumbprint))
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_INVALID_THUMBPRINT);
            return TrustDecision.Rejected;
        }

        try
        {
            // The blacklist comes first, so a blacklisted thumbprint is denied even if it also has a whitelist row.
            if (await _certificateBlackList.IsBlackListedAsync(thumbprint, cancellationToken))
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.TRUST_DECISION_BLACK_LISTED);
                return TrustDecision.BlackListed;
            }

            if (await _certificateWhitelist.IsWhitelistedAsync(thumbprint, cancellationToken))
            {
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.TRUST_DECISION_WHITELISTED);
                return TrustDecision.Whitelisted;
            }

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_UNKNOWN);
            return TrustDecision.Unknown;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The caller cancelled the lookup. That is not a lookup failure, so it is passed on.
            throw;
        }
        catch (Exception ex)
        {
            // Fail closed: if the lists cannot be read, the certificate is not trusted.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_LOOKUP_FAILED,
                ex.Message);
            return TrustDecision.Rejected;
        }
    }

    #endregion
}
