﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Models;

/// <summary>
/// What the listener does with a peer that sends a certificate request.
/// </summary>
public enum CertificateRequestDecision
{
    /// <summary>The certificate passed validation and is whitelisted; the certificate request is allowed.</summary>
    Allowed,

    /// <summary>The request has no certificate details, or the thumbprint is missing, not valid or does not match.</summary>
    RefusedInvalidRequest,

    /// <summary>The certificate failed validation, such as a bad signature, a broken chain or an expired date.</summary>
    RefusedValidationFailed,

    /// <summary>The peer did not prove during the connection that it holds the private key of the certificate.</summary>
    RefusedAuthenticationFailed,

    /// <summary>The certificate is on the blacklist.</summary>
    RefusedBlackListed,

    /// <summary>The trust lists or the queue could not be read, so the peer is not trusted.</summary>
    RefusedLookupFailed,

    /// <summary>The peer is unknown and was added to the pending queue; it waits for an administrator decision.</summary>
    RefusedPendingApproval,

    /// <summary>The peer is unknown and already waits in the pending queue.</summary>
    RefusedAlreadyPending,

    /// <summary>The peer is unknown and the pending queue is full, so it was not added.</summary>
    RefusedQueueFull
}
