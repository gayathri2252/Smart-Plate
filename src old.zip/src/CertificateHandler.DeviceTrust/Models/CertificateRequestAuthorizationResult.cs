﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Models;

/// <summary>
/// The answer to a certificate request: whether the peer may communicate, and why not when it may not.
/// </summary>
public sealed class CertificateRequestAuthorizationResult
{
    #region Public Properties

    /// <summary>What the listener does with the peer.</summary>
    public CertificateRequestDecision Decision { get; init; }

    /// <summary>True only when the certificate request is allowed.</summary>
    public bool IsAllowed => Decision == CertificateRequestDecision.Allowed;

    /// <summary>True when the certificate was removed from the blacklist before and was checked again in full.</summary>
    public bool WasRevalidatedAfterBlackList { get; init; }

    /// <summary>Id of the pending request that was added for the peer; null when none was added.</summary>
    public Guid? PendingRequestId { get; init; }

    /// <summary>Error text when the lists or the queue could not be read or written; empty otherwise.</summary>
    public string FailureReason { get; init; } = string.Empty;

    #endregion
}
