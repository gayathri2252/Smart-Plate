﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Models;

namespace CertificateHandler.DeviceTrust.Models;

/// <summary>
/// A peer that sends a certificate request: the certificate it presented and the result of validating it.
/// </summary>
public sealed class CertificateRequest
{
    #region Public Properties

    /// <summary>Certificate and device details of the peer.</summary>
    public PeerOnboardingRequest? Peer { get; init; }

    /// <summary>Result of validating the peer certificate (signature, chain, revocation and dates).</summary>
    public TrustValidationResult? ValidationResult { get; init; }

    /// <summary>
    /// True when the connection proved that the peer holds the private key of the certificate, such
    /// as SslStream.IsMutuallyAuthenticated. A certificate alone can be copied, so it is not enough.
    /// </summary>
    public bool IsAuthenticated { get; init; }

    /// <summary>DER encoding of the peer leaf certificate when validation should not use the local store.</summary>
    public byte[]? PresentedCertificateDer { get; init; }

    #endregion
}
