using System.Collections.Concurrent;

namespace CertificateHandler.DeviceTrust.Tls;

public sealed class TlsHandshakeCoordinator : ITlsHandshakeCoordinator
{
    #region Member Variables

    private readonly ConcurrentDictionary<string, string> _suspended = new();

    #endregion

    #region Public Methods

    public bool TrySuspend(string correlationId, string thumbprintSha256)
    {
        if (string.IsNullOrWhiteSpace(correlationId))
        {
            return false;
        }

        return _suspended.TryAdd(correlationId, thumbprintSha256 ?? string.Empty);
    }

    public void Resume(string correlationId)
    {
        if (!string.IsNullOrWhiteSpace(correlationId))
        {
            _suspended.TryRemove(correlationId, out _);
        }
    }

    public bool IsSuspended(string correlationId) =>
        !string.IsNullOrWhiteSpace(correlationId) && _suspended.ContainsKey(correlationId);

    #endregion
}
