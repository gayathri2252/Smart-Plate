namespace CertificateHandler.DeviceTrust.Tls;

/// <summary>
/// Process-wide TLS handshake coordinator so the UI, listener host, and authorization share suspend/resume state (RS_11).
/// </summary>
public static class TlsHandshakeCoordinatorRegistry
{
    #region Member Variables

    private static readonly Lazy<TlsHandshakeCoordinator> Shared = new(() => new TlsHandshakeCoordinator());

    #endregion

    #region Public Methods

    public static TlsHandshakeCoordinator Current => Shared.Value;

    #endregion
}
