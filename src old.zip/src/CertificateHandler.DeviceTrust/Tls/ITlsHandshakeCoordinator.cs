namespace CertificateHandler.DeviceTrust.Tls;

public interface ITlsHandshakeCoordinator
{
    bool TrySuspend(string correlationId, string thumbprintSha256);

    void Resume(string correlationId);

    bool IsSuspended(string correlationId);
}
