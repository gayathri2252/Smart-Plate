using CertificateHandler.Shared.Security;
using DashboardCH.Models;

namespace CertificateHandler.DeviceTrust.Security;

/// <summary>
/// Minimum public-key strength for RS_03 (reject weak peer / local certs).
/// </summary>
public static class CertificateKeyStrengthPolicy
{
    public static void ValidateOrThrow(CertificateMetadata leaf)
    {
        ArgumentNullException.ThrowIfNull(leaf);
        CertificatePublicKeyInfo key = leaf.PublicKey ?? throw new ArgumentException("Certificate has no public key.");

        if (string.IsNullOrWhiteSpace(key.Algorithm))
        {
            throw new ArgumentException("Certificate public key algorithm is missing.");
        }

        if (key.KeyBits <= 0)
        {
            throw new ArgumentException("Certificate public key size is unknown.");
        }

        if (key.Algorithm.Contains("RSA", StringComparison.OrdinalIgnoreCase))
        {
            if (key.KeyBits < CertificatePublicKeyStrengthPolicy.MinimumRsaKeyBits)
            {
                throw new ArgumentException($"RSA key must be at least {CertificatePublicKeyStrengthPolicy.MinimumRsaKeyBits} bits.");
            }

            return;
        }

        if (key.Algorithm.Contains("EC", StringComparison.OrdinalIgnoreCase)
            || key.Algorithm.Contains("ECDsa", StringComparison.OrdinalIgnoreCase))
        {
            if (key.KeyBits < CertificatePublicKeyStrengthPolicy.MinimumEcdsaKeyBits)
            {
                throw new ArgumentException($"ECDSA key must be at least {CertificatePublicKeyStrengthPolicy.MinimumEcdsaKeyBits} bits.");
            }
        }
    }
}
