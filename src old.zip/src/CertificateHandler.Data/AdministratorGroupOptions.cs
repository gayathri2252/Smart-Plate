using CertificateHandler.Shared.Constants;
using Microsoft.Extensions.Configuration;

namespace CertificateHandler.Data;

/// <summary>
/// Platform local Windows group used to authorize MAXUM device administrators (GC export, cert-info APIs).
/// </summary>
public sealed class AdministratorGroupOptions
{
    public const string SectionName = "CertificateHandler:Login";

    public const string DefaultAdministratorGroup = DeviceAdministratorConstants.DefaultWindowsGroup;

    public string AdministratorGroup { get; set; } = DefaultAdministratorGroup;

    public static AdministratorGroupOptions Load()
    {
        string? fromPlatform = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.PlatformGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromPlatform))
        {
            return new AdministratorGroupOptions { AdministratorGroup = fromPlatform.Trim() };
        }

        string? fromLegacy = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.LegacyGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromLegacy))
        {
            return new AdministratorGroupOptions { AdministratorGroup = fromLegacy.Trim() };
        }

        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        AdministratorGroupOptions? options = configuration.GetSection(SectionName).Get<AdministratorGroupOptions>();
        if (options is null || string.IsNullOrWhiteSpace(options.AdministratorGroup))
        {
            return new AdministratorGroupOptions();
        }

        options.AdministratorGroup = options.AdministratorGroup.Trim();
        return options;
    }
}
