using System.Net.Http.Json;
using System.Text.Json;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// POSTs notification delivery to a configured HTTP endpoint (dev / gateway).
/// </summary>
public sealed class HttpPeerNotificationChannel : IPeerNotificationChannel, IDisposable
{
    private readonly HttpClient _client = new();

    public async Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default)
    {
        string? url = Environment.GetEnvironmentVariable("CH_PEER_NOTIFY_URL");
        if (string.IsNullOrWhiteSpace(url))
        {
            return false;
        }

        if (!Uri.TryCreate(url, UriKind.Absolute, out Uri? endpoint)
            || !string.Equals(endpoint.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase))
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Peer notification URL must be absolute HTTPS; delivery skipped.");
            return false;
        }

        try
        {
            using var response = await _client.PostAsJsonAsync(
                endpoint,
                new { notificationId, requestId, sentAtUtc = DateTimeOffset.UtcNow },
                cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return true;
            }

            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Peer notification HTTP delivery failed: {0}",
                response.StatusCode);
            return false;
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or TaskCanceledException)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "Peer notification HTTP error: {0}", ex.Message);
            return false;
        }
    }

    public void Dispose() => _client.Dispose();
}
