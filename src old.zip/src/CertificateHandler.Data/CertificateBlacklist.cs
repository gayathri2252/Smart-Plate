﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Trust;

namespace CertificateHandler.Data;

/// <summary>
/// Writes and reads the certificate blacklist with raw SQL statements that cast the enum
/// parameters explicitly.
/// </summary>
public sealed class CertificateBlackList : ICertificateBlackList
{
    #region Member Variables

    /// <summary>
    /// Casts the kind parameter to the trust list kind enum.
    /// </summary>
    private const string TRUST_KIND_CAST = $"CAST(@{DatabaseConstants.KIND_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.TRUST_LIST_KIND_TYPE})";

    /// <summary>
    /// Reads the certificate details for a thumbprint.
    /// </summary>
    private const string FIND_CERTIFICATE_SQL = $"SELECT certificate_id, device_id, subject_dn, issuer_dn, serial_number, not_before, not_after " +
        $"FROM {DatabaseConstants.SchemaName}.ch_certificate WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} LIMIT 1";

    /// <summary>
    /// Ends the active whitelist row of a thumbprint.
    /// </summary>
    private const string DEACTIVATE_WHITELIST_SQL = $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"SET is_active = FALSE, deactivated_at = @{DatabaseConstants.NOW_PARAMETER}, deactivated_by = @{DatabaseConstants.ACTOR_PARAMETER} " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND is_active AND list_kind = {TRUST_KIND_CAST}";

    /// <summary>
    /// Finds the latest blacklist row of a thumbprint, active or not.
    /// </summary>
    private const string FIND_BLACK_LIST_ROW_SQL = $"SELECT id, is_active FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND list_kind = {TRUST_KIND_CAST} " +
        "ORDER BY id DESC LIMIT 1";

    /// <summary>
    /// Inserts an active blacklist row.
    /// </summary>
    private const string INSERT_BLACK_LIST_ROW_SQL = $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        "(list_kind, certificate_id, thumbprint_sha256, device_id, subject_dn, serial_number, " +
        "not_before, not_after, added_by, added_at, comment, blacklist_reason_class, is_active) " +
        $"VALUES ({TRUST_KIND_CAST}, @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.THUMBPRINT_PARAMETER}, @{DatabaseConstants.DEVICE_ID_PARAMETER}, @{DatabaseConstants.SUBJECT_DN_PARAMETER}, @{DatabaseConstants.SERIAL_NUMBER_PARAMETER}, " +
        $"@{DatabaseConstants.NOT_BEFORE_PARAMETER}, @{DatabaseConstants.NOT_AFTER_PARAMETER}, @{DatabaseConstants.ACTOR_PARAMETER}, @{DatabaseConstants.NOW_PARAMETER}, @{DatabaseConstants.REASON_PARAMETER}, " +
        $"CAST(@{DatabaseConstants.REASON_CLASS_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.BLACK_LIST_REASON_CLASS_TYPE}), TRUE)";

    /// <summary>
    /// Makes an earlier blacklist row active again.
    /// </summary>
    private const string REACTIVATE_BLACK_LIST_ROW_SQL = $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        "SET is_active = TRUE, deactivated_at = NULL, deactivated_by = NULL, " +
        $"added_by = @{DatabaseConstants.ACTOR_PARAMETER}, added_at = @{DatabaseConstants.NOW_PARAMETER}, comment = @{DatabaseConstants.REASON_PARAMETER}, " +
        $"blacklist_reason_class = CAST(@{DatabaseConstants.REASON_CLASS_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.BLACK_LIST_REASON_CLASS_TYPE}) " +
        $"WHERE id = @{DatabaseConstants.ID_PARAMETER} AND NOT is_active";

    /// <summary>
    /// Writes the audit row of a blacklist write.
    /// </summary>
    private const string INSERT_AUDIT_SQL = $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
        "(event_type, event_timestamp, actor_identity, device_id, certificate_id, thumbprint_sha256, " +
        "previous_status, new_status, action_status, reason, details_json, result, source_component) " +
        $"VALUES (@{DatabaseConstants.EVENT_TYPE_PARAMETER}, @{DatabaseConstants.NOW_PARAMETER}, @{DatabaseConstants.ACTOR_PARAMETER}, @{DatabaseConstants.DEVICE_ID_PARAMETER}, @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.THUMBPRINT_PARAMETER}, " +
        $"@{DatabaseConstants.PREVIOUS_STATUS_PARAMETER}, @{DatabaseConstants.NEW_STATUS_PARAMETER}, @{DatabaseConstants.ACTION_STATUS_PARAMETER}, @{DatabaseConstants.REASON_PARAMETER}, CAST(@{DatabaseConstants.DETAILS_PARAMETER} AS jsonb), '{DatabaseConstants.RESULT_SUCCESS}', @{DatabaseConstants.SOURCE_PARAMETER})";

    /// <summary>
    /// Checks whether a thumbprint has an active blacklist row.
    /// </summary>
    private const string IS_BLACK_LISTED_SQL = $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND is_active AND list_kind = {TRUST_KIND_CAST} " +
        $"UNION ALL SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_propagated_blacklist " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER})";

    private readonly CertificateHandlerDbContext _dbContext;

    private readonly ISubnetBlacklistPropagator? _propagator;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the blacklist on top of the given database context.
    /// The context must not be null.
    /// </summary>
    public CertificateBlackList(CertificateHandlerDbContext dbContext, ISubnetBlacklistPropagator? propagator = null)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        _propagator = propagator;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Inserts an active blacklist row for the thumbprint, or reactivates an earlier one, ends any
    /// active whitelist row and writes one audit row, all in a single transaction.
    /// </summary>
    public async Task<BlackListResponse> BlackListAsync(
        BlackListRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(request.ThumbprintSha256);
            string reason = request.Reason?.Trim() ?? string.Empty;
            string actor = string.IsNullOrWhiteSpace(request.ActorIdentity)
                ? DatabaseConstants.SystemActor
                : request.ActorIdentity.Trim();

            // Guard: the audit row must always say why the thumbprint was blacklisted.
            BlacklistReasonPolicy.ValidateOrThrow(reason);

            DateTimeOffset now = request.EvaluatedAt.ToUniversalTime();

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

                CertificateRow? certificate = await FindCertificateAsync(connection, transaction, thumbprint, cancellationToken);

                // Guard: a blacklist row needs the certificate details, so an unknown thumbprint writes nothing.
                if (certificate is null)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_CERTIFICATE_NOT_FOUND, thumbprint);
                    return new BlackListResponse { Outcome = Models.CertificateBlackList.CertificateNotFound };
                }

                // One active trust decision is allowed per thumbprint, so an active whitelist
                // row has to be ended before a blacklist row can be active.
                int whitelistRowsEnded = await ExecuteAsync(
                    connection, transaction, DEACTIVATE_WHITELIST_SQL, cancellationToken,
                    (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                    (DatabaseConstants.NOW_PARAMETER, now),
                    (DatabaseConstants.ACTOR_PARAMETER, actor),
                    (DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Whitelist)));

                (long Id, bool IsActive)? existing = await FindBlackListRowAsync(connection, transaction, thumbprint, cancellationToken);

                Models.CertificateBlackList outcome;
                string previousStatus;

                if (existing is { IsActive: true })
                {
                    outcome = Models.CertificateBlackList.AlreadyBlackListed;
                    previousStatus = DatabaseConstants.STATUS_BLACK_LISTED;
                }
                else if (existing is not null)
                {
                    outcome = Models.CertificateBlackList.Reactivated;
                    previousStatus = whitelistRowsEnded > 0 ? DatabaseConstants.STATUS_WHITELISTED : DatabaseConstants.STATUS_BLACK_LIST_INACTIVE;

                    await ExecuteAsync(
                        connection, transaction, REACTIVATE_BLACK_LIST_ROW_SQL, cancellationToken,
                        (DatabaseConstants.ID_PARAMETER, existing.Value.Id),
                        (DatabaseConstants.ACTOR_PARAMETER, actor),
                        (DatabaseConstants.NOW_PARAMETER, now),
                        (DatabaseConstants.REASON_PARAMETER, reason),
                        (DatabaseConstants.REASON_CLASS_PARAMETER, PostgresEnumNames.ToPgName(request.ReasonClass)));
                }
                else
                {
                    outcome = Models.CertificateBlackList.Added;
                    previousStatus = whitelistRowsEnded > 0 ? DatabaseConstants.STATUS_WHITELISTED : DatabaseConstants.STATUS_NOT_LISTED;

                    await ExecuteAsync(
                        connection, transaction, INSERT_BLACK_LIST_ROW_SQL, cancellationToken,
                        (DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)),
                        (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificate.CertificateId),
                        (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                        (DatabaseConstants.DEVICE_ID_PARAMETER, certificate.DeviceId),
                        (DatabaseConstants.SUBJECT_DN_PARAMETER, certificate.SubjectDn),
                        (DatabaseConstants.SERIAL_NUMBER_PARAMETER, certificate.SerialNumber),
                        (DatabaseConstants.NOT_BEFORE_PARAMETER, certificate.NotBefore),
                        (DatabaseConstants.NOT_AFTER_PARAMETER, certificate.NotAfter),
                        (DatabaseConstants.ACTOR_PARAMETER, actor),
                        (DatabaseConstants.NOW_PARAMETER, now),
                        (DatabaseConstants.REASON_PARAMETER, reason),
                        (DatabaseConstants.REASON_CLASS_PARAMETER, PostgresEnumNames.ToPgName(request.ReasonClass)));
                }

                await ExecuteAsync(
                    connection, transaction, INSERT_AUDIT_SQL, cancellationToken,
                    (DatabaseConstants.EVENT_TYPE_PARAMETER, DatabaseConstants.AUDIT_EVENT_TYPE),
                    (DatabaseConstants.NOW_PARAMETER, now),
                    (DatabaseConstants.ACTOR_PARAMETER, actor),
                    (DatabaseConstants.DEVICE_ID_PARAMETER, certificate.DeviceId),
                    (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificate.CertificateId),
                    (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                    (DatabaseConstants.PREVIOUS_STATUS_PARAMETER, previousStatus),
                    (DatabaseConstants.NEW_STATUS_PARAMETER, DatabaseConstants.STATUS_BLACK_LISTED),
                    (DatabaseConstants.ACTION_STATUS_PARAMETER, ToActionStatus(outcome)),
                    (DatabaseConstants.REASON_PARAMETER, reason),
                    (DatabaseConstants.DETAILS_PARAMETER, BuildDetailsJson(certificate, request, now)),
                    (DatabaseConstants.SOURCE_PARAMETER, request.SourceComponent));

                await transaction.CommitAsync(cancellationToken);

                if (outcome == Models.CertificateBlackList.AlreadyBlackListed)
                {
                    CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_ALREADY_ACTIVE, thumbprint);
                }
                else
                {
                    CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_SAVED, thumbprint, outcome.ToString(), reason);
                    if (_propagator is not null)
                    {
                        try
                        {
                            await _propagator.PropagateAsync(thumbprint, reason, cancellationToken);
                        }
                        catch (Exception propagateEx) when (propagateEx is not OperationCanceledException)
                        {
                            CertificateHandlerLogger.Warning(
                                MessageIdGenerator.Next(),
                                "Local blacklist was saved. Subnet propagation failed: {0}",
                                propagateEx.Message);
                        }
                    }
                }

                ProtectedServiceGate.Shared.Deny(thumbprint);
                return new BlackListResponse { Outcome = outcome, CertificateId = certificate.CertificateId };
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_SAVE_FAILED, request.ThumbprintSha256, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Returns true when the thumbprint has an active blacklist row.
    /// The connection is opened for the lookup and closed again if it was closed before.
    /// </summary>
    public async Task<bool> IsBlackListedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(thumbprintSha256);

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using var command = new NpgsqlCommand(IS_BLACK_LISTED_SQL, connection);
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)));

                object? result = await command.ExecuteScalarAsync(cancellationToken);
                bool isBlackListed = result is true;
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_CHECKED, thumbprint, isBlackListed.ToString());
                return isBlackListed;
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_LOOKUP_FAILED, thumbprintSha256 ?? string.Empty, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the certificate details for the thumbprint from ch_certificate.
    /// Returns null when no certificate has this thumbprint.
    /// </summary>
    private static async Task<CertificateRow?> FindCertificateAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(FIND_CERTIFICATE_SQL, connection, transaction);
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        Guid? deviceId = await reader.IsDBNullAsync(DatabaseConstants.DEVICE_ID_COLUMN, cancellationToken)
            ? null
            : reader.GetGuid(DatabaseConstants.DEVICE_ID_COLUMN);

        string? serialNumber = await reader.IsDBNullAsync(DatabaseConstants.SERIAL_NUMBER_COLUMN, cancellationToken)
            ? null
            : reader.GetString(DatabaseConstants.SERIAL_NUMBER_COLUMN);

        return new CertificateRow(
            reader.GetGuid(DatabaseConstants.CERTIFICATE_ID_COLUMN),
            deviceId,
            reader.GetString(DatabaseConstants.SUBJECT_DN_COLUMN),
            reader.GetString(DatabaseConstants.ISSUER_DN_COLUMN),
            serialNumber,
            await reader.GetFieldValueAsync<DateTimeOffset>(DatabaseConstants.NOT_BEFORE_COLUMN, cancellationToken),
            await reader.GetFieldValueAsync<DateTimeOffset>(DatabaseConstants.NOT_AFTER_COLUMN, cancellationToken));
    }

    /// <summary>
    /// Finds the latest blacklist row for the thumbprint, active or not.
    /// Returns null when the thumbprint was never blacklisted.
    /// </summary>
    private static async Task<(long Id, bool IsActive)?> FindBlackListRowAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(FIND_BLACK_LIST_ROW_SQL, connection, transaction);
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)));

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return (reader.GetInt64(DatabaseConstants.BLACK_LIST_ROW_ID_COLUMN), reader.GetBoolean(DatabaseConstants.BLACK_LIST_ROW_IS_ACTIVE_COLUMN));
    }

    /// <summary>
    /// Runs one statement inside the transaction with the given named parameters.
    /// Returns the number of rows the statement changed.
    /// </summary>
    private static async Task<int> ExecuteAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string sql,
        CancellationToken cancellationToken,
        params (string Name, object? Value)[] parameters)
    {
        await using var command = new NpgsqlCommand(sql, connection, transaction);

        foreach ((string name, object? value) in parameters)
        {
            command.Parameters.Add(new NpgsqlParameter(name, value ?? DBNull.Value));
        }

        return await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Maps the blacklist outcome to the action status stored in the audit row.
    /// </summary>
    private static string ToActionStatus(Models.CertificateBlackList outcome)
    {
        return outcome switch
        {
            Models.CertificateBlackList.Added => DatabaseConstants.ACTION_ADDED,
            Models.CertificateBlackList.Reactivated => DatabaseConstants.ACTION_REACTIVATED,
            _ => DatabaseConstants.ACTION_ALREADY_BLACK_LISTED
        };
    }

    /// <summary>
    /// Builds the JSON with the certificate details, the reason class and the UTC time
    /// that is stored in the audit row.
    /// </summary>
    private static string BuildDetailsJson(CertificateRow certificate, BlackListRequest request, DateTimeOffset now)
    {
        return JsonSerializer.Serialize(new
        {
            subjectDn = certificate.SubjectDn,
            issuerDn = certificate.IssuerDn,
            serialNumber = certificate.SerialNumber,
            notBefore = certificate.NotBefore,
            notAfter = certificate.NotAfter,
            blacklistReasonClass = PostgresEnumNames.ToPgName(request.ReasonClass),
            evaluatedAtUtc = now
        });
    }

    #endregion

    #region Member Variables

    /// <summary>
    /// The certificate columns read from ch_certificate and written to the blacklist and audit rows.
    /// </summary>
    private sealed record CertificateRow(
        Guid CertificateId,
        Guid? DeviceId,
        string SubjectDn,
        string IssuerDn,
        string? SerialNumber,
        DateTimeOffset NotBefore,
        DateTimeOffset NotAfter);

    #endregion
}