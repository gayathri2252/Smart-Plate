using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
namespace CertificateHandler.Data;

/// <summary>
/// Selects production or simulated trust-event publishers (RS_27).
/// </summary>
public static class TrustUpdatePublisherFactory
{
    #region Public Methods

    public static ITrustUpdatePublisher Create(DatabaseOptions? options = null)
    {
        if (string.Equals(Environment.GetEnvironmentVariable("CH_USE_SIMULATED_TRUST_PUBLISHER"), "1", StringComparison.Ordinal))
        {
            return new SimulatedTrustUpdatePublisher();
        }

        CertificateHandlerDataAccess access = CertificateHandlerDataAccess.Create(options ?? new DatabaseOptions());
        return new DatabaseTrustEventPublisher(access.CreateDbContext());
    }

    public static ITrustUpdatePublisher Create(CertificateHandlerDataAccess dataAccess)
    {
        ArgumentNullException.ThrowIfNull(dataAccess);
        if (string.Equals(Environment.GetEnvironmentVariable("CH_USE_SIMULATED_TRUST_PUBLISHER"), "1", StringComparison.Ordinal))
        {
            return new SimulatedTrustUpdatePublisher();
        }

        return new DatabaseTrustEventPublisher(dataAccess.CreateDbContext());
    }

    #endregion
}
