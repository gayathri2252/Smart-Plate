using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Writes certificate expiry events to Windows Event Log for MCC / WEF pickup (RS_25).
/// </summary>
public sealed class WefCertificateEventWriter : IWefCertificateEventWriter
{
    private static int _eventSourceReady;

    #region Public Methods

    public bool WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter)
    {
        string message = $"WEF certificate expiry alert: {certificateName} thumbprint {thumbprint} notAfter {notAfter:u}";
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message);

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            const string source = "CertificateHandler";
            EnsureEventSource(source);

            using var log = new System.Diagnostics.EventLog("Application") { Source = source };
            log.WriteEntry(message, System.Diagnostics.EventLogEntryType.Warning, 42501);
            return true;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "WEF Event Log write failed: {0}", ex.Message);
            return false;
        }
    }

    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    private static void EnsureEventSource(string source)
    {
        if (System.Threading.Interlocked.CompareExchange(ref _eventSourceReady, 0, 0) == 1)
        {
            return;
        }

        if (!System.Diagnostics.EventLog.SourceExists(source))
        {
            System.Diagnostics.EventLog.CreateEventSource(source, "Application");
        }

        System.Threading.Interlocked.Exchange(ref _eventSourceReady, 1);
    }

    #endregion
}
