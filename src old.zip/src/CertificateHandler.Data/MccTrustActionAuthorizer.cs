using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// MCC trust actions are refused until one workstation was whitelisted on the SBC HMI.
/// After that, a Keycloak MCC Administrator and the SBC local administrator must both succeed (RS_34).
/// </summary>
public interface IHmiWorkstationWhitelistQuery
{
    Task<bool> HasHmiApprovedWorkstationAsync(CancellationToken cancellationToken = default);
}

public interface IKeycloakMccAdminVerifier
{
    Task<KeycloakAdminCheck> VerifyAsync(string accessToken, CancellationToken cancellationToken = default);
}

public interface ISbcLocalAdminCredentialVerifier
{
    Task<bool> ValidateAsync(string userName, string password, CancellationToken cancellationToken = default);
}

public sealed class KeycloakAdminCheck
{
    public bool IsAdministrator { get; init; }

    public string Subject { get; init; } = string.Empty;
}

public sealed class MccTrustActionRequest
{
    public string AccessToken { get; init; } = string.Empty;

    public string LocalAdministratorUser { get; init; } = string.Empty;

    public string LocalAdministratorPassword { get; init; } = string.Empty;
}

public sealed class MccTrustActionResult
{
    public bool IsAllowed { get; init; }

    public string DenialReason { get; init; } = string.Empty;

    public string KeycloakSubject { get; init; } = string.Empty;

    public string SbcAdministrator { get; init; } = string.Empty;

    public string ActorIdentity => IsAllowed ? $"mcc:{KeycloakSubject};sbc:{SbcAdministrator}" : string.Empty;
}

public sealed class MccTrustActionAuthorizer
{
    private readonly IHmiWorkstationWhitelistQuery _workstations;
    private readonly IKeycloakMccAdminVerifier _keycloak;
    private readonly ISbcLocalAdminCredentialVerifier _localAdmin;

    public MccTrustActionAuthorizer(
        IHmiWorkstationWhitelistQuery workstations,
        IKeycloakMccAdminVerifier keycloak,
        ISbcLocalAdminCredentialVerifier localAdmin)
    {
        _workstations = workstations ?? throw new ArgumentNullException(nameof(workstations));
        _keycloak = keycloak ?? throw new ArgumentNullException(nameof(keycloak));
        _localAdmin = localAdmin ?? throw new ArgumentNullException(nameof(localAdmin));
    }

    public async Task<MccTrustActionResult> AuthorizeAsync(MccTrustActionRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        bool workstationApproved;
        try
        {
            workstationApproved = await _workstations.HasHmiApprovedWorkstationAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            return Deny("The HMI workstation whitelist could not be verified.");
        }

        if (!workstationApproved)
        {
            return Deny("The first workstation for this SBC must be approved on the SBC HMI by a local administrator.");
        }

        KeycloakAdminCheck admin = await _keycloak.VerifyAsync(request.AccessToken, cancellationToken);
        if (!admin.IsAdministrator)
        {
            return Deny("A Keycloak MCC Administrator session is required.");
        }

        bool localOk = await _localAdmin.ValidateAsync(
            request.LocalAdministratorUser,
            request.LocalAdministratorPassword,
            cancellationToken);
        if (!localOk)
        {
            return Deny("SBC local administrator credentials were rejected.");
        }

        return new MccTrustActionResult
        {
            IsAllowed = true,
            KeycloakSubject = admin.Subject,
            SbcAdministrator = request.LocalAdministratorUser.Trim()
        };
    }

    private static MccTrustActionResult Deny(string reason) =>
        new() { IsAllowed = false, DenialReason = reason };
}

public sealed class HmiWorkstationWhitelistQuery : IHmiWorkstationWhitelistQuery
{
    private readonly NpgsqlDataSource _dataSource;

    public HmiWorkstationWhitelistQuery(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    public async Task<bool> HasHmiApprovedWorkstationAsync(CancellationToken cancellationToken = default)
    {
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry t " +
            $"JOIN {DatabaseConstants.SchemaName}.ch_device d ON d.device_id = t.device_id " +
            "WHERE t.is_active AND t.list_kind = CAST('WHITELIST' AS certificate_handler.trust_list_kind) " +
            "AND t.approval_channel = @channel " +
            "AND d.device_type IN (CAST('GCP_WORKSTATION' AS certificate_handler.device_type), CAST('OTHER' AS certificate_handler.device_type)))",
            connection);
        command.Parameters.AddWithValue("channel", TrustApprovalChannels.HmiLocal);
        object? exists = await command.ExecuteScalarAsync(cancellationToken);
        return exists is true;
    }
}

public sealed class HttpKeycloakMccAdminVerifier : IKeycloakMccAdminVerifier
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

    public async Task<KeycloakAdminCheck> VerifyAsync(string accessToken, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            return new KeycloakAdminCheck();
        }

        string? url = Environment.GetEnvironmentVariable("CH_KEYCLOAK_INTROSPECTION_URL");
        string? clientId = Environment.GetEnvironmentVariable("CH_KEYCLOAK_CLIENT_ID");
        string? clientSecret = Environment.GetEnvironmentVariable("CH_KEYCLOAK_CLIENT_SECRET");
        if (string.IsNullOrWhiteSpace(url) || string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
        {
            return new KeycloakAdminCheck();
        }

        string? role = Environment.GetEnvironmentVariable("CH_MCC_ADMIN_ROLE");
        if (string.IsNullOrWhiteSpace(role))
        {
            role = "MCC_ADMINISTRATOR";
        }

        using var content = new FormUrlEncodedContent(new Dictionary<string, string> { ["token"] = accessToken.Trim() });
        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, url) { Content = content };
        string basic = Convert.ToBase64String(Encoding.UTF8.GetBytes(clientId + ":" + clientSecret));
        httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);

        try
        {
            using HttpResponseMessage response = await Http.SendAsync(httpRequest, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                return new KeycloakAdminCheck();
            }

            await using Stream body = await response.Content.ReadAsStreamAsync(cancellationToken);
            using JsonDocument document = await JsonDocument.ParseAsync(body, cancellationToken: cancellationToken);
            return ReadCheck(document.RootElement, role);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or TaskCanceledException)
        {
            return new KeycloakAdminCheck();
        }
    }

    private static KeycloakAdminCheck ReadCheck(JsonElement root, string role)
    {
        if (!root.TryGetProperty("active", out JsonElement active) || active.ValueKind != JsonValueKind.True)
        {
            return new KeycloakAdminCheck();
        }

        string subject = ReadString(root, "preferred_username");
        if (subject.Length == 0)
        {
            subject = ReadString(root, "sub");
        }

        return new KeycloakAdminCheck
        {
            IsAdministrator = HasRole(root, role),
            Subject = subject
        };
    }

    private static bool HasRole(JsonElement root, string role)
    {
        if (root.TryGetProperty("realm_access", out JsonElement realm)
            && realm.TryGetProperty("roles", out JsonElement realmRoles)
            && Contains(realmRoles, role))
        {
            return true;
        }

        if (root.TryGetProperty("roles", out JsonElement roles) && Contains(roles, role))
        {
            return true;
        }

        if (!root.TryGetProperty("resource_access", out JsonElement resources) || resources.ValueKind != JsonValueKind.Object)
        {
            return false;
        }

        foreach (JsonProperty client in resources.EnumerateObject())
        {
            if (client.Value.TryGetProperty("roles", out JsonElement clientRoles) && Contains(clientRoles, role))
            {
                return true;
            }
        }

        return false;
    }

    private static bool Contains(JsonElement roles, string role)
    {
        if (roles.ValueKind != JsonValueKind.Array)
        {
            return false;
        }

        foreach (JsonElement item in roles.EnumerateArray())
        {
            if (item.ValueKind == JsonValueKind.String
                && string.Equals(item.GetString(), role, StringComparison.Ordinal))
            {
                return true;
            }
        }

        return false;
    }

    private static string ReadString(JsonElement root, string name) =>
        root.TryGetProperty(name, out JsonElement value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;
}
