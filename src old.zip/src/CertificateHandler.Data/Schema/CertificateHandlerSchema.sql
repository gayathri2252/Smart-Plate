-- =============================================================================
-- MAXUM Certificate Handler PostgreSQL schema (v1.2)
-- Baseline: Design Document v1.0 (ER 8.1 to 8.2), SBC_CH_RS_01 to RS_30, JIRA backlog.
--
-- v1.1 review fixes (planning and integrity)
--   One active trust row per thumbprint (whitelist or blacklist, not both at enforcement).
--   At most one PENDING queue row per certificate.
--   requested_by on pending (RS_17 requestor cannot self-approve).
--   FK links for audit, history, and event request ids; renewal cert chain column.
--   Thumbprint hex validation; bulk item must identify target.
--   updated_at maintenance; audit event_id uniqueness.
--   Dashboard KPIs scoped to managed trust entries and local identity certs.
--   Trigger syntax compatible with PostgreSQL 12 and later (EXECUTE PROCEDURE).
--
-- Re-run: this script is for greenfield install. Use migrations for upgrades.
-- Target: PostgreSQL 14+ on localhost (Windows 11 IoT MAXUM device).
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS certificate_handler;
SET search_path TO certificate_handler, public;

-- ---------------------------------------------------------------------------
-- Column types: this script targets PostgreSQL, which has no VARCHAR2 type, so the
-- VARCHAR columns below are correct. Each one is marked NOSONAR to silence the
-- Oracle-specific rule plsql:VarcharUsageCheck.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Enumerations
-- Enum labels are declarations and cannot reference a constant, so a label that
-- several enums share (PENDING, APPROVED, REJECTED, FAILED, SUCCESS) is repeated
-- on purpose. Its first definition is marked NOSONAR (rule plsql:S1192).
-- ---------------------------------------------------------------------------

-- Enum labels are declarations and cannot reference a constant; device_type and
-- certificate_role both legitimately define LOCAL_SBC and LOCAL_MIB.
CREATE TYPE device_type AS ENUM (
  'MAXUM_PEER',
  'LOCAL_SBC', -- NOSONAR
  'LOCAL_MIB', -- NOSONAR
  'GCP_WORKSTATION',
  'OTHER'
);

-- Operational lifecycle of a device record (not the TLS trust decision).
CREATE TYPE device_operational_status AS ENUM (
  'ACTIVE',
  'PROVISIONING_FAILED',
  'STORAGE_UNAVAILABLE',
  'DECOMMISSIONED'
);

CREATE TYPE certificate_role AS ENUM (
  'PEER',
  'LOCAL_SBC',
  'LOCAL_MIB',
  'GCP_APPLICATION',
  'FACTORY_DEFAULT',
  'TEMPORARY_POST_COMPROMISE'
);

CREATE TYPE trust_list_kind AS ENUM (
  'WHITELIST',
  'BLACKLIST'
);

CREATE TYPE pending_request_type AS ENUM (
  'PEER_ONBOARDING',
  'REINSTATEMENT',
  'WHITELIST_TO_BLACKLIST'
);

CREATE TYPE pending_request_status AS ENUM (
  'PENDING', -- NOSONAR
  'APPROVED', -- NOSONAR
  'REJECTED', -- NOSONAR
  'EXPIRED'
);

CREATE TYPE blacklist_reason_class AS ENUM (
  'SIGNATURE_FAILURE',
  'REVOKED_CERTIFICATE',
  'BROKEN_CHAIN',
  'MANUAL_ACTION',
  'SECURITY_INCIDENT'
);

CREATE TYPE renewal_request_status AS ENUM (
  'CREATED',
  'EXPORTED',
  'IMPORTED',
  'VALIDATED',
  'ACTIVATED',
  'FAILED', -- NOSONAR
  'ROLLED_BACK'
);

CREATE TYPE bulk_operation_status AS ENUM (
  'RUNNING',
  'COMPLETED',
  'COMPLETED_WITH_ERRORS',
  'TIMED_OUT',
  'CANCELLED'
);

CREATE TYPE trust_event_delivery_status AS ENUM (
  'PENDING',
  'DELIVERED',
  'FAILED',
  'RETRYING'
);

CREATE TYPE provisioning_outcome AS ENUM (
  'IN_PROGRESS',
  'SUCCESS', -- NOSONAR
  'FAILED',
  'MANUAL_INTERVENTION_REQUIRED'
);

CREATE TYPE peer_notification_status AS ENUM (
  'PENDING',
  'APPROVED',
  'REJECTED'
);

CREATE TYPE delivery_result AS ENUM (
  'SUCCESS',
  'FAILED'
);

-- ---------------------------------------------------------------------------
-- Shared: normalize thumbprint to uppercase SHA-256 hex (64 chars)
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION fn_normalize_thumbprint(raw TEXT)
RETURNS CHAR(64) AS $$
BEGIN
  IF raw IS NULL OR raw !~ '^[0-9A-Fa-f]{64}$' THEN
    RAISE EXCEPTION 'Invalid SHA-256 thumbprint (expected 64 hex characters)';
  END IF;
  RETURN upper(raw);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- ---------------------------------------------------------------------------
-- Shared: certificate role groups (single source of truth)
-- Enum labels cannot reference constants, so each group is defined once here
-- and reused by constraints and views instead of repeating the label lists.
-- IMMUTABLE is safe: an enum label never changes its meaning once created.
-- ---------------------------------------------------------------------------

-- Roles bound to this device: the SBC and MIB identity certificates.
CREATE OR REPLACE FUNCTION fn_local_device_roles()
RETURNS certificate_role[] AS $$
  SELECT ARRAY['LOCAL_SBC', 'LOCAL_MIB']::certificate_role[];
$$ LANGUAGE sql IMMUTABLE;

-- Roles counted as managed local identity certificates (dashboard KPIs).
CREATE OR REPLACE FUNCTION fn_local_identity_roles()
RETURNS certificate_role[] AS $$
  SELECT fn_local_device_roles() || 'GCP_APPLICATION'::certificate_role;
$$ LANGUAGE sql IMMUTABLE;

-- Roles a factory provisioning attempt may target.
CREATE OR REPLACE FUNCTION fn_factory_target_roles()
RETURNS certificate_role[] AS $$
  SELECT fn_local_device_roles() || 'FACTORY_DEFAULT'::certificate_role;
$$ LANGUAGE sql IMMUTABLE;

-- ---------------------------------------------------------------------------
-- Shared: constants
-- SQL has no constant declaration, so each value that is used in several places
-- is defined once as an IMMUTABLE function. PostgreSQL folds the call to a
-- constant while planning, so indexes and partial-index predicates still match.
-- ---------------------------------------------------------------------------

-- A SHA-256 thumbprint is stored as 64 uppercase hex characters.
CREATE OR REPLACE FUNCTION fn_thumbprint_pattern()
RETURNS TEXT AS $$
  SELECT '^[0-9A-F]{64}$'::text;
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION fn_whitelist_kind()
RETURNS trust_list_kind AS $$
  SELECT 'WHITELIST'::trust_list_kind;
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION fn_blacklist_kind()
RETURNS trust_list_kind AS $$
  SELECT 'BLACKLIST'::trust_list_kind;
$$ LANGUAGE sql IMMUTABLE;

-- ---------------------------------------------------------------------------
-- 1. MAXUM device (design 8.2)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_device (
  device_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_code               VARCHAR(128) NOT NULL, -- NOSONAR
  device_name               VARCHAR(256), -- NOSONAR
  device_type               device_type NOT NULL DEFAULT 'MAXUM_PEER',
  maxum_ip                  INET,
  operational_status        device_operational_status NOT NULL DEFAULT 'ACTIVE',
  primary_certificate_id    UUID,  -- FK added after ch_certificate exists
  created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_ch_device_code UNIQUE (device_code)
);

CREATE INDEX ix_ch_device_maxum_ip ON ch_device (maxum_ip);
CREATE INDEX ix_ch_device_operational_status ON ch_device (operational_status);

COMMENT ON TABLE ch_device IS
  'Device identity for HMI and filters. TLS enforcement uses certificate thumbprint via ch_trust_list_entry, not operational_status.';

-- ---------------------------------------------------------------------------
-- 2. Secure key reference (TPM / CNG  - no private key material)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_secure_key_reference (
  key_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id           UUID NOT NULL REFERENCES ch_device (device_id) ON DELETE RESTRICT,
  key_label           VARCHAR(256) NOT NULL, -- NOSONAR
  protection_mode     VARCHAR(64) NOT NULL DEFAULT 'TPM_NON_EXPORTABLE', -- NOSONAR
  is_exportable       BOOLEAN NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at        TIMESTAMPTZ,
  CONSTRAINT uq_ch_secure_key_device_label UNIQUE (device_id, key_label),
  CONSTRAINT chk_ch_key_not_exportable CHECK (is_exportable = FALSE)
);

CREATE INDEX ix_ch_secure_key_device ON ch_secure_key_reference (device_id);

-- ---------------------------------------------------------------------------
-- 3. Certificate metadata (design 8.2)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_certificate (
  certificate_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id                 UUID REFERENCES ch_device (device_id) ON DELETE RESTRICT,
  certificate_role          certificate_role NOT NULL,
  thumbprint_sha256         CHAR(64) NOT NULL,
  subject_dn                TEXT NOT NULL,
  issuer_dn                 TEXT NOT NULL,
  serial_number             VARCHAR(128), -- NOSONAR
  not_before                TIMESTAMPTZ NOT NULL,
  not_after                 TIMESTAMPTZ NOT NULL,
  public_key_algorithm      VARCHAR(64), -- NOSONAR
  public_key_pem              TEXT,
  cert_der                  BYTEA,
  windows_store_location    VARCHAR(128), -- NOSONAR
  windows_store_thumbprint  CHAR(64),
  is_active                 BOOLEAN NOT NULL DEFAULT TRUE,
  superseded_by_certificate_id UUID,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_ch_cert_validity CHECK (not_after > not_before),
  CONSTRAINT chk_ch_cert_thumbprint_hex CHECK (thumbprint_sha256 ~ fn_thumbprint_pattern())
);

CREATE UNIQUE INDEX uq_ch_certificate_active_thumbprint_role
  ON ch_certificate (thumbprint_sha256, certificate_role)
  WHERE is_active;

CREATE INDEX ix_ch_certificate_thumbprint ON ch_certificate (thumbprint_sha256);
CREATE INDEX ix_ch_certificate_not_after ON ch_certificate (not_after) WHERE is_active;
CREATE INDEX ix_ch_certificate_device ON ch_certificate (device_id);
CREATE INDEX ix_ch_certificate_role_active ON ch_certificate (certificate_role) WHERE is_active;

ALTER TABLE ch_device
  ADD CONSTRAINT fk_ch_device_primary_cert
  FOREIGN KEY (primary_certificate_id) REFERENCES ch_certificate (certificate_id)
  ON DELETE SET NULL;

ALTER TABLE ch_certificate
  ADD CONSTRAINT fk_ch_certificate_superseded
  FOREIGN KEY (superseded_by_certificate_id) REFERENCES ch_certificate (certificate_id)
  ON DELETE SET NULL;

COMMENT ON TABLE ch_certificate IS
  'X.509 metadata. Peer certs require device_id. Local SBC/MIB/GCP rows use certificate_role. Private keys remain in Windows store / TPM.';

-- ---------------------------------------------------------------------------
-- 4. Trust list (design 8.1)  - enforcement source of truth
-- ---------------------------------------------------------------------------

CREATE TABLE ch_trust_list_entry (
  id                        BIGSERIAL PRIMARY KEY,
  list_kind                 trust_list_kind NOT NULL,
  certificate_id            UUID NOT NULL REFERENCES ch_certificate (certificate_id) ON DELETE RESTRICT,
  thumbprint_sha256         CHAR(64) NOT NULL,
  device_id                 UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  subject_dn                TEXT,
  serial_number             VARCHAR(128), -- NOSONAR
  not_before                TIMESTAMPTZ,
  not_after                 TIMESTAMPTZ,
  added_by                  VARCHAR(256) NOT NULL DEFAULT 'SYSTEM', -- NOSONAR
  added_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
  comment                   TEXT,
  blacklist_reason_class    blacklist_reason_class,
  is_active                 BOOLEAN NOT NULL DEFAULT TRUE,
  deactivated_at            TIMESTAMPTZ,
  deactivated_by            VARCHAR(256), -- NOSONAR
  approval_channel          VARCHAR(32) NOT NULL DEFAULT 'HMI_LOCAL', -- NOSONAR
  CONSTRAINT chk_ch_trust_thumbprint_hex CHECK (thumbprint_sha256 ~ fn_thumbprint_pattern()),
  CONSTRAINT chk_ch_trust_blacklist_reason
    CHECK (
      list_kind = fn_whitelist_kind()
      OR blacklist_reason_class IS NOT NULL
      OR (comment IS NOT NULL AND btrim(comment) <> '')
    ),
  CONSTRAINT chk_ch_trust_deactivated_consistency
    CHECK (
      (is_active = TRUE AND deactivated_at IS NULL)
      OR (is_active = FALSE AND deactivated_at IS NOT NULL)
    )
);

-- Exactly one active trust decision per thumbprint (cannot be whitelisted and blacklisted).
CREATE UNIQUE INDEX uq_ch_trust_one_active_per_thumbprint
  ON ch_trust_list_entry (thumbprint_sha256)
  WHERE is_active;

CREATE INDEX ix_ch_trust_blacklist_lookup
  ON ch_trust_list_entry (thumbprint_sha256)
  WHERE is_active AND list_kind = fn_blacklist_kind();

CREATE INDEX ix_ch_trust_whitelist_lookup
  ON ch_trust_list_entry (thumbprint_sha256)
  WHERE is_active AND list_kind = fn_whitelist_kind();

CREATE INDEX ix_ch_trust_device_active ON ch_trust_list_entry (device_id) WHERE is_active;

COMMENT ON TABLE ch_trust_list_entry IS
  'Active row defines TLS trust. Deactivate prior row and insert new row on reinstatement or cert rotation; never UPDATE list_kind in place. approval_channel is HMI_LOCAL, MCC, or MAXUM_AUTO.';

-- Propagated blacklist (RS_33). Blocks TLS even when this device has no local certificate row yet.
CREATE TABLE ch_propagated_blacklist (
  thumbprint_sha256   CHAR(64) PRIMARY KEY,
  reason              TEXT NOT NULL,
  origin_device_code  VARCHAR(128) NOT NULL, -- NOSONAR
  received_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_ch_propagated_thumbprint_hex CHECK (thumbprint_sha256 ~ fn_thumbprint_pattern())
);

-- ---------------------------------------------------------------------------
-- 5. Certificate status history (append-only, RS_18)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_certificate_status_history (
  history_id          BIGSERIAL PRIMARY KEY,
  certificate_id      UUID NOT NULL REFERENCES ch_certificate (certificate_id) ON DELETE RESTRICT,
  device_id           UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  previous_status     VARCHAR(64) NOT NULL, -- NOSONAR
  new_status          VARCHAR(64) NOT NULL, -- NOSONAR
  changed_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  changed_by          VARCHAR(256) NOT NULL, -- NOSONAR
  reason              TEXT,
  related_request_id  UUID
);

CREATE INDEX ix_ch_cert_history_cert_time ON ch_certificate_status_history (certificate_id, changed_at);

-- ---------------------------------------------------------------------------
-- 6. Pending requests (RS_19, RS_22, RS_17)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_pending_request (
  request_id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_type                pending_request_type NOT NULL DEFAULT 'PEER_ONBOARDING',
  certificate_id              UUID NOT NULL REFERENCES ch_certificate (certificate_id) ON DELETE RESTRICT,
  device_id                   UUID NOT NULL REFERENCES ch_device (device_id) ON DELETE RESTRICT,
  requester_identity          VARCHAR(256), -- NOSONAR
  requested_by                VARCHAR(256) NOT NULL, -- NOSONAR
  status                      pending_request_status NOT NULL DEFAULT 'PENDING',
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at                  TIMESTAMPTZ NOT NULL,
  decided_at                  TIMESTAMPTZ,
  decided_by                  VARCHAR(256), -- NOSONAR
  decision_reason             TEXT,
  connection_correlation_id   UUID,
  CONSTRAINT chk_ch_pending_expires_after_create CHECK (expires_at > created_at),
  CONSTRAINT chk_ch_pending_decision_consistency
    CHECK (
      (status = 'PENDING' AND decided_at IS NULL)
      OR (status <> 'PENDING' AND decided_at IS NOT NULL)
    )
);

-- One open queue slot per certificate (pending queue cap applies to count of these rows).
CREATE UNIQUE INDEX uq_ch_pending_one_open_per_certificate
  ON ch_pending_request (certificate_id)
  WHERE status = 'PENDING';

CREATE INDEX ix_ch_pending_status_created ON ch_pending_request (status, created_at DESC);
CREATE INDEX ix_ch_pending_expires ON ch_pending_request (expires_at) WHERE status = 'PENDING';
CREATE INDEX ix_ch_pending_device ON ch_pending_request (device_id);

ALTER TABLE ch_certificate_status_history
  ADD CONSTRAINT fk_ch_history_pending_request
  FOREIGN KEY (related_request_id) REFERENCES ch_pending_request (request_id)
  ON DELETE SET NULL;

CREATE TABLE ch_reinstatement_approval (
  approval_id         BIGSERIAL PRIMARY KEY,
  request_id          UUID NOT NULL REFERENCES ch_pending_request (request_id) ON DELETE CASCADE,
  approval_sequence   SMALLINT NOT NULL CHECK (approval_sequence IN (1, 2)),
  approver_identity   VARCHAR(256) NOT NULL, -- NOSONAR
  decision            VARCHAR(16) NOT NULL CHECK (decision IN ('APPROVED', 'REJECTED')), -- NOSONAR
  decided_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  comments            TEXT,
  CONSTRAINT uq_ch_reinstatement_seq UNIQUE (request_id, approval_sequence),
  CONSTRAINT uq_ch_reinstatement_approver UNIQUE (request_id, approver_identity)
);

-- ---------------------------------------------------------------------------
-- 7. CSR / renewal (RS_06, RS_26)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_csr_renewal_request (
  renewal_request_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  certificate_id            UUID NOT NULL REFERENCES ch_certificate (certificate_id) ON DELETE RESTRICT,
  key_id                    UUID NOT NULL REFERENCES ch_secure_key_reference (key_id) ON DELETE RESTRICT,
  csr_pem                   TEXT,
  status                    renewal_request_status NOT NULL DEFAULT 'CREATED',
  created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  exported_at               TIMESTAMPTZ,
  exported_by               VARCHAR(256), -- NOSONAR
  imported_at               TIMESTAMPTZ,
  activated_at              TIMESTAMPTZ,
  failure_reason            TEXT,
  previous_certificate_id   UUID REFERENCES ch_certificate (certificate_id) ON DELETE SET NULL
);

CREATE INDEX ix_ch_renewal_status ON ch_csr_renewal_request (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Factory provisioning (RS_01)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_factory_provisioning_attempt (
  attempt_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id                 UUID NOT NULL REFERENCES ch_device (device_id) ON DELETE RESTRICT,
  target_role               certificate_role NOT NULL,
  outcome                   provisioning_outcome NOT NULL DEFAULT 'IN_PROGRESS',
  retry_count               INT NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
  max_retries               INT NOT NULL DEFAULT 3 CHECK (max_retries >= 0),
  started_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at              TIMESTAMPTZ,
  error_message             TEXT,
  resulting_certificate_id  UUID REFERENCES ch_certificate (certificate_id) ON DELETE SET NULL,
  CONSTRAINT chk_ch_factory_target_role
    CHECK (target_role = ANY (fn_factory_target_roles()))
);

-- ---------------------------------------------------------------------------
-- 9. Audit log (RS_09, RS_18)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_audit_log (
  audit_id            BIGSERIAL PRIMARY KEY,
  event_id            UUID NOT NULL DEFAULT gen_random_uuid(),
  event_type          VARCHAR(128) NOT NULL, -- NOSONAR
  event_timestamp     TIMESTAMPTZ NOT NULL DEFAULT now(),
  actor_identity      VARCHAR(256) NOT NULL, -- NOSONAR
  device_id           UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  request_id          UUID REFERENCES ch_pending_request (request_id) ON DELETE SET NULL,
  certificate_id      UUID REFERENCES ch_certificate (certificate_id) ON DELETE SET NULL,
  thumbprint_sha256   CHAR(64),
  previous_status     VARCHAR(64), -- NOSONAR
  new_status          VARCHAR(64), -- NOSONAR
  action_status       VARCHAR(64), -- NOSONAR
  reason              TEXT,
  details_json        JSONB,
  result              VARCHAR(32) NOT NULL DEFAULT 'SUCCESS', -- NOSONAR
  source_component    VARCHAR(128), -- NOSONAR
  CONSTRAINT uq_ch_audit_event_id UNIQUE (event_id),
  CONSTRAINT chk_ch_audit_thumbprint_hex
    CHECK (thumbprint_sha256 IS NULL OR thumbprint_sha256 ~ fn_thumbprint_pattern())
);

CREATE INDEX ix_ch_audit_time ON ch_audit_log (event_timestamp DESC);
CREATE INDEX ix_ch_audit_request ON ch_audit_log (request_id);
CREATE INDEX ix_ch_audit_thumbprint ON ch_audit_log (thumbprint_sha256);
CREATE INDEX ix_ch_audit_event_type_time ON ch_audit_log (event_type, event_timestamp DESC);

-- ---------------------------------------------------------------------------
-- 10. Bulk blacklist (RS_13)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_bulk_operation (
  bulk_operation_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  initiated_by                VARCHAR(256) NOT NULL, -- NOSONAR
  reason                      TEXT NOT NULL CHECK (btrim(reason) <> ''),
  max_batch_size              INT NOT NULL CHECK (max_batch_size > 0),
  processing_timeout_seconds  INT NOT NULL CHECK (processing_timeout_seconds > 0),
  status                      bulk_operation_status NOT NULL DEFAULT 'RUNNING',
  started_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at                TIMESTAMPTZ
);

CREATE TABLE ch_bulk_operation_item (
  item_id             BIGSERIAL PRIMARY KEY,
  bulk_operation_id   UUID NOT NULL REFERENCES ch_bulk_operation (bulk_operation_id) ON DELETE CASCADE,
  device_id           UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  thumbprint_sha256   CHAR(64),
  item_status         VARCHAR(32) NOT NULL, -- NOSONAR
  error_message       TEXT,
  processed_at        TIMESTAMPTZ,
  CONSTRAINT chk_ch_bulk_item_target
    CHECK (device_id IS NOT NULL OR thumbprint_sha256 IS NOT NULL),
  CONSTRAINT chk_ch_bulk_item_thumbprint_hex
    CHECK (thumbprint_sha256 IS NULL OR thumbprint_sha256 ~ fn_thumbprint_pattern())
);

CREATE INDEX ix_ch_bulk_item_operation ON ch_bulk_operation_item (bulk_operation_id);

-- ---------------------------------------------------------------------------
-- 11. Trust events / outbox (RS_27)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_trust_event (
  event_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id           UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  thumbprint_sha256   CHAR(64) NOT NULL,
  new_trust_status    VARCHAR(32) NOT NULL, -- NOSONAR
  related_request_id  UUID REFERENCES ch_pending_request (request_id) ON DELETE SET NULL,
  actor_identity      VARCHAR(256), -- NOSONAR
  occurred_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  payload_json        JSONB NOT NULL,
  CONSTRAINT chk_ch_trust_event_thumbprint_hex CHECK (thumbprint_sha256 ~ fn_thumbprint_pattern())
);

CREATE TABLE ch_trust_event_delivery (
  delivery_id         BIGSERIAL PRIMARY KEY,
  event_id            UUID NOT NULL REFERENCES ch_trust_event (event_id) ON DELETE CASCADE,
  subscriber_name     VARCHAR(256) NOT NULL, -- NOSONAR
  status              trust_event_delivery_status NOT NULL DEFAULT 'PENDING',
  attempt_count       INT NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
  last_attempt_at     TIMESTAMPTZ,
  last_error          TEXT,
  delivered_at        TIMESTAMPTZ,
  CONSTRAINT uq_ch_event_subscriber UNIQUE (event_id, subscriber_name)
);

-- ---------------------------------------------------------------------------
-- 12. Peer notifications (RS_10)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_peer_notification (
  notification_id       BIGSERIAL PRIMARY KEY,
  request_id            UUID NOT NULL REFERENCES ch_pending_request (request_id) ON DELETE CASCADE,
  target_device_id      UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  notification_status   peer_notification_status NOT NULL,
  sent_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  delivery_result       delivery_result NOT NULL,
  retry_count           INT NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
  last_error            TEXT
);

CREATE INDEX ix_ch_peer_notification_request ON ch_peer_notification (request_id);

-- ---------------------------------------------------------------------------
-- 13. Validation results (RS_03, RS_02 KPI)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_validation_result (
  validation_id       BIGSERIAL PRIMARY KEY,
  evaluated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  thumbprint_sha256   CHAR(64),
  device_id           UUID REFERENCES ch_device (device_id) ON DELETE SET NULL,
  validation_step     VARCHAR(64) NOT NULL, -- NOSONAR
  passed              BOOLEAN NOT NULL,
  failure_reason      TEXT,
  time_verified       BOOLEAN NOT NULL DEFAULT TRUE,
  auto_blacklisted    BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT chk_ch_validation_thumbprint_hex
    CHECK (thumbprint_sha256 IS NULL OR thumbprint_sha256 ~ fn_thumbprint_pattern())
);

CREATE INDEX ix_ch_validation_evaluated ON ch_validation_result (evaluated_at DESC);
CREATE INDEX ix_ch_validation_failed_recent
  ON ch_validation_result (evaluated_at DESC) WHERE NOT passed;

-- ---------------------------------------------------------------------------
-- 14. Runtime configuration
-- ---------------------------------------------------------------------------

CREATE TABLE ch_system_config (
  config_key          VARCHAR(128) PRIMARY KEY, -- NOSONAR
  config_value        TEXT NOT NULL,
  description         TEXT,
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by          VARCHAR(256) NOT NULL DEFAULT 'system' -- NOSONAR
);

INSERT INTO ch_system_config (config_key, config_value, description) VALUES
  ('pending_request_timeout_hours', '24', 'RS_22 default pending auto-expiry'),
  ('max_pending_connections', '10', 'Design  - max concurrent PENDING rows (queue cap)'),
  ('bulk_blacklist_max_batch_size', '50', 'RS_13  - tune per product policy'),
  ('bulk_blacklist_timeout_seconds', '300', 'RS_13 processing timeout'),
  ('ui_page_size', '50', 'RS_20 pagination default'),
  ('revocation_hard_fail', 'false', 'RS_03 default: unknown CRL/OCSP status soft-fails; a revoked certificate still fails'),
  ('clock_skew_tolerance_minutes', '5', 'Design  - reduce after hardware characterization'),
  ('validation_failure_kpi_window_hours', '24', 'RS_02 dashboard KPI window')
ON CONFLICT (config_key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- 15. Schema migrations (RS_29)
-- ---------------------------------------------------------------------------

CREATE TABLE ch_schema_migration (
  migration_id        VARCHAR(64) PRIMARY KEY, -- NOSONAR
  applied_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  applied_by          VARCHAR(256) NOT NULL -- NOSONAR
);

INSERT INTO ch_schema_migration (migration_id, applied_by)
VALUES ('v1.2_security', 'certificate_handler_ddl')
ON CONFLICT (migration_id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Triggers: updated_at, immutability (RS_18)
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ch_device_updated_at
  BEFORE UPDATE ON ch_device
  FOR EACH ROW EXECUTE PROCEDURE fn_set_updated_at();

CREATE TRIGGER trg_ch_certificate_updated_at
  BEFORE UPDATE ON ch_certificate
  FOR EACH ROW EXECUTE PROCEDURE fn_set_updated_at();

CREATE OR REPLACE FUNCTION fn_deny_audit_mutation()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Audit and status history rows are append-only';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ch_audit_log_immutable
  BEFORE UPDATE OR DELETE ON ch_audit_log
  FOR EACH ROW EXECUTE PROCEDURE fn_deny_audit_mutation();

CREATE TRIGGER trg_ch_cert_history_immutable
  BEFORE UPDATE OR DELETE ON ch_certificate_status_history
  FOR EACH ROW EXECUTE PROCEDURE fn_deny_audit_mutation();

-- Optional: enforce reinstatement approvals only on REINSTATEMENT requests
CREATE OR REPLACE FUNCTION fn_reinstatement_request_type()
RETURNS TRIGGER AS $$
DECLARE
  v_type pending_request_type;
BEGIN
  SELECT request_type INTO v_type FROM ch_pending_request WHERE request_id = NEW.request_id;
  IF v_type IS DISTINCT FROM 'REINSTATEMENT' THEN
    RAISE EXCEPTION 'Reinstatement approvals apply only to REINSTATEMENT pending requests';
  END IF;
  IF NEW.approver_identity = (SELECT requested_by FROM ch_pending_request WHERE request_id = NEW.request_id) THEN
    RAISE EXCEPTION 'Requestor cannot approve their own reinstatement request (RS_17)';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ch_reinstatement_rules
  BEFORE INSERT ON ch_reinstatement_approval
  FOR EACH ROW EXECUTE PROCEDURE fn_reinstatement_request_type();

-- Sync trust row thumbprint with certificate on insert (planning guard)
CREATE OR REPLACE FUNCTION fn_trust_entry_thumbprint_matches_cert()
RETURNS TRIGGER AS $$
DECLARE
  v_tp CHAR(64);
BEGIN
  SELECT thumbprint_sha256 INTO v_tp FROM ch_certificate WHERE certificate_id = NEW.certificate_id;
  IF v_tp IS DISTINCT FROM NEW.thumbprint_sha256 THEN
    RAISE EXCEPTION 'Trust entry thumbprint must match linked certificate';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ch_trust_thumbprint_match
  BEFORE INSERT OR UPDATE OF certificate_id, thumbprint_sha256 ON ch_trust_list_entry
  FOR EACH ROW EXECUTE PROCEDURE fn_trust_entry_thumbprint_matches_cert();

-- ---------------------------------------------------------------------------
-- Dashboard views (RS_02)
-- ---------------------------------------------------------------------------

CREATE OR REPLACE VIEW vw_dashboard_counts AS
SELECT
  (SELECT COUNT(*) FROM ch_trust_list_entry t WHERE t.is_active AND t.list_kind = fn_whitelist_kind()) AS whitelisted_count,
  (SELECT COUNT(*) FROM ch_trust_list_entry t WHERE t.is_active AND t.list_kind = fn_blacklist_kind()) AS blacklisted_count,
  (SELECT COUNT(*) FROM ch_pending_request p WHERE p.status = 'PENDING') AS pending_count,
  (SELECT COUNT(*) FROM ch_certificate c
     WHERE c.is_active
       AND c.certificate_role = ANY (fn_local_identity_roles())
       AND c.not_after < now()) AS expired_local_cert_count,
  (SELECT COUNT(*) FROM ch_certificate c
     WHERE c.is_active
       AND c.certificate_role = ANY (fn_local_identity_roles())
       AND c.not_after >= now()
       AND c.not_after < now() + interval '90 days') AS expiring_90_days,
  (SELECT COUNT(*) FROM ch_certificate c
     WHERE c.is_active
       AND c.certificate_role = ANY (fn_local_identity_roles())
       AND c.not_after >= now()
       AND c.not_after < now() + interval '30 days') AS expiring_30_days,
  (SELECT COUNT(*) FROM ch_validation_result v
     WHERE NOT v.passed
       AND v.evaluated_at >= now() - (
         SELECT (config_value || ' hours')::interval
         FROM ch_system_config
         WHERE config_key = 'validation_failure_kpi_window_hours'
       )) AS validation_failures_window,
  (SELECT COUNT(*) FROM (
     SELECT thumbprint_sha256 AS tp FROM ch_trust_list_entry WHERE is_active
     UNION
     SELECT thumbprint_sha256 FROM ch_certificate
       WHERE is_active AND certificate_role = ANY (fn_local_identity_roles())
   ) managed) AS total_managed_certificates;

CREATE OR REPLACE VIEW vw_pending_queue_overview AS
SELECT
  pr.request_id,
  d.device_code AS device_identifier,
  pr.request_type,
  pr.requester_identity,
  pr.requested_by,
  pr.created_at AS request_date,
  pr.status AS current_status,
  d.maxum_ip,
  c.thumbprint_sha256,
  c.subject_dn,
  pr.expires_at
FROM ch_pending_request pr
JOIN ch_device d ON d.device_id = pr.device_id
JOIN ch_certificate c ON c.certificate_id = pr.certificate_id;

-- ---------------------------------------------------------------------------
-- TLS enforcement (application query pattern, RS_11)
-- ---------------------------------------------------------------------------
-- The application reads the list kind of the active trust entry whose thumbprint
-- equals the normalized thumbprint of the presented certificate (see
-- fn_normalize_thumbprint). At most one active entry exists per thumbprint.
--
-- Before a request is queued, the application counts the rows that are still
-- pending and compares that count with max_pending_connections in ch_system_config.

-- ---------------------------------------------------------------------------
-- Security hardening (v1.2)  - RS_18, local IoT attack surface reduction
-- ---------------------------------------------------------------------------

ALTER FUNCTION fn_normalize_thumbprint(TEXT) SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_local_device_roles() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_local_identity_roles() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_factory_target_roles() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_thumbprint_pattern() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_whitelist_kind() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_blacklist_kind() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_set_updated_at() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_deny_audit_mutation() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_reinstatement_request_type() SET search_path = certificate_handler, pg_catalog;
ALTER FUNCTION fn_trust_entry_thumbprint_matches_cert() SET search_path = certificate_handler, pg_catalog;

CREATE OR REPLACE FUNCTION fn_deny_trust_hard_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Trust list rows must be deactivated, not deleted';
END;
$$ LANGUAGE plpgsql SET search_path = certificate_handler, pg_catalog;

CREATE TRIGGER trg_ch_trust_no_delete
  BEFORE DELETE ON ch_trust_list_entry
  FOR EACH ROW EXECUTE PROCEDURE fn_deny_trust_hard_delete();

CREATE OR REPLACE FUNCTION fn_deny_trust_list_kind_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.list_kind IS DISTINCT FROM NEW.list_kind THEN
    RAISE EXCEPTION 'Trust list kind cannot change in place; deactivate and insert a new row';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = certificate_handler, pg_catalog;

CREATE TRIGGER trg_ch_trust_no_kind_update
  BEFORE UPDATE OF list_kind ON ch_trust_list_entry
  FOR EACH ROW EXECUTE PROCEDURE fn_deny_trust_list_kind_change();

REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA certificate_handler FROM PUBLIC;
REVOKE TRUNCATE ON ALL TABLES IN SCHEMA certificate_handler FROM PUBLIC;

-- Least-privilege runtime role (created by installer / ops; password via CH_DB_PASSWORD):
--   CREATE ROLE "Valmet$CertificateManagement" LOGIN PASSWORD '...';
--   GRANT USAGE ON SCHEMA certificate_handler TO "Valmet$CertificateManagement";
--   GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA certificate_handler TO "Valmet$CertificateManagement";
--   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA certificate_handler TO "Valmet$CertificateManagement";
--   REVOKE DELETE ON ch_audit_log, ch_certificate_status_history, ch_trust_list_entry,
--     ch_validation_result FROM "Valmet$CertificateManagement";
-- Bootstrap and migrations use an admin account; application runtime uses Valmet$CertificateManagement.
