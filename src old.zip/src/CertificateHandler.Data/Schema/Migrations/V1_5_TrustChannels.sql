-- =============================================================================
-- Certificate Handler migration v1.5_trust_channels
--
-- RS_03: unknown CRL/OCSP status soft-fails unless an administrator already chose hard-fail.
-- RS_32 / RS_34: approval_channel records HMI_LOCAL, MCC, or MAXUM_AUTO.
-- RS_33: propagated blacklist blocks a thumbprint received from a subnet peer.
-- =============================================================================

ALTER TABLE certificate_handler.ch_trust_list_entry
  ADD COLUMN IF NOT EXISTS approval_channel VARCHAR(32) NOT NULL DEFAULT 'HMI_LOCAL';

CREATE TABLE IF NOT EXISTS certificate_handler.ch_propagated_blacklist (
  thumbprint_sha256   CHAR(64) PRIMARY KEY,
  reason              TEXT NOT NULL,
  origin_device_code  VARCHAR(128) NOT NULL,
  received_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT chk_ch_propagated_thumbprint_hex CHECK (thumbprint_sha256 ~ '^[0-9A-Fa-f]{64}$')
);

UPDATE certificate_handler.ch_system_config
SET config_value = 'false',
    description = 'RS_03 default: unknown CRL/OCSP status soft-fails; a revoked certificate still fails'
WHERE config_key = 'revocation_hard_fail'
  AND description = 'RS_03  - unknown revocation fails closed';

INSERT INTO certificate_handler.ch_schema_migration (migration_id, applied_by)
VALUES ('v1.5_trust_channels', 'certificate_handler_ddl')
ON CONFLICT (migration_id) DO NOTHING;
