﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Globalization;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;
using NpgsqlTypes;
using DataConstants = CertificateHandler.Data.Constants.Constants;
using CertificateHandler.Data.Infrastructure;

namespace CertificateHandler.Data;

/// <summary>
/// Reads the dashboard counts, one page of pending requests and the active trust list entries from the
/// trust database. The counts cover the certificate expiry, the validation failures inside the configured
/// window and the trust lists. Only stored columns are read, so no certificate chain is built during a load.
/// </summary>
public sealed class CertificateDashboard : ICertificateDashboard
{
    #region Member Variables

    /// <summary>
    /// Escape character used in the search pattern.
    /// It is also named in the ESCAPE part of the ILIKE conditions.
    /// </summary>
    private const string LIKE_ESCAPE = "\\";

    /// <summary>
    /// LIKE wildcard that matches any run of characters.
    /// It is escaped when it appears in the text typed by the user.
    /// </summary>
    private const string LIKE_ANY_TEXT = "%";

    /// <summary>
    /// LIKE wildcard that matches exactly one character.
    /// It is escaped when it appears in the text typed by the user.
    /// </summary>
    private const string LIKE_ANY_CHARACTER = "_";

    /// <summary>
    /// Status value of a request that is still waiting for a decision.
    /// Used by the pending request counts and by the request page.
    /// </summary>
    private const string PENDING_STATUS = "PENDING";

    /// <summary>
    /// List kind value of an entry on the whitelist.
    /// Used when the trust list entries are counted.
    /// </summary>
    private const string WHITELIST_KIND = "WHITELIST";

    /// <summary>
    /// List kind value of an entry on the blacklist.
    /// Used when the trust list entries are counted.
    /// </summary>
    private const string BLACKLIST_KIND = "BLACKLIST";

    /// <summary>
    /// Certificate roles that are managed by the Certificate Handler on this device.
    /// Only active certificates with one of these roles are counted as managed and in the expiry cards.
    /// </summary>
    private const string MANAGED_CERTIFICATE_ROLES = "'LOCAL_SBC', 'LOCAL_MIB', 'GCP_APPLICATION'";

    /// <summary>
    /// Database type name of the pending request type.
    /// The request type parameter is cast to this type in the filter.
    /// </summary>
    private const string PENDING_REQUEST_PG_TYPE = "pending_request_type";

    /// <summary>
    /// Name of the parameter that holds the current time.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string NOW_PARAMETER = "now";

    /// <summary>
    /// Name of the parameter that holds the end of the soon window.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string EXPIRING_SOON_PARAMETER = "expiringSoon";

    /// <summary>
    /// Name of the parameter that holds the end of the later window.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string EXPIRING_LATER_PARAMETER = "expiringLater";

    /// <summary>
    /// Name of the parameter that holds the selected request type.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string REQUEST_TYPE_PARAMETER = "requestType";

    /// <summary>
    /// Name of the parameter that holds the search text.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string SEARCH_PARAMETER = "search";

    /// <summary>
    /// Name of the parameter that holds the ILIKE pattern built from the search text.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string PATTERN_PARAMETER = "pattern";

    /// <summary>
    /// Name of the parameter that holds the number of rows on the page.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string LIMIT_PARAMETER = "limit";

    /// <summary>
    /// Name of the parameter that holds the number of rows to skip.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string OFFSET_PARAMETER = "offset";

    /// <summary>
    /// Key of the system setting that holds the validation failure window in hours.
    /// The setting is read from the system configuration table on every load.
    /// </summary>
    private const string FAILURE_WINDOW_CONFIG_KEY = "validation_failure_kpi_window_hours";

    /// <summary>
    /// Name of the parameter that holds the key of the setting to read.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string CONFIG_KEY_PARAMETER = "configKey";

    /// <summary>
    /// Name of the parameter that holds the start of the validation failure window.
    /// Used in the SQL text and when the parameter is added.
    /// </summary>
    private const string FAILURE_WINDOW_START_PARAMETER = "failureWindowStart";

    /// <summary>
    /// Statement that reads the stored validation failure window.
    /// It returns no row when the setting has not been stored.
    /// </summary>
    private const string FAILURE_WINDOW_SQL =
        $"SELECT config_value FROM {DatabaseConstants.SchemaName}.ch_system_config WHERE config_key = @{CONFIG_KEY_PARAMETER}";

    /// <summary>
    /// FROM and WHERE part shared by the request count and the request page.
    /// Keeps only pending requests that match the request type and the search text. The search looks in the
    /// device name, the device code, the MAXUM IP address, the requester and the status.
    /// </summary>
    private const string REQUESTS_FROM_AND_WHERE =
        $"""
        FROM {DatabaseConstants.SchemaName}.ch_pending_request r
        JOIN {DatabaseConstants.SchemaName}.ch_device d ON d.device_id = r.device_id
        WHERE r.status = '{PENDING_STATUS}'
          AND (CAST(@{REQUEST_TYPE_PARAMETER} AS text) IS NULL
               OR r.request_type = CAST(@{REQUEST_TYPE_PARAMETER} AS {DatabaseConstants.SchemaName}.{PENDING_REQUEST_PG_TYPE}))
          AND (@{SEARCH_PARAMETER} = ''
               OR d.device_name ILIKE @{PATTERN_PARAMETER} ESCAPE '{LIKE_ESCAPE}'
               OR d.device_code ILIKE @{PATTERN_PARAMETER} ESCAPE '{LIKE_ESCAPE}'
               OR host(d.maxum_ip) ILIKE @{PATTERN_PARAMETER} ESCAPE '{LIKE_ESCAPE}'
               OR r.requested_by ILIKE @{PATTERN_PARAMETER} ESCAPE '{LIKE_ESCAPE}'
               OR r.status::text ILIKE @{PATTERN_PARAMETER} ESCAPE '{LIKE_ESCAPE}')
        """;

    /// <summary>
    /// Statement that returns every dashboard count in one row.
    /// It reads stored columns only, so no certificate chain is built.
    /// The expiry limits are exclusive, as in the vw_dashboard_counts view: a certificate that expires exactly
    /// 30 or 90 days from now is not counted. The total counts each managed thumbprint once, whether it is
    /// on the trust list, a local certificate, or both.
    /// </summary>
    private const string COUNTS_SQL =
        $"""
        SELECT t.whitelisted, t.blacklisted, p.pending, c.expired, g.total,
               c.expiring_soon, c.expiring_later, m.matching, v.validation_failures
        FROM (SELECT COUNT(*) FILTER (WHERE not_after >= @{NOW_PARAMETER} AND not_after < @{EXPIRING_SOON_PARAMETER}) AS expiring_soon,
                     COUNT(*) FILTER (WHERE not_after >= @{NOW_PARAMETER} AND not_after < @{EXPIRING_LATER_PARAMETER}) AS expiring_later,
                     COUNT(*) FILTER (WHERE not_after < @{NOW_PARAMETER}) AS expired
              FROM {DatabaseConstants.SchemaName}.ch_certificate
              WHERE is_active AND certificate_role IN ({MANAGED_CERTIFICATE_ROLES})) c
        CROSS JOIN (SELECT COUNT(*) AS total
                    FROM (SELECT thumbprint_sha256
                          FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry
                          WHERE is_active
                          UNION
                          SELECT thumbprint_sha256
                          FROM {DatabaseConstants.SchemaName}.ch_certificate
                          WHERE is_active AND certificate_role IN ({MANAGED_CERTIFICATE_ROLES})) managed) g
        CROSS JOIN (SELECT COUNT(*) FILTER (WHERE list_kind = '{WHITELIST_KIND}') AS whitelisted,
                           COUNT(*) FILTER (WHERE list_kind = '{BLACKLIST_KIND}') AS blacklisted
                    FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry
                    WHERE is_active) t
        CROSS JOIN (SELECT COUNT(*) AS pending
                    FROM {DatabaseConstants.SchemaName}.ch_pending_request
                    WHERE status = '{PENDING_STATUS}') p
        CROSS JOIN (SELECT COUNT(*) AS matching
                    {REQUESTS_FROM_AND_WHERE}) m
        CROSS JOIN (SELECT COUNT(*) AS validation_failures
                    FROM {DatabaseConstants.SchemaName}.ch_validation_result
                    WHERE NOT passed AND evaluated_at >= @{FAILURE_WINDOW_START_PARAMETER}) v
        """;

    /// <summary>
    /// SELECT, FROM and WHERE part of the statement that returns one page of pending requests.
    /// The ORDER BY part is added from the fixed sort expressions below, never from user text.
    /// </summary>
    private const string PAGE_SELECT_SQL =
        $"""
        SELECT r.request_id, COALESCE(NULLIF(d.device_name, ''), d.device_code),
               r.request_type::text, r.requested_by, r.created_at, COALESCE(host(d.maxum_ip), '')
        {REQUESTS_FROM_AND_WHERE}
        """;

    /// <summary>
    /// Paging part of the page statement.
    /// </summary>
    private const string PAGE_LIMIT_SQL = $"LIMIT @{LIMIT_PARAMETER} OFFSET @{OFFSET_PARAMETER}";

    /// <summary>Sort expression for the request date.</summary>
    private const string SORT_BY_REQUEST_DATE = "r.created_at";

    /// <summary>Sort expression for the device name, or the device code when the device has no name.</summary>
    private const string SORT_BY_DEVICE_NAME = "lower(COALESCE(NULLIF(d.device_name, ''), d.device_code))";

    /// <summary>Sort expression for the MAXUM IP address; inet values sort by address, not as text.</summary>
    private const string SORT_BY_IP_ADDRESS = "d.maxum_ip";

    /// <summary>Sort expression for the request type.</summary>
    private const string SORT_BY_REQUEST_TYPE = "r.request_type::text";

    /// <summary>Sort expression for the user who raised the request.</summary>
    private const string SORT_BY_REQUESTED_BY = "lower(r.requested_by)";

    /// <summary>
    /// Tie-breaker added after every sort expression, so rows with equal values keep the same order on every load.
    /// </summary>
    private const string SORT_TIE_BREAKER = "r.created_at DESC, r.request_id";

    /// <summary>Descending sort direction; rows without a value come last.</summary>
    private const string SORT_DESCENDING = "DESC NULLS LAST";

    /// <summary>Ascending sort direction; rows without a value come last.</summary>
    private const string SORT_ASCENDING = "ASC NULLS LAST";

    /// <summary>Position of the whitelist count in the counts row.</summary>
    private const int WHITELISTED_COLUMN = 0;

    /// <summary>Position of the blacklist count in the counts row.</summary>
    private const int BLACKLISTED_COLUMN = 1;

    /// <summary>Position of the pending request count in the counts row.</summary>
    private const int PENDING_COLUMN = 2;

    /// <summary>Position of the expired certificate count in the counts row.</summary>
    private const int EXPIRED_COLUMN = 3;

    /// <summary>Position of the total certificate count in the counts row.</summary>
    private const int TOTAL_COLUMN = 4;

    /// <summary>Position of the expiring soon count in the counts row.</summary>
    private const int EXPIRING_SOON_COLUMN = 5;

    /// <summary>Position of the expiring later count in the counts row.</summary>
    private const int EXPIRING_LATER_COLUMN = 6;

    /// <summary>Position of the matching request count in the counts row.</summary>
    private const int MATCHING_COLUMN = 7;

    /// <summary>Position of the validation failure count in the counts row.</summary>
    private const int VALIDATION_FAILURES_COLUMN = 8;

    /// <summary>Position of the request id in a page row.</summary>
    private const int REQUEST_ID_COLUMN = 0;

    /// <summary>Position of the device name or code in a page row.</summary>
    private const int DEVICE_IDENTIFIER_COLUMN = 1;

    /// <summary>Position of the request type in a page row.</summary>
    private const int REQUEST_TYPE_COLUMN = 2;

    /// <summary>Position of the requesting user in a page row.</summary>
    private const int REQUESTED_BY_COLUMN = 3;

    /// <summary>Position of the request date in a page row.</summary>
    private const int REQUEST_DATE_COLUMN = 4;

    /// <summary>Position of the MAXUM IP address in a page row.</summary>
    private const int MAXUM_IP_COLUMN = 5;

    /// <summary>
    /// Statement that returns every active whitelist and blacklist entry, newest first and then by id.
    /// The device is taken from the entry, or from its certificate when the entry has none. The certificate
    /// is joined with LEFT JOIN, so every active entry is listed and the lists always match the card counts.
    /// It reads stored columns only, so no certificate chain is built.
    /// </summary>
    private const string TRUST_LISTS_SQL =
        $"""
        SELECT t.list_kind::text, t.id, COALESCE(NULLIF(d.device_name, ''), d.device_code, ''),
               COALESCE(NULLIF(t.subject_dn, ''), c.subject_dn, ''), t.thumbprint_sha256,
               COALESCE(NULLIF(btrim(t.comment), ''), t.blacklist_reason_class::text, ''),
               t.added_by, t.added_at, COALESCE(host(d.maxum_ip), '')
        FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry t
        LEFT JOIN {DatabaseConstants.SchemaName}.ch_certificate c ON c.certificate_id = t.certificate_id
        LEFT JOIN {DatabaseConstants.SchemaName}.ch_device d ON d.device_id = COALESCE(t.device_id, c.device_id)
        WHERE t.is_active
        ORDER BY t.added_at DESC, t.id
        """;

    /// <summary>Position of the list kind in a trust list row.</summary>
    private const int TRUST_LIST_KIND_COLUMN = 0;

    /// <summary>Position of the entry id in a trust list row.</summary>
    private const int TRUST_ENTRY_ID_COLUMN = 1;

    /// <summary>Position of the device name or code in a trust list row.</summary>
    private const int TRUST_DEVICE_COLUMN = 2;

    /// <summary>Position of the certificate subject in a trust list row.</summary>
    private const int TRUST_SUBJECT_COLUMN = 3;

    /// <summary>Position of the thumbprint in a trust list row.</summary>
    private const int TRUST_THUMBPRINT_COLUMN = 4;

    /// <summary>Position of the comment or blacklist reason in a trust list row.</summary>
    private const int TRUST_REASON_COLUMN = 5;

    /// <summary>Position of the user who added the entry in a trust list row.</summary>
    private const int TRUST_ADDED_BY_COLUMN = 6;

    /// <summary>Position of the time the entry was added in a trust list row.</summary>
    private const int TRUST_ADDED_AT_COLUMN = 7;

    /// <summary>Position of the MAXUM IP address in a trust list row.</summary>
    private const int TRUST_MAXUM_IP_COLUMN = 8;

    /// <summary>Data source that opens one connection for each dashboard load.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>Clock used to get the current time for the expiry counts.</summary>
    private readonly TimeProvider _timeProvider;

    /// <summary>
    /// What one page of the dashboard request table should contain: the filter, the order and the page position.
    /// </summary>
    /// <param name="RequestType">Request type to show, or null for every type.</param>
    /// <param name="Search">Normalized search text; empty matches every request.</param>
    /// <param name="SortColumn">Column the requests are ordered by.</param>
    /// <param name="SortDescending">True to order from high to low.</param>
    /// <param name="PageSize">Maximum number of requests on the page.</param>
    /// <param name="Offset">Number of matching requests before the page.</param>
    private readonly record struct DashboardPageQuery(
        string? RequestType,
        string Search,
        DashboardSortColumn SortColumn,
        bool SortDescending,
        int PageSize,
        long Offset);

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the dashboard query on top of the given data source, using the system clock.
    /// The data source must not be null.
    /// </summary>
    public CertificateDashboard(NpgsqlDataSource dataSource)
        : this(dataSource, TimeProvider.System)
    {
    }

    /// <summary>
    /// Creates the dashboard query on top of the given data source and clock.
    /// Neither may be null.
    /// </summary>
    public CertificateDashboard(NpgsqlDataSource dataSource, TimeProvider timeProvider)
    {
        // Without a connection the dashboard query cannot run.
        if (dataSource is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DASHBOARD_DATA_SOURCE_IS_NULL);
            throw new ArgumentNullException(nameof(dataSource));
        }

        // Without a clock the expiry counts cannot be calculated.
        if (timeProvider is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DASHBOARD_CLOCK_IS_NULL);
            throw new ArgumentNullException(nameof(timeProvider));
        }

        _dataSource = dataSource;
        _timeProvider = timeProvider;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns the counts over all rows and the requested page of pending requests that match
    /// the filter, both read in one snapshot so they agree. A page after the last one has no rows.
    /// </summary>
    public async Task<DashboardPage> GetDashboardPageAsync(
        int pageNumber,
        int pageSize,
        DashboardRequestFilter? filter = null,
        CancellationToken cancellationToken = default)
    {
        // Page numbers start at 1.
        if (pageNumber < DataConstants.FIRST_PAGE_NUMBER)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DatabaseConstants.DASHBOARD_PAGE_NUMBER_OUT_OF_RANGE,
                pageNumber.ToString(CultureInfo.InvariantCulture),
                DataConstants.FIRST_PAGE_NUMBER.ToString(CultureInfo.InvariantCulture));
            throw new ArgumentOutOfRangeException(nameof(pageNumber));
        }

        // A page holds at least one row and never more than the maximum, so a load stays small.
        if (pageSize < DataConstants.MIN_PAGE_SIZE || pageSize > DataConstants.MAX_PAGE_SIZE)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DatabaseConstants.DASHBOARD_PAGE_SIZE_OUT_OF_RANGE,
                pageSize.ToString(CultureInfo.InvariantCulture),
                DataConstants.MIN_PAGE_SIZE.ToString(CultureInfo.InvariantCulture),
                DataConstants.MAX_PAGE_SIZE.ToString(CultureInfo.InvariantCulture));
            throw new ArgumentOutOfRangeException(nameof(pageSize));
        }

        DateTimeOffset now = _timeProvider.GetUtcNow();
        long offset = (long)(pageNumber - DataConstants.FIRST_PAGE_NUMBER) * pageSize;
        string? requestType = ToPgRequestType(filter?.RequestType);
        string search = NormalizeSearchText(filter?.SearchText);

        await using NpgsqlConnection connection = await DatabaseServerConnection.OpenAsync(_dataSource, cancellationToken);
        await using NpgsqlTransaction transaction =
            await connection.BeginTransactionAsync(IsolationLevel.RepeatableRead, cancellationToken);

        int failureWindowHours = await ReadFailureWindowHoursAsync(connection, transaction, cancellationToken);
        (DashboardCounts counts, long matching) =
            await ReadCountsAsync(connection, transaction, now, failureWindowHours, requestType, search, cancellationToken);
        List<DashboardRequestRow> rows = await ReadPageAsync(
         connection,
         transaction,
         new DashboardPageQuery(
         requestType,
         search,
         filter?.SortColumn ?? DashboardSortColumn.RequestDate,
         filter?.SortDescending ?? true,
         pageSize,
         offset),
     cancellationToken);

        await transaction.CommitAsync(cancellationToken);

        return new DashboardPage
        {
            Counts = counts,
            Rows = rows,
            PageNumber = pageNumber,
            PageSize = pageSize,
            MatchingRequests = matching
        };
    }

    /// <summary>
    /// Returns the active whitelist and blacklist entries, each newest first, read in one statement.
    /// Inactive entries are left out.
    /// </summary>
    public async Task<DashboardTrustLists> GetTrustListsAsync(CancellationToken cancellationToken = default)
    {
        var whitelisted = new List<DashboardTrustListRow>();
        var blacklisted = new List<DashboardTrustListRow>();

        await using NpgsqlConnection connection = await DatabaseServerConnection.OpenAsync(_dataSource, cancellationToken);
        await using var command = new NpgsqlCommand(TRUST_LISTS_SQL, connection);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            var row = new DashboardTrustListRow
            {
                EntryId = reader.GetInt64(TRUST_ENTRY_ID_COLUMN),
                DeviceIdentifier = reader.GetString(TRUST_DEVICE_COLUMN),
                Subject = reader.GetString(TRUST_SUBJECT_COLUMN),
                Thumbprint = reader.GetString(TRUST_THUMBPRINT_COLUMN),
                Reason = reader.GetString(TRUST_REASON_COLUMN),
                AddedBy = reader.GetString(TRUST_ADDED_BY_COLUMN),
                AddedAt = await reader.GetFieldValueAsync<DateTimeOffset>(TRUST_ADDED_AT_COLUMN, cancellationToken),
                MaxumIp = reader.GetString(TRUST_MAXUM_IP_COLUMN)
            };

            // Each active entry is on exactly one of the two lists.
            string listKind = reader.GetString(TRUST_LIST_KIND_COLUMN);

            if (listKind == WHITELIST_KIND)
            {
                whitelisted.Add(row);
            }
            else if (listKind == BLACKLIST_KIND)
            {
                blacklisted.Add(row);
            }
        }

        return new DashboardTrustLists { Whitelisted = whitelisted, Blacklisted = blacklisted };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the validation failure window in hours from the system settings. A missing,
    /// non-numeric or out-of-range value gives the default window, so the dashboard still loads.
    /// </summary>
    private static async Task<int> ReadFailureWindowHoursAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(FAILURE_WINDOW_SQL, connection, transaction);
        command.Parameters.Add(new NpgsqlParameter(CONFIG_KEY_PARAMETER, NpgsqlDbType.Text)
        {
            Value = FAILURE_WINDOW_CONFIG_KEY
        });

        object? stored = await command.ExecuteScalarAsync(cancellationToken);

        // No stored setting means the default window applies.
        if (stored is not string text)
        {
            return DataConstants.DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS;
        }

        if (int.TryParse(text.Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out int hours)
            && hours >= DataConstants.MIN_VALIDATION_FAILURE_WINDOW_HOURS
            && hours <= DataConstants.MAX_VALIDATION_FAILURE_WINDOW_HOURS)
        {
            return hours;
        }

        // A bad setting must not stop the dashboard, so it is reported and the default is used.
        CertificateHandlerLogger.Warning(
            MessageIdGenerator.Next(),
            DatabaseConstants.DASHBOARD_FAILURE_WINDOW_INVALID,
            DataConstants.MIN_VALIDATION_FAILURE_WINDOW_HOURS.ToString(CultureInfo.InvariantCulture),
            DataConstants.MAX_VALIDATION_FAILURE_WINDOW_HOURS.ToString(CultureInfo.InvariantCulture),
            DataConstants.DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS.ToString(CultureInfo.InvariantCulture));

        return DataConstants.DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS;
    }

    /// <summary>
    /// Counts the trust list entries, the pending requests, the certificates by expiry, the validation
    /// failures inside the window, and the requests that match the filter, in one statement.
    /// </summary>
    private static async Task<(DashboardCounts Counts, long Matching)> ReadCountsAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        DateTimeOffset now,
        int failureWindowHours,
        string? requestType,
        string search,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(COUNTS_SQL, connection, transaction);
        command.Parameters.AddWithValue(NOW_PARAMETER, now);
        command.Parameters.AddWithValue(EXPIRING_SOON_PARAMETER, now.AddDays(DataConstants.EXPIRING_SOON_DAYS));
        command.Parameters.AddWithValue(EXPIRING_LATER_PARAMETER, now.AddDays(DataConstants.EXPIRING_LATER_DAYS));
        command.Parameters.AddWithValue(FAILURE_WINDOW_START_PARAMETER, now.AddHours(-failureWindowHours));
        AddFilterParameters(command, requestType, search);

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
        await reader.ReadAsync(cancellationToken);

        var counts = new DashboardCounts
        {
            Whitelisted = reader.GetInt64(WHITELISTED_COLUMN),
            Blacklisted = reader.GetInt64(BLACKLISTED_COLUMN),
            Pending = reader.GetInt64(PENDING_COLUMN),
            Expired = reader.GetInt64(EXPIRED_COLUMN),
            Total = reader.GetInt64(TOTAL_COLUMN),
            ExpiringWithin30Days = reader.GetInt64(EXPIRING_SOON_COLUMN),
            ExpiringWithin90Days = reader.GetInt64(EXPIRING_LATER_COLUMN),
            ValidationFailures = reader.GetInt64(VALIDATION_FAILURES_COLUMN),
            ValidationFailureWindowHours = failureWindowHours
        };

        return (counts, reader.GetInt64(MATCHING_COLUMN));
    }



    /// <summary>
    /// Reads one page of pending requests that match the filter, in the requested order. Equal values are
    /// ordered newest first and then by id, so the order is the same on every load.
    /// </summary>
    private static async Task<List<DashboardRequestRow>> ReadPageAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        DashboardPageQuery query,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(BuildPageSql(query.SortColumn, query.SortDescending), connection, transaction);
        AddFilterParameters(command, query.RequestType, query.Search);
        command.Parameters.AddWithValue(LIMIT_PARAMETER, query.PageSize);
        command.Parameters.AddWithValue(OFFSET_PARAMETER, query.Offset);

        var rows = new List<DashboardRequestRow>(query.PageSize);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            rows.Add(new DashboardRequestRow
            {
                RequestId = reader.GetGuid(REQUEST_ID_COLUMN),
                DeviceIdentifier = reader.GetString(DEVICE_IDENTIFIER_COLUMN),
                RequestType = ToDisplayText(reader.GetString(REQUEST_TYPE_COLUMN)),
                RequestedBy = reader.GetString(REQUESTED_BY_COLUMN),
                RequestDate = await reader.GetFieldValueAsync<DateTimeOffset>(REQUEST_DATE_COLUMN, cancellationToken),
                MaxumIp = reader.GetString(MAXUM_IP_COLUMN)
            });
        }

        return rows;
    }

    /// <summary>
    /// Adds the request type and search parameters. The search text is always sent as a parameter,
    /// never joined into the statement.
    /// </summary>
    private static void AddFilterParameters(NpgsqlCommand command, string? requestType, string search)
    {
        command.Parameters.Add(new NpgsqlParameter(REQUEST_TYPE_PARAMETER, NpgsqlDbType.Text)
        {
            Value = (object?)requestType ?? DBNull.Value
        });
        command.Parameters.Add(new NpgsqlParameter(SEARCH_PARAMETER, NpgsqlDbType.Text) { Value = search });
        command.Parameters.Add(new NpgsqlParameter(PATTERN_PARAMETER, NpgsqlDbType.Text) { Value = BuildLikePattern(search) });
    }

    /// <summary>
    /// Builds the page statement for the given sort. The sort expression and direction come from fixed
    /// constants, so nothing typed by the user ends up in the statement. An unknown column sorts by date.
    /// </summary>
    private static string BuildPageSql(DashboardSortColumn sortColumn, bool sortDescending)
    {
        string expression = sortColumn switch
        {
            DashboardSortColumn.DeviceName => SORT_BY_DEVICE_NAME,
            DashboardSortColumn.IpAddress => SORT_BY_IP_ADDRESS,
            DashboardSortColumn.RequestType => SORT_BY_REQUEST_TYPE,
            DashboardSortColumn.RequestedBy => SORT_BY_REQUESTED_BY,
            _ => SORT_BY_REQUEST_DATE
        };

        string direction = sortDescending ? SORT_DESCENDING : SORT_ASCENDING;

        return $"{PAGE_SELECT_SQL}\nORDER BY {expression} {direction}, {SORT_TIE_BREAKER}\n{PAGE_LIMIT_SQL}";
    }

    /// <summary>
    /// Trims the search text and cuts it to the longest allowed length. Null becomes empty.
    /// </summary>
    private static string NormalizeSearchText(string? searchText)
    {
        string text = searchText?.Trim() ?? string.Empty;

        return text.Length > DataConstants.MAX_SEARCH_LENGTH
            ? text[..DataConstants.MAX_SEARCH_LENGTH]
            : text;
    }

    /// <summary>
    /// Builds a contains pattern for ILIKE. The characters that mean something to LIKE are escaped,
    /// so they are matched as typed.
    /// </summary>
    private static string BuildLikePattern(string search)
    {
        string escaped = search
            .Replace(LIKE_ESCAPE, LIKE_ESCAPE + LIKE_ESCAPE, StringComparison.Ordinal)
            .Replace(LIKE_ANY_TEXT, LIKE_ESCAPE + LIKE_ANY_TEXT, StringComparison.Ordinal)
            .Replace(LIKE_ANY_CHARACTER, LIKE_ESCAPE + LIKE_ANY_CHARACTER, StringComparison.Ordinal);

        return LIKE_ANY_TEXT + escaped + LIKE_ANY_TEXT;
    }

    /// <summary>
    /// Returns the database name of the request type, or null when no type is selected.
    /// </summary>
    private static string? ToPgRequestType(PendingRequestType? requestType)
    {
        return requestType switch
        {
            PendingRequestType.PeerOnboarding => DataConstants.PEER_ONBOARDING_DB_NAME,
            PendingRequestType.Reinstatement => DataConstants.REINSTATEMENT_DB_NAME,
            PendingRequestType.WhitelistToBlacklist => DataConstants.WHITELIST_TO_BLACKLIST_DB_NAME,
            _ => null
        };
    }

    /// <summary>
    /// Returns the readable text of a request type; an unknown type is shown as stored.
    /// </summary>
    private static string ToDisplayText(string pgRequestType)
    {
        return pgRequestType switch
        {
            DataConstants.PEER_ONBOARDING_DB_NAME => DataConstants.PEER_ONBOARDING_TEXT,
            DataConstants.REINSTATEMENT_DB_NAME => DataConstants.REINSTATEMENT_TEXT,
            DataConstants.WHITELIST_TO_BLACKLIST_DB_NAME => DataConstants.WHITELIST_TO_BLACKLIST_TEXT,
            _ => pgRequestType
        };
    }

    #endregion
}
