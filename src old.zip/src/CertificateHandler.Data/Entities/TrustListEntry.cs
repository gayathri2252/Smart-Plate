// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Active whitelist or blacklist row used for TLS trust enforcement.
/// </summary>
public class TrustListEntry
{
    #region Public Properties

    public long Id { get; set; }

    public TrustListKind ListKind { get; set; }

    public Guid CertificateId { get; set; }

    public string ThumbprintSha256 { get; set; } = string.Empty;

    public Guid? DeviceId { get; set; }

    public string? SubjectDn { get; set; }

    public string? SerialNumber { get; set; }

    public DateTimeOffset? NotBefore { get; set; }

    public DateTimeOffset? NotAfter { get; set; }

    public string AddedBy { get; set; } = "SYSTEM";

    public DateTimeOffset AddedAt { get; set; }

    public string? Comment { get; set; }

    public BlacklistReasonClass? BlacklistReasonClass { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTimeOffset? DeactivatedAt { get; set; }

    public string? DeactivatedBy { get; set; }

    public Certificate Certificate { get; set; } = null!;

    public Device? Device { get; set; }

    #endregion
}
