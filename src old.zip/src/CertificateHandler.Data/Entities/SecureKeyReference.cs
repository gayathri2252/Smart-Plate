// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Reference to a TPM / CNG key label (no private key material in the database).
/// </summary>
public class SecureKeyReference
{
    #region Public Properties

    public Guid KeyId { get; set; }

    public Guid DeviceId { get; set; }

    public string KeyLabel { get; set; } = string.Empty;

    public string ProtectionMode { get; set; } = "TPM_NON_EXPORTABLE";

    public bool IsExportable { get; set; }

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset? LastUsedAt { get; set; }

    public Device Device { get; set; } = null!;

    public ICollection<CsrRenewalRequest> RenewalRequests { get; set; } = new List<CsrRenewalRequest>();

    #endregion
}
