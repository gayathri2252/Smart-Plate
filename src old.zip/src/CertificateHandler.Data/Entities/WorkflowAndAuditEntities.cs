// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

public class CertificateStatusHistory
{
    #region Public Properties

    public long HistoryId { get; set; }

    public Guid CertificateId { get; set; }

    public Guid? DeviceId { get; set; }

    public string PreviousStatus { get; set; } = string.Empty;

    public string NewStatus { get; set; } = string.Empty;

    public DateTimeOffset ChangedAt { get; set; }

    public string ChangedBy { get; set; } = string.Empty;

    public string? Reason { get; set; }

    public Guid? RelatedRequestId { get; set; }

    public Certificate Certificate { get; set; } = null!;

    public PendingRequest? RelatedRequest { get; set; }

    #endregion
}

public class ReinstatementApproval
{
    #region Public Properties

    public long ApprovalId { get; set; }

    public Guid RequestId { get; set; }

    public short ApprovalSequence { get; set; }

    public string ApproverIdentity { get; set; } = string.Empty;

    public string Decision { get; set; } = string.Empty;

    public DateTimeOffset DecidedAt { get; set; }

    public string? Comments { get; set; }

    public PendingRequest Request { get; set; } = null!;

    #endregion
}

public class CsrRenewalRequest
{
    #region Public Properties

    public Guid RenewalRequestId { get; set; }

    public Guid CertificateId { get; set; }

    public Guid KeyId { get; set; }

    public string? CsrPem { get; set; }

    public RenewalRequestStatus Status { get; set; } = RenewalRequestStatus.Created;

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset? ExportedAt { get; set; }

    public string? ExportedBy { get; set; }

    public DateTimeOffset? ImportedAt { get; set; }

    public DateTimeOffset? ActivatedAt { get; set; }

    public string? FailureReason { get; set; }

    public Guid? PreviousCertificateId { get; set; }

    public Certificate Certificate { get; set; } = null!;

    public SecureKeyReference Key { get; set; } = null!;

    #endregion
}

public class FactoryProvisioningAttempt
{
    #region Public Properties

    public Guid AttemptId { get; set; }

    public Guid DeviceId { get; set; }

    public CertificateRole TargetRole { get; set; }

    public ProvisioningOutcome Outcome { get; set; } = ProvisioningOutcome.InProgress;

    public int RetryCount { get; set; }

    public int MaxRetries { get; set; } = 3;

    public DateTimeOffset StartedAt { get; set; }

    public DateTimeOffset? CompletedAt { get; set; }

    public string? ErrorMessage { get; set; }

    public Guid? ResultingCertificateId { get; set; }

    public Device Device { get; set; } = null!;

    #endregion
}

public class AuditLog
{
    #region Public Properties

    public long AuditId { get; set; }

    public Guid EventId { get; set; }

    public string EventType { get; set; } = string.Empty;

    public DateTimeOffset EventTimestamp { get; set; }

    public string ActorIdentity { get; set; } = string.Empty;

    public Guid? DeviceId { get; set; }

    public Guid? RequestId { get; set; }

    public Guid? CertificateId { get; set; }

    public string? ThumbprintSha256 { get; set; }

    public string? PreviousStatus { get; set; }

    public string? NewStatus { get; set; }

    public string? ActionStatus { get; set; }

    public string? Reason { get; set; }

    public string? DetailsJson { get; set; }

    public string Result { get; set; } = "SUCCESS";

    public string? SourceComponent { get; set; }

    #endregion
}

public class BulkOperation
{
    #region Public Properties

    public Guid BulkOperationId { get; set; }

    public string InitiatedBy { get; set; } = string.Empty;

    public string Reason { get; set; } = string.Empty;

    public int MaxBatchSize { get; set; }

    public int ProcessingTimeoutSeconds { get; set; }

    public BulkOperationStatus Status { get; set; } = BulkOperationStatus.Running;

    public DateTimeOffset StartedAt { get; set; }

    public DateTimeOffset? CompletedAt { get; set; }

    public ICollection<BulkOperationItem> Items { get; set; } = new List<BulkOperationItem>();

    #endregion
}

public class BulkOperationItem
{
    #region Public Properties

    public long ItemId { get; set; }

    public Guid BulkOperationId { get; set; }

    public Guid? DeviceId { get; set; }

    public string? ThumbprintSha256 { get; set; }

    public string ItemStatus { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }

    public DateTimeOffset? ProcessedAt { get; set; }

    public BulkOperation BulkOperation { get; set; } = null!;

    #endregion
}

public class TrustEvent
{
    #region Public Properties

    public Guid EventId { get; set; }

    public Guid? DeviceId { get; set; }

    public string ThumbprintSha256 { get; set; } = string.Empty;

    public string NewTrustStatus { get; set; } = string.Empty;

    public Guid? RelatedRequestId { get; set; }

    public string? ActorIdentity { get; set; }

    public DateTimeOffset OccurredAt { get; set; }

    public string PayloadJson { get; set; } = "{}";

    public ICollection<TrustEventDelivery> Deliveries { get; set; } = new List<TrustEventDelivery>();

    #endregion
}

public class TrustEventDelivery
{
    #region Public Properties

    public long DeliveryId { get; set; }

    public Guid EventId { get; set; }

    public string SubscriberName { get; set; } = string.Empty;

    public TrustEventDeliveryStatus Status { get; set; } = TrustEventDeliveryStatus.Pending;

    public int AttemptCount { get; set; }

    public DateTimeOffset? LastAttemptAt { get; set; }

    public string? LastError { get; set; }

    public DateTimeOffset? DeliveredAt { get; set; }

    public TrustEvent Event { get; set; } = null!;

    #endregion
}

public class PeerNotification
{
    #region Public Properties

    public long NotificationId { get; set; }

    public Guid RequestId { get; set; }

    public Guid? TargetDeviceId { get; set; }

    public PeerNotificationStatus NotificationStatus { get; set; }

    public DateTimeOffset SentAt { get; set; }

    public DeliveryResult DeliveryResult { get; set; }

    public int RetryCount { get; set; }

    public string? LastError { get; set; }

    public PendingRequest Request { get; set; } = null!;

    #endregion
}

public class ValidationResult
{
    #region Public Properties

    public long ValidationId { get; set; }

    public DateTimeOffset EvaluatedAt { get; set; }

    public string? ThumbprintSha256 { get; set; }

    public Guid? DeviceId { get; set; }

    public string ValidationStep { get; set; } = string.Empty;

    public bool Passed { get; set; }

    public string? FailureReason { get; set; }

    public bool TimeVerified { get; set; } = true;

    public bool AutoBlacklisted { get; set; }

    #endregion
}

public class SystemConfig
{
    #region Public Properties

    public string ConfigKey { get; set; } = string.Empty;

    public string ConfigValue { get; set; } = string.Empty;

    public string? Description { get; set; }

    public DateTimeOffset UpdatedAt { get; set; }

    public string UpdatedBy { get; set; } = "system";

    #endregion
}

public class SchemaMigration
{
    #region Public Properties

    public string MigrationId { get; set; } = string.Empty;

    public DateTimeOffset AppliedAt { get; set; }

    public string AppliedBy { get; set; } = string.Empty;

    #endregion
}

public class DashboardCounts
{
    #region Public Properties

    public long WhitelistedCount { get; set; }

    public long BlacklistedCount { get; set; }

    public long PendingCount { get; set; }

    public long ExpiredLocalCertCount { get; set; }

    public long Expiring90Days { get; set; }

    public long Expiring30Days { get; set; }

    public long ValidationFailuresWindow { get; set; }

    public long TotalManagedCertificates { get; set; }

    #endregion
}

public class PendingQueueOverview
{
    #region Public Properties

    public Guid RequestId { get; set; }

    public string DeviceIdentifier { get; set; } = string.Empty;

    public PendingRequestType RequestType { get; set; }

    public string? RequesterIdentity { get; set; }

    public string RequestedBy { get; set; } = string.Empty;

    public DateTimeOffset RequestDate { get; set; }

    public PendingRequestStatus CurrentStatus { get; set; }

    public string? MaxumIp { get; set; }

    public string ThumbprintSha256 { get; set; } = string.Empty;

    public string SubjectDn { get; set; } = string.Empty;

    public DateTimeOffset ExpiresAt { get; set; }

    #endregion
}
