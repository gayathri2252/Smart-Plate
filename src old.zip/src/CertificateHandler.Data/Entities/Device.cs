// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// MAXUM device identity stored for HMI and trust workflows.
/// </summary>
public class Device
{
    #region Public Properties

    public Guid DeviceId { get; set; }

    public string DeviceCode { get; set; } = string.Empty;

    public string? DeviceName { get; set; }

    public DeviceType DeviceType { get; set; } = DeviceType.MaxumPeer;

    public string? MaxumIp { get; set; }

    public DeviceOperationalStatus OperationalStatus { get; set; } = DeviceOperationalStatus.Active;

    public Guid? PrimaryCertificateId { get; set; }

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset UpdatedAt { get; set; }

    public Certificate? PrimaryCertificate { get; set; }

    public ICollection<Certificate> Certificates { get; set; } = new List<Certificate>();

    public ICollection<SecureKeyReference> SecureKeys { get; set; } = new List<SecureKeyReference>();

    #endregion
}
