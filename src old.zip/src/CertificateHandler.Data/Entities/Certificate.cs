// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// X.509 certificate metadata (private keys remain in Windows Certificate Store / TPM).
/// </summary>
public class Certificate
{
    #region Public Properties

    public Guid CertificateId { get; set; }

    public Guid? DeviceId { get; set; }

    public CertificateRole CertificateRole { get; set; }

    public string ThumbprintSha256 { get; set; } = string.Empty;

    public string SubjectDn { get; set; } = string.Empty;

    public string IssuerDn { get; set; } = string.Empty;

    public string? SerialNumber { get; set; }

    public DateTimeOffset NotBefore { get; set; }

    public DateTimeOffset NotAfter { get; set; }

    public string? PublicKeyAlgorithm { get; set; }

    public string? PublicKeyPem { get; set; }

    public byte[]? CertDer { get; set; }

    public string? WindowsStoreLocation { get; set; }

    public string? WindowsStoreThumbprint { get; set; }

    public bool IsActive { get; set; } = true;

    public Guid? SupersededByCertificateId { get; set; }

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset UpdatedAt { get; set; }

    public Device? Device { get; set; }

    public Certificate? SupersededByCertificate { get; set; }

    public ICollection<TrustListEntry> TrustListEntries { get; set; } = new List<TrustListEntry>();

    public ICollection<PendingRequest> PendingRequests { get; set; } = new List<PendingRequest>();

    #endregion
}
