// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Administrator queue item for onboarding, reinstatement, or whitelist-to-blacklist approval.
/// </summary>
public class PendingRequest
{
    #region Public Properties

    public Guid RequestId { get; set; }

    public PendingRequestType RequestType { get; set; } = PendingRequestType.PeerOnboarding;

    public Guid CertificateId { get; set; }

    public Guid DeviceId { get; set; }

    public string? RequesterIdentity { get; set; }

    public string RequestedBy { get; set; } = string.Empty;

    public PendingRequestStatus Status { get; set; } = PendingRequestStatus.Pending;

    public DateTimeOffset CreatedAt { get; set; }

    public DateTimeOffset ExpiresAt { get; set; }

    public DateTimeOffset? DecidedAt { get; set; }

    public string? DecidedBy { get; set; }

    public string? DecisionReason { get; set; }

    public Guid? ConnectionCorrelationId { get; set; }

    public Certificate Certificate { get; set; } = null!;

    public Device Device { get; set; } = null!;

    public ICollection<ReinstatementApproval> ReinstatementApprovals { get; set; } =
        new List<ReinstatementApproval>();

    #endregion
}
