namespace CertificateHandler.Data.Models;

public sealed class RenewalWorkflowState
{
    public Guid RenewalRequestId { get; init; }

    public Guid CertificateId { get; init; }

    public Guid KeyId { get; init; }

    public string Status { get; init; } = string.Empty;

    public string? CsrPem { get; init; }

    public string? SignedCertificatePem { get; init; }
}
