namespace CertificateHandler.Data.Models;

public sealed class BulkBlacklistRequest
{
    public string ActorIdentity { get; init; } = string.Empty;

    public string Reason { get; init; } = string.Empty;

    public IReadOnlyList<string> ThumbprintsSha256 { get; init; } = Array.Empty<string>();
}

public sealed class BulkBlacklistItemResult
{
    public string ThumbprintSha256 { get; init; } = string.Empty;

    public bool Succeeded { get; init; }

    public string? Error { get; init; }
}

public sealed class BulkBlacklistResponse
{
    public Guid BulkOperationId { get; init; }

    public IReadOnlyList<BulkBlacklistItemResult> Items { get; init; } = Array.Empty<BulkBlacklistItemResult>();
}
