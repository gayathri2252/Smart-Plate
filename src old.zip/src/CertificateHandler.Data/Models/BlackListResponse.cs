// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// Response to a blacklist request.
/// </summary>
public sealed class BlackListResponse
{
    #region Public Properties

    /// <summary>
    /// What the blacklist request did.
    /// </summary>
    public CertificateBlackList Outcome { get; init; }

    /// <summary>
    /// The certificate row the thumbprint belongs to; null when not found.
    /// </summary>
    public Guid? CertificateId { get; init; }

    #endregion
}
