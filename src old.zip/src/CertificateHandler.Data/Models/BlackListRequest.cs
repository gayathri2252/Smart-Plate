// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// Input for blacklisting one thumbprint after a security failure.
/// </summary>
public sealed class BlackListRequest
{
    #region Public Properties

    /// <summary>
    /// SHA-256 thumbprint of the failed certificate: 64 hexadecimal characters, any case.
    /// </summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>
    /// Why the thumbprint is blacklisted.
    /// </summary>
    public BlacklistReasonClass ReasonClass { get; set; }

    /// <summary>
    /// Readable detail from the trust engine, stored as the reason in the audit row.
    /// </summary>
    public string Reason { get; set; } = string.Empty;

    /// <summary>
    /// When the trust engine finished (UTC).
    /// </summary>
    public DateTimeOffset EvaluatedAt { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>
    /// Component that raised the failure; stored in the audit row.
    /// </summary>
    public string SourceComponent { get; set; } = DatabaseConstants.DEFAULT_SOURCE_COMPONENT;

    /// <summary>
    /// Administrator recorded on the audit row. Empty keeps the system actor.
    /// MCC actions pass both the Keycloak subject and the SBC local administrator.
    /// </summary>
    public string ActorIdentity { get; set; } = string.Empty;

    #endregion
}