// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// One row of the encrypted local trust store: a certificate on the whitelist, the blacklist or the pending list.
/// Times are stored and returned in UTC.
/// </summary>
public sealed class TrustStoreEntry
{
    #region Public Properties

    /// <summary>SHA-256 thumbprint as 64 hexadecimal characters. It is the unique lookup key.</summary>
    public string Thumbprint { get; set; } = string.Empty;

    /// <summary>The list the certificate is on.</summary>
    public TrustListType ListType { get; set; }

    /// <summary>Subject distinguished name of the certificate.</summary>
    public string SubjectDistinguishedName { get; set; } = string.Empty;

    /// <summary>Serial number of the certificate.</summary>
    public string SerialNumber { get; set; } = string.Empty;

    /// <summary>Start of the validity period of the certificate.</summary>
    public DateTimeOffset NotBefore { get; set; }

    /// <summary>End of the validity period of the certificate.</summary>
    public DateTimeOffset NotAfter { get; set; }

    /// <summary>User or component that added the row.</summary>
    public string AddedBy { get; set; } = string.Empty;

    /// <summary>Time the row was added, in UTC.</summary>
    public DateTimeOffset AddedAt { get; set; }

    /// <summary>Optional comment of the user who added the row.</summary>
    public string? Comment { get; set; }

    /// <summary>True when the row is in use. An inactive row is kept but not returned as active.</summary>
    public bool IsActive { get; set; } = true;

    #endregion
}
