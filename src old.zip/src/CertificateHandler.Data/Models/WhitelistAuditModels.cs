namespace CertificateHandler.Data.Models;

/// <summary>
/// One whitelist audit row for RS_09 history views.
/// </summary>
public sealed class WhitelistAuditEntry
{
    public long AuditId { get; init; }

    public DateTimeOffset EventTimestamp { get; init; }

    public string EventType { get; init; } = string.Empty;

    public string ActorIdentity { get; init; } = string.Empty;

    public Guid? RequestId { get; init; }

    public string? ThumbprintSha256 { get; init; }

    public Guid? DeviceId { get; init; }

    public string? PreviousStatus { get; init; }

    public string? NewStatus { get; init; }

    public string? ActionStatus { get; init; }

    public string? Reason { get; init; }
}
