using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// MCC GC certificate snapshot for SBC and MIB (RS_25).
/// </summary>
public sealed class GcCertificateStatusSnapshot
{
    public DateTimeOffset GeneratedAtUtc { get; init; }

    public IReadOnlyList<GcCertificateRoleStatus> Certificates { get; init; } = Array.Empty<GcCertificateRoleStatus>();
}

public sealed class GcCertificateRoleStatus
{
    public CertificateRole Role { get; init; }

    public string RoleLabel { get; init; } = string.Empty;

    public string Subject { get; init; } = string.Empty;

    public string Issuer { get; init; } = string.Empty;

    public string ThumbprintSha256 { get; init; } = string.Empty;

    public DateTimeOffset? NotAfter { get; init; }

    public CertificateExpiryStatus Status { get; init; }

    public string StatusLabel { get; init; } = string.Empty;
}
