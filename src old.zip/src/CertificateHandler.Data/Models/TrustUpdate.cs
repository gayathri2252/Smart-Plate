﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// A trust change that has already been saved and now has to be published.
/// </summary>
public sealed class TrustUpdate
{
    #region Public Properties

    /// <summary>SHA-256 thumbprint of the certificate whose trust row was saved.</summary>
    public string ThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>Certificate row the trust row belongs to; null when unknown.</summary>
    public Guid? CertificateId { get; init; }

    /// <summary>What the save step did, for example Added or Reactivated.</summary>
    public string Change { get; init; } = string.Empty;

    /// <summary>Why the trust row was changed.</summary>
    public string Reason { get; init; } = string.Empty;

    /// <summary>When the trust row was committed (UTC).</summary>
    public DateTimeOffset SavedAt { get; init; } = DateTimeOffset.UtcNow;

    #endregion
}
