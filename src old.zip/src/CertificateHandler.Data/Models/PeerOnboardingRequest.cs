﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// The certificate and device details of an unknown peer, used to put it in the pending queue.
/// </summary>
public sealed class PeerOnboardingRequest
{
    #region Public Properties

    /// <summary>SHA-256 thumbprint of the peer certificate, as 64 hex characters.</summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>Subject of the peer certificate.</summary>
    public string SubjectDn { get; set; } = string.Empty;

    /// <summary>Issuer of the peer certificate.</summary>
    public string IssuerDn { get; set; } = string.Empty;

    /// <summary>Serial number of the peer certificate; null when unknown.</summary>
    public string? SerialNumber { get; set; }

    /// <summary>Start of the certificate validity (UTC).</summary>
    public DateTimeOffset NotBefore { get; set; }

    /// <summary>End of the certificate validity (UTC).</summary>
    public DateTimeOffset NotAfter { get; set; }

    /// <summary>Identifier of the peer device, such as its name; stored as the device code.</summary>
    public string DeviceCode { get; set; } = string.Empty;

    /// <summary>IP address of the peer MAXUM; null when unknown.</summary>
    public string? MaxumIp { get; set; }

    /// <summary>Who created the request; the system for a peer that connects.</summary>
    public string RequestedBy { get; set; } = DatabaseConstants.SystemActor;

    /// <summary>Id of the refused connection, so the request can be matched to the connection log.</summary>
    public Guid? ConnectionCorrelationId { get; set; }

    /// <summary>When the request expires if nobody decides on it (UTC).</summary>
    public DateTimeOffset ExpiresAt { get; set; }

    /// <summary>DER encoding of the certificate the peer presented (for cryptographic re-validation).</summary>
    public byte[]? PresentedCertificateDer { get; set; }

    /// <summary>
    /// Client profile when the listener already knows it. Null means classify from the certificate subject.
    /// </summary>
    public DeviceType? ClientProfile { get; set; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates the request from the certificate a peer presented in its certificate request.
    /// </summary>
    /// <param name="certificate">Peer certificate; must not be null.</param>
    /// <param name="deviceCode">Identifier of the peer device; must not be empty.</param>
    /// <param name="maxumIp">IP address of the peer; null when unknown.</param>
    /// <returns>The request, without an expiry time.</returns>
    public static PeerOnboardingRequest FromCertificate(X509Certificate2 certificate, string deviceCode, string? maxumIp)
    {
        ArgumentNullException.ThrowIfNull(certificate);
        ArgumentException.ThrowIfNullOrWhiteSpace(deviceCode);

        return new PeerOnboardingRequest
        {
            ThumbprintSha256 = certificate.GetCertHashString(HashAlgorithmName.SHA256),
            SubjectDn = certificate.Subject,
            IssuerDn = certificate.Issuer,
            SerialNumber = certificate.SerialNumber,
            NotBefore = new DateTimeOffset(certificate.NotBefore.ToUniversalTime(), TimeSpan.Zero),
            NotAfter = new DateTimeOffset(certificate.NotAfter.ToUniversalTime(), TimeSpan.Zero),
            DeviceCode = deviceCode.Trim(),
            MaxumIp = string.IsNullOrWhiteSpace(maxumIp) ? null : maxumIp.Trim(),
            PresentedCertificateDer = certificate.RawData
        };
    }

    #endregion
}
