// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Configurations;
using CertificateHandler.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace CertificateHandler.Data;

/// <summary>
/// Entity Framework Core context for Certificate Handler PostgreSQL persistence.
/// </summary>
public class CertificateHandlerDbContext : DbContext
{
    #region Constructor

    public CertificateHandlerDbContext(DbContextOptions<CertificateHandlerDbContext> options)
        : base(options)
    {
    }

    #endregion

    #region Public Properties

    public DbSet<Device> Devices => Set<Device>();

    public DbSet<Certificate> Certificates => Set<Certificate>();

    public DbSet<SecureKeyReference> SecureKeyReferences => Set<SecureKeyReference>();

    public DbSet<TrustListEntry> TrustListEntries => Set<TrustListEntry>();

    public DbSet<CertificateStatusHistory> CertificateStatusHistory => Set<CertificateStatusHistory>();

    public DbSet<PendingRequest> PendingRequests => Set<PendingRequest>();

    public DbSet<ReinstatementApproval> ReinstatementApprovals => Set<ReinstatementApproval>();

    public DbSet<CsrRenewalRequest> CsrRenewalRequests => Set<CsrRenewalRequest>();

    public DbSet<FactoryProvisioningAttempt> FactoryProvisioningAttempts => Set<FactoryProvisioningAttempt>();

    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    public DbSet<BulkOperation> BulkOperations => Set<BulkOperation>();

    public DbSet<BulkOperationItem> BulkOperationItems => Set<BulkOperationItem>();

    public DbSet<TrustEvent> TrustEvents => Set<TrustEvent>();

    public DbSet<TrustEventDelivery> TrustEventDeliveries => Set<TrustEventDelivery>();

    public DbSet<PeerNotification> PeerNotifications => Set<PeerNotification>();

    public DbSet<ValidationResult> ValidationResults => Set<ValidationResult>();

    public DbSet<SystemConfig> SystemConfig => Set<SystemConfig>();

    public DbSet<SchemaMigration> SchemaMigrations => Set<SchemaMigration>();

    public DbSet<DashboardCounts> DashboardCounts => Set<DashboardCounts>();

    public DbSet<PendingQueueOverview> PendingQueueOverview => Set<PendingQueueOverview>();

    #endregion

    #region Override Methods

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyCertificateHandlerConfigurations();
    }

    #endregion
}
