// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using NpgsqlTypes;

namespace CertificateHandler.Data.Enums;

public enum DeviceType
{
    [PgName("MAXUM_PEER")]
    MaxumPeer,

    [PgName("LOCAL_SBC")]
    LocalSbc,

    [PgName("LOCAL_MIB")]
    LocalMib,

    [PgName("GCP_WORKSTATION")]
    GcpWorkstation,

    [PgName("OTHER")]
    Other
}

public enum DeviceOperationalStatus
{
    [PgName("ACTIVE")]
    Active,

    [PgName("PROVISIONING_FAILED")]
    ProvisioningFailed,

    [PgName("STORAGE_UNAVAILABLE")]
    StorageUnavailable,

    [PgName("DECOMMISSIONED")]
    Decommissioned
}

public enum CertificateRole
{
    [PgName("PEER")]
    Peer,

    [PgName("LOCAL_SBC")]
    LocalSbc,

    [PgName("LOCAL_MIB")]
    LocalMib,

    [PgName("GCP_APPLICATION")]
    GcpApplication,

    [PgName("FACTORY_DEFAULT")]
    FactoryDefault,

    [PgName("TEMPORARY_POST_COMPROMISE")]
    TemporaryPostCompromise
}

public enum TrustListKind
{
    [PgName("WHITELIST")]
    Whitelist,

    [PgName("BLACKLIST")]
    Blacklist
}

public enum PendingRequestType
{
    [PgName("PEER_ONBOARDING")]
    PeerOnboarding,

    [PgName("REINSTATEMENT")]
    Reinstatement,

    [PgName("WHITELIST_TO_BLACKLIST")]
    WhitelistToBlacklist
}

public enum PendingRequestStatus
{
    [PgName("PENDING")]
    Pending,

    [PgName("APPROVED")]
    Approved,

    [PgName("REJECTED")]
    Rejected,

    [PgName("EXPIRED")]
    Expired
}

public enum BlacklistReasonClass
{
    [PgName("SIGNATURE_FAILURE")]
    SignatureFailure,

    [PgName("REVOKED_CERTIFICATE")]
    RevokedCertificate,

    [PgName("BROKEN_CHAIN")]
    BrokenChain,

    [PgName("MANUAL_ACTION")]
    ManualAction,

    [PgName("SECURITY_INCIDENT")]
    SecurityIncident
}

public enum RenewalRequestStatus
{
    [PgName("CREATED")]
    Created,

    [PgName("EXPORTED")]
    Exported,

    [PgName("IMPORTED")]
    Imported,

    [PgName("VALIDATED")]
    Validated,

    [PgName("ACTIVATED")]
    Activated,

    [PgName("FAILED")]
    Failed,

    [PgName("ROLLED_BACK")]
    RolledBack
}

public enum BulkOperationStatus
{
    [PgName("RUNNING")]
    Running,

    [PgName("COMPLETED")]
    Completed,

    [PgName("COMPLETED_WITH_ERRORS")]
    CompletedWithErrors,

    [PgName("TIMED_OUT")]
    TimedOut,

    [PgName("CANCELLED")]
    Cancelled
}

public enum TrustEventDeliveryStatus
{
    [PgName("PENDING")]
    Pending,

    [PgName("DELIVERED")]
    Delivered,

    [PgName("FAILED")]
    Failed,

    [PgName("RETRYING")]
    Retrying
}

public enum ProvisioningOutcome
{
    [PgName("IN_PROGRESS")]
    InProgress,

    [PgName("SUCCESS")]
    Success,

    [PgName("FAILED")]
    Failed,

    [PgName("MANUAL_INTERVENTION_REQUIRED")]
    ManualInterventionRequired
}

public enum PeerNotificationStatus
{
    [PgName("PENDING")]
    Pending,

    [PgName("APPROVED")]
    Approved,

    [PgName("REJECTED")]
    Rejected
}

public enum DeliveryResult
{
    [PgName("SUCCESS")]
    Success,

    [PgName("FAILED")]
    Failed
}

public enum ReinstatementDecision
{
    Approved,
    Rejected
}
