using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Stand-in peer channel that logs delivery until the MAXUM listener transport is wired.
/// </summary>
public sealed class LoggingPeerNotificationChannel : IPeerNotificationChannel
{
    #region Public Methods

    public Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default)
    {
        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            $"Peer notification {notificationId} for request {requestId} delivered via log channel (RS_10 stub).");
        return Task.FromResult(true);
    }

    #endregion
}
