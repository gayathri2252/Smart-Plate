using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

/// <summary>
/// Selects peer notification transport (RS_10).
/// </summary>
public static class PeerNotificationChannelFactory
{
    public static IPeerNotificationChannel Create()
    {
        if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("CH_PEER_NOTIFY_URL")))
        {
            return new HttpPeerNotificationChannel();
        }

        return new LoggingPeerNotificationChannel();
    }
}
