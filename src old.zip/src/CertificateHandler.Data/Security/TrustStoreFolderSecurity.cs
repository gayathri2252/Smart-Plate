﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Runtime.Versioning;
using System.Security.AccessControl;
using System.Security.Principal;
using CertificateHandler.Data.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Restricts the trust store folder to the system, the administrators (read only), the running account and any
/// additional accounts. With DPAPI in the LocalMachine scope every user of the computer could unseal the key,
/// so the folder permission is what keeps other users away from the database and the key file.
/// </summary>
public static class TrustStoreFolderSecurity
{
    #region Public Methods

    /// <summary>
    /// Removes the inherited permissions of the folder and gives full control to the system, read-only rights to
    /// the administrators and change rights to the running account and the additional accounts. Files inherit this,
    /// so only the account that runs the application can change the database. The rules are set again on every
    /// call, so a folder made by an earlier version gets the read-only rule for the administrators too.
    /// Returns true when the folder is protected afterwards. A failure is logged and never stops the application.
    /// </summary>
    public static bool Restrict(string directory, IEnumerable<string>? additionalAccounts = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(directory);

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            var directoryInfo = new DirectoryInfo(directory);
            DirectorySecurity security = directoryInfo.GetAccessControl();

            security.SetAccessRuleProtection(isProtected: true, preserveInheritance: false);
            RemoveExplicitRules(security);
            AddRule(security, new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl);
            AddRule(security, new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), FileSystemRights.ReadAndExecute);

            SecurityIdentifier? runningAccount = WindowsIdentity.GetCurrent().User;
            if (runningAccount is not null)
            {
                AddRule(security, runningAccount, FileSystemRights.Modify);
            }

            foreach (string account in additionalAccounts ?? Enumerable.Empty<string>())
            {
                GrantAdditionalAccount(security, account);
            }

            directoryInfo.SetAccessControl(security);
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_FOLDER_RESTRICTED, directory);
            return true;
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException or InvalidOperationException or PrivilegeNotHeldException)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_FOLDER_RESTRICT_FAILED, directory, ex.Message);
            return IsAlreadyProtected(directory);
        }
    }

    /// <summary>
    /// Makes a file read-only for every account, the running account included, by denying the write rights.
    /// Used for the sealed key file, which is never changed after it was created. Whoever may change the
    /// permissions of the file can still remove the rule, but a normal edit or save is refused.
    /// Returns true when the file is read-only afterwards. A failure is logged and never stops the application.
    /// </summary>
    public static bool MakeReadOnly(string filePath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            var fileInfo = new FileInfo(filePath);
            FileSecurity security = fileInfo.GetAccessControl();
            security.AddAccessRule(new FileSystemAccessRule(
                new SecurityIdentifier(WellKnownSidType.WorldSid, null),
                FileSystemRights.WriteData | FileSystemRights.AppendData | FileSystemRights.WriteAttributes | FileSystemRights.WriteExtendedAttributes,
                AccessControlType.Deny));
            fileInfo.SetAccessControl(security);
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_FILE_READ_ONLY, filePath);
            return true;
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException or InvalidOperationException or PrivilegeNotHeldException)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_FILE_READ_ONLY_FAILED, filePath, ex.Message);
            return false;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Returns true when the folder already has protected permissions. Used when the rules cannot be set again,
    /// for example because the running account is not allowed to change permissions.
    /// </summary>
    [SupportedOSPlatform("windows")]
    private static bool IsAlreadyProtected(string directory)
    {
        try
        {
            return new DirectoryInfo(directory).GetAccessControl().AreAccessRulesProtected;
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException or InvalidOperationException)
        {
            return false;
        }
    }

    /// <summary>
    /// Removes the rules that were set directly on the folder, so the new rules replace them.
    /// </summary>
    [SupportedOSPlatform("windows")]
    private static void RemoveExplicitRules(DirectorySecurity security)
    {
        foreach (FileSystemAccessRule rule in security.GetAccessRules(includeExplicit: true, includeInherited: false, typeof(SecurityIdentifier)))
        {
            security.RemoveAccessRuleSpecific(rule);
        }
    }

    /// <summary>
    /// Gives an extra account change rights. An account that is unknown on this computer is logged and skipped.
    /// </summary>
    [SupportedOSPlatform("windows")]
    private static void GrantAdditionalAccount(DirectorySecurity security, string account)
    {
        if (string.IsNullOrWhiteSpace(account))
        {
            return;
        }

        try
        {
            var identity = (SecurityIdentifier)new NTAccount(account.Trim()).Translate(typeof(SecurityIdentifier));
            AddRule(security, identity, FileSystemRights.Modify);
        }
        catch (IdentityNotMappedException)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_ACCOUNT_NOT_FOUND, account);
        }
    }

    /// <summary>
    /// Adds an allow rule that applies to the folder, its sub folders and its files.
    /// </summary>
    [SupportedOSPlatform("windows")]
    private static void AddRule(DirectorySecurity security, SecurityIdentifier identity, FileSystemRights rights)
    {
        security.AddAccessRule(new FileSystemAccessRule(
            identity,
            rights,
            InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
            PropagationFlags.None,
            AccessControlType.Allow));
    }

    #endregion
}
