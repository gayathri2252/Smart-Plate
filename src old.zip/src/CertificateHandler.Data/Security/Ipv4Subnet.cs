using System.Net;
using System.Net.Sockets;

namespace CertificateHandler.Data.Security;

/// <summary>
/// IPv4 subnet comparison used to choose MAXUM peers for blacklist unicast (RS_33).
/// </summary>
public static class Ipv4Subnet
{
    public static bool SameSubnet(IPAddress left, IPAddress right, int prefixLength)
    {
        if (left.AddressFamily != AddressFamily.InterNetwork || right.AddressFamily != AddressFamily.InterNetwork)
        {
            return false;
        }

        if (prefixLength is < 0 or > 32)
        {
            throw new ArgumentOutOfRangeException(nameof(prefixLength));
        }

        uint mask = prefixLength == 0 ? 0u : uint.MaxValue << (32 - prefixLength);
        return (ToUInt32(left) & mask) == (ToUInt32(right) & mask);
    }

    public static IReadOnlyList<IPAddress> LocalUnicastAddresses()
    {
        var addresses = new List<IPAddress>();
        foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up)
            {
                continue;
            }

            foreach (System.Net.NetworkInformation.UnicastIPAddressInformation unicast in nic.GetIPProperties().UnicastAddresses)
            {
                if (unicast.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(unicast.Address))
                {
                    addresses.Add(unicast.Address);
                }
            }
        }

        return addresses;
    }

    private static uint ToUInt32(IPAddress address)
    {
        byte[] bytes = address.GetAddressBytes();
        return ((uint)bytes[0] << 24) | ((uint)bytes[1] << 16) | ((uint)bytes[2] << 8) | bytes[3];
    }
}
