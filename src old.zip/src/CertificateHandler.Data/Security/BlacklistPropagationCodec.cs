using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Signed unicast payload for a blacklist that must be applied by peer MAXUM devices (RS_33).
/// </summary>
public sealed class BlacklistPropagationMessage
{
    public string Thumbprint { get; init; } = string.Empty;

    public string Reason { get; init; } = string.Empty;

    public string Origin { get; init; } = string.Empty;

    public long SentAtUnixMs { get; init; }

    public string Signature { get; init; } = string.Empty;
}

public static class BlacklistPropagationCodec
{
    public const int DefaultPort = 47433;

    public const int DefaultPrefixLength = 24;

    public const int MaxReasonLength = 500;

    public const int MaxOriginLength = 128;

    public static readonly TimeSpan MaximumAge = TimeSpan.FromMinutes(5);

    public static byte[] CreateSignedPayload(string thumbprint, string reason, string origin, DateTimeOffset sentAt, string key)
    {
        string normalized = NormalizeThumbprint(thumbprint);
        string boundedReason = Bound(reason, MaxReasonLength);
        string boundedOrigin = Bound(origin, MaxOriginLength);
        long sentAtUnixMs = sentAt.ToUnixTimeMilliseconds();
        var message = new BlacklistPropagationMessage
        {
            Thumbprint = normalized,
            Reason = boundedReason,
            Origin = boundedOrigin,
            SentAtUnixMs = sentAtUnixMs,
            Signature = Sign(normalized, boundedReason, boundedOrigin, sentAtUnixMs, key)
        };
        return JsonSerializer.SerializeToUtf8Bytes(message);
    }

    public static bool TryValidate(
        ReadOnlySpan<byte> payload,
        IPAddress remoteAddress,
        DateTimeOffset now,
        string? key,
        IReadOnlyCollection<IPAddress> localAddresses,
        int prefixLength,
        out BlacklistPropagationMessage? message,
        out string error)
    {
        message = null;
        if (string.IsNullOrWhiteSpace(key) || key.Length < 16)
        {
            error = "Blacklist sync key is missing.";
            return false;
        }

        BlacklistPropagationMessage? parsed;
        try
        {
            parsed = JsonSerializer.Deserialize<BlacklistPropagationMessage>(payload);
        }
        catch (JsonException)
        {
            error = "Blacklist message is not valid JSON.";
            return false;
        }

        if (parsed is null || !IsHexThumbprint(parsed.Thumbprint))
        {
            error = "Blacklist message thumbprint is missing.";
            return false;
        }

        if (parsed.Reason.Length > MaxReasonLength || parsed.Origin.Length > MaxOriginLength)
        {
            error = "Blacklist message fields are too long.";
            return false;
        }

        string expected = Sign(parsed.Thumbprint, parsed.Reason, parsed.Origin, parsed.SentAtUnixMs, key);
        if (!FixedEquals(expected, parsed.Signature))
        {
            error = "Blacklist message signature is not valid.";
            return false;
        }

        DateTimeOffset sentAt = DateTimeOffset.FromUnixTimeMilliseconds(parsed.SentAtUnixMs);
        if (sentAt > now.Add(MaximumAge) || now - sentAt > MaximumAge)
        {
            error = "Blacklist message is outside the allowed time window.";
            return false;
        }

        if (!SharesSubnet(remoteAddress, localAddresses, prefixLength))
        {
            error = "Blacklist message did not come from the same IP subnet.";
            return false;
        }

        message = parsed;
        error = string.Empty;
        return true;
    }

    public static int ReadPrefixLength()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_BLACKLIST_SUBNET_PREFIX");
        return int.TryParse(raw, out int prefix) && prefix is >= 1 and <= 32
            ? prefix
            : DefaultPrefixLength;
    }

    public static int ReadPort()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_BLACKLIST_UNICAST_PORT");
        return int.TryParse(raw, out int port) && port is > 0 and <= 65535
            ? port
            : DefaultPort;
    }

    public static string? ReadKey() => Environment.GetEnvironmentVariable("CH_BLACKLIST_SYNC_KEY");

    private static bool SharesSubnet(IPAddress remote, IReadOnlyCollection<IPAddress> localAddresses, int prefixLength)
    {
        foreach (IPAddress local in localAddresses)
        {
            if (Ipv4Subnet.SameSubnet(local, remote, prefixLength))
            {
                return true;
            }
        }

        return false;
    }

    private static string Sign(string thumbprint, string reason, string origin, long sentAtUnixMs, string key)
    {
        string canonical = thumbprint + "\n" + reason + "\n" + origin + "\n" + sentAtUnixMs.ToString(System.Globalization.CultureInfo.InvariantCulture);
        byte[] hash = HMACSHA256.HashData(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(canonical));
        return Convert.ToHexString(hash);
    }

    private static bool FixedEquals(string expected, string actual)
    {
        byte[] left = Encoding.UTF8.GetBytes(expected);
        byte[] right = Encoding.UTF8.GetBytes(actual ?? string.Empty);
        return left.Length == right.Length && CryptographicOperations.FixedTimeEquals(left, right);
    }

    private static string NormalizeThumbprint(string thumbprint)
    {
        string normalized = (thumbprint ?? string.Empty).Replace(" ", string.Empty, StringComparison.Ordinal).ToUpperInvariant();
        if (!IsHexThumbprint(normalized))
        {
            throw new ArgumentException("Thumbprint must be 64 hexadecimal characters.", nameof(thumbprint));
        }

        return normalized;
    }

    private static bool IsHexThumbprint(string? thumbprint)
    {
        if (thumbprint is null || thumbprint.Length != 64)
        {
            return false;
        }

        foreach (char character in thumbprint)
        {
            bool hex = character is >= '0' and <= '9' or >= 'A' and <= 'F' or >= 'a' and <= 'f';
            if (!hex)
            {
                return false;
            }
        }

        return true;
    }

    private static string Bound(string? value, int max)
    {
        string trimmed = value?.Trim() ?? string.Empty;
        return trimmed.Length <= max ? trimmed : trimmed[..max];
    }
}
