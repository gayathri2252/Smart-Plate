using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Classifies a connecting client before the trust decision (RS_32, RS_34).
/// An explicit <see cref="PeerOnboardingRequest.ClientProfile"/> wins. Otherwise the certificate
/// subject is used. Anything that is not a MAXUM peer stays on the pending queue.
/// </summary>
public static class ClientProfileClassifier
{
    public static DeviceType Classify(PeerOnboardingRequest peer)
    {
        ArgumentNullException.ThrowIfNull(peer);
        if (peer.ClientProfile is DeviceType explicitProfile)
        {
            return explicitProfile;
        }

        string subject = peer.SubjectDn ?? string.Empty;
        if (HasOrganizationalUnit(subject, "MAXUM") || HasCommonNamePrefix(subject, "MAXUM-"))
        {
            return DeviceType.MaxumPeer;
        }

        if (HasOrganizationalUnit(subject, "GCP")
            || HasOrganizationalUnit(subject, "MCC")
            || HasOrganizationalUnit(subject, "WORKSTATION"))
        {
            return DeviceType.GcpWorkstation;
        }

        return DeviceType.Other;
    }

    private static bool HasOrganizationalUnit(string subject, string unit)
    {
        foreach (string part in subject.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (part.StartsWith("OU=", StringComparison.OrdinalIgnoreCase)
                && string.Equals(part[3..].Trim(), unit, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    private static bool HasCommonNamePrefix(string subject, string prefix)
    {
        foreach (string part in subject.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (part.StartsWith("CN=", StringComparison.OrdinalIgnoreCase)
                && part[3..].Trim().StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }
}
