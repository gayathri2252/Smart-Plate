namespace CertificateHandler.Data.Security;

/// <summary>
/// Enforces mandatory reject/ decision reasons (RS_19).
/// </summary>
public static class DecisionReasonPolicy
{
    public const int MinimumLength = BlacklistReasonPolicy.MinimumLength;

    public static void ValidateOrThrow(string? reason)
    {
        string trimmed = reason?.Trim() ?? string.Empty;
        if (trimmed.Length < MinimumLength)
        {
            throw new ArgumentException($"Decision reason must be at least {MinimumLength} characters.", nameof(reason));
        }
    }
}
