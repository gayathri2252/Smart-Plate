// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text;
using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Seals the database key with Windows data protection (DPAPI) in the LocalMachine scope.
/// The sealed bytes can only be unsealed on the same computer. It works on Windows only;
/// on other systems the data protection call throws PlatformNotSupportedException.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class DpapiKeyProtector : IKeyProtector
{
    #region Member Variables

    private const string ENTROPY_TEXT = "Valmet.CertificateHandler.TrustStore";

    private static readonly byte[] _entropy = Encoding.UTF8.GetBytes(ENTROPY_TEXT);

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public byte[] Protect(byte[] data)
    {
        ArgumentNullException.ThrowIfNull(data);

        return ProtectedData.Protect(data, _entropy, DataProtectionScope.LocalMachine);
    }

    /// <inheritdoc />
    public byte[] Unprotect(byte[] protectedData)
    {
        ArgumentNullException.ThrowIfNull(protectedData);

        return ProtectedData.Unprotect(protectedData, _entropy, DataProtectionScope.LocalMachine);
    }

    #endregion
}
