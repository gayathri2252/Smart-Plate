using System.Security.Cryptography;
using System.Text;

namespace CertificateHandler.Data.Security;

/// <summary>
/// DPAPI (LocalMachine) protection for the database password — PostgreSQL equivalent to SQLCipher key sealing (design §3.3).
/// </summary>
public static class DatabasePasswordProtector
{
    public const string ProtectedPasswordEnvironmentVariable = "CH_DB_PASSWORD_PROTECTED";

    public static string ProtectToBase64(string plaintext)
    {
        ArgumentException.ThrowIfNullOrEmpty(plaintext);

        if (!OperatingSystem.IsWindows())
        {
            throw new PlatformNotSupportedException("DPAPI password protection is only supported on Windows.");
        }

        byte[] encrypted = ProtectedData.Protect(
            Encoding.UTF8.GetBytes(plaintext),
            optionalEntropy: null,
            DataProtectionScope.LocalMachine);

        return Convert.ToBase64String(encrypted);
    }

    public static bool TryUnprotectFromBase64(string? protectedBase64, out string plaintext)
    {
        plaintext = string.Empty;

        if (string.IsNullOrWhiteSpace(protectedBase64))
        {
            return false;
        }

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            byte[] encrypted = Convert.FromBase64String(protectedBase64.Trim());
            byte[] decrypted = ProtectedData.Unprotect(
                encrypted,
                optionalEntropy: null,
                DataProtectionScope.LocalMachine);
            plaintext = Encoding.UTF8.GetString(decrypted);
            return !string.IsNullOrEmpty(plaintext);
        }
        catch (CryptographicException)
        {
            return false;
        }
        catch (FormatException)
        {
            return false;
        }
    }
}
