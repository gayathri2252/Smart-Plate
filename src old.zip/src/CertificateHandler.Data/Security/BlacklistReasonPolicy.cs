namespace CertificateHandler.Data.Security;

/// <summary>
/// Enforces mandatory blacklist reason quality (RS_12).
/// </summary>
public static class BlacklistReasonPolicy
{
    public const int MinimumLength = 8;

    public static void ValidateOrThrow(string? reason)
    {
        string trimmed = reason?.Trim() ?? string.Empty;
        if (trimmed.Length < MinimumLength)
        {
            throw new ArgumentException($"Blacklist reason must be at least {MinimumLength} characters.", nameof(reason));
        }
    }
}
