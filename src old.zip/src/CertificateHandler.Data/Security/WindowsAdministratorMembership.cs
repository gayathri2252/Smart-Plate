using System.Security.Principal;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Checks local Windows group membership for the current interactive user.
/// </summary>
public static class WindowsAdministratorMembership
{
    public static bool IsCurrentUserInGroup(string groupName)
    {
        if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        try
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(groupName.Trim());
        }
        catch (Exception)
        {
            return false;
        }
    }
}
