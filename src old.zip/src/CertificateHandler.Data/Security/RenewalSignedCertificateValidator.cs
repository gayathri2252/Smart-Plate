using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Signed-certificate checks before renewal activation (RS_06).
/// </summary>
public static class RenewalSignedCertificateValidator
{
    public static void ValidateOrThrow(string? signedCertificatePem, string? csrPem = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(signedCertificatePem);

        X509Certificate2 certificate;
        try
        {
            certificate = X509Certificate2.CreateFromPem(signedCertificatePem);
        }
        catch (CryptographicException ex)
        {
            throw new InvalidOperationException("Signed certificate PEM is not a valid X.509 certificate.", ex);
        }

        using (certificate)
        {
            DateTimeOffset now = DateTimeOffset.UtcNow;
            if (now < certificate.NotBefore.ToUniversalTime())
            {
                throw new InvalidOperationException("Signed certificate is not yet valid.");
            }

            if (now > certificate.NotAfter.ToUniversalTime())
            {
                throw new InvalidOperationException("Signed certificate has expired.");
            }

            if (!string.IsNullOrWhiteSpace(csrPem))
            {
                ValidatePublicKeyMatchesCsr(certificate, csrPem);
            }
        }
    }

    private static void ValidatePublicKeyMatchesCsr(X509Certificate2 certificate, string csrPem)
    {
        try
        {
            byte[] csrSpki = ExtractSubjectPublicKeyInfoFromCsrPem(csrPem);
            byte[] certSpki = certificate.PublicKey.ExportSubjectPublicKeyInfo();
            if (!csrSpki.AsSpan().SequenceEqual(certSpki))
            {
                throw new InvalidOperationException("Signed certificate public key does not match the recorded CSR.");
            }
        }
        catch (InvalidOperationException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Unable to validate CSR against signed certificate.", ex);
        }
    }

    private static byte[] ExtractSubjectPublicKeyInfoFromCsrPem(string csrPem)
    {
        byte[] der = DecodePem(csrPem, "CERTIFICATE REQUEST");
        var reader = new AsnReader(der, AsnEncodingRules.DER);
        AsnReader outer = reader.ReadSequence();
        AsnReader certificationRequestInfo = outer.ReadSequence();
        certificationRequestInfo.ReadInteger();
        certificationRequestInfo.ReadEncodedValue();
        return certificationRequestInfo.ReadEncodedValue().ToArray();
    }

    private static byte[] DecodePem(string pem, string label)
    {
        var data = new StringBuilder();
        bool capture = false;
        foreach (string rawLine in pem.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            string line = rawLine.Trim();
            if (line.Contains($"BEGIN {label}", StringComparison.Ordinal))
            {
                capture = true;
                continue;
            }

            if (line.Contains($"END {label}", StringComparison.Ordinal))
            {
                break;
            }

            if (capture)
            {
                data.Append(line);
            }
        }

        if (data.Length == 0)
        {
            throw new InvalidOperationException("CSR PEM block is missing.");
        }

        return Convert.FromBase64String(data.ToString());
    }
}
