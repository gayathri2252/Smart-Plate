// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Globalization;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Microsoft.Data.Sqlite;

namespace CertificateHandler.Data;

/// <summary>
/// Reads and writes the whitelist, blacklist and pending rows in the encrypted local trust store.
/// All statements use parameters and the thumbprint is normalized to upper case before it is used.
/// </summary>
public sealed class TrustStoreRepository : ITrustStoreRepository
{
    #region Member Variables

    private const string TABLE = TrustStoreDatabase.TABLE_NAME;

    private const string SAVE_SQL =
        $"INSERT INTO {TABLE} " +
        "(thumbprint, list_type, subject_dn, serial_number, not_before, not_after, added_by, added_at, comment, is_active) " +
        "VALUES (@thumbprint, @listType, @subjectDn, @serialNumber, @notBefore, @notAfter, @addedBy, @addedAt, @comment, @isActive) " +
        "ON CONFLICT (thumbprint) DO UPDATE SET " +
        "list_type = excluded.list_type, subject_dn = excluded.subject_dn, serial_number = excluded.serial_number, " +
        "not_before = excluded.not_before, not_after = excluded.not_after, added_by = excluded.added_by, " +
        "added_at = excluded.added_at, comment = excluded.comment, is_active = excluded.is_active;";

    private const string SELECT_COLUMNS =
        "thumbprint, list_type, subject_dn, serial_number, not_before, not_after, added_by, added_at, comment, is_active";

    private const string GET_BY_THUMBPRINT_SQL =
        $"SELECT {SELECT_COLUMNS} FROM {TABLE} WHERE thumbprint = @thumbprint;";

    private const string GET_ACTIVE_BY_LIST_SQL =
        $"SELECT {SELECT_COLUMNS} FROM {TABLE} WHERE list_type = @listType AND is_active = 1 ORDER BY added_at, thumbprint;";

    private const string THUMBPRINT_PARAMETER = "@thumbprint";
    private const string LIST_TYPE_PARAMETER = "@listType";
    private const string SUBJECT_DN_PARAMETER = "@subjectDn";
    private const string SERIAL_NUMBER_PARAMETER = "@serialNumber";
    private const string NOT_BEFORE_PARAMETER = "@notBefore";
    private const string NOT_AFTER_PARAMETER = "@notAfter";
    private const string ADDED_BY_PARAMETER = "@addedBy";
    private const string ADDED_AT_PARAMETER = "@addedAt";
    private const string COMMENT_PARAMETER = "@comment";
    private const string IS_ACTIVE_PARAMETER = "@isActive";

    private const int THUMBPRINT_COLUMN = 0;
    private const int LIST_TYPE_COLUMN = 1;
    private const int SUBJECT_DN_COLUMN = 2;
    private const int SERIAL_NUMBER_COLUMN = 3;
    private const int NOT_BEFORE_COLUMN = 4;
    private const int NOT_AFTER_COLUMN = 5;
    private const int ADDED_BY_COLUMN = 6;
    private const int ADDED_AT_COLUMN = 7;
    private const int COMMENT_COLUMN = 8;
    private const int IS_ACTIVE_COLUMN = 9;

    private const string TIME_FORMAT = "O";
    private const string SUBJECT_FIELD_NAME = "subject distinguished name";
    private const string SERIAL_NUMBER_FIELD_NAME = "serial number";
    private const string ADDED_BY_FIELD_NAME = "added by";

    private readonly TrustStoreDatabase _database;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the repository on the given trust store. The database must not be null.
    /// </summary>
    public TrustStoreRepository(TrustStoreDatabase database)
    {
        if (database is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_DATABASE_IS_NULL);
            throw new ArgumentNullException(nameof(database));
        }

        _database = database;
    }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public async Task SaveAsync(TrustStoreEntry entry, CancellationToken cancellationToken = default)
    {
        if (entry is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_ENTRY_IS_NULL);
            throw new ArgumentNullException(nameof(entry));
        }

        string thumbprint = ThumbprintNormalizer.NormalizeRequired(entry.Thumbprint);
        RequireText(thumbprint, entry.SubjectDistinguishedName, SUBJECT_FIELD_NAME);
        RequireText(thumbprint, entry.SerialNumber, SERIAL_NUMBER_FIELD_NAME);
        RequireText(thumbprint, entry.AddedBy, ADDED_BY_FIELD_NAME);

        try
        {
            await using SqliteConnection connection = _database.OpenConnection();
            await using SqliteCommand command = connection.CreateCommand();
            command.CommandText = SAVE_SQL;
            command.Parameters.AddWithValue(THUMBPRINT_PARAMETER, thumbprint);
            command.Parameters.AddWithValue(LIST_TYPE_PARAMETER, entry.ListType.ToString());
            command.Parameters.AddWithValue(SUBJECT_DN_PARAMETER, entry.SubjectDistinguishedName);
            command.Parameters.AddWithValue(SERIAL_NUMBER_PARAMETER, entry.SerialNumber);
            command.Parameters.AddWithValue(NOT_BEFORE_PARAMETER, FormatTime(entry.NotBefore));
            command.Parameters.AddWithValue(NOT_AFTER_PARAMETER, FormatTime(entry.NotAfter));
            command.Parameters.AddWithValue(ADDED_BY_PARAMETER, entry.AddedBy);
            command.Parameters.AddWithValue(ADDED_AT_PARAMETER, FormatTime(entry.AddedAt));
            command.Parameters.AddWithValue(COMMENT_PARAMETER, (object?)entry.Comment ?? DBNull.Value);
            command.Parameters.AddWithValue(IS_ACTIVE_PARAMETER, entry.IsActive ? 1 : 0);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (SqliteException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_SAVE_FAILED, thumbprint, ex.Message);
            throw;
        }
    }

    /// <inheritdoc />
    public async Task<TrustStoreEntry?> GetByThumbprintAsync(string thumbprint, CancellationToken cancellationToken = default)
    {
        string normalized = ThumbprintNormalizer.NormalizeRequired(thumbprint);

        try
        {
            await using SqliteConnection connection = _database.OpenConnection();
            await using SqliteCommand command = connection.CreateCommand();
            command.CommandText = GET_BY_THUMBPRINT_SQL;
            command.Parameters.AddWithValue(THUMBPRINT_PARAMETER, normalized);

            await using SqliteDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
            return await reader.ReadAsync(cancellationToken) ? ReadEntry(reader) : null;
        }
        catch (SqliteException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_READ_FAILED, ex.Message);
            throw;
        }
    }

    /// <inheritdoc />
    public async Task<IReadOnlyList<TrustStoreEntry>> GetActiveByListAsync(TrustListType listType, CancellationToken cancellationToken = default)
    {
        var entries = new List<TrustStoreEntry>();

        try
        {
            await using SqliteConnection connection = _database.OpenConnection();
            await using SqliteCommand command = connection.CreateCommand();
            command.CommandText = GET_ACTIVE_BY_LIST_SQL;
            command.Parameters.AddWithValue(LIST_TYPE_PARAMETER, listType.ToString());

            await using SqliteDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                entries.Add(ReadEntry(reader));
            }
        }
        catch (SqliteException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_READ_FAILED, ex.Message);
            throw;
        }

        return entries;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Throws ArgumentException and logs when a required text of the entry is empty.
    /// </summary>
    private static void RequireText(string thumbprint, string? value, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_ENTRY_FIELD_MISSING, thumbprint, fieldName);
            throw new ArgumentException($"The {fieldName} is required.", nameof(value));
        }
    }

    /// <summary>
    /// Writes a time as UTC text that sorts correctly and keeps its full precision.
    /// </summary>
    private static string FormatTime(DateTimeOffset value)
    {
        return value.ToUniversalTime().ToString(TIME_FORMAT, CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Reads a time that FormatTime wrote.
    /// </summary>
    private static DateTimeOffset ParseTime(string value)
    {
        return DateTimeOffset.Parse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
    }

    /// <summary>
    /// Turns the current row of the reader into an entry.
    /// </summary>
    private static TrustStoreEntry ReadEntry(SqliteDataReader reader)
    {
        return new TrustStoreEntry
        {
            Thumbprint = reader.GetString(THUMBPRINT_COLUMN),
            ListType = Enum.Parse<TrustListType>(reader.GetString(LIST_TYPE_COLUMN)),
            SubjectDistinguishedName = reader.GetString(SUBJECT_DN_COLUMN),
            SerialNumber = reader.GetString(SERIAL_NUMBER_COLUMN),
            NotBefore = ParseTime(reader.GetString(NOT_BEFORE_COLUMN)),
            NotAfter = ParseTime(reader.GetString(NOT_AFTER_COLUMN)),
            AddedBy = reader.GetString(ADDED_BY_COLUMN),
            AddedAt = ParseTime(reader.GetString(ADDED_AT_COLUMN)),
            Comment = reader.IsDBNull(COMMENT_COLUMN) ? null : reader.GetString(COMMENT_COLUMN),
            IsActive = reader.GetInt64(IS_ACTIVE_COLUMN) != 0
        };
    }

    #endregion
}
