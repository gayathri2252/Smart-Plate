﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Sets up the PostgreSQL side of Certificate Handler by itself: the database user and its password,
/// the database, the schema, the migrations and the permissions. No manual database work is needed.
/// The password of the database user is created by the application and kept sealed on this computer.
/// The administrator account is used only when something is missing; it is not needed on a normal start.
/// </summary>
public static class DatabaseSetup
{
    #region Member Variables

    private const string SEALED_SECRET_FILE_NAME = "database-user.secret";

    #endregion

    #region Public Methods

    /// <summary>
    /// Makes the database ready for the application and puts the password of the database user into
    /// <paramref name="options"/>. Does nothing when SkipBootstrap is set.
    /// A normal start only checks the database with the database user. When the user, the database,
    /// the schema or a migration is missing, the administrator password from the environment variable
    /// CH_DB_ADMIN_PASSWORD is used to create it. Throws DatabaseSetupException with a message for the user.
    /// </summary>
    /// <param name="options">Database settings. Its Password is set to the password of the database user.</param>
    /// <param name="keyProtector">Seals the password of the database user on this computer.</param>
    /// <param name="additionalAccounts">Extra Windows accounts that may use the folder of the sealed password.</param>
    public static void EnsureReady(
        DatabaseOptions options,
        IKeyProtector keyProtector,
        IEnumerable<string>? additionalAccounts = null)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(keyProtector);

        if (options.SkipBootstrap)
        {
            return;
        }

        options.Validate();
        CheckUsersDiffer(options);

        options.Password = ResolveApplicationPassword(options, keyProtector, additionalAccounts);

        if (IsReady(options, out string reason))
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_READY, options.Username);
            return;
        }

        string adminPassword = ResolveAdminPassword(reason);
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_STARTED, options.AdminUsername, reason);
        try
        {
            CreateMissing(options, adminPassword);
        }
        catch (NpgsqlException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_FAILED, ex.Message);
            throw new DatabaseSetupException(string.Format(DatabaseConstants.DB_SETUP_FAILED_MESSAGE, ex.Message), ex);
        }

        if (!IsReady(options, out _))
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_NOT_READY, options.Username);
            throw new DatabaseSetupException(DatabaseConstants.DB_SETUP_NOT_READY_MESSAGE);
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_READY, options.Username);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Throws when the database user and the administrator are the same account, because the application
    /// must run with the limited database user only.
    /// </summary>
    private static void CheckUsersDiffer(DatabaseOptions options)
    {
        if (string.Equals(options.Username, options.AdminUsername, StringComparison.OrdinalIgnoreCase))
        {
            throw new DatabaseSetupException(DatabaseConstants.DB_SETUP_SAME_USER_MESSAGE);
        }
    }

    /// <summary>
    /// Returns the password of the database user. A developer override in CH_DB_PASSWORD or in the settings
    /// is used as it is; otherwise the password is read from the sealed file or created on the first run.
    /// </summary>
    private static string ResolveApplicationPassword(
        DatabaseOptions options,
        IKeyProtector keyProtector,
        IEnumerable<string>? additionalAccounts)
    {
        string? fromEnvironment = Environment.GetEnvironmentVariable(DatabaseConstants.PasswordEnvironmentVariable);
        if (!string.IsNullOrEmpty(fromEnvironment))
        {
            return fromEnvironment;
        }

        if (!string.IsNullOrEmpty(options.Password))
        {
            return options.Password;
        }

        string directory = options.ResolveSecretDirectory();
        PrepareSecretFolder(directory, additionalAccounts);

        var provider = new DatabasePasswordProvider(Path.Combine(directory, SEALED_SECRET_FILE_NAME), keyProtector);
        return provider.GetOrCreatePassword();
    }

    /// <summary>
    /// Creates the folder of the sealed password and restricts it to the system, the administrators
    /// and the running account.
    /// </summary>
    private static void PrepareSecretFolder(string directory, IEnumerable<string>? additionalAccounts)
    {
        try
        {
            Directory.CreateDirectory(directory);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_CREATE_FAILED, directory, ex.Message);
            throw new DatabaseSetupException(DatabaseConstants.DB_SETUP_PASSWORD_CREATE_MESSAGE, ex);
        }

        TrustStoreFolderSecurity.Restrict(directory, additionalAccounts);
    }

    /// <summary>
    /// Returns the administrator password from the environment variable, or throws a message for the user.
    /// </summary>
    private static string ResolveAdminPassword(string reason)
    {
        string? password = Environment.GetEnvironmentVariable(DatabaseConstants.ADMIN_PASSWORD_ENVIRONMENT_VARIABLE);
        if (string.IsNullOrEmpty(password))
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_ADMIN_PASSWORD_MISSING, reason);
            throw new DatabaseSetupException(string.Format(DatabaseConstants.DB_SETUP_ADMIN_PASSWORD_MISSING_MESSAGE, reason));
        }

        return password;
    }

    /// <summary>
    /// Returns true when the database user can sign in and both migrations are recorded.
    /// Returns false with the reason when the user, the database, the schema or a migration is missing or not allowed.
    /// Problems that the set-up cannot fix (for example a missing certificate) are thrown.
    /// </summary>
    private static bool IsReady(DatabaseOptions options, out string reason)
    {
        reason = DatabaseConstants.DB_SETUP_REASON_MIGRATION_MISSING;
        try
        {
            using var connection = DatabaseConnection.Open(options, options.BuildConnectionString());
            return MigrationRecorded(connection.Connection, DatabaseConstants.AppliedMigrationId)
                && MigrationRecorded(connection.Connection, DatabaseConstants.DASHBOARD_INDEXES_MIGRATION_ID);
        }
        catch (NpgsqlException ex)
        {
            reason = ex.Message;
            return false;
        }
    }

    /// <summary>
    /// Creates what is missing with the administrator account. Everything is idempotent, so a start
    /// that was interrupted can simply run again.
    /// </summary>
    private static void CreateMissing(DatabaseOptions options, string adminPassword)
    {
        string adminServerConnection = options.BuildSetupConnectionString(
            DatabaseConstants.AdminDatabaseName, options.AdminUsername, adminPassword);

        using (var server = DatabaseConnection.Open(options, adminServerConnection))
        {
            EnsureRole(server.Connection, options.Username, options.Password);
            EnsureDatabase(server.Connection, DatabaseOptions.Database);
        }

        string adminDatabaseConnection = options.BuildSetupConnectionString(
            DatabaseOptions.Database, options.AdminUsername, adminPassword);

        using var database = DatabaseConnection.Open(options, adminDatabaseConnection);
        using NpgsqlTransaction transaction = database.Connection.BeginTransaction();

        if (!MigrationRecorded(database.Connection, DatabaseConstants.AppliedMigrationId, transaction))
        {
            Execute(database.Connection, LoadEmbeddedSql(DatabaseConstants.EmbeddedSchemaResourceName), transaction);
            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_SCHEMA_APPLIED, DatabaseConstants.SchemaName);
        }

        if (!MigrationRecorded(database.Connection, DatabaseConstants.DASHBOARD_INDEXES_MIGRATION_ID, transaction))
        {
            Execute(database.Connection, LoadEmbeddedSql(DatabaseConstants.EMBEDDED_DASHBOARD_INDEXES_RESOURCE_NAME), transaction);
            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_MIGRATION_APPLIED, DatabaseConstants.DASHBOARD_INDEXES_MIGRATION_ID);
        }

        Execute(database.Connection, BuildGrantStatements(DatabaseOptions.Database, options.Username), transaction);
        transaction.Commit();
        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PERMISSIONS_GRANTED, options.Username);
    }

    /// <summary>
    /// Creates the database user, or sets the password of the existing user, so the password in the
    /// sealed file always works. The user may sign in but is not a superuser and cannot create databases or roles.
    /// </summary>
    private static void EnsureRole(NpgsqlConnection connection, string role, string password)
    {
        bool exists = ExecuteScalar(connection, "SELECT 1 FROM pg_roles WHERE rolname = @name", ("name", role)) is not null;
        string verb = exists ? "ALTER ROLE" : "CREATE ROLE";

        string statement = (string)ExecuteScalar(
            connection,
            $"SELECT format('{verb} %I WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD %L', @name::text, @password::text)",
            ("name", role),
            ("password", password))!;

        Execute(connection, statement);
        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_ROLE_READY, role);
    }

    /// <summary>
    /// Creates the database when it does not exist yet.
    /// </summary>
    private static void EnsureDatabase(NpgsqlConnection connection, string database)
    {
        if (ExecuteScalar(connection, "SELECT 1 FROM pg_database WHERE datname = @name", ("name", database)) is not null)
        {
            return;
        }

        string statement = (string)ExecuteScalar(
            connection,
            "SELECT format('CREATE DATABASE %I ENCODING ''UTF8'' TEMPLATE template0', @name::text)",
            ("name", database))!;

        Execute(connection, statement);
        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_DATABASE_CREATED, database);
    }

    /// <summary>
    /// Builds the permissions of the database user: read, insert and update on the tables, use of the
    /// sequences, and the same for tables created later. There is no delete or truncate permission.
    /// </summary>
    private static string BuildGrantStatements(string database, string role)
    {
        string user = QuoteIdentifier(role);
        string schema = DatabaseConstants.SchemaName;

        return $"""
            GRANT CONNECT ON DATABASE {QuoteIdentifier(database)} TO {user};
            GRANT USAGE ON SCHEMA {schema} TO {user};
            GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA {schema} TO {user};
            GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA {schema} TO {user};
            ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} GRANT SELECT, INSERT, UPDATE ON TABLES TO {user};
            ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} GRANT USAGE, SELECT ON SEQUENCES TO {user};
            """;
    }

    /// <summary>
    /// Returns true when the migration is recorded in the schema migration table. A missing table means no.
    /// </summary>
    private static bool MigrationRecorded(NpgsqlConnection connection, string migrationId, NpgsqlTransaction? transaction = null)
    {
        string table = $"{DatabaseConstants.SchemaName}.{DatabaseConstants.SchemaMigrationTable}";
        if (ExecuteScalar(connection, "SELECT to_regclass(@table)::text", transaction, ("table", table)) is not string)
        {
            return false;
        }

        return ExecuteScalar(
            connection,
            $"SELECT 1 FROM {table} WHERE migration_id = @migrationId",
            transaction,
            ("migrationId", migrationId)) is not null;
    }

    /// <summary>
    /// Doubles quotes and puts the name in quotes, so it is safe as a PostgreSQL identifier.
    /// </summary>
    private static string QuoteIdentifier(string name)
    {
        return "\"" + name.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    }

    /// <summary>
    /// Reads an embedded SQL file of this assembly.
    /// </summary>
    private static string LoadEmbeddedSql(string resourceName)
    {
        using Stream stream = typeof(DatabaseSetup).Assembly.GetManifestResourceStream(resourceName)
            ?? throw new DatabaseSetupException(string.Format(DatabaseConstants.DB_SETUP_RESOURCE_MISSING_MESSAGE, resourceName));

        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    /// <summary>
    /// Runs statements that return no rows. A long timeout is used because the schema script is large.
    /// </summary>
    private static void Execute(NpgsqlConnection connection, string sql, NpgsqlTransaction? transaction = null)
    {
        using var command = new NpgsqlCommand(sql, connection, transaction)
        {
            CommandTimeout = DatabaseConstants.SchemaCommandTimeoutSeconds
        };
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Runs a query with parameters and returns the first value, or null when there is no row.
    /// </summary>
    private static object? ExecuteScalar(NpgsqlConnection connection, string sql, params (string Name, object Value)[] parameters)
    {
        return ExecuteScalar(connection, sql, null, parameters);
    }

    /// <summary>
    /// Runs a query with parameters inside the transaction and returns the first value, or null when there is no row.
    /// </summary>
    private static object? ExecuteScalar(
        NpgsqlConnection connection,
        string sql,
        NpgsqlTransaction? transaction,
        params (string Name, object Value)[] parameters)
    {
        using var command = new NpgsqlCommand(sql, connection, transaction);
        foreach ((string name, object value) in parameters)
        {
            command.Parameters.AddWithValue(name, value);
        }

        object? result = command.ExecuteScalar();
        return result is DBNull ? null : result;
    }

    #endregion
}
