// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Reflection;
using NpgsqlTypes;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Converts enums to and from the PostgreSQL labels declared by their PgName attributes.
/// </summary>
public static class PostgresEnumNames
{
    #region Public Methods

    /// <summary>
    /// Returns the PostgreSQL label of the value; throws if it has none.
    /// </summary>
    public static string ToPgName<TEnum>(TEnum value)
        where TEnum : struct, Enum
    {
        if (!Labels<TEnum>.ByValue.TryGetValue(value, out string? label))
        {
            throw new InvalidOperationException($"Unrecognized {typeof(TEnum).Name} value: {value}");
        }

        return label;
    }

    /// <summary>
    /// Returns the enum value for the PostgreSQL label; throws if it is unknown.
    /// </summary>
    public static TEnum FromPgName<TEnum>(string label)
        where TEnum : struct, Enum
    {
        if (label is null || !Labels<TEnum>.ByLabel.TryGetValue(label, out TEnum value))
        {
            throw new InvalidOperationException($"Unrecognized {typeof(TEnum).Name} label: {label}");
        }

        return value;
    }

    #endregion

    #region Member Variables

    // Built once per enum type, from its PgName attributes.
    /// <summary>
    /// Caches the PostgreSQL labels of one enum type, built once from its PgName attributes.
    /// </summary>
    private static class Labels<TEnum>
        where TEnum : struct, Enum
    {
        #region Member Variables

        public static readonly Dictionary<TEnum, string> ByValue;

        public static readonly Dictionary<string, TEnum> ByLabel;

        #endregion

        #region Constructor

        /// <summary>
        /// Reads the PostgreSQL label of each enum member from its PgName attribute
        /// and fills the lookup tables.
        /// </summary>
        static Labels()
        {
            var byValue = new Dictionary<TEnum, string>();
            var byLabel = new Dictionary<string, TEnum>(StringComparer.Ordinal);

            foreach (FieldInfo field in typeof(TEnum).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                PgNameAttribute? attribute = field.GetCustomAttribute<PgNameAttribute>();
                if (attribute is null)
                {
                    continue;
                }

                var value = (TEnum)field.GetValue(null)!;
                byValue[value] = attribute.PgName;
                byLabel[attribute.PgName] = value;
            }

            ByValue = byValue;
            ByLabel = byLabel;
        }

        #endregion
    }

    #endregion
}
