﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Options;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Creates the application database and applies the embedded schema on first run.
/// </summary>
public static class DatabaseBootstrapper
{
    #region Member Variables

    private static readonly Lazy<string> EmbeddedSchemaSql = new(
        LoadEmbeddedSchemaSql,
        LazyThreadSafetyMode.ExecutionAndPublication);

    private static readonly (string MigrationId, string ResourceName)[] IncrementalMigrations =
    [
        (DatabaseConstants.DashboardIndexesMigrationId, DatabaseConstants.EmbeddedDashboardIndexesMigrationResourceName),
        (DatabaseConstants.SecurityHardeningMigrationId, DatabaseConstants.EmbeddedSecurityHardeningMigrationResourceName),
        (DatabaseConstants.TrustChannelsMigrationId, DatabaseConstants.EmbeddedTrustChannelsMigrationResourceName)
    ];

    #endregion

    #region Public Methods

    public static void EnsureInitialized(DatabaseOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        options.Validate();

        if (options.SkipBootstrap)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_SKIPPED);
            TryApplyPendingMigrations(options);
            return;
        }

        try
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_STARTED, DatabaseOptions.Database);
            EnsureDatabaseExists(options);

            if (IsSchemaApplied(options))
            {
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_SCHEMA_PRESENT, DatabaseOptions.Database);
            }
            else
            {
                ApplyEmbeddedSchema(options);
                CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.DB_SCHEMA_APPLIED, DatabaseOptions.Database);
            }

            TryApplyPendingMigrations(options);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_FAILED, DatabaseOptions.Database, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    private static void EnsureDatabaseExists(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenConnection(options, DatabaseConstants.AdminDatabaseName);
        NpgsqlConnection connection = scope.Connection;

        using var existsCommand = connection.CreateCommand();
        existsCommand.CommandText = "SELECT 1 FROM pg_database WHERE datname = @name";
        existsCommand.Parameters.AddWithValue("name", DatabaseOptions.Database);

        if (existsCommand.ExecuteScalar() is not null)
        {
            return;
        }

        using var createCommand = connection.CreateCommand();
        createCommand.CommandText = BuildCreateDatabaseStatement(DatabaseOptions.Database);
        createCommand.ExecuteNonQuery();
        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.DB_CREATED, DatabaseOptions.Database);
    }

    private static bool IsSchemaApplied(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenApplicationConnection(options);
        NpgsqlConnection connection = scope.Connection;

        if (!MigrationTableExists(connection))
        {
            return false;
        }

        return MigrationRecordExists(connection, DatabaseConstants.AppliedMigrationId);
    }

    private static void ApplyEmbeddedSchema(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenApplicationConnection(options);
        NpgsqlConnection connection = scope.Connection;

        using var command = connection.CreateCommand();
        command.CommandText = EmbeddedSchemaSql.Value;
        command.CommandTimeout = DatabaseConstants.SchemaCommandTimeoutSeconds;
        command.ExecuteNonQuery();
    }

    private static void TryApplyPendingMigrations(DatabaseOptions options)
    {
        try
        {
            using BootstrapConnectionScope scope = OpenApplicationConnection(options);
            NpgsqlConnection connection = scope.Connection;

            if (!MigrationTableExists(connection))
            {
                return;
            }

            foreach ((string migrationId, string resourceName) in IncrementalMigrations)
            {
                if (MigrationRecordExists(connection, migrationId))
                {
                    continue;
                }

                ApplyEmbeddedMigration(connection, resourceName);
            }
        }
        catch (NpgsqlException)
        {
            if (!options.SkipBootstrap)
            {
                throw;
            }
        }
    }

    private static BootstrapConnectionScope OpenApplicationConnection(DatabaseOptions options) =>
        OpenConnection(options, DatabaseOptions.Database);

    private static BootstrapConnectionScope OpenConnection(DatabaseOptions options, string databaseName)
    {
        var connectionStringBuilder = new NpgsqlConnectionStringBuilder(options.BuildConnectionString())
        {
            Database = databaseName
        };

        if (!options.UsesClientCertificate)
        {
            var connection = new NpgsqlConnection(connectionStringBuilder.ConnectionString);
            DatabaseServerConnection.Open(connection);
            return new BootstrapConnectionScope(connection, null, null);
        }

        var dataSourceBuilder = new NpgsqlDataSourceBuilder(connectionStringBuilder.ConnectionString);
        X509Certificate2? clientCertificate = PostgresTlsConfiguration.Apply(dataSourceBuilder, options);
        NpgsqlDataSource dataSource = dataSourceBuilder.Build();
        NpgsqlConnection tlsConnection = dataSource.OpenConnection();
        return new BootstrapConnectionScope(tlsConnection, dataSource, clientCertificate);
    }

    private sealed class BootstrapConnectionScope : IDisposable
    {
        private readonly NpgsqlConnection _connection;
        private readonly NpgsqlDataSource? _dataSource;
        private readonly X509Certificate2? _clientCertificate;

        public BootstrapConnectionScope(
            NpgsqlConnection connection,
            NpgsqlDataSource? dataSource,
            X509Certificate2? clientCertificate)
        {
            _connection = connection;
            _dataSource = dataSource;
            _clientCertificate = clientCertificate;
        }

        public NpgsqlConnection Connection => _connection;

        public void Dispose()
        {
            _connection.Dispose();
            _dataSource?.Dispose();
            _clientCertificate?.Dispose();
        }
    }

    private static void ApplyEmbeddedMigration(NpgsqlConnection connection, string resourceName)
    {
        string sql = LoadEmbeddedResource(resourceName);

        using var command = connection.CreateCommand();
        command.CommandText = sql;
        command.CommandTimeout = DatabaseConstants.SchemaCommandTimeoutSeconds;
        command.ExecuteNonQuery();
    }

    private static string LoadEmbeddedSchemaSql() =>
        LoadEmbeddedResource(DatabaseConstants.EmbeddedSchemaResourceName);

    private static string LoadEmbeddedResource(string resourceName)
    {
        var assembly = typeof(DatabaseBootstrapper).Assembly;
        using var stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException($"Embedded resource not found: {resourceName}");

        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    private static string BuildCreateDatabaseStatement(string databaseName)
    {
        var escapedName = databaseName.Replace("\"", "\"\"", StringComparison.Ordinal);
        return $"""CREATE DATABASE "{escapedName}" ENCODING 'UTF8' TEMPLATE template0""";
    }

    private static bool MigrationTableExists(NpgsqlConnection connection)
    {
        using var schemaCommand = connection.CreateCommand();
        schemaCommand.CommandText =
            """
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = @schemaName
              AND table_name = @tableName
            """;
        schemaCommand.Parameters.AddWithValue("schemaName", DatabaseConstants.SchemaName);
        schemaCommand.Parameters.AddWithValue("tableName", DatabaseConstants.SchemaMigrationTable);
        return schemaCommand.ExecuteScalar() is not null;
    }

    private static bool MigrationRecordExists(NpgsqlConnection connection, string migrationId)
    {
        using var migrationCommand = connection.CreateCommand();
        migrationCommand.CommandText =
            $"""
            SELECT 1
            FROM {DatabaseConstants.SchemaName}.{DatabaseConstants.SchemaMigrationTable}
            WHERE migration_id = @migrationId
            """;
        migrationCommand.Parameters.AddWithValue("migrationId", migrationId);
        return migrationCommand.ExecuteScalar() is not null;
    }

    #endregion
}
