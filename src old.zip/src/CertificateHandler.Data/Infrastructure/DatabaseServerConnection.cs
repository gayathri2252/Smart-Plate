﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Opens connections to the database server. When the server cannot be reached, the server (host:port)
/// and the reason are written to the Log Monitor before the error is passed on, so a lost database server
/// is always visible in the logs.
/// </summary>
public static class DatabaseServerConnection
{
    #region Public Methods

    /// <summary>Opens the given connection; logs the server and the reason when it fails.</summary>
    public static async Task OpenAsync(NpgsqlConnection connection, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(connection);

        try
        {
            await connection.OpenAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            LogUnreachable(connection.Host, connection.Port, ex);
            throw;
        }
    }

    /// <summary>Opens a connection from the data source; logs the server and the reason when it fails.</summary>
    public static async Task<NpgsqlConnection> OpenAsync(NpgsqlDataSource dataSource, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(dataSource);

        try
        {
            return await dataSource.OpenConnectionAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            LogUnreachable(dataSource, ex);
            throw;
        }
    }

    /// <summary>Opens the given connection synchronously; logs the server and the reason when it fails.</summary>
    public static void Open(NpgsqlConnection connection)
    {
        ArgumentNullException.ThrowIfNull(connection);

        try
        {
            connection.Open();
        }
        catch (Exception ex)
        {
            LogUnreachable(connection.Host, connection.Port, ex);
            throw;
        }
    }

    /// <summary>Opens a connection from the data source synchronously; logs the server and the reason when it fails.</summary>
    public static NpgsqlConnection Open(NpgsqlDataSource dataSource)
    {
        ArgumentNullException.ThrowIfNull(dataSource);

        try
        {
            return dataSource.OpenConnection();
        }
        catch (Exception ex)
        {
            LogUnreachable(dataSource, ex);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>Logs the server of the data source and the reason.</summary>
    private static void LogUnreachable(NpgsqlDataSource dataSource, Exception error)
    {
        string? host = null;
        int port = 0;
        try
        {
            var builder = new NpgsqlConnectionStringBuilder(dataSource.ConnectionString);
            host = builder.Host;
            port = builder.Port;
        }
        catch (ArgumentException)
        {
            // The server stays unknown in the log line.
        }

        LogUnreachable(host, port, error);
    }

    /// <summary>Writes the Error line with host:port and the reason.</summary>
    private static void LogUnreachable(string? host, int port, Exception error)
    {
        string server = string.IsNullOrWhiteSpace(host) ? DatabaseConstants.UNKNOWN_SERVER : host + ":" + port;
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.DB_SERVER_UNREACHABLE, server, error.Message);
    }

    #endregion
}