// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Thrown when the application cannot set up the PostgreSQL database by itself.
/// The message is written for the user and can be shown as it is.
/// </summary>
public sealed class DatabaseSetupException : Exception
{
    #region Constructor

    /// <summary>
    /// Creates the exception with a message for the user.
    /// </summary>
    public DatabaseSetupException(string message) : base(message)
    {
    }

    /// <summary>
    /// Creates the exception with a message for the user and the error that caused it.
    /// </summary>
    public DatabaseSetupException(string message, Exception innerException) : base(message, innerException)
    {
    }

    #endregion
}
