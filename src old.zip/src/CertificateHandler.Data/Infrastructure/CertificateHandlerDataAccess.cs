﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Options;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Owns the shared <see cref="NpgsqlDataSource"/> and factory for <see cref="CertificateHandlerDbContext"/>.
/// Dispose once per application lifetime to release the connection pool.
/// </summary>
public sealed class CertificateHandlerDataAccess : IAsyncDisposable, IDisposable
{
    #region Member Variables

    private readonly NpgsqlDataSource _dataSource;

    private readonly X509Certificate2? _clientCertificate;

    private readonly DbContextOptions<CertificateHandlerDbContext> _contextOptions;

    private bool _disposed;

    #endregion

    #region Public Properties

    /// <summary>
    /// Shared connection pool used by EF Core and ad hoc SQL callers.
    /// </summary>
    public NpgsqlDataSource DataSource
    {
        get
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            return _dataSource;
        }
    }

    #endregion

    #region Constructor

    /// <summary>
    /// Stores the data source, the context options and the client certificate that this object owns.
    /// </summary>
    private CertificateHandlerDataAccess(
        NpgsqlDataSource dataSource,
        DbContextOptions<CertificateHandlerDbContext> contextOptions,
        X509Certificate2? clientCertificate)
    {
        _dataSource = dataSource;
        _contextOptions = contextOptions;
        _clientCertificate = clientCertificate;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Builds the data source from the options, with the enum mappings and the TLS client certificate.
    /// Reads the certificates from the given store location, LocalMachine by default.
    /// Returns the data access object that owns them.
    /// </summary>
    public static CertificateHandlerDataAccess Create(
        DatabaseOptions options,
        StoreLocation certificateStoreLocation = StoreLocation.LocalMachine)
    {
        ArgumentNullException.ThrowIfNull(options);
        options.Validate();

        var dataSourceBuilder = new NpgsqlDataSourceBuilder(options.BuildConnectionString());
        PostgresEnumRegistration.Configure(dataSourceBuilder);
        X509Certificate2? clientCertificate = PostgresTlsConfiguration.Apply(dataSourceBuilder, options, certificateStoreLocation);

        try
        {
            var dataSource = dataSourceBuilder.Build();

            var contextOptions = new DbContextOptionsBuilder<CertificateHandlerDbContext>()
                .UseNpgsql(dataSource, npgsql => npgsql.EnableRetryOnFailure(maxRetryCount: 3))
                .UseSnakeCaseNamingConvention()
                .Options;

            return new CertificateHandlerDataAccess(dataSource, contextOptions, clientCertificate);
        }
        catch
        {
            clientCertificate?.Dispose();
            throw;
        }
    }

    /// <summary>
    /// Creates a new database context that uses the shared data source.
    /// </summary>
    public CertificateHandlerDbContext CreateDbContext()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        return new CertificateHandlerDbContext(_contextOptions);
    }

    /// <summary>
    /// Opens a raw connection through the same data source the application uses,
    /// so the TLS settings and certificate checks are exercised exactly as in production.
    /// </summary>
    public ValueTask<NpgsqlConnection> OpenConnectionAsync(CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        return new ValueTask<NpgsqlConnection>(DatabaseServerConnection.OpenAsync(_dataSource, cancellationToken));
    }

    #endregion

    #region Dispose Methods

    /// <summary>
    /// Releases the data source and the client certificate.
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _dataSource.Dispose();
        _clientCertificate?.Dispose();
        _disposed = true;
    }

    /// <inheritdoc />
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        await _dataSource.DisposeAsync().ConfigureAwait(false);
        _clientCertificate?.Dispose();
        _disposed = true;
    }

    #endregion
}