﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Stand-in publisher until the real one exists. It succeeds, unless the flag file
/// simulate-publish-failure.flag exists in the working directory; then it throws, so QA can force a failure
/// after a successful save. Replace it with the real publisher by changing one registration.
/// </summary>
public sealed class SimulatedTrustUpdatePublisher : ITrustUpdatePublisher
{
    #region Public Methods

    /// <summary>
    /// Publishes the specified trust update. When the simulation flag file exists,
    /// a publish failure is intentionally generated to support testing of failure
    /// handling, audit logging, and administrator notifications.
    /// </summary>
    /// <param name="update">
    /// Trust update to publish.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the publish operation.
    /// </param>
    /// <returns>
    /// A task that completes when the publish operation finishes.
    /// </returns>
    public Task PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default)
    {
        string flagPath = Path.Combine(AppContext.BaseDirectory, TrustPublishConstants.SIMULATE_FAILURE_FLAG_FILE);
        if (File.Exists(flagPath) || File.Exists(TrustPublishConstants.SIMULATE_FAILURE_FLAG_FILE))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataLogConstants.TRUST_UPDATE_SIMULATED_FAILURE, update?.ThumbprintSha256 ?? string.Empty);
            throw new InvalidOperationException(TrustPublishConstants.SIMULATED_FAILURE_MESSAGE);
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.TRUST_UPDATE_SIMULATED, update?.Change ?? string.Empty, update?.ThumbprintSha256 ?? string.Empty);
        return Task.CompletedTask;
    }

    #endregion
}
