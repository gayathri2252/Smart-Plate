using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Retries pending trust-event deliveries to in-device subscribers (RS_27).
/// </summary>
public sealed class TrustEventDeliveryService
{
    #region Member Variables

    private readonly NpgsqlDataSource _dataSource;

    private readonly IInDeviceTrustSubscriberChannel _channel;

    private const int MaxAttempts = 5;

    private const string DefaultSubscriber = "MAXUM_IN_DEVICE";

    #endregion

    #region Constructor

    public TrustEventDeliveryService(NpgsqlDataSource dataSource, IInDeviceTrustSubscriberChannel? channel = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _channel = channel ?? new ServiceGateTrustSubscriberChannel();
    }

    #endregion

    #region Public Methods

    public async Task<int> DeliverPendingAsync(CancellationToken cancellationToken = default)
    {
        int delivered = 0;
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var select = new NpgsqlCommand(
            $"SELECT d.delivery_id, d.event_id, d.subscriber_name, d.attempt_count, e.new_trust_status, e.thumbprint_sha256 " +
            $"FROM {DatabaseConstants.SchemaName}.ch_trust_event_delivery d " +
            $"JOIN {DatabaseConstants.SchemaName}.ch_trust_event e ON e.event_id = d.event_id " +
            "WHERE d.status IN ('PENDING', 'RETRYING', 'FAILED') AND d.attempt_count < @max ORDER BY d.delivery_id LIMIT 50",
            connection);
        select.Parameters.AddWithValue("max", MaxAttempts);

        var pending = new List<(long DeliveryId, Guid EventId, string Subscriber, int Attempts, string Status, string Thumbprint)>();
        await using (var reader = await select.ExecuteReaderAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                pending.Add((reader.GetInt64(0), reader.GetGuid(1), reader.GetString(2), reader.GetInt32(3), reader.GetString(4), reader.GetString(5)));
            }
        }

        foreach ((long deliveryId, Guid eventId, string subscriber, int attempts, string trustStatus, string thumbprint) in pending)
        {
            bool ok = await _channel.TryDeliverAsync(eventId, subscriber, trustStatus, thumbprint, cancellationToken);
            if (ok)
            {
                await using var update = new NpgsqlCommand(
                    $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
                    "SET status = 'DELIVERED', delivered_at = now(), last_attempt_at = now(), last_error = NULL, " +
                    "attempt_count = attempt_count + 1 WHERE delivery_id = @id",
                    connection);
                update.Parameters.AddWithValue("id", deliveryId);
                await update.ExecuteNonQueryAsync(cancellationToken);
                delivered++;
                continue;
            }

            int nextAttempts = attempts + 1;
            string status = nextAttempts >= MaxAttempts ? "FAILED" : "RETRYING";
            await using var fail = new NpgsqlCommand(
                $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
                "SET status = CAST(@status AS certificate_handler.trust_event_delivery_status), last_attempt_at = now(), " +
                "attempt_count = attempt_count + 1, last_error = @error WHERE delivery_id = @id",
                connection);
            fail.Parameters.AddWithValue("status", status);
            fail.Parameters.AddWithValue("error", "Delivery to in-device subscriber failed.");
            fail.Parameters.AddWithValue("id", deliveryId);
            await fail.ExecuteNonQueryAsync(cancellationToken);

            if (nextAttempts >= MaxAttempts)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Trust event {0} delivery exhausted retries; notify administrator (RS_27).",
                    eventId);
            }
        }

        return delivered;
    }

    public static async Task QueueDefaultSubscriberAsync(
        NpgsqlConnection connection,
        Guid eventId,
        CancellationToken cancellationToken = default)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
            "(event_id, subscriber_name, status) VALUES (@eventId, @subscriber, 'PENDING') " +
            "ON CONFLICT (event_id, subscriber_name) DO NOTHING",
            connection);
        command.Parameters.AddWithValue("eventId", eventId);
        command.Parameters.AddWithValue("subscriber", DefaultSubscriber);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion
}
