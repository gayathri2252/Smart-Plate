using CertificateHandler.Data.Interfaces;
using CertificateHandler.Shared.Trust;

namespace CertificateHandler.Data;

/// <summary>
/// Applies a delivered trust event to the in-device service gate (RS_27).
/// Whitelist opens protected services for that thumbprint. Every other status keeps them closed.
/// </summary>
public sealed class ServiceGateTrustSubscriberChannel : IInDeviceTrustSubscriberChannel
{
    public Task<bool> TryDeliverAsync(
        Guid eventId,
        string subscriberName,
        string newTrustStatus,
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _ = eventId;
        _ = subscriberName;
        if (string.Equals(newTrustStatus, "WHITELISTED", StringComparison.OrdinalIgnoreCase)
            || string.Equals(newTrustStatus, "ALLOWED", StringComparison.OrdinalIgnoreCase))
        {
            ProtectedServiceGate.Shared.Allow(thumbprintSha256);
        }
        else
        {
            ProtectedServiceGate.Shared.Deny(thumbprintSha256);
        }

        return Task.FromResult(true);
    }
}
