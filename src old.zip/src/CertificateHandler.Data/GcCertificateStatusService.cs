using CertificateHandler.Shared.Security;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data;

/// <summary>
/// Builds GC certificate expiry snapshot for administrators (RS_25).
/// </summary>
public sealed class GcCertificateStatusService : IGcCertificateStatusService
{
    #region Member Variables

    private readonly ICertificateExpiryReader _reader;

    private readonly ICertificateExpiryStatusCalculator _calculator;

    private readonly IAdministratorAuthorizer _authorizer;

    private readonly TimeProvider _time;

    #endregion

    #region Constructor

    public GcCertificateStatusService(
        ICertificateExpiryReader reader,
        ICertificateExpiryStatusCalculator calculator,
        IAdministratorAuthorizer authorizer,
        TimeProvider? time = null)
    {
        _reader = reader ?? throw new ArgumentNullException(nameof(reader));
        _calculator = calculator ?? throw new ArgumentNullException(nameof(calculator));
        _authorizer = authorizer ?? throw new ArgumentNullException(nameof(authorizer));
        _time = time ?? TimeProvider.System;
    }

    #endregion

    #region Public Methods

    public async Task<GcCertificateStatusSnapshot> GetSnapshotForAdministratorAsync(
        string? administratorUserName,
        CancellationToken cancellationToken = default)
    {
        if (!IsGcAccessAllowed(administratorUserName))
        {
            throw new UnauthorizedAccessException("Only authorized administrators can read GC certificate status.");
        }

        DateTimeOffset now = _time.GetUtcNow();
        IReadOnlyList<StoredCertificateInfo> stored = await _reader.ReadActiveLocalCertificatesAsync(cancellationToken);
        var rows = new List<GcCertificateRoleStatus>(2);
        foreach (CertificateRole role in new[] { CertificateRole.LocalSbc, CertificateRole.LocalMib })
        {
            StoredCertificateInfo? match = stored.FirstOrDefault(c => c.Role == role);
            if (match is null)
            {
                rows.Add(new GcCertificateRoleStatus
                {
                    Role = role,
                    RoleLabel = ToRoleLabel(role),
                    Status = CertificateExpiryStatus.NotAvailable,
                    StatusLabel = "Not available"
                });
                continue;
            }

            CertificateExpiryStatus status = _calculator.Calculate(match.NotAfter, now);
            rows.Add(new GcCertificateRoleStatus
            {
                Role = role,
                RoleLabel = ToRoleLabel(role),
                Subject = match.Subject,
                Issuer = match.Issuer,
                ThumbprintSha256 = match.Thumbprint,
                NotAfter = match.NotAfter,
                Status = status,
                StatusLabel = ToStatusLabel(status)
            });
        }

        return new GcCertificateStatusSnapshot
        {
            GeneratedAtUtc = now,
            Certificates = rows
        };
    }

    #endregion

    #region Private Methods

    private bool IsGcAccessAllowed(string? administratorUserName)
    {
        if (DevelopmentBypassGuard.IsBypassEnabled("CH_GC_SKIP_AUTH"))
        {
            CertificateHandler.Logger.CertificateHandlerLogger.Warning(
                CertificateHandler.Shared.Constants.MessageIdGenerator.Next(),
                "GC certificate export auth bypass is enabled (CH_GC_SKIP_AUTH).");
            return true;
        }

        return _authorizer.IsAdministrator(administratorUserName);
    }

    private static string ToRoleLabel(CertificateRole role) => role switch
    {
        CertificateRole.LocalSbc => "SBC",
        CertificateRole.LocalMib => "MIB",
        _ => role.ToString()
    };

    private static string ToStatusLabel(CertificateExpiryStatus status) => status switch
    {
        CertificateExpiryStatus.Valid => "Valid",
        CertificateExpiryStatus.NearingExpiration => "Nearing expiration",
        CertificateExpiryStatus.Expired => "Expired",
        _ => "Not available"
    };

    #endregion
}
