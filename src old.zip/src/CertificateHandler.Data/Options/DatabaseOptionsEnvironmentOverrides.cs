namespace CertificateHandler.Data.Options;

/// <summary>
/// Optional environment overrides for developer workstations (same variables as integration tests).
/// </summary>
public static class DatabaseOptionsEnvironmentOverrides
{
    public const string IntegrationUsernameVariable = "CH_PG_INTEGRATION_USERNAME";

    public const string ClientCertificateVariable = "CH_PG_CLIENT_CERT_NAME";

    public const string DefaultClientCertificateName = "Valmet-UserManagement-PostgreSQL-Client";

    public static void Apply(DatabaseOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        string? integrationUser = Environment.GetEnvironmentVariable(IntegrationUsernameVariable);
        if (!string.IsNullOrWhiteSpace(integrationUser))
        {
            options.Username = integrationUser;
        }

        if (DatabaseOptions.IsSameMachine(options.Host))
        {
            options.UsePlainTransportOnSameMachine();
            return;
        }

        string? clientCert = Environment.GetEnvironmentVariable(ClientCertificateVariable);
        if (!string.IsNullOrWhiteSpace(clientCert))
        {
            options.SslMode = true;
            options.ClientCertificateName = clientCert;
            return;
        }

        if (!string.IsNullOrWhiteSpace(integrationUser))
        {
            options.SslMode = true;
            options.ClientCertificateName = DefaultClientCertificateName;
        }
    }
}
