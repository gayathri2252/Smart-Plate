using System.Net;
using System.Net.Sockets;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Trust;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Receives subnet blacklist unicasts, checks the signature and subnet, then blocks the thumbprint (RS_33).
/// </summary>
public sealed class SubnetBlacklistReceiver : IDisposable
{
    private readonly IPropagatedBlacklistStore _store;
    private readonly object _gate = new();
    private CancellationTokenSource _stop = new();
    private UdpClient? _client;
    private Task? _loop;
    private bool _disposed;
    private DateTimeOffset _lastRejectLogUtc = DateTimeOffset.MinValue;
    private IReadOnlyList<IPAddress> _localAddresses = Array.Empty<IPAddress>();
    private DateTimeOffset _localAddressesReadUtc = DateTimeOffset.MinValue;

    public SubnetBlacklistReceiver(IPropagatedBlacklistStore store)
    {
        _store = store ?? throw new ArgumentNullException(nameof(store));
    }

    public void Start()
    {
        lock (_gate)
        {
            if (_disposed || _client is not null || _loop is { IsCompleted: false })
            {
                return;
            }

            _loop = null;

            string? key = BlacklistPropagationCodec.ReadKey();
            if (string.IsNullOrWhiteSpace(key) || key.Length < 16)
            {
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    "Blacklist unicast receiver is not listening because CH_BLACKLIST_SYNC_KEY is missing (RS_33).");
                return;
            }

            try
            {
                if (_stop.IsCancellationRequested)
                {
                    _stop.Dispose();
                    _stop = new CancellationTokenSource();
                }

                int port = BlacklistPropagationCodec.ReadPort();
                _client = new UdpClient(new IPEndPoint(IPAddress.Any, port));
                _loop = Task.Run(() => ReceiveLoopAsync(_client, _stop.Token));
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    "Blacklist unicast receiver is listening on UDP {0} (RS_33).",
                    port);
            }
            catch (Exception ex)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Blacklist unicast receiver did not start: {0}",
                    ex.Message);
                _client?.Dispose();
                _client = null;
                _loop = null;
            }
        }
    }

    /// <summary>
    /// Closes the socket and waits for the receive loop. A later <see cref="Start"/> can listen again.
    /// </summary>
    public void Stop()
    {
        lock (_gate)
        {
            UdpClient? client = _client;
            Task? loop = _loop;
            _client = null;
            _loop = null;

            try
            {
                _stop.Cancel();
            }
            catch (ObjectDisposedException)
            {
            }

            client?.Dispose();
            bool finished = true;
            try
            {
                finished = loop is null || loop.Wait(TimeSpan.FromSeconds(2));
            }
            catch (AggregateException)
            {
                finished = loop is null || loop.IsCompleted;
            }

            if (!finished)
            {
                _loop = loop;
            }
        }
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed)
            {
                return;
            }

            _disposed = true;
        }

        Stop();
        _stop.Dispose();
    }

    private async Task ReceiveLoopAsync(UdpClient client, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                UdpReceiveResult result = await client.ReceiveAsync(cancellationToken);
                if (!BlacklistPropagationCodec.TryValidate(
                        result.Buffer,
                        result.RemoteEndPoint.Address,
                        DateTimeOffset.UtcNow,
                        BlacklistPropagationCodec.ReadKey(),
                        LocalAddresses(),
                        BlacklistPropagationCodec.ReadPrefixLength(),
                        out BlacklistPropagationMessage? message,
                        out string error)
                    || message is null)
                {
                    LogReject(error);
                    continue;
                }

                await _store.ApplyAsync(message, cancellationToken);
                ProtectedServiceGate.Shared.Deny(message.Thumbprint);
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    "Applied propagated blacklist for thumbprint {0} from {1} (RS_33).",
                    message.Thumbprint,
                    message.Origin);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                return;
            }
            catch (ObjectDisposedException)
            {
                return;
            }
            catch (SocketException) when (cancellationToken.IsCancellationRequested)
            {
                return;
            }
            catch (Exception ex)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "Blacklist unicast receive failed: {0}", ex.Message);
                try
                {
                    await Task.Delay(TimeSpan.FromMilliseconds(250), cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
            }
        }
    }

    private IReadOnlyList<IPAddress> LocalAddresses()
    {
        DateTimeOffset now = DateTimeOffset.UtcNow;
        if (now - _localAddressesReadUtc < TimeSpan.FromSeconds(30))
        {
            return _localAddresses;
        }

        _localAddresses = Ipv4Subnet.LocalUnicastAddresses();
        _localAddressesReadUtc = now;
        return _localAddresses;
    }

    private void LogReject(string error)
    {
        DateTimeOffset now = DateTimeOffset.UtcNow;
        if (now - _lastRejectLogUtc < TimeSpan.FromSeconds(10))
        {
            return;
        }

        _lastRejectLogUtc = now;
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "Blacklist unicast rejected: {0}", error);
    }
}

public sealed class PropagatedBlacklistStore : IPropagatedBlacklistStore
{
    private readonly NpgsqlDataSource _dataSource;

    public PropagatedBlacklistStore(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    public async Task ApplyAsync(BlacklistPropagationMessage message, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(message);
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_propagated_blacklist " +
            "(thumbprint_sha256, reason, origin_device_code, received_at) " +
            "VALUES (@thumbprint, @reason, @origin, now()) " +
            "ON CONFLICT (thumbprint_sha256) DO UPDATE SET reason = EXCLUDED.reason, " +
            "origin_device_code = EXCLUDED.origin_device_code, received_at = now()",
            connection);
        command.Parameters.AddWithValue("thumbprint", message.Thumbprint.ToUpperInvariant());
        command.Parameters.AddWithValue("reason", message.Reason);
        command.Parameters.AddWithValue("origin", message.Origin);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
