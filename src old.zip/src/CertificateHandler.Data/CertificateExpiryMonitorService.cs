using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

/// <summary>
/// Daily certificate expiry validation summary (RS_25).
/// </summary>
public sealed class CertificateExpiryMonitorService : ICertificateExpiryMonitorService
{
    #region Member Variables

    private readonly ICertificateExpiryReader _reader;

    private readonly TimeProvider _time;

    #endregion

    #region Constructor

    public CertificateExpiryMonitorService(ICertificateExpiryReader reader, TimeProvider? time = null)
    {
        _reader = reader ?? throw new ArgumentNullException(nameof(reader));
        _time = time ?? TimeProvider.System;
    }

    #endregion

    #region Public Methods

    public async Task<string> GetDailyCheckStatusAsync(string thumbprint, CancellationToken cancellationToken = default)
    {
        var certificates = await _reader.ReadActiveLocalCertificatesAsync(cancellationToken);
        bool found = certificates.Any(c =>
            string.Equals(c.Thumbprint, thumbprint, StringComparison.OrdinalIgnoreCase)
            && c.NotAfter <= _time.GetUtcNow().AddDays(30));
        return found ? "Attention required" : "Passed";
    }

    #endregion
}
