using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

public sealed class NoOpAdministratorNotifier : IAdministratorNotifier
{
    public void NotifyPublishFailed(string message)
    {
    }
}
