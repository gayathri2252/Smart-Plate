using System.Net;
using CertificateHandler.Data.Security;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Sends one unicast blacklist message to each MAXUM peer on the same IP subnet (RS_33).
/// </summary>
public interface ISubnetBlacklistPropagator
{
    Task PropagateAsync(string thumbprintSha256, string reason, CancellationToken cancellationToken = default);
}

public interface ISubnetPeerDirectory
{
    Task<IReadOnlyList<IPAddress>> ListSameSubnetPeersAsync(CancellationToken cancellationToken = default);
}

public interface IBlacklistUnicastTransport
{
    Task SendAsync(IPAddress peer, byte[] payload, CancellationToken cancellationToken = default);
}

public interface IPropagatedBlacklistStore
{
    Task ApplyAsync(BlacklistPropagationMessage message, CancellationToken cancellationToken = default);
}
