﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Tells whether a certificate was on the blacklist before and has been removed from it.
/// </summary>
public interface IBlackListHistory
{
    #region Public Methods

    /// <summary>
    /// Returns true when the thumbprint has a blacklist row that an administrator deactivated and
    /// no active blacklist row.
    /// </summary>
    Task<bool> WasRemovedFromBlackListAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default);

    #endregion
}
