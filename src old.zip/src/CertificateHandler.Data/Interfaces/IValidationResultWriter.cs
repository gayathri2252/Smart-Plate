namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Persists certificate validation step outcomes (RS_03).
/// </summary>
public interface IValidationResultWriter
{
    Task WriteAsync(
        string? thumbprintSha256,
        Guid? deviceId,
        string validationStep,
        bool passed,
        string? failureReason,
        bool timeVerified,
        bool autoBlacklisted,
        CancellationToken cancellationToken = default);
}
