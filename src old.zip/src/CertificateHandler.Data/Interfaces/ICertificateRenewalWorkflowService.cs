using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

public interface ICertificateRenewalWorkflowService
{
    Task<Guid> CreateRenewalRequestAsync(Guid certificateId, Guid keyId, string? csrPem, CancellationToken cancellationToken = default);

    Task<Guid> StartLocalRenewalAsync(CertificateRole role, CancellationToken cancellationToken = default);

    Task<RenewalWorkflowState?> GetLatestRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default);

    Task RecordCsrPemAsync(Guid renewalRequestId, string csrPem, bool markExported, CancellationToken cancellationToken = default);

    Task RecordImportedAsync(Guid renewalRequestId, string signedCertificatePem, CancellationToken cancellationToken = default);

    Task ActivateRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default);

    Task MarkActivatedAsync(Guid renewalRequestId, CancellationToken cancellationToken = default);
}
