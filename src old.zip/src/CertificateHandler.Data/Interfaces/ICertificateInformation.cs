﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Decides whether a caller may see certificate information.
/// </summary>
public interface IAdministratorAuthorizer
{
    /// <summary>
    /// Returns true only when the given user name belongs to an administrator.
    /// A null or empty name is never authorized.
    /// </summary>
    bool IsAdministrator(string? userName);
}

/// <summary>
/// Reads the stored details of the active local certificates. Read only.
/// </summary>
public interface ICertificateExpiryReader
{
    /// <summary>
    /// Returns the active local SBC and MIB certificates. A role without an active certificate
    /// is not in the result. When a role has several active certificates, the one that
    /// expires last is returned.
    /// </summary>
    Task<IReadOnlyList<StoredCertificateInfo>> ReadActiveLocalCertificatesAsync(
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Calculates the expiry status of a certificate.
/// </summary>
public interface ICertificateExpiryStatusCalculator
{
    /// <summary>
    /// Returns Expired when now is after the not-after date, NearingExpiration when the
    /// not-after date is inside the warning window, and Valid otherwise.
    /// </summary>
    CertificateExpiryStatus Calculate(DateTimeOffset notAfter, DateTimeOffset now);
}

/// <summary>
/// Returns the SBC and MIB certificate information for an authorized administrator.
/// </summary>
public interface ICertificateInformationService
{
    /// <summary>
    /// Returns the SBC and MIB certificate details for the given caller. A caller who is not
    /// an administrator gets IsAuthorized false and no certificate fields.
    /// </summary>
    Task<CertificateInformationResult> GetCertificateInformationAsync(
        string? callerUserName,
        CancellationToken cancellationToken = default);
}
