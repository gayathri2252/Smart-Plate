namespace CertificateHandler.Data.Interfaces;

public interface ICertificateExpiryMonitorService
{
    Task<string> GetDailyCheckStatusAsync(string thumbprint, CancellationToken cancellationToken = default);
}
