using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Exposes SBC/MIB certificate expiry for MCC (RS_25).
/// </summary>
public interface IGcCertificateStatusService
{
    Task<GcCertificateStatusSnapshot> GetSnapshotForAdministratorAsync(
        string? administratorUserName,
        CancellationToken cancellationToken = default);
}
