using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes a whitelist and audit row for a validated MAXUM peer (RS_32).
/// </summary>
public interface IMaxumPeerAutoApprover
{
    /// <summary>
    /// Returns true when the peer is whitelisted. Returns false when the write did not happen
    /// and the caller should keep the peer on the pending queue.
    /// </summary>
    Task<bool> TryAutoApproveAsync(PeerOnboardingRequest peer, CancellationToken cancellationToken = default);
}
