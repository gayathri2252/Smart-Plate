﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Runs the publish step after a trust row was saved and handles its failure.
/// </summary>
public interface ITrustUpdatePublishService
{
    #region Public Methods

    /// <summary>
    /// Publishes the update. When the publish fails, writes the log, the audit row and the administrator
    /// notice and returns the result; it does not throw and never touches the saved trust row.
    /// </summary>
    Task<PublishResult> PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default);

    #endregion
}
