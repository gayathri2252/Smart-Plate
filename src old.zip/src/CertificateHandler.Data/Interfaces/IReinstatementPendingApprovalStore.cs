using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

public interface IReinstatementPendingApprovalStore
{
    Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);
}
