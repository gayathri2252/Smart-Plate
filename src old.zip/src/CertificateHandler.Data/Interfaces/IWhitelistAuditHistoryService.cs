using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Reads whitelist audit history in chronological order (RS_09).
/// </summary>
public interface IWhitelistAuditHistoryService
{
    Task<IReadOnlyList<WhitelistAuditEntry>> GetWhitelistHistoryAsync(
        int maxRows = 500,
        CancellationToken cancellationToken = default);
}
