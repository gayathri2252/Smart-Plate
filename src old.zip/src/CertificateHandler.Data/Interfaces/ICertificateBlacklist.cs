// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access contract for the certificate blacklist.
/// </summary>
public interface ICertificateBlackList
{
    #region Public Methods

    /// <summary>
    /// Blacklists the thumbprint: inserts an active blacklist row, or reactivates an
    /// earlier one, ends any active whitelist row for it, and writes one audit row,
    /// all in a single transaction.
    /// </summary>
    Task<BlackListResponse> BlackListAsync(
        BlackListRequest request,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns true when the thumbprint has an active blacklist row.
    /// </summary>
    Task<bool> IsBlackListedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default);

    #endregion
}
