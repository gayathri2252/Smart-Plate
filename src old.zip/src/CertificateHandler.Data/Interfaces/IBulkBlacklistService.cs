using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

public interface IBulkBlacklistService
{
    Task<BulkBlacklistResponse> ExecuteAsync(BulkBlacklistRequest request, CancellationToken cancellationToken = default);
}
