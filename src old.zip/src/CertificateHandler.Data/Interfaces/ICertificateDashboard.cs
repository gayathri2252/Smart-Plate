// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access contract for the certificate dashboard.
/// </summary>
public interface ICertificateDashboard
{
    /// <summary>
    /// Returns the dashboard counts and the requested page of pending requests, newest first.
    /// Page numbers start at 1. A null filter shows every pending request.
    /// </summary>
    Task<DashboardPage> GetDashboardPageAsync(
        int pageNumber,
        int pageSize,
        DashboardRequestFilter? filter = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the active whitelist and blacklist entries, newest first.
    /// Inactive entries are not returned.
    /// </summary>
    Task<DashboardTrustLists> GetTrustListsAsync(CancellationToken cancellationToken = default);
}
