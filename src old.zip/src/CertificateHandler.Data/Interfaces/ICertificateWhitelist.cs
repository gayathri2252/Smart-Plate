// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access contract for the certificate whitelist lookup.
/// </summary>
public interface ICertificateWhitelist
{
    #region Public Methods

    /// <summary>
    /// Returns true when the thumbprint has an active whitelist row.
    /// </summary>
    Task<bool> IsWhitelistedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default);

    #endregion
}
