using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Installs a renewed signed certificate into the Windows Certificate Store (RS_06).
/// </summary>
public interface ICertificateStoreRenewalImporter
{
    Task ImportSignedCertificateAsync(X509Certificate2 certificate, CancellationToken cancellationToken = default);
}
