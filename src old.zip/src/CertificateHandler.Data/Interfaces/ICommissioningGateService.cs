namespace CertificateHandler.Data.Interfaces;

public sealed class CommissioningHaltResult
{
    public bool ShouldHalt { get; init; }

    public string Message { get; init; } = string.Empty;

    public static CommissioningHaltResult Continue() => new() { ShouldHalt = false };

    public static CommissioningHaltResult Halt(string message) =>
        new() { ShouldHalt = true, Message = message };
}

public interface ICommissioningGateService
{
    Task<CommissioningHaltResult> EvaluateAsync(CancellationToken cancellationToken = default);
}
