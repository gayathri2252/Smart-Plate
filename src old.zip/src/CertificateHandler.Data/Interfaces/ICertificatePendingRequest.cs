// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Entities;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access contract for pending certificate requests.
/// </summary>
public interface ICertificatePendingRequest
{
    #region Public Methods

    /// <summary>
    /// Retrieves all requests currently in the Pending state.
    /// </summary>
    Task<List<PendingRequest>> GetPendingRequestsAsync(
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Retrieves Pending requests older than the given timeout, by CreatedAt.
    /// </summary>
    Task<List<PendingRequest>> GetExpiredCertificateRequestsAsync(
        int timeoutHours,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Marks a request Expired, only if still Pending. Returns false if
    /// it was already decided.
    /// </summary>
    Task<bool> MarkAsExpiredAsync(
        Guid requestId,
        DateTimeOffset expiredAtUtc,
        CancellationToken cancellationToken = default);

    #endregion
}
