namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers trust-list notifications to peers (RS_10). Production MAXUM comms replaces this transport.
/// </summary>
public interface IPeerNotificationChannel
{
    Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default);
}
