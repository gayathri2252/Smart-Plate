namespace CertificateHandler.Data.Interfaces;

public interface IWefCertificateEventWriter
{
    /// <summary>Writes the expiry alert. Returns true when the Windows Event Log accepted it.</summary>
    bool WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter);
}
