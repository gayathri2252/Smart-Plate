// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Access to the whitelist, blacklist and pending rows in the encrypted local trust store.
/// A handshake decision reads from this store and needs no remote server.
/// </summary>
public interface ITrustStoreRepository
{
    #region Public Methods

    /// <summary>
    /// Saves the row. A thumbprint exists only once, so saving a thumbprint that is already stored
    /// replaces that row, for example when a pending certificate moves to the whitelist.
    /// </summary>
    Task SaveAsync(TrustStoreEntry entry, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the whitelist, blacklist or pending row of the thumbprint, or null when it is not stored.
    /// </summary>
    Task<TrustStoreEntry?> GetByThumbprintAsync(string thumbprint, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns the active rows of one list, oldest first.
    /// </summary>
    Task<IReadOnlyList<TrustStoreEntry>> GetActiveByListAsync(TrustListType listType, CancellationToken cancellationToken = default);

    #endregion
}
