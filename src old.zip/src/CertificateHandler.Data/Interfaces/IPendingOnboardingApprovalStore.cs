// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Approves or rejects peer onboarding pending requests with whitelist, audit, events, and notifications (RS_21).
/// </summary>
public interface IPendingOnboardingApprovalStore
{
    #region Public Methods

    /// <summary>
    /// Validates the pending request and inserts an active whitelist row when approved.
    /// </summary>
    Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    /// <summary>
    /// Rejects the pending request with a mandatory reason and queues peer notification.
    /// </summary>
    Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    #endregion
}
