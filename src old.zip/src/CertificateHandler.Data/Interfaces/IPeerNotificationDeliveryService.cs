namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers pending peer notifications with retry (RS_10).
/// </summary>
public interface IPeerNotificationDeliveryService
{
    Task<int> DeliverPendingAsync(CancellationToken cancellationToken = default);
}
