using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

public interface IReinstatementWorkflowService
{
    Task<Guid> RequestReinstatementAsync(string thumbprintSha256, string requesterIdentity, CancellationToken cancellationToken = default);

    Task RecordApprovalAsync(Guid requestId, string approverIdentity, bool approved, string? comments, CancellationToken cancellationToken = default);

    Task CompleteReinstatementAsync(Guid requestId, string actorIdentity, CancellationToken cancellationToken = default);
}
