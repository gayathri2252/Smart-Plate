namespace CertificateHandler.Data.Interfaces;

public interface IFactoryProvisioningService
{
    Task<Guid> StartAttemptAsync(Guid deviceId, string targetRole, CancellationToken cancellationToken = default);

    Task CompleteAttemptAsync(Guid attemptId, bool success, Guid? certificateId, string? error, CancellationToken cancellationToken = default);
}
