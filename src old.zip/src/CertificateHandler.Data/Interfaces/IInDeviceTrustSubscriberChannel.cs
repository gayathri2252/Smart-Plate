namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers trust events to in-device subscribers that gate protected services (RS_27).
/// </summary>
public interface IInDeviceTrustSubscriberChannel
{
    Task<bool> TryDeliverAsync(
        Guid eventId,
        string subscriberName,
        string newTrustStatus,
        string thumbprintSha256,
        CancellationToken cancellationToken = default);
}
