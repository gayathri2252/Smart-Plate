﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes the audit row of a failed publish in its own transaction.
/// </summary>
public interface IPublishFailureAuditWriter
{
    #region Public Methods

    /// <summary>
    /// Inserts one audit row with the result FAILURE for the failed publish.
    /// </summary>
    Task WriteAsync(TrustUpdate update, Exception error, CancellationToken cancellationToken = default);

    #endregion
}
