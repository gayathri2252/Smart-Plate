// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Seals and unseals the database key, so the key file is useless on another computer.
/// The production implementation uses Windows data protection (DPAPI).
/// </summary>
public interface IKeyProtector
{
    #region Public Methods

    /// <summary>
    /// Seals the data. The sealed bytes can only be unsealed by the same protector on the same computer.
    /// </summary>
    byte[] Protect(byte[] data);

    /// <summary>
    /// Unseals the bytes returned by Protect. Throws CryptographicException when they cannot be unsealed here.
    /// </summary>
    byte[] Unprotect(byte[] protectedData);

    #endregion
}
