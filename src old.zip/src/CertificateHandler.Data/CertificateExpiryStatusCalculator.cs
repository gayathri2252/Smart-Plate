﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using DataConstants = CertificateHandler.Data.Constants.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Calculates the expiry status of a certificate. The warning window is 30 days by default.
/// </summary>
public sealed class CertificateExpiryStatusCalculator : ICertificateExpiryStatusCalculator
{
    #region Member Variables

    /// <summary>Time before the not-after date from which a certificate is nearing expiration.</summary>
    private readonly TimeSpan _warningWindow;

    #endregion

    #region Constructor

    /// <summary>Creates the calculator with the default warning window.</summary>
    public CertificateExpiryStatusCalculator()
        : this(TimeSpan.FromDays(DataConstants.EXPIRING_SOON_DAYS))
    {
    }

    /// <summary>
    /// Creates the calculator with the given warning window. A negative window is treated as zero.
    /// </summary>
    public CertificateExpiryStatusCalculator(TimeSpan warningWindow)
    {
        _warningWindow = warningWindow < TimeSpan.Zero ? TimeSpan.Zero : warningWindow;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Calculates the certificate expiry status based on the not-after date,
    /// current date and configured warning window.
    /// </summary>
    /// <param name="notAfter">The date and time after which the certificate is no longer valid.</param>
    /// <param name="now">The current date and time used for the status calculation.</param>
    /// <returns>
    /// </returns
    public CertificateExpiryStatus Calculate(DateTimeOffset notAfter, DateTimeOffset now)
    {
        if (now > notAfter)
        {
            return CertificateExpiryStatus.Expired;
        }
        if (notAfter - now <= _warningWindow)
        {
            return CertificateExpiryStatus.NearingExpiration;
        }

        return CertificateExpiryStatus.Valid;
    }

    #endregion
}
