// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Entities;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace CertificateHandler.Data.Configurations;

/// <summary>
/// Applies the database schema, enum and entity configuration of the Certificate Handler.
/// </summary>
internal static class CertificateHandlerModelBuilderExtensions
{
    #region Internal Methods

    /// <summary>
    /// Sets the default schema and configures every entity, enum and view of the model.
    /// </summary>
    internal static void ApplyCertificateHandlerConfigurations(this ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema(DatabaseConstants.SchemaName);
        RegisterPostgresEnums(modelBuilder);
        ConfigureDevice(modelBuilder);
        ConfigureCertificate(modelBuilder);
        ConfigureSecureKeyReference(modelBuilder);
        ConfigureTrustListEntry(modelBuilder);
        ConfigurePendingRequest(modelBuilder);
        ConfigureCertificateStatusHistory(modelBuilder);
        ConfigureReinstatementApproval(modelBuilder);
        ConfigureCsrRenewalRequest(modelBuilder);
        ConfigureFactoryProvisioningAttempt(modelBuilder);
        ConfigureAuditLog(modelBuilder);
        ConfigureBulkOperation(modelBuilder);
        ConfigureTrustEvent(modelBuilder);
        ConfigurePeerNotification(modelBuilder);
        ConfigureValidationResult(modelBuilder);
        ConfigureSystemConfig(modelBuilder);
        ConfigureViews(modelBuilder);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Registers the PostgreSQL enum types used by the entities.
    /// </summary>
    private static void RegisterPostgresEnums(ModelBuilder modelBuilder)
    {
        modelBuilder.HasPostgresEnum<DeviceType>("device_type", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<DeviceOperationalStatus>("device_operational_status", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<CertificateRole>("certificate_role", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<TrustListKind>("trust_list_kind", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<BlacklistReasonClass>("blacklist_reason_class", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<RenewalRequestStatus>("renewal_request_status", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<BulkOperationStatus>("bulk_operation_status", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<TrustEventDeliveryStatus>("trust_event_delivery_status", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<ProvisioningOutcome>("provisioning_outcome", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<PeerNotificationStatus>("peer_notification_status", DatabaseConstants.SchemaName);
        modelBuilder.HasPostgresEnum<DeliveryResult>("delivery_result", DatabaseConstants.SchemaName);
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the device entity.
    /// </summary>
    private static void ConfigureDevice(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Device>(entity =>
        {
            entity.ToTable("ch_device");
            entity.HasKey(e => e.DeviceId);
            entity.HasIndex(e => e.DeviceCode).IsUnique();
            entity.Property(e => e.DeviceCode).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.DeviceName).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.HasOne(e => e.PrimaryCertificate)
                .WithMany()
                .HasForeignKey(e => e.PrimaryCertificateId)
                .OnDelete(DeleteBehavior.SetNull);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the certificate entity.
    /// </summary>
    private static void ConfigureCertificate(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Certificate>(entity =>
        {
            entity.ToTable("ch_certificate");
            entity.HasKey(e => e.CertificateId);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.SerialNumber).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.PublicKeyAlgorithm).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.WindowsStoreLocation).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.WindowsStoreThumbprint).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.HasOne(e => e.Device)
                .WithMany(d => d.Certificates)
                .HasForeignKey(e => e.DeviceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.SupersededByCertificate)
                .WithMany()
                .HasForeignKey(e => e.SupersededByCertificateId)
                .OnDelete(DeleteBehavior.SetNull);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the secure key reference entity.
    /// </summary>
    private static void ConfigureSecureKeyReference(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SecureKeyReference>(entity =>
        {
            entity.ToTable("ch_secure_key_reference");
            entity.HasKey(e => e.KeyId);
            entity.Property(e => e.KeyLabel).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.ProtectionMode).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.HasOne(e => e.Device)
                .WithMany(d => d.SecureKeys)
                .HasForeignKey(e => e.DeviceId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the trust list entry entity.
    /// </summary>
    private static void ConfigureTrustListEntry(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TrustListEntry>(entity =>
        {
            entity.ToTable("ch_trust_list_entry");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.AddedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.DeactivatedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.HasOne(e => e.Certificate)
                .WithMany(c => c.TrustListEntries)
                .HasForeignKey(e => e.CertificateId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the pending request entity.
    /// </summary>
    private static void ConfigurePendingRequest(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PendingRequest>(entity =>
        {
            entity.ToTable(DatabaseConstants.PendingRequestTable);
            entity.HasKey(e => e.RequestId);
            entity.Property(e => e.RequesterIdentity).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.RequestedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.DecidedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.HasOne(e => e.Certificate)
                .WithMany(c => c.PendingRequests)
                .HasForeignKey(e => e.CertificateId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.Device)
                .WithMany()
                .HasForeignKey(e => e.DeviceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.Property(e => e.Status)
                .HasConversion(
                    status => PostgresEnumNames.ToPgName(status),
                    label => PostgresEnumNames.FromPgName<PendingRequestStatus>(label))
                .HasColumnType(DatabaseConstants.PendingRequestStatusEnumName);

            entity.Property(e => e.RequestType)
                .HasConversion(
                    requestType => PostgresEnumNames.ToPgName(requestType),
                    label => PostgresEnumNames.FromPgName<PendingRequestType>(label))
                .HasColumnType(DatabaseConstants.PendingRequestTypeEnumName);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the certificate status history entity.
    /// </summary>
    private static void ConfigureCertificateStatusHistory(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CertificateStatusHistory>(entity =>
        {
            entity.ToTable("ch_certificate_status_history");
            entity.HasKey(e => e.HistoryId);
            entity.Property(e => e.PreviousStatus).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.NewStatus).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.ChangedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.HasOne(e => e.RelatedRequest)
                .WithMany()
                .HasForeignKey(e => e.RelatedRequestId)
                .OnDelete(DeleteBehavior.SetNull);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the reinstatement approval entity.
    /// </summary>
    private static void ConfigureReinstatementApproval(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ReinstatementApproval>(entity =>
        {
            entity.ToTable("ch_reinstatement_approval");
            entity.HasKey(e => e.ApprovalId);
            entity.Property(e => e.ApproverIdentity).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.Decision).HasMaxLength(DatabaseConstants.MaxDecisionLength);
            entity.HasOne(e => e.Request)
                .WithMany(r => r.ReinstatementApprovals)
                .HasForeignKey(e => e.RequestId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the csr renewal request entity.
    /// </summary>
    private static void ConfigureCsrRenewalRequest(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CsrRenewalRequest>(entity =>
        {
            entity.ToTable("ch_csr_renewal_request");
            entity.HasKey(e => e.RenewalRequestId);
            entity.HasOne(e => e.Certificate)
                .WithMany()
                .HasForeignKey(e => e.CertificateId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.Key)
                .WithMany(k => k.RenewalRequests)
                .HasForeignKey(e => e.KeyId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the factory provisioning attempt entity.
    /// </summary>
    private static void ConfigureFactoryProvisioningAttempt(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<FactoryProvisioningAttempt>(entity =>
        {
            entity.ToTable("ch_factory_provisioning_attempt");
            entity.HasKey(e => e.AttemptId);
            entity.HasOne(e => e.Device)
                .WithMany()
                .HasForeignKey(e => e.DeviceId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the audit log entity.
    /// </summary>
    private static void ConfigureAuditLog(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.ToTable("ch_audit_log");
            entity.HasKey(e => e.AuditId);
            entity.HasIndex(e => e.EventId).IsUnique();
            entity.Property(e => e.EventType).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.ActorIdentity).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.PreviousStatus).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.NewStatus).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.ActionStatus).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.Result).HasMaxLength(DatabaseConstants.MaxStatusLength);
            entity.Property(e => e.SourceComponent).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.DetailsJson).HasColumnType("jsonb");
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the bulk operation entity.
    /// </summary>
    private static void ConfigureBulkOperation(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BulkOperation>(entity =>
        {
            entity.ToTable("ch_bulk_operation");
            entity.HasKey(e => e.BulkOperationId);
            entity.Property(e => e.InitiatedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
        });

        modelBuilder.Entity<BulkOperationItem>(entity =>
        {
            entity.ToTable("ch_bulk_operation_item");
            entity.HasKey(e => e.ItemId);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.ItemStatus).HasMaxLength(DatabaseConstants.MaxStatusLength);
            entity.HasOne(e => e.BulkOperation)
                .WithMany(b => b.Items)
                .HasForeignKey(e => e.BulkOperationId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the trust event entity.
    /// </summary>
    private static void ConfigureTrustEvent(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TrustEvent>(entity =>
        {
            entity.ToTable("ch_trust_event");
            entity.HasKey(e => e.EventId);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.NewTrustStatus).HasMaxLength(DatabaseConstants.MaxStatusLength);
            entity.Property(e => e.ActorIdentity).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.Property(e => e.PayloadJson).HasColumnType("jsonb");
        });

        modelBuilder.Entity<TrustEventDelivery>(entity =>
        {
            entity.ToTable("ch_trust_event_delivery");
            entity.HasKey(e => e.DeliveryId);
            entity.Property(e => e.SubscriberName).HasMaxLength(DatabaseConstants.MaxTextLength);
            entity.HasOne(e => e.Event)
                .WithMany(t => t.Deliveries)
                .HasForeignKey(e => e.EventId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the peer notification entity.
    /// </summary>
    private static void ConfigurePeerNotification(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PeerNotification>(entity =>
        {
            entity.ToTable("ch_peer_notification");
            entity.HasKey(e => e.NotificationId);
            entity.HasOne(e => e.Request)
                .WithMany()
                .HasForeignKey(e => e.RequestId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the validation result entity.
    /// </summary>
    private static void ConfigureValidationResult(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ValidationResult>(entity =>
        {
            entity.ToTable("ch_validation_result");
            entity.HasKey(e => e.ValidationId);
            entity.Property(e => e.ThumbprintSha256).HasMaxLength(DatabaseConstants.MaxThumbprintLength);
            entity.Property(e => e.ValidationStep).HasMaxLength(DatabaseConstants.MaxLabelLength);
        });
    }

    /// <summary>
    /// Configures the table, keys, columns and relationships of the system config entity.
    /// </summary>
    private static void ConfigureSystemConfig(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SystemConfig>(entity =>
        {
            entity.ToTable("ch_system_config");
            entity.HasKey(e => e.ConfigKey);
            entity.Property(e => e.ConfigKey).HasMaxLength(DatabaseConstants.MaxIdentifierLength);
            entity.Property(e => e.UpdatedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
        });

        modelBuilder.Entity<SchemaMigration>(entity =>
        {
            entity.ToTable("ch_schema_migration");
            entity.HasKey(e => e.MigrationId);
            entity.Property(e => e.MigrationId).HasMaxLength(DatabaseConstants.MaxLabelLength);
            entity.Property(e => e.AppliedBy).HasMaxLength(DatabaseConstants.MaxTextLength);
        });
    }

    /// <summary>
    /// Configures the database views that the model reads.
    /// </summary>
    private static void ConfigureViews(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DashboardCounts>(entity =>
        {
            entity.HasNoKey();
            entity.ToView("vw_dashboard_counts");
        });

        modelBuilder.Entity<PendingQueueOverview>(entity =>
        {
            entity.HasNoKey();
            entity.ToView("vw_pending_queue_overview");
            entity.Property(e => e.DeviceIdentifier).HasColumnName("device_identifier");
            entity.Property(e => e.RequestDate).HasColumnName("request_date");
            entity.Property(e => e.CurrentStatus).HasColumnName("current_status");
            entity.Property(e => e.MaxumIp).HasColumnName("maxum_ip");
            entity.Property(e => e.SubjectDn).HasColumnName("subject_dn");
            entity.Property(e => e.ExpiresAt).HasColumnName("expires_at");
        });
    }

    #endregion
}
