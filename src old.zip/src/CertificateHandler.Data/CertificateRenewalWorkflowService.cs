using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// CSR / renewal workflow persistence (RS_06, RS_26).
/// </summary>
public sealed class CertificateRenewalWorkflowService : ICertificateRenewalWorkflowService
{
    #region Member Variables

    private readonly NpgsqlDataSource _dataSource;

    private readonly ICertificateStoreRenewalImporter? _storeImporter;

    #endregion

    #region Constructor

    public CertificateRenewalWorkflowService(
        NpgsqlDataSource dataSource,
        ICertificateStoreRenewalImporter? storeImporter = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _storeImporter = storeImporter;
    }

    #endregion

    #region Public Methods

    public async Task<Guid> CreateRenewalRequestAsync(Guid certificateId, Guid keyId, string? csrPem, CancellationToken cancellationToken = default)
    {
        Guid renewalId = Guid.NewGuid();
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_csr_renewal_request " +
            "(renewal_request_id, certificate_id, key_id, csr_pem, status) VALUES (@id, @certId, @keyId, @csr, 'CREATED')",
            connection);
        command.Parameters.AddWithValue("id", renewalId);
        command.Parameters.AddWithValue("certId", certificateId);
        command.Parameters.AddWithValue("keyId", keyId);
        command.Parameters.AddWithValue("csr", (object?)csrPem ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return renewalId;
    }

    public async Task<Guid> StartLocalRenewalAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var lookup = new NpgsqlCommand(
            $"SELECT c.certificate_id, k.key_id FROM {DatabaseConstants.SchemaName}.ch_certificate c " +
            $"JOIN {DatabaseConstants.SchemaName}.ch_secure_key_reference k ON k.device_id = c.device_id " +
            "WHERE c.certificate_role = CAST(@role AS certificate_handler.certificate_role) " +
            "AND c.not_after > now() ORDER BY c.not_after DESC LIMIT 1",
            connection);
        lookup.Parameters.AddWithValue("role", MapRole(role));

        await using var reader = await lookup.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            throw new InvalidOperationException("No active certificate and secure key reference found for renewal.");
        }

        Guid certificateId = reader.GetGuid(0);
        Guid keyId = reader.GetGuid(1);
        await reader.CloseAsync();
        return await CreateRenewalRequestAsync(certificateId, keyId, csrPem: null, cancellationToken);
    }

    public async Task<RenewalWorkflowState?> GetLatestRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        string dbRole = MapRole(role);
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT r.renewal_request_id, r.certificate_id, r.key_id, r.status::text, r.csr_pem, r.signed_certificate_pem " +
            $"FROM {DatabaseConstants.SchemaName}.ch_csr_renewal_request r " +
            $"JOIN {DatabaseConstants.SchemaName}.ch_certificate c ON c.certificate_id = r.certificate_id " +
            "WHERE c.certificate_role = CAST(@role AS certificate_handler.certificate_role) " +
            "ORDER BY r.created_at DESC LIMIT 1",
            connection);
        command.Parameters.AddWithValue("role", dbRole);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return new RenewalWorkflowState
        {
            RenewalRequestId = reader.GetGuid(0),
            CertificateId = reader.GetGuid(1),
            KeyId = reader.GetGuid(2),
            Status = reader.GetString(3),
            CsrPem = reader.IsDBNull(4) ? null : reader.GetString(4),
            SignedCertificatePem = reader.IsDBNull(5) ? null : reader.GetString(5)
        };
    }

    public async Task RecordCsrPemAsync(Guid renewalRequestId, string csrPem, bool markExported, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(csrPem);
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_csr_renewal_request " +
            "SET csr_pem = @csr, status = CAST(@status AS certificate_handler.renewal_request_status), " +
            "exported_at = CASE WHEN @exported THEN now() ELSE exported_at END WHERE renewal_request_id = @id",
            connection);
        command.Parameters.AddWithValue("csr", csrPem);
        command.Parameters.AddWithValue("status", markExported ? "EXPORTED" : "CREATED");
        command.Parameters.AddWithValue("exported", markExported);
        command.Parameters.AddWithValue("id", renewalRequestId);
        int rows = await command.ExecuteNonQueryAsync(cancellationToken);
        if (rows == 0)
        {
            throw new InvalidOperationException("Renewal request not found.");
        }
    }

    public async Task RecordImportedAsync(Guid renewalRequestId, string signedCertificatePem, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(signedCertificatePem);
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_csr_renewal_request " +
            "SET status = 'IMPORTED', imported_at = now(), signed_certificate_pem = @pem " +
            "WHERE renewal_request_id = @id",
            connection);
        command.Parameters.AddWithValue("pem", signedCertificatePem);
        command.Parameters.AddWithValue("id", renewalRequestId);
        int rows = await command.ExecuteNonQueryAsync(cancellationToken);
        if (rows == 0)
        {
            throw new InvalidOperationException("Renewal request not found.");
        }
    }

    public async Task ActivateRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        RenewalWorkflowState? state = await GetLatestRenewalForRoleAsync(role, cancellationToken);
        if (state is null)
        {
            throw new InvalidOperationException("No renewal request exists for this certificate role.");
        }

        if (string.Equals(state.Status, "ACTIVATED", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Renewal is already activated.");
        }

        if (!string.Equals(state.Status, "IMPORTED", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(state.Status, "VALIDATED", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Import the signed certificate before activation.");
        }

        string? signedPem = state.SignedCertificatePem ?? state.CsrPem;
        if (string.IsNullOrWhiteSpace(signedPem))
        {
            throw new InvalidOperationException("Signed certificate PEM is missing for this renewal.");
        }

        RenewalSignedCertificateValidator.ValidateOrThrow(signedPem, state.CsrPem);

        using X509Certificate2 certificate = X509Certificate2.CreateFromPem(signedPem);
        string thumbprintSha256 = certificate.GetCertHashString(HashAlgorithmName.SHA256).ToUpperInvariant();

        if (_storeImporter is not null)
        {
            await _storeImporter.ImportSignedCertificateAsync(certificate, cancellationToken);
        }

        await RotateActiveCertificateAndMarkRenewalActivatedAsync(
            state,
            role,
            certificate,
            thumbprintSha256,
            cancellationToken);
    }

    public async Task MarkActivatedAsync(Guid renewalRequestId, CancellationToken cancellationToken = default)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_csr_renewal_request SET status = 'ACTIVATED', activated_at = now() " +
            "WHERE renewal_request_id = @id AND status <> 'ACTIVATED'",
            connection);
        command.Parameters.AddWithValue("id", renewalRequestId);
        int rows = await command.ExecuteNonQueryAsync(cancellationToken);
        if (rows == 0)
        {
            throw new InvalidOperationException("Renewal request not found or already activated.");
        }
    }

    private async Task RotateActiveCertificateAndMarkRenewalActivatedAsync(
        RenewalWorkflowState state,
        CertificateRole role,
        X509Certificate2 certificate,
        string thumbprintSha256,
        CancellationToken cancellationToken)
    {
        string dbRole = MapRole(role);
        string storeLocation = Environment.GetEnvironmentVariable("CH_RENEWAL_STORE_LOCATION") ?? "LocalMachine";
        Guid newCertificateId = Guid.NewGuid();

        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);

        Guid? deviceId;
        await using (var lookup = new NpgsqlCommand(
            $"SELECT device_id FROM {DatabaseConstants.SchemaName}.ch_certificate WHERE certificate_id = @certId",
            connection,
            transaction))
        {
            lookup.Parameters.AddWithValue("certId", state.CertificateId);
            object? device = await lookup.ExecuteScalarAsync(cancellationToken);
            deviceId = device is Guid g ? g : null;
        }

        await using (var insert = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_certificate " +
            "(certificate_id, device_id, certificate_role, thumbprint_sha256, subject_dn, issuer_dn, serial_number, " +
            "not_before, not_after, public_key_algorithm, cert_der, windows_store_location, windows_store_thumbprint, is_active) " +
            "VALUES (@id, @deviceId, CAST(@role AS certificate_handler.certificate_role), @thumbprint, @subject, @issuer, " +
            "@serial, @notBefore, @notAfter, @algorithm, @der, @storeLocation, @thumbprint, TRUE)",
            connection,
            transaction))
        {
            insert.Parameters.AddWithValue("id", newCertificateId);
            insert.Parameters.AddWithValue("deviceId", (object?)deviceId ?? DBNull.Value);
            insert.Parameters.AddWithValue("role", dbRole);
            insert.Parameters.AddWithValue("thumbprint", thumbprintSha256);
            insert.Parameters.AddWithValue("subject", certificate.Subject);
            insert.Parameters.AddWithValue("issuer", certificate.Issuer);
            insert.Parameters.AddWithValue("serial", certificate.SerialNumber ?? string.Empty);
            insert.Parameters.AddWithValue("notBefore", certificate.NotBefore.ToUniversalTime());
            insert.Parameters.AddWithValue("notAfter", certificate.NotAfter.ToUniversalTime());
            insert.Parameters.AddWithValue("algorithm", certificate.PublicKey.Oid?.FriendlyName ?? string.Empty);
            insert.Parameters.AddWithValue("der", certificate.RawData);
            insert.Parameters.AddWithValue("storeLocation", storeLocation);
            await insert.ExecuteNonQueryAsync(cancellationToken);
        }

        await using (var deactivate = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_certificate SET is_active = FALSE, updated_at = now(), " +
            "superseded_by_certificate_id = @newId WHERE certificate_id = @oldId",
            connection,
            transaction))
        {
            deactivate.Parameters.AddWithValue("newId", newCertificateId);
            deactivate.Parameters.AddWithValue("oldId", state.CertificateId);
            await deactivate.ExecuteNonQueryAsync(cancellationToken);
        }

        await using (var renewal = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_csr_renewal_request " +
            "SET status = 'ACTIVATED', activated_at = now(), previous_certificate_id = @prevCert " +
            "WHERE renewal_request_id = @id AND status <> 'ACTIVATED'",
            connection,
            transaction))
        {
            renewal.Parameters.AddWithValue("prevCert", state.CertificateId);
            renewal.Parameters.AddWithValue("id", state.RenewalRequestId);
            int rows = await renewal.ExecuteNonQueryAsync(cancellationToken);
            if (rows == 0)
            {
                throw new InvalidOperationException("Renewal request not found or already activated.");
            }
        }

        await transaction.CommitAsync(cancellationToken);
    }

    private static string MapRole(CertificateRole role) => role switch
    {
        CertificateRole.LocalSbc => "LOCAL_SBC",
        CertificateRole.LocalMib => "LOCAL_MIB",
        _ => throw new ArgumentOutOfRangeException(nameof(role), role, "Only local SBC/MIB renewal is supported.")
    };

    #endregion
}
