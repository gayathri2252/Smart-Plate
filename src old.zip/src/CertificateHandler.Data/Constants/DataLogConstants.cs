﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Texts written to the Log Monitor by the data layer, so every database action and every problem with
/// the database server can be followed in the logs. %s is filled in by the logger, in the given order.
/// </summary>
public static class DataLogConstants
{
    #region Database Server

    /// <summary>Error: the database server cannot be reached; the arguments are the server (host:port) and the error.</summary>
    public const string DB_SERVER_UNREACHABLE = "The database server %s could not be reached: %s";

    /// <summary>Information: the database is being checked at start-up; the argument is the database name.</summary>
    public const string DB_BOOTSTRAP_STARTED = "Checking the database %s on the database server.";

    /// <summary>Information: start-up checks are switched off.</summary>
    public const string DB_BOOTSTRAP_SKIPPED = "The database check at start-up is switched off, so the database was not checked.";

    /// <summary>Success: the database did not exist and was created; the argument is the database name.</summary>
    public const string DB_CREATED = "The database %s did not exist and was created.";

    /// <summary>Information: the schema is already present; the argument is the database name.</summary>
    public const string DB_SCHEMA_PRESENT = "The database %s is ready; the schema is already applied.";

    /// <summary>Success: the schema was applied; the argument is the database name.</summary>
    public const string DB_SCHEMA_APPLIED = "The schema was applied to the database %s.";

    /// <summary>Error: the database could not be prepared; the arguments are the database name and the error.</summary>
    public const string DB_BOOTSTRAP_FAILED = "The database %s could not be prepared at start-up: %s";

    #endregion

    #region Blacklist and Whitelist

    /// <summary>Success: a certificate was put on the blacklist; the arguments are the thumbprint, the outcome and the reason.</summary>
    public const string BLACK_LIST_SAVED = "Certificate %s was blacklisted (%s). Reason: %s";

    /// <summary>Information: the certificate was already on the blacklist; the argument is the thumbprint.</summary>
    public const string BLACK_LIST_ALREADY_ACTIVE = "Certificate %s is already on the blacklist; nothing was changed.";

    /// <summary>Warning: the certificate to blacklist is not stored; the argument is the thumbprint.</summary>
    public const string BLACK_LIST_CERTIFICATE_NOT_FOUND = "Certificate %s could not be blacklisted because it is not stored in the database.";

    /// <summary>Error: blacklisting failed; the arguments are the thumbprint and the error.</summary>
    public const string BLACK_LIST_SAVE_FAILED = "Certificate %s could not be blacklisted: %s";

    /// <summary>Information: the blacklist was checked; the arguments are the thumbprint and the result (true or false).</summary>
    public const string BLACK_LIST_CHECKED = "Blacklist checked for certificate %s: blacklisted = %s.";

    /// <summary>Error: the blacklist could not be checked; the arguments are the thumbprint and the error.</summary>
    public const string BLACK_LIST_LOOKUP_FAILED = "The blacklist could not be checked for certificate %s: %s";

    /// <summary>Information: the whitelist was checked; the arguments are the thumbprint and the result (true or false).</summary>
    public const string WHITELIST_CHECKED = "Whitelist checked for certificate %s: whitelisted = %s.";

    /// <summary>Error: the whitelist could not be checked; the arguments are the thumbprint and the error.</summary>
    public const string WHITELIST_LOOKUP_FAILED = "The whitelist could not be checked for certificate %s: %s";

    #endregion

    #region Pending Requests

    /// <summary>Information: pending requests were read; the argument is the number read.</summary>
    public const string PENDING_REQUESTS_READ = "%s pending request(s) were read from the database.";

    /// <summary>Error: pending requests could not be read; the argument is the error.</summary>
    public const string PENDING_REQUESTS_READ_FAILED = "The pending requests could not be read from the database: %s";

    /// <summary>Information: requests older than the timeout were found; the arguments are the number and the timeout in hours.</summary>
    public const string EXPIRED_REQUESTS_FOUND = "%s pending request(s) are older than %s hours and will be marked as Expired.";

    /// <summary>Error: the requests to expire could not be read; the argument is the error.</summary>
    public const string EXPIRED_REQUESTS_READ_FAILED = "The pending requests to expire could not be read from the database: %s";

    /// <summary>Success: a request was marked as expired; the argument is the request id.</summary>
    public const string REQUEST_MARKED_EXPIRED = "Pending request %s was marked as Expired after the timeout.";

    /// <summary>Information: the request was decided before it could expire; the argument is the request id.</summary>
    public const string REQUEST_ALREADY_DECIDED = "Pending request %s was not expired because it was already approved or rejected.";

    /// <summary>Error: a request could not be marked as expired; the arguments are the request id and the error.</summary>
    public const string REQUEST_EXPIRE_FAILED = "Pending request %s could not be marked as Expired: %s";

    /// <summary>Error: the open peer requests could not be counted; the argument is the error.</summary>
    public const string PEER_REQUEST_COUNT_FAILED = "The open peer requests could not be counted: %s";

    /// <summary>Error: an unknown peer could not be added to the queue; the arguments are the device and the error.</summary>
    public const string PEER_REQUEST_ADD_FAILED = "The unknown peer %s could not be added to the pending queue: %s";

    #endregion

    #region Trust Updates

    /// <summary>Information: a trust update was published (simulated); the arguments are the change and the thumbprint.</summary>
    public const string TRUST_UPDATE_SIMULATED = "Trust update %s for certificate %s was published (simulated publisher).";

    /// <summary>Warning: the simulated publisher was told to fail; the argument is the thumbprint.</summary>
    public const string TRUST_UPDATE_SIMULATED_FAILURE = "The simulated publisher failed the trust update for certificate %s on purpose (failure flag file found).";

    #endregion

    #region Administrator

    /// <summary>Information: an administrator check was made; the arguments are the user name and the result.</summary>
    public const string ADMINISTRATOR_CHECKED = "Administrator check for user %s: administrator = %s.";

    /// <summary>Warning: the administrator check was asked for an empty user name.</summary>
    public const string ADMINISTRATOR_CHECK_NO_USER = "Administrator check made without a user name; access is denied.";

    #endregion
}
