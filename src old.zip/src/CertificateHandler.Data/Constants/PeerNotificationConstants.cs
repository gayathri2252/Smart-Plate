namespace CertificateHandler.Data.Constants;

/// <summary>
/// Peer notification queue and retry policy (RS_10).
/// </summary>
public static class PeerNotificationConstants
{
    public const string PendingDeliveryMarker = "PENDING_DELIVERY";

    public const string MaxRetriesExceeded = "MAX_RETRIES_EXCEEDED";

    public const string AuditEventDelivered = "PEER_NOTIFICATION_DELIVERED";

    public const string AuditEventFailed = "PEER_NOTIFICATION_FAILED";

    public const string SourceComponent = "PeerNotificationDeliveryService";

    public const int DefaultMaxRetries = 3;

    public static int ResolveMaxRetries()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_PEER_NOTIFY_MAX_RETRIES");
        return int.TryParse(raw, out int value) && value > 0 ? value : DefaultMaxRetries;
    }
}
