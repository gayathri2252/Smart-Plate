// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Text and event identifiers for pending onboarding approve/reject (RS_21, RS_09).
/// </summary>
internal static class OnboardingApprovalConstants
{
    #region Member Variables

    internal const string EVENT_WHITELISTED = "PEER_WHITELISTED";

    internal const string EVENT_REJECTED = "PEER_ONBOARDING_REJECTED";

    internal const string TRUST_STATUS_WHITELISTED = "WHITELISTED";

    internal const string TRUST_STATUS_REJECTED = "REJECTED";

    internal const string SELF_APPROVAL_DENIED = "The requester cannot approve their own onboarding request.";

    internal const string REJECTION_REASON_REQUIRED = "A rejection reason is required.";

    internal const string REQUEST_NOT_PENDING = "The request is not pending or does not exist.";

    internal const string CERTIFICATE_EXPIRED = "The certificate has expired and cannot be whitelisted.";

    internal const string PRESENTED_CERTIFICATE_REQUIRED =
        "The presented certificate bytes are missing; the peer must reconnect before approval.";

    internal const string ALREADY_LISTED = "The certificate thumbprint already has an active trust list row.";

    internal const string SOURCE_COMPONENT = "PendingOnboardingApproval";

    #endregion
}
