﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Shared PostgreSQL identifiers, limits and blacklist texts for Certificate Handler persistence.
/// </summary>
public static class DatabaseConstants
{
    #region Member Variables

    /// <summary>Name of the PostgreSQL schema that holds all Certificate Handler tables.</summary>
    public const string SchemaName = "certificate_handler";

    /// <summary>Id of the schema version recorded when the embedded schema has been applied.</summary>
    public const string AppliedMigrationId = "v1.2_security";

    /// <summary>Incremental migration: dashboard indexes (RS_02).</summary>
    public const string DashboardIndexesMigrationId = "v1.3_dashboard_indexes";

    public const string SecurityHardeningMigrationId = "v1.4_security_hardening";

    public const string TrustChannelsMigrationId = "v1.5_trust_channels";

    /// <summary>Table that records which schema versions have been applied.</summary>
    public const string SchemaMigrationTable = "ch_schema_migration";

    /// <summary>Resource name of the schema script embedded in the Data assembly.</summary>
    public const string EmbeddedSchemaResourceName = "CertificateHandler.Data.Schema.CertificateHandlerSchema.sql";

    /// <summary>Embedded SQL for v1.3 dashboard indexes.</summary>
    public const string EmbeddedDashboardIndexesMigrationResourceName =
        "CertificateHandler.Data.Schema.Migrations.V1_3_DashboardIndexes.sql";

    public const string EmbeddedSecurityHardeningMigrationResourceName =
        "CertificateHandler.Data.Schema.Migrations.V1_4_SecurityHardening.sql";

    public const string EmbeddedTrustChannelsMigrationResourceName =
        "CertificateHandler.Data.Schema.Migrations.V1_5_TrustChannels.sql";

    /// <summary>Environment variable that holds the database password; it is preferred over the configured password.</summary>
    public const string PasswordEnvironmentVariable = "CH_DB_PASSWORD";

    /// <summary>Table that holds the pending certificate requests.</summary>
    public const string PendingRequestTable = "ch_pending_request";

    /// <summary>Name of the PostgreSQL enum type of the pending request status.</summary>
    public const string PendingRequestStatusEnumName = "pending_request_status";

    /// <summary>Name of the PostgreSQL enum type of the pending request type.</summary>
    public const string PendingRequestTypeEnumName = "pending_request_type";

    /// <summary>Actor name stored when the system, not a user, makes a change.</summary>
    public const string SystemActor = "System";

    /// <summary>
    /// Shown in the log instead of host:port when the database server address is not known.
    /// </summary>
    public const string UNKNOWN_SERVER = "(unknown server)";

    /// <summary>Name of the Certificate Handler database.</summary>
    public const string DatabaseName = "Valmet_MCP";

    /// <summary>Database used to connect when the Certificate Handler database still has to be created.</summary>
    public const string AdminDatabaseName = "postgres";

    /// <summary>Largest length of a general text column, such as a user or device name.</summary>
    public const int MaxTextLength = 256;

    /// <summary>Largest length of an identifier column, such as a device code or serial number.</summary>
    public const int MaxIdentifierLength = 128;

    /// <summary>Largest length of a short label column, such as an algorithm or protection mode.</summary>
    public const int MaxLabelLength = 64;

    /// <summary>Length of a SHA-256 thumbprint as hex text.</summary>
    public const int MaxThumbprintLength = 64;

    /// <summary>Largest length of a status column.</summary>
    public const int MaxStatusLength = 32;

    /// <summary>Largest length of a decision column.</summary>
    public const int MaxDecisionLength = 16;

    /// <summary>Largest number of open connections in the connection pool.</summary>
    public const int MaxPoolSize = 20;

    /// <summary>Seconds to wait for a database connection before giving up.</summary>
    public const int ConnectionTimeoutSeconds = 15;

    /// <summary>Seconds a normal database command may run before it is cancelled.</summary>
    public const int CommandTimeoutSeconds = 120;

    /// <summary>Seconds the schema script may run before it is cancelled.</summary>
    public const int SchemaCommandTimeoutSeconds = 300;

    /// <summary>Logged when the dashboard query is created without a data source.</summary>
    public const string DASHBOARD_DATA_SOURCE_IS_NULL = "The dashboard query cannot be created because no database connection was given.";

    /// <summary>Logged when the dashboard query is created without a clock.</summary>
    public const string DASHBOARD_CLOCK_IS_NULL = "The dashboard query cannot be created because no clock was given.";

    /// <summary>Logged when the requested page number is below the first page.</summary>
    public const string DASHBOARD_PAGE_NUMBER_OUT_OF_RANGE = "The dashboard page number %s is not allowed. Page numbers start at %s.";

    /// <summary>Logged when the requested page size is outside the allowed range.</summary>
    public const string DASHBOARD_PAGE_SIZE_OUT_OF_RANGE = "The dashboard page size %s is not allowed. It must be between %s and %s.";

    /// <summary>Logged when the validation failure window setting cannot be used and the default is applied.</summary>
    public const string DASHBOARD_FAILURE_WINDOW_INVALID = "The time window for counting validation failures is not valid, so it cannot be used. It must be a whole number of hours from %s to %s. The default of %s hours is used instead.";

    /// <summary>Logged when the database is prepared without database options.</summary>
    public const string BOOTSTRAP_OPTIONS_IS_NULL = "The database cannot be prepared because no database options were given.";

    /// <summary>Logged when an embedded SQL script is not found in the application.</summary>
    public const string EMBEDDED_SCRIPT_MISSING = "The database cannot be prepared because the SQL script %s is missing from the application.";

    /// <summary>
    /// Event type written to the audit row when a thumbprint is blacklisted.
    /// </summary>
    internal const string AUDIT_EVENT_TYPE = "THUMBPRINT_BLACKLISTED";

    /// <summary>
    /// Audit status of a thumbprint that is on the blacklist.
    /// </summary>
    internal const string STATUS_BLACK_LISTED = "BLACKLISTED";

    /// <summary>
    /// Audit status of a thumbprint that was on the whitelist before it was blacklisted.
    /// </summary>
    internal const string STATUS_WHITELISTED = "WHITELISTED";

    /// <summary>
    /// Audit status of a thumbprint that was on no list before it was blacklisted.
    /// </summary>
    internal const string STATUS_NOT_LISTED = "NOT_LISTED";

    /// <summary>
    /// Audit status of a thumbprint whose earlier blacklist row was inactive.
    /// </summary>
    internal const string STATUS_BLACK_LIST_INACTIVE = "BLACKLIST_INACTIVE";

    /// <summary>
    /// Audit action status when a new blacklist row was inserted.
    /// </summary>
    internal const string ACTION_ADDED = "BLACKLIST_ADDED";

    /// <summary>
    /// Audit action status when an earlier blacklist row was made active again.
    /// </summary>
    internal const string ACTION_REACTIVATED = "BLACKLIST_REACTIVATED";

    /// <summary>
    /// Audit action status when the thumbprint was already actively blacklisted.
    /// </summary>
    internal const string ACTION_ALREADY_BLACK_LISTED = "ALREADY_BLACKLISTED";

    /// <summary>
    /// Result text stored in the audit row of a completed blacklist write.
    /// </summary>
    internal const string RESULT_SUCCESS = "SUCCESS";

    /// <summary>
    /// Component name stored in the audit row when the caller does not set one.
    /// </summary>
    internal const string DEFAULT_SOURCE_COMPONENT = "TrustEngine";

    /// <summary>
    /// Message of the exception thrown when no reason is given.
    /// </summary>
    internal const string REASON_REQUIRED_MESSAGE = "A reason is required to blacklist a thumbprint.";

    /// <summary>
    /// Name of the PostgreSQL enum type of the trust list kind.
    /// </summary>
    internal const string TRUST_LIST_KIND_TYPE = "trust_list_kind";

    /// <summary>
    /// Name of the PostgreSQL enum type of the blacklist reason class.
    /// </summary>
    internal const string BLACK_LIST_REASON_CLASS_TYPE = "blacklist_reason_class";

    /// <summary>
    /// Name of the SQL parameter that carries the thumbprint.
    /// </summary>
    internal const string THUMBPRINT_PARAMETER = "thumbprint";

    internal const string PRESENTED_CERT_PARAMETER = "presentedCertDer";

    /// <summary>
    /// Name of the SQL parameter that carries the current time.
    /// </summary>
    internal const string NOW_PARAMETER = "now";

    /// <summary>
    /// Name of the SQL parameter that carries who made the change.
    /// </summary>
    internal const string ACTOR_PARAMETER = "actor";

    /// <summary>
    /// Name of the SQL parameter that carries the trust list kind.
    /// </summary>
    internal const string KIND_PARAMETER = "kind";

    /// <summary>
    /// Name of the SQL parameter that carries the row id.
    /// </summary>
    internal const string ID_PARAMETER = "id";

    /// <summary>
    /// Name of the SQL parameter that carries the reason.
    /// </summary>
    internal const string REASON_PARAMETER = "reason";

    /// <summary>
    /// Name of the SQL parameter that carries the blacklist reason class.
    /// </summary>
    internal const string REASON_CLASS_PARAMETER = "reasonClass";

    /// <summary>
    /// Name of the SQL parameter that carries the certificate id.
    /// </summary>
    internal const string CERTIFICATE_ID_PARAMETER = "certificateId";

    /// <summary>
    /// Name of the SQL parameter that carries the device id.
    /// </summary>
    internal const string DEVICE_ID_PARAMETER = "deviceId";

    /// <summary>
    /// Name of the SQL parameter that carries the certificate subject.
    /// </summary>
    internal const string SUBJECT_DN_PARAMETER = "subjectDn";

    /// <summary>
    /// Name of the SQL parameter that carries the certificate serial number.
    /// </summary>
    internal const string SERIAL_NUMBER_PARAMETER = "serialNumber";

    /// <summary>
    /// Name of the SQL parameter that carries the start of the certificate validity.
    /// </summary>
    internal const string NOT_BEFORE_PARAMETER = "notBefore";

    /// <summary>
    /// Name of the SQL parameter that carries the end of the certificate validity.
    /// </summary>
    internal const string NOT_AFTER_PARAMETER = "notAfter";

    /// <summary>
    /// Name of the SQL parameter that carries the audit event type.
    /// </summary>
    internal const string EVENT_TYPE_PARAMETER = "eventType";

    /// <summary>
    /// Name of the SQL parameter that carries the status before the change.
    /// </summary>
    internal const string PREVIOUS_STATUS_PARAMETER = "previousStatus";

    /// <summary>
    /// Name of the SQL parameter that carries the status after the change.
    /// </summary>
    internal const string NEW_STATUS_PARAMETER = "newStatus";

    /// <summary>
    /// Name of the SQL parameter that carries the audit action status.
    /// </summary>
    internal const string ACTION_STATUS_PARAMETER = "actionStatus";

    /// <summary>
    /// Name of the SQL parameter that carries the audit details as JSON.
    /// </summary>
    internal const string DETAILS_PARAMETER = "details";

    /// <summary>
    /// Name of the SQL parameter that carries the name of the component that made the change.
    /// </summary>
    internal const string SOURCE_PARAMETER = "source";

    /// <summary>
    /// Position of the certificate id in the result of the certificate lookup.
    /// </summary>
    internal const int CERTIFICATE_ID_COLUMN = 0;

    /// <summary>
    /// Position of the device id in the result of the certificate lookup.
    /// </summary>
    internal const int DEVICE_ID_COLUMN = 1;

    /// <summary>
    /// Position of the subject in the result of the certificate lookup.
    /// </summary>
    internal const int SUBJECT_DN_COLUMN = 2;

    /// <summary>
    /// Position of the issuer in the result of the certificate lookup.
    /// </summary>
    internal const int ISSUER_DN_COLUMN = 3;

    /// <summary>
    /// Position of the serial number in the result of the certificate lookup.
    /// </summary>
    internal const int SERIAL_NUMBER_COLUMN = 4;

    /// <summary>
    /// Position of the not-before time in the result of the certificate lookup.
    /// </summary>
    internal const int NOT_BEFORE_COLUMN = 5;

    /// <summary>
    /// Position of the not-after time in the result of the certificate lookup.
    /// </summary>
    internal const int NOT_AFTER_COLUMN = 6;

    /// <summary>
    /// Position of the row id in the result of the blacklist row lookup.
    /// </summary>
    internal const int BLACK_LIST_ROW_ID_COLUMN = 0;

    /// <summary>
    /// Position of the active flag in the result of the blacklist row lookup.
    /// </summary>
    internal const int BLACK_LIST_ROW_IS_ACTIVE_COLUMN = 1;

    /// <summary>Key of the database lock that makes the queue limit check and the insert one step.</summary>
    internal const long PENDING_QUEUE_LOCK_KEY = 7_311_011;

    /// <summary>Name of the SQL parameter that carries the pending queue lock key.</summary>
    internal const string LOCK_KEY_PARAMETER = "lockKey";

    /// <summary>Name of the SQL parameter that carries the pending request status.</summary>
    internal const string PENDING_STATUS_PARAMETER = "pendingStatus";

    /// <summary>Name of the SQL parameter that carries the pending request type.</summary>
    internal const string REQUEST_TYPE_PARAMETER = "requestType";

    /// <summary>Name of the SQL parameter that carries the device code.</summary>
    internal const string DEVICE_CODE_PARAMETER = "deviceCode";

    /// <summary>Name of the SQL parameter that carries the device type.</summary>
    internal const string DEVICE_TYPE_PARAMETER = "deviceType";

    /// <summary>Name of the SQL parameter that carries the MAXUM IP address.</summary>
    internal const string MAXUM_IP_PARAMETER = "maxumIp";

    /// <summary>Name of the SQL parameter that carries the certificate role.</summary>
    internal const string ROLE_PARAMETER = "role";

    /// <summary>Name of the SQL parameter that carries the certificate issuer.</summary>
    internal const string ISSUER_DN_PARAMETER = "issuerDn";

    /// <summary>Name of the SQL parameter that carries the time the request expires.</summary>
    internal const string EXPIRES_AT_PARAMETER = "expiresAt";

    /// <summary>Name of the SQL parameter that carries the connection correlation id.</summary>
    internal const string CORRELATION_ID_PARAMETER = "correlationId";

    #endregion

    #region Blacklist History Messages

    /// <summary>Logged when the blacklist history lookup is created without a database context.</summary>
    public const string BLACK_LIST_HISTORY_CONTEXT_IS_NULL = "The blacklist history lookup cannot be created because no database context was given.";

    /// <summary>Logged when the thumbprint to check is missing or not 64 hex characters.</summary>
    public const string BLACK_LIST_HISTORY_INVALID_THUMBPRINT = "The blacklist history cannot be checked because the certificate thumbprint is missing or not valid.";

    /// <summary>Logged when the lookup starts; the argument is the thumbprint.</summary>
    public const string BLACK_LIST_HISTORY_CHECK_STARTED = "Checking whether certificate %s was removed from the blacklist.";

    /// <summary>Logged when the connection to the database server cannot be opened; the argument is the error.</summary>
    public const string BLACK_LIST_HISTORY_SERVER_UNREACHABLE = "The database server could not be reached to check the blacklist history. Error: %s";

    /// <summary>Logged when the database server rejects or fails the lookup; the arguments are the thumbprint and the error.</summary>
    public const string BLACK_LIST_HISTORY_QUERY_FAILED = "The blacklist history of certificate %s could not be read from the database server. Error: %s";

    /// <summary>Logged when the certificate was removed from the blacklist before; the argument is the thumbprint.</summary>
    public const string BLACK_LIST_HISTORY_REMOVED = "Certificate %s was removed from the blacklist before, so it is checked again in full.";

    /// <summary>Logged when the certificate was never removed from the blacklist; the argument is the thumbprint.</summary>
    public const string BLACK_LIST_HISTORY_NOT_REMOVED = "Certificate %s has no removed blacklist entry.";

    #endregion

    #region Database Setup Constants

    /// <summary>Environment variable name of the administrator password (same value as ADMIN_PASSWORD_ENVIRONMENT_VARIABLE).</summary>
    public const string AdminPasswordEnvironmentVariable = ADMIN_PASSWORD_ENVIRONMENT_VARIABLE;

    /// <summary>Logged when the database is ready and nothing had to be created.</summary>
    public const string DB_SETUP_READY = "The Certificate Handler database is ready for the database user %s.";

    /// <summary>Logged when the application starts to set up the database. The first value is the administrator account, the second the reason.</summary>
    public const string DB_SETUP_STARTED = "The Certificate Handler database is not ready. The application sets it up with the administrator account %s. Reason: %s";

    /// <summary>Logged when the database user was created or its password was set.</summary>
    public const string DB_SETUP_ROLE_READY = "The database user %s was created or updated and its password was set.";

    /// <summary>Logged when the database was created.</summary>
    public const string DB_SETUP_DATABASE_CREATED = "The database %s was created.";

    /// <summary>Logged when the schema was installed.</summary>
    public const string DB_SETUP_SCHEMA_APPLIED = "The database schema %s was installed.";

    /// <summary>Logged when a migration was applied.</summary>
    public const string DB_SETUP_MIGRATION_APPLIED = "The database migration %s was applied.";

    /// <summary>Logged when the permissions of the database user were set.</summary>
    public const string DB_SETUP_PERMISSIONS_GRANTED = "The permissions of the database user %s were set.";

    /// <summary>Logged when the database is still not ready after the set-up.</summary>
    public const string DB_SETUP_NOT_READY = "The database user %s cannot use the database after the set-up.";

    /// <summary>Logged when the administrator password is not available.</summary>
    public const string DB_SETUP_ADMIN_PASSWORD_MISSING = "The database must be set up but the administrator password is not available. Reason: %s";

    /// <summary>Logged when the set-up with the administrator account fails.</summary>
    public const string DB_SETUP_FAILED = "The database set-up failed: %s";

    /// <summary>Logged when a new sealed database password was created.</summary>
    public const string DB_SETUP_PASSWORD_CREATED = "A new database password was created and sealed in %s.";

    /// <summary>Logged when the sealed database password cannot be unsealed and a new one is created.</summary>
    public const string DB_SETUP_PASSWORD_UNREADABLE = "The sealed database password in %s cannot be used (%s). A new password is created.";

    /// <summary>Reason text when the sealed password file has no password in it.</summary>
    public const string DB_SETUP_FILE_EMPTY = "the file is empty";

    /// <summary>Logged when the sealed database password file cannot be read.</summary>
    public const string DB_SETUP_PASSWORD_READ_FAILED = "The sealed database password in %s cannot be read: %s";

    /// <summary>Logged when the sealed database password file cannot be written.</summary>
    public const string DB_SETUP_PASSWORD_CREATE_FAILED = "The sealed database password in %s cannot be written: %s";

    /// <summary>Reason text when only a migration is missing.</summary>
    public const string DB_SETUP_REASON_MIGRATION_MISSING = "the schema or a migration is missing";

    /// <summary>Shown when the administrator password is missing. {0} is the reason the database is not ready.</summary>
    public const string DB_SETUP_ADMIN_PASSWORD_MISSING_MESSAGE = "The Certificate Handler database is not ready ({0}) and the application cannot set it up because the administrator password is not available. Set the machine environment variable CH_DB_ADMIN_PASSWORD (the installer does this) and start the application again.";

    /// <summary>Shown when the set-up fails. {0} is the database error.</summary>
    public const string DB_SETUP_FAILED_MESSAGE = "The application could not set up the Certificate Handler database: {0}";

    /// <summary>Shown when the database is still not usable after the set-up.</summary>
    public const string DB_SETUP_NOT_READY_MESSAGE = "The Certificate Handler database was set up but the database user still cannot use it. Check the PostgreSQL log, or contact support.";

    /// <summary>Shown when the database user and the administrator are the same account.</summary>
    public const string DB_SETUP_SAME_USER_MESSAGE = "The database user of the application must be a different account than the PostgreSQL administrator. Change Username or AdminUsername in the settings.";

    /// <summary>Shown when the sealed password file cannot be read.</summary>
    public const string DB_SETUP_PASSWORD_READ_MESSAGE = "The sealed database password cannot be read. Check that the application may read its database folder.";

    /// <summary>Shown when the sealed password file cannot be written.</summary>
    public const string DB_SETUP_PASSWORD_CREATE_MESSAGE = "The database password cannot be created. Check that the application may write to its database folder.";

    /// <summary>Shown when an embedded SQL file is missing. {0} is its name.</summary>
    public const string DB_SETUP_RESOURCE_MISSING_MESSAGE = "The embedded database script {0} was not found.";

    /// <summary>
    /// Environment variable that holds the password of the PostgreSQL administrator account.
    /// It is read only when the application has to create or repair the database.
    /// </summary>
    public const string ADMIN_PASSWORD_ENVIRONMENT_VARIABLE = "CH_DB_ADMIN_PASSWORD";

    /// <summary>
    /// PostgreSQL administrator account used when the settings do not name one.
    /// </summary>
    public const string DEFAULT_ADMIN_USERNAME = "postgres";

    /// <summary>
    /// Runtime database user on <see cref="DatabaseName"/> (same naming pattern as Valmet$UserManagement).
    /// </summary>
    public const string DEFAULT_APPLICATION_USERNAME = "Valmet$CertificateManagement";

    /// <summary>
    /// Id of the migration that creates the dashboard indexes.
    /// </summary>
    public const string DASHBOARD_INDEXES_MIGRATION_ID = "v1.3_dashboard_indexes";

    /// <summary>
    /// Name of the embedded file of the dashboard indexes migration.
    /// </summary>
    public const string EMBEDDED_DASHBOARD_INDEXES_RESOURCE_NAME = "CertificateHandler.Data.Schema.Migrations.V1_3_DashboardIndexes.sql";

    #endregion

    #region Trust Store Constants

    /// <summary>Logged when the local trust store is created without options.</summary>
    public const string TRUST_STORE_OPTIONS_IS_NULL = "The local trust store cannot be created because no trust store options were given.";

    /// <summary>Logged when the local trust store is created without a key protector.</summary>
    public const string TRUST_STORE_KEY_PROTECTOR_IS_NULL = "The local trust store cannot be created because no key protector was given.";

    /// <summary>Logged when the local trust store repository is created without a database.</summary>
    public const string TRUST_STORE_DATABASE_IS_NULL = "The trust store repository cannot be created because no trust store database was given.";

    /// <summary>Logged when a trust entry that must be saved is missing.</summary>
    public const string TRUST_STORE_ENTRY_IS_NULL = "The trust entry cannot be saved because no entry was given.";

    /// <summary>Logged when a required text of a trust entry is empty.</summary>
    public const string TRUST_STORE_ENTRY_FIELD_MISSING = "The trust entry %s cannot be saved because the field %s is empty.";

    /// <summary>Logged when a new database key was created and sealed for the local trust store.</summary>
    public const string TRUST_STORE_KEY_CREATED = "A new database key for the local trust store was created and sealed in the file %s.";

    /// <summary>Logged when the sealed database key cannot be created.</summary>
    public const string TRUST_STORE_KEY_CREATE_FAILED = "The database key of the local trust store could not be created in the file %s: %s";

    /// <summary>Logged when the sealed database key cannot be read or unsealed.</summary>
    public const string TRUST_STORE_KEY_UNSEAL_FAILED = "The database key of the local trust store could not be unsealed from the file %s: %s";

    /// <summary>Logged when the unsealed database key has the wrong length.</summary>
    public const string TRUST_STORE_KEY_INVALID = "The key file %s of the local trust store does not contain a valid database key.";

    /// <summary>Logged when the trust store database exists but its key file is missing.</summary>
    public const string TRUST_STORE_KEY_FILE_MISSING = "The local trust store %s exists but its key file %s is missing.";

    /// <summary>Logged when the trust store database cannot be decrypted with its key.</summary>
    public const string TRUST_STORE_OPEN_FAILED = "The local trust store %s could not be decrypted or opened: %s";

    /// <summary>Logged when a new encrypted trust store database was created.</summary>
    public const string TRUST_STORE_CREATED = "A new encrypted local trust store was created in the file %s.";

    /// <summary>Logged when a trust entry cannot be saved.</summary>
    public const string TRUST_STORE_SAVE_FAILED = "The trust entry %s could not be saved in the local trust store: %s";

    /// <summary>Logged when a trust entry cannot be read.</summary>
    public const string TRUST_STORE_READ_FAILED = "The local trust store could not be read: %s";

    /// <summary>Logged when the trust store folder was restricted to administrators and the listed accounts.</summary>
    public const string TRUST_STORE_FOLDER_RESTRICTED = "The local trust store folder %s was restricted to administrators, the system and the running account.";

    /// <summary>Logged when the trust store folder permissions cannot be set.</summary>
    public const string TRUST_STORE_FOLDER_RESTRICT_FAILED = "The permissions of the local trust store folder %s could not be restricted: %s";

    /// <summary>Logged when a trust store file was made read-only.</summary>
    public const string TRUST_STORE_FILE_READ_ONLY = "The local trust store file %s was made read-only.";

    /// <summary>Logged when a trust store file cannot be made read-only.</summary>
    public const string TRUST_STORE_FILE_READ_ONLY_FAILED = "The local trust store file %s could not be made read-only: %s";

    /// <summary>Logged when an additional account of the trust store folder is unknown on this computer.</summary>
    public const string TRUST_STORE_ACCOUNT_NOT_FOUND = "The account %s could not be given access to the local trust store folder because it is unknown on this computer.";

    /// <summary>Shown when the trust store database cannot be decrypted, for example because it was copied from another computer.</summary>
    public const string TRUST_STORE_DECRYPT_FAILED_MESSAGE = "The local trust store cannot be opened. The file is encrypted for another computer or does not match its key. Restore the original trust store and key files, or contact support.";

    /// <summary>Shown when the key file of an existing trust store database is missing.</summary>
    public const string TRUST_STORE_KEY_MISSING_MESSAGE = "The local trust store cannot be opened because its key file is missing. Restore the original key file next to the trust store, or contact support.";

    /// <summary>Shown when the sealed key cannot be unsealed on this computer.</summary>
    public const string TRUST_STORE_KEY_UNSEAL_MESSAGE = "The local trust store key cannot be unsealed on this computer. The key file was probably copied from another computer. Restore the original files, or contact support.";

    /// <summary>Shown when the key file does not contain a valid key.</summary>
    public const string TRUST_STORE_KEY_INVALID_MESSAGE = "The local trust store key file is damaged. Restore the original key file, or contact support.";

    /// <summary>Shown when a new key file cannot be written.</summary>
    public const string TRUST_STORE_KEY_CREATE_MESSAGE = "The local trust store key cannot be created. Check that the application may write to the trust store folder.";

    #endregion
}