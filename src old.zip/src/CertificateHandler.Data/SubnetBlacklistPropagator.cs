using System.Net;
using System.Net.Sockets;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// After a local blacklist, unicasts a signed message to each other MAXUM device on the same subnet (RS_33).
/// </summary>
public sealed class SubnetBlacklistPropagator : ISubnetBlacklistPropagator
{
    private readonly ISubnetPeerDirectory _peers;
    private readonly IBlacklistUnicastTransport _transport;
    private readonly string? _syncKey;
    private readonly string _origin;

    public SubnetBlacklistPropagator(
        ISubnetPeerDirectory peers,
        IBlacklistUnicastTransport transport,
        string? syncKey,
        string origin)
    {
        _peers = peers ?? throw new ArgumentNullException(nameof(peers));
        _transport = transport ?? throw new ArgumentNullException(nameof(transport));
        _syncKey = syncKey;
        _origin = string.IsNullOrWhiteSpace(origin) ? Environment.MachineName : origin.Trim();
    }

    public static SubnetBlacklistPropagator Create(NpgsqlDataSource dataSource) =>
        new(new DatabaseSubnetPeerDirectory(dataSource), new UdpBlacklistUnicastTransport(), BlacklistPropagationCodec.ReadKey(), Environment.MachineName);

    public async Task PropagateAsync(string thumbprintSha256, string reason, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_syncKey) || _syncKey.Length < 16)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Blacklist was saved locally. Subnet unicast was skipped because CH_BLACKLIST_SYNC_KEY is missing (RS_33).");
            return;
        }

        byte[] payload = BlacklistPropagationCodec.CreateSignedPayload(
            thumbprintSha256,
            reason,
            _origin,
            DateTimeOffset.UtcNow,
            _syncKey);

        IReadOnlyList<IPAddress> peers = await _peers.ListSameSubnetPeersAsync(cancellationToken);
        int sent = 0;
        foreach (IPAddress peer in peers)
        {
            try
            {
                await _transport.SendAsync(peer, payload, cancellationToken);
                sent++;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Blacklist unicast to {0} failed: {1}",
                    peer,
                    ex.Message);
            }
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Blacklist unicast sent to {0} MAXUM peer(s) on the local subnet (RS_33).",
            sent);
    }
}

public sealed class DatabaseSubnetPeerDirectory : ISubnetPeerDirectory
{
    private readonly NpgsqlDataSource _dataSource;

    public DatabaseSubnetPeerDirectory(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    public async Task<IReadOnlyList<IPAddress>> ListSameSubnetPeersAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyList<IPAddress> local = Ipv4Subnet.LocalUnicastAddresses();
        int prefix = BlacklistPropagationCodec.ReadPrefixLength();
        var peers = new List<IPAddress>();
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT host(maxum_ip) FROM {DatabaseConstants.SchemaName}.ch_device " +
            "WHERE device_type = CAST('MAXUM_PEER' AS certificate_handler.device_type) " +
            "AND maxum_ip IS NOT NULL AND operational_status = CAST('ACTIVE' AS certificate_handler.device_operational_status)",
            connection);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            if (!IPAddress.TryParse(reader.GetString(0), out IPAddress? peer))
            {
                continue;
            }

            if (local.Any(address => address.Equals(peer)))
            {
                continue;
            }

            if (local.Any(address => Ipv4Subnet.SameSubnet(address, peer, prefix)))
            {
                peers.Add(peer);
            }
        }

        return peers;
    }
}

public sealed class UdpBlacklistUnicastTransport : IBlacklistUnicastTransport
{
    public async Task SendAsync(IPAddress peer, byte[] payload, CancellationToken cancellationToken = default)
    {
        using var client = new UdpClient();
        await client.SendAsync(payload, new IPEndPoint(peer, BlacklistPropagationCodec.ReadPort()), cancellationToken);
    }
}
