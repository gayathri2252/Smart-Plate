// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Runtime.Versioning;
using CertificateHandler.LaunchGuard.Enums;
using CertificateHandler.LaunchGuard.Interfaces;
using Microsoft.Win32;

namespace CertificateHandler.LaunchGuard;

/// <summary>
/// Reads SecurityMode from the MCP registry key (design §17).
/// </summary>
public sealed class RegistrySecurityModeReader : ISecurityModeReader
{
    #region Member Variables

    private const string REGISTRY_PATH = @"SOFTWARE\WOW6432Node\Valmet\MCP";

    private const string SECURITY_MODE_VALUE_NAME = "SecurityMode";

    private readonly Func<RegistryKey?> _localMachineOpener;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates a reader that opens <see cref="Registry.LocalMachine"/> by default.
    /// </summary>
    public RegistrySecurityModeReader()
        : this(OpenLocalMachine)
    {
    }

    /// <summary>
    /// Creates a reader with a custom local-machine registry opener (for tests).
    /// </summary>
    internal RegistrySecurityModeReader(Func<RegistryKey?> localMachineOpener)
    {
        _localMachineOpener = localMachineOpener ?? throw new ArgumentNullException(nameof(localMachineOpener));
    }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public SecurityMode Read()
    {
        if (!OperatingSystem.IsWindows())
        {
            return SecurityMode.Unknown;
        }

        return ReadWindowsRegistry();
    }

    private static RegistryKey? OpenLocalMachine()
    {
        if (!OperatingSystem.IsWindows())
        {
            return null;
        }

        return OpenWindowsLocalMachine();
    }

    [SupportedOSPlatform("windows")]
    private static RegistryKey OpenWindowsLocalMachine() => Registry.LocalMachine;

    [SupportedOSPlatform("windows")]
    private SecurityMode ReadWindowsRegistry()
    {
        RegistryKey? machine = _localMachineOpener();
        if (machine is null)
        {
            return SecurityMode.Unknown;
        }

        using RegistryKey? key = machine.OpenSubKey(REGISTRY_PATH, writable: false);
        if (key is null)
        {
            return SecurityMode.Unknown;
        }

        object? raw = key.GetValue(SECURITY_MODE_VALUE_NAME);
        if (raw is null)
        {
            return SecurityMode.Unknown;
        }

        return ParseMode(raw.ToString());
    }

    #endregion

    #region Internal Methods

    /// <summary>
    /// Maps the registry string to <see cref="SecurityMode"/> (unit-tested).
    /// </summary>
    public static SecurityMode ParseMode(string? text)
    {
        string normalized = text?.Trim() ?? string.Empty;
        return normalized.ToUpperInvariant() switch
        {
            "SECURE" => SecurityMode.Secure,
            "HYBRID" => SecurityMode.Hybrid,
            "UNSECURE" => SecurityMode.Unsecure,
            _ => SecurityMode.Unknown
        };
    }

    #endregion
}
