using System.Security.Principal;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.UI.Integration;

/// <summary>
/// Host integration surface for embedding Certificate Handler in MAXUM HMI (RS_24).
/// </summary>
public static class MaxumHmiHostBridge
{
    public static bool IsHostedInMaxumHmi =>
        string.Equals(Environment.GetEnvironmentVariable("CH_MAXUM_HMI_HOST"), "1", StringComparison.Ordinal);

    public static string NavigationEntryPoint => IsHostedInMaxumHmi ? "CertificateHandler.Embedded" : "CertificateHandler.Standalone";

    public static string WindowTitleSuffix => IsHostedInMaxumHmi ? " (MAXUM HMI)" : string.Empty;

    public static bool UseCompactChrome => IsHostedInMaxumHmi;

    /// <summary>
    /// When the HMI host pre-authenticates a Device Administrator, skip the login window.
    /// The named user must match the current Windows interactive principal.
    /// </summary>
    public static bool TryCreateEmbeddedUser(out SignedInUser user)
    {
        user = null!;
        if (!IsHostedInMaxumHmi)
        {
            return false;
        }

        string? name = Environment.GetEnvironmentVariable("CH_MAXUM_HMI_USER");
        if (string.IsNullOrWhiteSpace(name))
        {
            return false;
        }

        if (!CurrentPrincipalMatches(name.Trim()))
        {
            return false;
        }

        bool isDeviceAdmin = string.Equals(
            Environment.GetEnvironmentVariable("CH_MAXUM_HMI_DEVICE_ADMIN"),
            "1",
            StringComparison.Ordinal);
        if (!isDeviceAdmin)
        {
            return false;
        }

        user = new SignedInUser(name.Trim(), isDeviceAdministrator: true);
        return true;
    }

    private static bool CurrentPrincipalMatches(string expectedUser)
    {
        if (string.Equals(Environment.UserName, expectedUser, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        using WindowsIdentity identity = WindowsIdentity.GetCurrent();
        if (string.Equals(identity.Name, expectedUser, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        string? suffix = identity.Name?.Split('\\').LastOrDefault();
        return !string.IsNullOrWhiteSpace(suffix)
               && string.Equals(suffix, expectedUser, StringComparison.OrdinalIgnoreCase);
    }
}
