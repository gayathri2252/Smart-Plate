using CertificateHandler.Data;
using CertificateHandler.UI.Authentication;
using CertificateHandler.UI.Interfaces;
using Npgsql;

namespace CertificateHandler.UI.Integration;

/// <summary>
/// Database and local-admin verifier used when an MCC trust action is confirmed (RS_34).
/// </summary>
public static class MccTrustServices
{
    public static NpgsqlDataSource? DataSource { get; private set; }

    public static void Configure(NpgsqlDataSource dataSource)
    {
        DataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    public static MccTrustActionAuthorizer CreateAuthorizer(ILocalUserAuthenticator authenticator)
    {
        if (DataSource is null)
        {
            throw new InvalidOperationException("MCC trust actions are not available until the database is ready.");
        }

        return new MccTrustActionAuthorizer(
            new HmiWorkstationWhitelistQuery(DataSource),
            new HttpKeycloakMccAdminVerifier(),
            new AuthenticatorSbcLocalAdminVerifier(authenticator));
    }
}
