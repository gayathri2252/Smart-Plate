// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.

using System.Windows.Input;

namespace CertificateHandler.UI.Commands;

/// <summary>
/// Simple MVVM command wrapper.
/// </summary>
public sealed class RelayCommand : ICommand
{
    #region Member Variables

    private readonly Action<object?> _execute;

    private readonly Func<object?, bool>? _canExecute;

    #endregion

    #region Constructor

    public RelayCommand(Action execute, Func<bool>? canExecute = null)
        : this(_ => execute(), canExecute is null ? null : _ => canExecute())
    {
    }

    public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    #endregion

    #region Events

    public event EventHandler? CanExecuteChanged;

    #endregion

    #region Public Methods

    public bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter) ?? true;

    public void Execute(object? parameter) => _execute(parameter);

    public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);

    #endregion
}
