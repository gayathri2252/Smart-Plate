using System.Windows;

namespace CertificateHandler.UI.Views;

public partial class CsrPemDialog : Window
{
    public string Pem { get; private set; } = string.Empty;

    public CsrPemDialog()
    {
        InitializeComponent();
    }

    private void ImportButton_Click(object sender, RoutedEventArgs e)
    {
        Pem = PemTextBox.Text?.Trim() ?? string.Empty;
        if (string.IsNullOrEmpty(Pem))
        {
            MessageBox.Show(this, "PEM text is required.");
            return;
        }

        DialogResult = true;
    }
}
