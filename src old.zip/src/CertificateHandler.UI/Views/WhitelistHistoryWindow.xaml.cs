using System.Windows;
using CertificateHandler.Data;
using CertificateHandler.Data.Models;
using Npgsql;

namespace CertificateHandler.UI.Views;

public partial class WhitelistHistoryWindow : Window
{
    public WhitelistHistoryWindow(NpgsqlDataSource dataSource)
    {
        InitializeComponent();
        Loaded += async (_, _) => await LoadAsync(dataSource);
    }

    private async Task LoadAsync(NpgsqlDataSource dataSource)
    {
        try
        {
            IReadOnlyList<WhitelistAuditEntry> rows =
                await new WhitelistAuditHistoryService(dataSource).GetWhitelistHistoryAsync();
            HistoryGrid.ItemsSource = rows;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
