﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using CertificateHandler.UI.Authentication;
using CertificateHandler.UI.Interfaces;
using Npgsql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using UiConstants = CertificateHandler.UI.Constants.Constants;
using CertificateHandler.Logger;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Login window: administrators sign in with a local Windows account that is in the configured
/// administrator group. The Login button stays disabled until a user name and a password are entered.
/// </summary>
public partial class LoginView : Window
{
    #region Member Variables

    /// <summary>
    /// Trust database data source passed on to the main window.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;
    /// <summary>
    /// Checks the user name and password against the local Windows accounts.
    /// </summary>
    private readonly ILocalUserAuthenticator _authenticator;
    /// <summary>
    /// Resource key of the eye icon, shown while the password is hidden.
    /// </summary>
    private const string EYE_ICON_KEY = "EyeIconImage";
    /// <summary>
    /// Resource key of the crossed-out eye icon, shown while the password is visible.
    /// </summary>
    private const string EYE_HIDE_ICON_KEY = "EyeHideIconImage";
    /// <summary>
    /// True while the password is shown as plain text.
    /// </summary>
    private bool _showPassword = false;

    #endregion

    #region Public Properties

    /// <summary>
    /// How long "Logging in as ..." is shown at least; two seconds by default. Tests set it to zero.
    /// </summary>
    public TimeSpan LoginLoadingDelay { get; set; } = TimeSpan.FromMilliseconds(UiConstants.LOGIN_LOADING_DELAY_MILLISECONDS);

    #endregion

    #region Constructor
    /// <summary>
    /// Creates the login window that signs users in with the local Windows accounts and the group from appsettings.json.
    /// </summary>
    /// <param name="dataSource">
    /// Trust database data source used by the application.
    /// </param>
    public LoginView(NpgsqlDataSource dataSource)
        : this(dataSource, new WindowsLocalUserAuthenticator(LocalLoginOptions.Load().AdministratorGroup))
    {
    }

    /// <summary>
    /// Creates the login window with the given authenticator.
    /// </summary>
    /// <param name="dataSource">
    /// Trust database data source used by the application.
    /// </param>
    /// <param name="authenticator">
    /// Checks the user name and password.
    /// </param>
    public LoginView(NpgsqlDataSource dataSource, ILocalUserAuthenticator authenticator)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _authenticator = authenticator ?? throw new ArgumentNullException(nameof(authenticator));
        InitializeComponent();
        FitToWorkArea();
        LoginVersionText.Text = string.Format(UiConstants.PRODUCT_VERSION_FORMAT, PendingRequestQueueView.GetProductVersion());
        Loaded += (_, _) => txtUsername.Focus();
    }

    #endregion

    #region Private Methods
    /// <summary>
    /// Checks the credentials against the local Windows accounts while "Logging in as ..." is shown for
    /// two seconds. For a member of the administrator group, the main window opens on the dashboard with
    /// an animation like opening a book; otherwise the reason is shown in the error box.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private async void OnLoginButtonClicked(object sender, RoutedEventArgs e)
    {
        string username = txtUsername.Text.Trim();
        string password = _showPassword
            ? txtPasswordVisible.Text
            : txtPassword.Password;

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_LOGIN_ATTEMPT, username);
        ShowLoading(username);

        try
        {
            Task<LocalSignInResult> signIn = Task.Run(() => _authenticator.SignIn(username, password));
            await Task.WhenAll(signIn, Task.Delay(LoginLoadingDelay));
            LocalSignInResult result = await signIn;

            if (result == LocalSignInResult.Success)
            {
                CertificateHandlerLogger.Success(MessageIdGenerator.Next(), UiConstants.LOG_LOGIN_SUCCEEDED, username);
                SignedInUser signedInUser = new SignedInUser(username, isDeviceAdministrator: true);
                PendingRequestQueueView window = new PendingRequestQueueView(_dataSource, signedInUser);
                window.Show();
                window.PlayLoadingTransition();
                Close();
                return;
            }

            HideLoading();
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_LOGIN_REFUSED, username, result.ToString());

            switch (result)
            {
                case LocalSignInResult.NotAuthorized:
                    ShowError(string.Format(RequestStatusConstants.NOT_AUTHORIZED_FOR_USER, _authenticator.AdministratorGroup));
                    break;

                case LocalSignInResult.PasswordMustChange:
                    ShowError(RequestStatusConstants.PASSWORD_MUST_CHANGE_FOR_USER);
                    break;

                case LocalSignInResult.AccountDisabled:
                    ShowError(RequestStatusConstants.ACCOUNT_DISABLED_FOR_USER);
                    break;

                case LocalSignInResult.Unavailable:
                    ShowError(RequestStatusConstants.SIGN_IN_UNAVAILABLE_FOR_USER);
                    break;

                default:
                    ShowError(RequestStatusConstants.INVALID_CREDENTIALS_MESSAGE);
                    break;
            }
        }
        catch (Exception ex)
        {
            HideLoading();
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_LOGIN_FAILED, username, ex.Message);
            MessageBox.Show(
                ex.ToString(),
                RequestStatusConstants.ERROR_TITLE,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    /// <summary>
    /// Covers the fields with the turning circle and "Logging in as" the user name.
    /// </summary>
    /// <param name="username">User name that is being signed in.</param>
    private void ShowLoading(string username)
    {
        LoadingText.Text = string.Format(UiConstants.LOGGING_IN_FORMAT, username);
        FormPanel.IsEnabled = false;
        LoadingPanel.Visibility = Visibility.Visible;

        DoubleAnimation turn = new(0, 360, new Duration(TimeSpan.FromSeconds(1)))
        {
            RepeatBehavior = RepeatBehavior.Forever
        };
        SpinnerRotation.BeginAnimation(RotateTransform.AngleProperty, turn);
    }

    /// <summary>
    /// Shows the fields again after a failed login.
    /// </summary>
    private void HideLoading()
    {
        SpinnerRotation.BeginAnimation(RotateTransform.AngleProperty, null);
        LoadingPanel.Visibility = Visibility.Collapsed;
        FormPanel.IsEnabled = true;
    }

    /// <summary>
    /// Shrinks the window to the screen area above the taskbar, so the title bar and its buttons stay visible.
    /// </summary>
    private void FitToWorkArea()
    {
        Rect workArea = SystemParameters.WorkArea;

        Width = Math.Min(Width, workArea.Width);
        Height = Math.Min(Height, workArea.Height);
        MinWidth = Math.Min(MinWidth, Width);
        MinHeight = Math.Min(MinHeight, Height);
    }

    /// <summary>
    /// Shows the given message below the password box.
    /// </summary>
    /// <param name="message">
    /// Message for the user.
    /// </param>
    private void ShowError(string message)
    {
        txtError.Text = message;
        txtError.Visibility = Visibility.Visible;
    }

    /// <summary>
    /// Toggles password visibility between
    /// hidden and visible modes.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnShowPasswordButtonClicked(object sender, RoutedEventArgs e)
    {
        if (_showPassword)
        {
            txtPassword.Password = txtPasswordVisible.Text;
            txtPasswordVisible.Visibility = Visibility.Collapsed;
            txtPassword.Visibility = Visibility.Visible;
            _showPassword = false;
            imgEye.Source = (ImageSource)FindResource(EYE_ICON_KEY);
            btnShowPassword.ToolTip = UiConstants.TOOLTIP_SHOW_PASSWORD;
        }
        else
        {
            txtPasswordVisible.Text = txtPassword.Password;
            txtPassword.Visibility = Visibility.Collapsed;
            txtPasswordVisible.Visibility = Visibility.Visible;
            _showPassword = true;
            imgEye.Source = (ImageSource)FindResource(EYE_HIDE_ICON_KEY);
            btnShowPassword.ToolTip = UiConstants.TOOLTIP_HIDE_PASSWORD;
        }

        UpdateLoginState();
    }

    /// <summary>
    /// Updates the password placeholder and the Login button whenever the
    /// user name or the password changes.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnCredentialsChanged(object sender, RoutedEventArgs e)
    {
        UpdateLoginState();
    }

    /// <summary>
    /// Shows the placeholder for an empty password, hides the error, and enables Login only when
    /// both a user name and a password are entered.
    /// </summary>
    private void UpdateLoginState()
    {
        if (txtUsername is null || txtPassword is null || txtPasswordVisible is null
            || txtPasswordPlaceholder is null || txtError is null || btnLogin is null)
        {
            return;
        }

        string password = _showPassword ? txtPasswordVisible.Text : txtPassword.Password;
        bool hasUsername = !string.IsNullOrWhiteSpace(txtUsername.Text);
        bool hasPassword = !string.IsNullOrEmpty(password);

        txtPasswordPlaceholder.Visibility = hasPassword ? Visibility.Collapsed : Visibility.Visible;
        btnLogin.IsEnabled = hasUsername && hasPassword;
        txtError.Visibility = Visibility.Collapsed;
    }

    #endregion
}