// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.

using System.Windows;
using CertificateHandler.Data.Security;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Collects the mandatory rejection reason (RS_19).
/// </summary>
public partial class RejectReasonDialog : Window
{
    #region Public Properties

    /// <summary>Reason entered by the administrator.</summary>
    public string Reason { get; private set; } = string.Empty;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the dialog.
    /// </summary>
    public RejectReasonDialog()
    {
        InitializeComponent();
    }

    #endregion

    #region Private Methods

    private void RejectButton_Click(object sender, RoutedEventArgs e)
    {
        Reason = ReasonTextBox.Text.Trim();
        try
        {
            DecisionReasonPolicy.ValidateOrThrow(Reason);
        }
        catch (ArgumentException ex)
        {
            MessageBox.Show(this, ex.Message);
            return;
        }

        DialogResult = true;
    }

    #endregion
}
