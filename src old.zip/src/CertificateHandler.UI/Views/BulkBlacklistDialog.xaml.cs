using System.Windows;

namespace CertificateHandler.UI.Views;

public partial class BulkBlacklistDialog : Window
{
    public IReadOnlyList<string> Thumbprints { get; private set; } = Array.Empty<string>();

    public string Reason { get; private set; } = string.Empty;

    public BulkBlacklistDialog()
    {
        InitializeComponent();
    }

    private void BlacklistButton_Click(object sender, RoutedEventArgs e)
    {
        Reason = ReasonTextBox.Text?.Trim() ?? string.Empty;
        Thumbprints = (ThumbprintsTextBox.Text ?? string.Empty)
            .Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(line => !string.IsNullOrWhiteSpace(line))
            .ToArray();

        if (Thumbprints.Count == 0 || string.IsNullOrEmpty(Reason))
        {
            MessageBox.Show(this, "At least one thumbprint and a reason are required.", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DialogResult = true;
    }
}
