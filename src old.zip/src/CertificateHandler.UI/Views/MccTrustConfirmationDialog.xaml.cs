using System.Windows;
using CertificateHandler.Data;
using CertificateHandler.UI.Authentication;
using CertificateHandler.UI.Integration;

namespace CertificateHandler.UI.Views;

public partial class MccTrustConfirmationDialog : Window
{
    public MccTrustConfirmationDialog()
    {
        InitializeComponent();
    }

    public static bool ConfirmIfRequired(Window owner)
    {
        if (!MccTrustSession.IsActive)
        {
            return true;
        }

        var dialog = new MccTrustConfirmationDialog { Owner = owner };
        return dialog.ShowDialog() == true;
    }

    protected override void OnClosed(EventArgs e)
    {
        TokenBox.Password = string.Empty;
        PasswordBox.Password = string.Empty;
        base.OnClosed(e);
    }

    private async void Confirm_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var authenticator = new WindowsLocalUserAuthenticator(LocalLoginOptions.Load().AdministratorGroup);
            MccTrustActionAuthorizer authorizer = MccTrustServices.CreateAuthorizer(authenticator);
            MccTrustActionResult result = await authorizer.AuthorizeAsync(new MccTrustActionRequest
            {
                AccessToken = TokenBox.Password,
                LocalAdministratorUser = UserNameBox.Text.Trim(),
                LocalAdministratorPassword = PasswordBox.Password
            });

            if (!result.IsAllowed)
            {
                MessageBox.Show(result.DenialReason, Title, MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MccTrustProof.Set(result.KeycloakSubject, result.SbcAdministrator);
            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
