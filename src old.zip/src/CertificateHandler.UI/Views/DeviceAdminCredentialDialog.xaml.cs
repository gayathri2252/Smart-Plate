using System.Windows;
using CertificateHandler.Shared.Models;
using CertificateHandler.UI.Authentication;
using CertificateHandler.UI.Interfaces;

namespace CertificateHandler.UI.Views;

public partial class DeviceAdminCredentialDialog : Window
{
    private readonly ILocalUserAuthenticator _authenticator;

    public DeviceAdminCredentialDialog(ILocalUserAuthenticator? authenticator = null)
    {
        _authenticator = authenticator ?? new WindowsLocalUserAuthenticator(LocalLoginOptions.Load().AdministratorGroup);
        InitializeComponent();
    }

    public string UserName => UserNameBox.Text.Trim();

    public bool IsAuthorized { get; private set; }

    private void Confirm_Click(object sender, RoutedEventArgs e)
    {
        string user = UserNameBox.Text.Trim();
        string password = PasswordBox.Password;
        IsAuthorized = _authenticator.SignIn(user, password) == LocalSignInResult.Success;
        if (!IsAuthorized)
        {
            MessageBox.Show("Invalid Device Administrator credentials.", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DialogResult = true;
        Close();
    }
}
