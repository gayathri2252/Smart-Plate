﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Services;
using CertificateHandler.Data;
using CertificateHandler.Shared.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.UI.Integration;
using CertificateHandler.UI.ViewModels;
using Npgsql;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using UiConstants = CertificateHandler.UI.Constants.Constants;
using CertificateHandler.UI.Services;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Interaction logic for PendingRequestQueueView.
/// Displays pending certificate requests and allows users to approve or reject requests.
/// </summary>
public partial class PendingRequestQueueView : Window
{
    #region Member Variables

    /// <summary>Width of the side bar when it is collapsed.</summary>
    private const double COLLAPSED_SIDEBAR_WIDTH = 80;
    /// <summary>Width of the side bar when it is expanded.</summary>
    private const double EXPANDED_SIDEBAR_WIDTH = 270;
    /// <summary>Window width below which the side bar collapses by itself, so the whole request grid stays visible.</summary>
    private const double AUTO_COLLAPSE_WIDTH = 1100;
    /// <summary>Width of the window when it is restored from the maximized state.</summary>
    private const double DEFAULT_WINDOW_WIDTH = 1200;
    /// <summary>Height of the window when it is restored from the maximized state.</summary>
    private const double DEFAULT_WINDOW_HEIGHT = 760;
    /// <summary>Windows message sent when the user starts to move or resize the window.</summary>
    private const int WM_ENTERSIZEMOVE = 0x0231;
    /// <summary>Windows message sent when the user stops moving or resizing the window.</summary>
    private const int WM_EXITSIZEMOVE = 0x0232;
    /// <summary>Version shown in the footer when the assembly has no version.</summary>
    private const string DEFAULT_PRODUCT_VERSION = "1.0.0";
    /// <summary>True while the side bar is collapsed.</summary>
    private bool _isCollapsed = false;
    /// <summary>True when the side bar was collapsed by a small window and not by the user.</summary>
    private bool _isCollapsedAutomatically = false;
    /// <summary>True while the user drags the window to move or resize it.</summary>
    private bool _isUserDragging = false;
    /// <summary>Window state before the last state change; tells when the window is restored from maximized.</summary>
    private WindowState _previousWindowState = WindowState.Normal;

    /// <summary>Database connection used for the dashboard and the login screen; null when none was given.</summary>
    private readonly NpgsqlDataSource? _dataSource;

    /// <summary>Dashboard page shown inside this window; null until the Dashboard menu item is first chosen.</summary>
    private DashboardView? _dashboardView;

    /// <summary>Whitelist / Blacklist page shown inside this window; null until its menu item is first chosen.</summary>
    private TrustListView? _trustListView;

    /// <summary>Certificate Management page shown inside this window; null until its menu item is first chosen.</summary>
    private CertificateInformationView? _certificateInformationView;

    /// <summary>User who signed in; the dashboard and the Whitelist / Blacklist page check the role of this user. Null when no one signed in.</summary>
    private readonly SignedInUser? _signedInUser;

    /// <summary>Pages that can be shown in the content area of this window.</summary>
    private enum ContentPage
    {
        /// <summary>The request queue.</summary>
        RequestQueue,

        /// <summary>The dashboard.</summary>
        Dashboard,

        /// <summary>The Whitelist / Blacklist page.</summary>
        TrustList,

        /// <summary>The Certificate Management page.</summary>
        CertificateManagement
    }

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the PendingRequestQueueView using the provided database source,
    /// for the user who signed in.
    /// </summary>
    /// <param name="dataSource">Database connection source.</param>
    /// <param name="signedInUser">User who signed in; null when no one signed in.</param>
    public PendingRequestQueueView(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
        : this(CreateViewModel(dataSource, signedInUser))
    {
        _dataSource = dataSource;
        _signedInUser = signedInUser;
        ShowSignedInUser();
    }

    /// <summary>
    /// Initializes a new instance of the PendingRequestQueueView with the specified ViewModel,
    /// the database connection used for the dashboard and the login screen, and the user who signed in.
    /// </summary>
    /// <param name="viewModel">Pending request queue ViewModel.</param>
    /// <param name="dataSource">Database connection source.</param>
    /// <param name="signedInUser">User who signed in; null when no one signed in.</param>
    public PendingRequestQueueView(
        PendingRequestQueueViewModel viewModel,
        NpgsqlDataSource dataSource,
        SignedInUser? signedInUser)
        : this(viewModel)
    {
        _dataSource = dataSource;
        _signedInUser = signedInUser;
        ShowSignedInUser();
    }

    /// <summary>
    /// Initializes a new instance of the PendingRequestQueueView with the specified ViewModel.
    /// </summary>
    /// <param name="viewModel">Pending request queue ViewModel.</param>
    public PendingRequestQueueView(PendingRequestQueueViewModel viewModel)
    {
        InitializeComponent();
        Title += MaxumHmiHostBridge.WindowTitleSuffix;
        if (MaxumHmiHostBridge.UseCompactChrome)
        {
            ProductVersionText.Visibility = Visibility.Collapsed;
        }

        SourceInitialized += OnSourceInitialized;
        StateChanged += OnWindowStateChanged;
        ProductVersionText.Text = string.Format(UiConstants.PRODUCT_VERSION_FORMAT, GetProductVersion());
        FitToScreen();
        viewModel.LoadPendingRequests();
        DataContext = viewModel;
        viewModel.PropertyChanged += ViewModel_PropertyChanged;
        ShowSortArrow();
        PendingRequestsGrid.Loaded += (_, _) => ShowSortArrow();
        SubscribeToSessionReload();
        ShowSignedInUser();
        Loaded += OnFirstLoaded;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Shows a turning circle with a short text over the content while the first page loads, then fades it out
    /// and reveals the page. Called once after login, in place of opening the page at once.
    /// </summary>
    public void PlayLoadingTransition()
    {
        LoadingOverlay.Opacity = 1;
        LoadingOverlay.Visibility = Visibility.Visible;

        DoubleAnimation turn = new(0, 360, new Duration(TimeSpan.FromMilliseconds(UiConstants.SPINNER_TURN_MILLISECONDS)))
        {
            RepeatBehavior = RepeatBehavior.Forever
        };
        LoadingSpinnerRotation.BeginAnimation(RotateTransform.AngleProperty, turn);

        _ = HideLoadingOverlayAsync();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Keeps the loading panel for a short time, then fades it out so the page behind it appears.
    /// </summary>
    private async Task HideLoadingOverlayAsync()
    {
        await Task.Delay(UiConstants.CONTENT_LOADING_DELAY_MILLISECONDS);

        if (!IsLoaded)
        {
            return;
        }

        DoubleAnimation fadeOut = new(1, 0, new Duration(TimeSpan.FromMilliseconds(UiConstants.CONTENT_LOADING_FADE_MILLISECONDS)));
        fadeOut.Completed += (_, _) =>
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
            LoadingSpinnerRotation.BeginAnimation(RotateTransform.AngleProperty, null);
        };
        LoadingOverlay.BeginAnimation(OpacityProperty, fadeOut);
    }

    /// <summary>
    /// Opens the dashboard first, once the window is shown. A window created without a connection
    /// (for example in tests) stays on the Request Queue.
    /// </summary>
    private void OnFirstLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnFirstLoaded;

        if (_dataSource is not null)
        {
            Dashboard_Click(this, e);
        }
    }

    /// <summary>
    /// Shows the name of the signed-in user on the user button in the top bar.
    /// </summary>
    private void ShowSignedInUser()
    {
        string userName = string.IsNullOrWhiteSpace(_signedInUser?.UserName)
            ? UiConstants.LOG_OUT
            : _signedInUser!.UserName;

        UserNameText.Text = userName;
        UserButton.ToolTip = string.Format(UiConstants.TOOLTIP_USER_MENU_FORMAT, userName);
    }

    /// <summary>
    /// Opens the menu with Log out under the user button.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void UserButton_Click(object sender, RoutedEventArgs e)
    {
        if (UserButton.ContextMenu is null)
        {
            return;
        }

        UserButton.ContextMenu.PlacementTarget = UserButton;
        UserButton.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
        UserButton.ContextMenu.IsOpen = true;
    }

    /// <summary>
    /// Returns the version of the UI assembly as major.minor.build, such as 1.0.3, for the footer.
    /// The version comes from the Version property of the project.
    /// </summary>
    /// <returns>Version text without the revision number.</returns>
    internal static string GetProductVersion()
    {
        Version? version = typeof(PendingRequestQueueView).Assembly.GetName().Version;

        // Every built assembly has a version; the fallback only keeps the footer from showing nothing.
        return version is null
            ? DEFAULT_PRODUCT_VERSION
            : $"{version.Major}.{version.Minor}.{Math.Max(0, version.Build)}";
    }

    /// <summary>
    /// Creates and initializes the ViewModel required by the view.
    /// </summary>
    /// <param name="dataSource">Database connection source.</param>
    /// <returns>Configured PendingRequestQueueViewModel instance.</returns>
    private static PendingRequestQueueViewModel CreateViewModel(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
    {
        PendingRequestRepository repository = new(dataSource);
        CertificateHandler.DeviceTrust.Tls.TlsHandshakeCoordinator handshakes =
            CertificateHandler.DeviceTrust.Tls.TlsHandshakeCoordinatorRegistry.Current;
        CertificateHandler.Data.PendingOnboardingApprovalStore approvalStore = new(
            dataSource,
            resumePendingHandshake: id => handshakes.Resume(id.ToString()));
        var reinstatementWorkflow = new ReinstatementWorkflowService(dataSource);
        var reinstatementApprovals = new ReinstatementPendingApprovalStore(dataSource, reinstatementWorkflow);
        PendingRequestQueueService service = new(repository, approvalStore, reinstatementApprovals);
        return new PendingRequestQueueViewModel(
            service,
            () => signedInUser?.UserName ?? string.Empty);
    }

    /// <summary>
    /// Keeps the window inside the usable screen area, so a small or scaled display never pushes the
    /// title bar buttons off the screen.
    /// </summary>
    private void FitToScreen()
    {
        Rect workArea = SystemParameters.WorkArea;

        MaxWidth = workArea.Width;
        MaxHeight = workArea.Height;
        Width = Math.Min(Width, workArea.Width);
        Height = Math.Min(Height, workArea.Height);
        MinWidth = Math.Min(MinWidth, workArea.Width);
        MinHeight = Math.Min(MinHeight, workArea.Height);
    }

    /// <summary>
    /// Shows the dashboard inside this window, next to the same menu. The page is created the first
    /// time and loaded again each time after that. Logs a warning when this window was created
    /// without a connection, and an error when the dashboard cannot be shown.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private async void Dashboard_Click(object sender, RoutedEventArgs e)
    {
        // A window created from a view model alone has no connection to give the dashboard.
        if (_dataSource is null)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.DASHBOARD_NOT_AVAILABLE);
            return;
        }

        try
        {
            bool isDashboardViewCreated = _dashboardView is null;
            DashboardView dashboardView = _dashboardView ??= new DashboardView(_dataSource, _signedInUser);

            if (isDashboardViewCreated)
            {
                dashboardView.HorizontalAlignment = HorizontalAlignment.Stretch;
                dashboardView.VerticalAlignment = VerticalAlignment.Stretch;
                DashboardHost.Children.Add(dashboardView);
            }

            ShowPage(ContentPage.Dashboard);
            if (!isDashboardViewCreated)
            {
                await dashboardView.ReloadAsync();
            }
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_OPEN_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Shows the Whitelist / Blacklist page inside this window, next to the same menu. The page is created
    /// the first time and loaded again each time after that. Logs a warning when this window was created
    /// without a connection, and an error when the page cannot be shown.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private async void TrustList_Click(object sender, RoutedEventArgs e)
    {
        if (_dataSource is null)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.TRUST_LIST_NOT_AVAILABLE);
            return;
        }

        try
        {
            bool isTrustListViewCreated = _trustListView is null;
            TrustListView trustListView = _trustListView ??= new TrustListView(_dataSource, _signedInUser);

            if (isTrustListViewCreated)
            {
                trustListView.HorizontalAlignment = HorizontalAlignment.Stretch;
                trustListView.VerticalAlignment = VerticalAlignment.Stretch;
                TrustListHost.Children.Add(trustListView);
            }

            ShowPage(ContentPage.TrustList);
            if (!isTrustListViewCreated)
            {
                await trustListView.ReloadAsync();
            }
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LIST_OPEN_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Shows the Certificate Management page inside this window, next to the same menu; no other
    /// window is opened. The page is created the first time and loaded again each time after that.
    /// Logs a warning when this window was created without a connection, and an error when the page
    /// cannot be shown.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private async void CertificateInformation_Click(object sender, RoutedEventArgs e)
    {
        if (_dataSource is null)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.NAVIGATION_NOT_AVAILABLE);
            return;
        }

        try
        {
            bool isCertificateInformationViewCreated = _certificateInformationView is null;
            CertificateInformationView certificateInformationView = _certificateInformationView ??= new CertificateInformationView(_dataSource, _signedInUser);

            if (isCertificateInformationViewCreated)
            {
                certificateInformationView.HorizontalAlignment = HorizontalAlignment.Stretch;
                certificateInformationView.VerticalAlignment = VerticalAlignment.Stretch;
                CertificateManagementHost.Children.Add(certificateInformationView);
            }

            ShowPage(ContentPage.CertificateManagement);
            if (!isCertificateInformationViewCreated)
            {
                await certificateInformationView.ReloadAsync();
            }
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.NAVIGATION_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Shows the request queue again in place of the other pages.
    /// </summary>
    /// <param name="sender">Menu item that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void RequestQueueMenu_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        ShowPage(ContentPage.RequestQueue);
    }

    /// <summary>
    /// Shows the given page in the content area, hides the others and marks the matching menu item as selected.
    /// </summary>
    /// <param name="page">Page to show.</param>
    private void ShowPage(ContentPage page)
    {
        QueueContentGrid.Visibility = page == ContentPage.RequestQueue ? Visibility.Visible : Visibility.Collapsed;
        DashboardHost.Visibility = page == ContentPage.Dashboard ? Visibility.Visible : Visibility.Collapsed;
        TrustListHost.Visibility = page == ContentPage.TrustList ? Visibility.Visible : Visibility.Collapsed;
        CertificateManagementHost.Visibility = page == ContentPage.CertificateManagement ? Visibility.Visible : Visibility.Collapsed;

        Brush selected = (Brush)FindResource("RequestQueueMenuBrush");
        RequestQueueMenu.Background = page == ContentPage.RequestQueue ? selected : Brushes.Transparent;
        DashboardButton.Background = page == ContentPage.Dashboard ? selected : Brushes.Transparent;
        TrustListButton.Background = page == ContentPage.TrustList ? selected : Brushes.Transparent;
        CertificateManagementButton.Background = page == ContentPage.CertificateManagement ? selected : Brushes.Transparent;
    }

    /// <summary>
    /// Asks the user to confirm, then ends the session, returns to the login screen and closes this window. Logs a warning when this window was
    /// created without a connection, and an error when the login screen cannot be opened.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        if (_dataSource is null)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.NAVIGATION_NOT_AVAILABLE);
            return;
        }

        if (!ConfirmLogout())
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_LOGOUT_CANCELLED, _signedInUser?.UserName ?? UiConstants.LOG_EMPTY_VALUE);
            return;
        }

        try
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_LOGOUT, _signedInUser?.UserName ?? UiConstants.LOG_EMPTY_VALUE);
            App.EndSession();
            new LoginView(_dataSource).Show();
            Close();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.NAVIGATION_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Asks the user to confirm the log out. Returns true only when the user presses Log out; Cancel, Escape or
    /// closing the dialog keeps the user signed in.
    /// </summary>
    private bool ConfirmLogout()
    {
        LogoutConfirmWindow dialog = new() { Owner = this };
        dialog.ShowDialog();

        return dialog.IsLogoutConfirmed;
    }

    /// <summary>
    /// Listens for a session recovery so the pending requests reload after a network failure.
    /// Stops listening when the window closes.
    /// </summary>
    private void SubscribeToSessionReload()
    {
        if (App.SessionRefresh is { } sessionRefresh)
        {
            sessionRefresh.ReloadRequested += OnSessionReloadRequested;
            Closed += (_, _) => sessionRefresh.ReloadRequested -= OnSessionReloadRequested;
        }
    }

    /// <summary>
    /// Reloads the pending requests and the pages that are open on the UI thread after the session recovers.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Event arguments.</param>
    private void OnSessionReloadRequested(object? sender, EventArgs e)
    {
        Dispatcher.InvokeAsync(async () =>
        {
            (DataContext as PendingRequestQueueViewModel)?.LoadPendingRequests();
            if (_dashboardView is not null)
            {
                await _dashboardView.ReloadAsync();
            }

            if (_trustListView is not null)
            {
                await _trustListView.ReloadAsync();
            }

            if (_certificateInformationView is not null)
            {
                await _certificateInformationView.ReloadAsync();
            }
        });
    }

    /// <summary>
    /// Handles the approval of a selected pending request.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnApproveButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.DataContext is PendingRequestItem request
            && DataContext is PendingRequestQueueViewModel viewModel)
        {
            OpenRequestDecisionDialog(request, viewModel);
        }
    }

    /// <summary>
    /// Handles the rejection of a selected pending request.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnRejectButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.DataContext is PendingRequestItem request)
        {
            PendingRequestQueueViewModel viewModel = (PendingRequestQueueViewModel)DataContext;
            viewModel.SelectedRequest = request;
            RejectReasonDialog dialog = new();
            ApplyDialogOwner(dialog);
            if (dialog.ShowDialog() == true && MccTrustConfirmationDialog.ConfirmIfRequired(this))
            {
                try
                {
                    viewModel.RejectSelectedRequest(dialog.Reason);
                }
                finally
                {
                    MccTrustProof.Clear();
                }
            }
        }
    }

    /// <summary>
    /// Opens the details of the request in the clicked row. When the administrator approves or rejects
    /// the request in the dialog, the same approval or rejection as the row buttons is carried out.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnViewDetailsButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button || button.DataContext is not PendingRequestItem request
            || DataContext is not PendingRequestQueueViewModel viewModel)
        {
            return;
        }

        OpenRequestDecisionDialog(request, viewModel);
    }

    private void OpenRequestDecisionDialog(PendingRequestItem request, PendingRequestQueueViewModel viewModel)
    {
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_DETAILS_OPENED, request.RequestId);

        RequestDetailsWindow dialog = new(request);
        ApplyDialogOwner(dialog);
        dialog.ShowDialog();

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_DETAILS_CLOSED, request.RequestId, dialog.Decision.ToString());

        switch (dialog.Decision)
        {
            case RequestDetailsWindow.RequestDecision.Approve:
                if (!MccTrustConfirmationDialog.ConfirmIfRequired(this))
                {
                    break;
                }

                try
                {
                    viewModel.SelectedRequest = request;
                    viewModel.ApproveSelectedRequest();
                }
                finally
                {
                    MccTrustProof.Clear();
                }

                break;

            case RequestDetailsWindow.RequestDecision.Reject:
                viewModel.SelectedRequest = request;
                RejectReasonDialog rejectDialog = new();
                ApplyDialogOwner(rejectDialog);
                if (rejectDialog.ShowDialog() == true && MccTrustConfirmationDialog.ConfirmIfRequired(this))
                {
                    try
                    {
                        viewModel.RejectSelectedRequest(rejectDialog.Reason);
                    }
                    finally
                    {
                        MccTrustProof.Clear();
                    }
                }

                break;
        }
    }

    /// <summary>
    /// Toggles the sort direction for the pending request list.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void SortPendingRequestsButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.ToggleSort();
        }
    }

    /// <summary>
    /// Navigates to the previous page of pending requests.
    /// </summary>
    /// <param name="sender">
    /// Source of the event
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.PreviousPage();
        }
    }

    /// <summary>
    /// Navigates to the next page of pending requests.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    ///  Event arguments.
    /// </param>
    private void NextPageButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.NextPage();
        }
    }

    /// <summary>
    /// Changes the number of requests on a page to the size stored in the Tag of the chosen item,
    /// and shows the first page with the active filters.
    /// </summary>
    /// <param name="sender">The page size drop-down.</param>
    /// <param name="e">Selection changed event arguments.</param>
    private void PageSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // The Tag holds the page size as text, such as "10".
        if (DataContext is PendingRequestQueueViewModel viewModel
            && sender is ComboBox { SelectedItem: ComboBoxItem { Tag: string tag } }
            && int.TryParse(tag, out int pageSize))
        {
            viewModel.PageSize = pageSize;
        }
    }

    /// <summary>
    ///  Clears all applied filters from the pending request list.
    /// </summary>
    /// <param name="sender">
    ///  Source of the event
    /// </param>
    /// <param name="e">
    ///  Event arguments.
    /// </param>
    private void ClearFiltersButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.ClearFilters();
        }
    }

    /// <summary>
    /// Opens the filter window for applying advanced filters
    /// </summary>
    /// <param name="sender">
    ///  Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void FilterButton_Click(object sender, RoutedEventArgs e)
    {
        FilterWindow filterWindow = new();
        filterWindow.DataContext = DataContext;
        ApplyDialogOwner(filterWindow);

        // Open the panel under the filter button, like a drop-down; it closes when the user clicks elsewhere.
        if (sender is FrameworkElement filterButton)
        {
            filterWindow.ShowBelow(filterButton);
        }
        else
        {
            filterWindow.ShowDialog();
        }
    }

    /// <summary>
    /// Handles DataGrid sorting events and applies sorting
    /// through the ViewModel.
    /// </summary>
    /// <param name="sender">
    ///  Source of the event.
    /// </param>
    /// <param name="e">
    /// DataGrid sorting event arguments.
    /// </param>
    private void PendingRequestsGrid_Sorting(object sender, DataGridSortingEventArgs e)
    {
        e.Handled = true;
        if (DataContext is PendingRequestQueueViewModel vm)
        {
            vm.SortBy(e.Column.SortMemberPath);
        }
    }

    /// <summary>
    /// Moves the sort arrow when the sort column or direction changes, also after Clear.
    /// </summary>
    /// <param name="sender">The request queue view model.</param>
    /// <param name="e">Name of the property that changed.</param>
    private void ViewModel_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(PendingRequestQueueViewModel.SortField)
            or nameof(PendingRequestQueueViewModel.IsSortAscending))
        {
            ShowSortArrow();
        }
    }

    /// <summary>
    /// Shows the sort arrow on the column the requests are sorted by and clears it on every other column.
    /// </summary>
    private void ShowSortArrow()
    {
        if (DataContext is not PendingRequestQueueViewModel viewModel)
        {
            return;
        }

        foreach (DataGridColumn column in PendingRequestsGrid.Columns)
        {
            if (column.SortMemberPath != viewModel.SortField)
            {
                column.SortDirection = null;
                continue;
            }

            column.SortDirection = viewModel.IsSortAscending
                ? ListSortDirection.Ascending
                : ListSortDirection.Descending;
        }
    }

    /// <summary>
    /// Sets the owner for modal dialogs when this window is on screen (unit tests may invoke handlers without showing the window).
    /// </summary>
    private void ApplyDialogOwner(Window dialog)
    {
        if (IsLoaded)
        {
            dialog.Owner = this;
        }
    }

    /// <summary>
    /// Collapses or expands the navigation panel.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    ///  Event arguments.
    /// </param>
    private void CollapseButton_Click(object sender, RoutedEventArgs e)
    {
        _isCollapsedAutomatically = false;
        SetSidebarCollapsed(!_isCollapsed);
    }

    /// <summary>
    /// Uses the compact layout (smaller header, lower rows, no footer) while the window is small, such as on the
    /// analyzer HMI panel. Collapses the side bar when the user drags the window narrower than the limit and expands it again when the window
    /// is dragged wide enough, so all columns of the request grid stay visible. A side bar the user collapsed is left alone.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnWindowSizeChanged(object sender, SizeChangedEventArgs e)
    {
        CompactLayout.SetIsCompact(this, CompactLayout.IsCompactSize(e.NewSize.Width, e.NewSize.Height));

        if (!e.WidthChanged || !_isUserDragging || WindowState != WindowState.Normal)
        {
            return;
        }

        if (e.NewSize.Width < AUTO_COLLAPSE_WIDTH && !_isCollapsed)
        {
            SetSidebarCollapsed(true);
            _isCollapsedAutomatically = true;
        }
        else if (e.NewSize.Width >= AUTO_COLLAPSE_WIDTH && _isCollapsed && _isCollapsedAutomatically)
        {
            SetSidebarCollapsed(false);
            _isCollapsedAutomatically = false;
        }
    }

    /// <summary>
    /// Starts to listen to the Windows messages that tell when the user begins and ends a drag of the window.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnSourceInitialized(object? sender, EventArgs e)
    {
        if (PresentationSource.FromVisual(this) is HwndSource source)
        {
            source.AddHook(WindowMessageHook);
        }
    }

    /// <summary>
    /// Remembers whether the user is dragging the window.
    /// </summary>
    private IntPtr WindowMessageHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WM_ENTERSIZEMOVE)
        {
            _isUserDragging = true;
        }
        else if (msg == WM_EXITSIZEMOVE)
        {
            _isUserDragging = false;
        }

        return IntPtr.Zero;
    }

    /// <summary>
    /// Restores the window to its normal size, centered, when it leaves the maximized state, and opens a side bar
    /// that a drag had collapsed. The size changes only by dragging after that.
    /// </summary>
    /// <param name="sender">
    /// Source of the event.
    /// </param>
    /// <param name="e">
    /// Event arguments.
    /// </param>
    private void OnWindowStateChanged(object? sender, EventArgs e)
    {
        if (_isCollapsedAutomatically && WindowState != WindowState.Minimized)
        {
            SetSidebarCollapsed(false);
            _isCollapsedAutomatically = false;
        }

        if (WindowState == WindowState.Normal && _previousWindowState == WindowState.Maximized)
        {
            Rect workArea = SystemParameters.WorkArea;
            Width = Math.Min(DEFAULT_WINDOW_WIDTH, workArea.Width);
            Height = Math.Min(DEFAULT_WINDOW_HEIGHT, workArea.Height);
            Left = workArea.Left + ((workArea.Width - Width) / 2);
            Top = workArea.Top + ((workArea.Height - Height) / 2);
        }

        _previousWindowState = WindowState;
    }

    /// <summary>
    /// Shows the side bar as icons only, or with its texts.
    /// </summary>
    /// <param name="collapsed">True to show icons only.</param>
    private void SetSidebarCollapsed(bool collapsed)
    {
        Visibility textVisibility = collapsed ? Visibility.Collapsed : Visibility.Visible;

        SideBarColumn.Width = new GridLength(collapsed ? COLLAPSED_SIDEBAR_WIDTH : EXPANDED_SIDEBAR_WIDTH);
        TitleText.Visibility = textVisibility;
        DashboardText.Visibility = textVisibility;
        TrustListText.Visibility = textVisibility;
        CertificateManagementText.Visibility = textVisibility;
        RequestQueueText.Visibility = textVisibility;
        RequestCountBadge.Visibility = textVisibility;
        CollapseGlyph.Text = collapsed ? UiConstants.NEXT_GLYPH : UiConstants.PREVIOUS_GLYPH;
        CollapseText.Visibility = textVisibility;
        _isCollapsed = collapsed;
    }

    #endregion
}
