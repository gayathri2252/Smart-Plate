using System.Windows.Threading;
using CertificateHandler.Data;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.UI.Services;

/// <summary>
/// Periodic peer notification delivery and certificate expiry sweep (RS_10, RS_25).
/// </summary>
public sealed class BackgroundMaintenanceService : IDisposable
{
    #region Member Variables

    private readonly NpgsqlDataSource _dataSource;

    private readonly DispatcherTimer _timer;

    private bool _running;

    #endregion

    #region Constructor

    public BackgroundMaintenanceService(NpgsqlDataSource dataSource, TimeSpan? interval = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _timer = new DispatcherTimer { Interval = interval ?? TimeSpan.FromMinutes(15) };
        _timer.Tick += OnTick;
    }

    #endregion

    #region Public Methods

    public void Start() => _timer.Start();

    public void Stop() => _timer.Stop();

    public void Dispose()
    {
        _timer.Stop();
        _timer.Tick -= OnTick;
    }

    #endregion

    #region Private Methods

    private async void OnTick(object? sender, EventArgs e)
    {
        if (_running)
        {
            return;
        }

        _running = true;
        try
        {
            int delivered = await new PeerNotificationDeliveryService(_dataSource).DeliverPendingAsync();
            if (delivered > 0)
            {
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), $"Background maintenance delivered {delivered} peer notification(s).");
            }

            int trustDelivered = await new TrustEventDeliveryService(_dataSource).DeliverPendingAsync();
            if (trustDelivered > 0)
            {
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), $"Background maintenance delivered {trustDelivered} trust event(s).");
            }

            await RunDailyExpirySweepAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), $"Background maintenance failed: {ex.Message}");
        }
        finally
        {
            _running = false;
        }
    }

    private async Task RunDailyExpirySweepAsync()
    {
        var reader = new CertificateExpiryReader(_dataSource);
        var monitor = new CertificateExpiryMonitorService(reader);
        var wef = new WefCertificateEventWriter();
        var certificates = await reader.ReadActiveLocalCertificatesAsync();
        foreach (var certificate in certificates)
        {
            _ = await monitor.GetDailyCheckStatusAsync(certificate.Thumbprint);
            if (certificate.NotAfter <= DateTimeOffset.UtcNow.AddDays(30))
            {
                wef.WriteExpiryAlert(certificate.Role.ToString(), certificate.Thumbprint, certificate.NotAfter);
            }
        }
    }

    #endregion
}
