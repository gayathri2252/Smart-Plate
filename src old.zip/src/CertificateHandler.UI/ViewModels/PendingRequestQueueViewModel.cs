﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Data.Security;
using CertificateHandler.Shared.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows;
using UiConstants = CertificateHandler.UI.Constants.Constants;
using CertificateHandler.Logger;
using CertificateHandler.UI.Integration;

namespace CertificateHandler.UI.ViewModels;

/// <summary>
/// ViewModel responsible for managing pending request
/// data and interactions for the Pending Request Queue screen.
/// </summary>
public class PendingRequestQueueViewModel : INotifyPropertyChanged
{
    #region Member Variables

    /// <summary>
    ///  Service used to retrieve and manage pending requests.
    /// </summary>
    private readonly IPendingRequestQueueService _pendingRequestQueueService;

    private readonly Func<string> _actorIdentityProvider;

    /// <summary>
    ///  Currently selected pending request.
    /// </summary>
    private PendingRequestItem? _selectedRequest;

    /// <summary>
    ///  Complete collection of pending requests.
    /// </summary>
    private List<PendingRequestItem> _allRequests = new();

    /// <summary>
    /// Active filter, sort and paging settings; sorting and paging always use these filters.
    /// </summary>
    private readonly PendingRequestQuery _query = new();

    /// <summary>
    /// Number of requests that match the search and the filters, on all pages together.
    /// </summary>
    private int _matchingCount;

    /// <summary>
    /// Number of requests in each status, shown on the status tabs.
    /// </summary>
    private RequestStatusCounts _statusCounts = new();

    /// <summary>
    /// Status tab that is shown: PENDING, APPROVED, REJECTED or EXPIRED.
    /// </summary>
    private string _selectedTab = UiConstants.PENDING_STATUS;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the
    /// PendingRequestQueueViewModel class.
    /// </summary>
    /// <param name="pendingRequestQueueService">
    /// Service used to retrieve and update pending requests.
    /// </param>
    public PendingRequestQueueViewModel(
        IPendingRequestQueueService pendingRequestQueueService,
        Func<string>? actorIdentityProvider = null)
    {
        _pendingRequestQueueService = pendingRequestQueueService;
        _actorIdentityProvider = actorIdentityProvider ?? (() => string.Empty);
        PendingRequests = new ObservableCollection<PendingRequestItem>();
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Collection of pending requests displayed in the UI.
    /// </summary>
    public ObservableCollection<PendingRequestItem>
        PendingRequests
    {
        get;
        private set;
    }

    /// <summary>
    /// Currently selected pending request.
    /// </summary>
    public PendingRequestItem? SelectedRequest
    {
        get => _selectedRequest;
        set
        {
            _selectedRequest = value;
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// Gets or sets the search text used to filter requests.
    /// </summary>
    public string SearchText
    {
        get => _query.SearchText;
        set
        {
            _query.SearchText = value;
            ApplyFilterChange();
        }
    }

    /// <summary>
    /// Gets or sets the status filter used to
    /// display pending requests matching the
    /// selected request status.
    /// </summary>
    public string SelectedStatus
    {
        get => _query.Status;
        set
        {
            _query.Status = value;
            ApplyFilterChange();
        }
    }

    /// <summary>
    ///  Gets or sets the start date filter.
    /// </summary>
    public DateTime? FromDate
    {
        get => _query.FromDate;
        set
        {
            _query.FromDate = value;
            ApplyFilterChange();
        }
    }

    /// <summary>
    /// Gets or sets the end date filter.
    /// </summary>
    public DateTime? ToDate
    {
        get => _query.ToDate;
        set
        {
            _query.ToDate = value;
            ApplyFilterChange();
        }
    }

    /// <summary>
    /// Gets or sets the MAXUM IP filter.
    /// </summary>
    public string MaxumIpFilter
    {
        get => _query.MaxumIp;
        set
        {
            _query.MaxumIp = value;
            ApplyFilterChange();
        }
    }

    /// <summary>
    /// Gets or sets the field used for sorting.
    /// </summary>
    public string SortField
    {
        get => _query.SortField;
        set
        {
            _query.SortField = value;
            ApplyFilters();
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// Gets the current page number.
    /// </summary>
    public int CurrentPage
    {
        get => _query.PageNumber;
    }

    /// <summary>
    /// Copy of the active filter, sort and paging settings.
    /// </summary>
    public PendingRequestQuery ActiveQuery => _query.Copy();

    /// <summary>
    /// Text under the table such as "Showing 11 to 20 of 25 entries"; "Showing 0 to 0 of 0 entries"
    /// when the current page has no requests.
    /// </summary>
    public string ShowingText
    {
        get
        {
            int shown = PendingRequests.Count;
            int first = shown == 0 ? 0 : ((_query.PageNumber - 1) * _query.PageSize) + 1;
            int last = shown == 0 ? 0 : first + shown - 1;

            return string.Format(CultureInfo.CurrentCulture, UiConstants.SHOWING_ENTRIES_FORMAT, first, last, _matchingCount);
        }
    }

    /// <summary>
    /// Gets or sets the number of records displayed per page.
    /// </summary>
    public int PageSize
    {
        get => _query.PageSize;
        set
        {
            // A page must hold at least one request, or the pages cannot be worked out.
            if (value < 1)
            {
                return;
            }

            _query.PageSize = value;
            _query.PageNumber = PendingRequestQuery.FIRST_PAGE_NUMBER;
            ApplyFilters();
            OnPropertyChanged();
            OnPropertyChanged(nameof(CurrentPage));
        }
    }

    /// <summary>
    /// Indicates whether pending requests are available.
    /// </summary>
    public bool HasPendingRequests => PendingRequests.Count > 0;

    /// <summary>
    /// Gets a value indicating whether the list is sorted ascending.
    /// </summary>
    public bool IsSortAscending => _query.SortAscending;

    /// <summary>
    /// Gets the total number of pending requests
    /// currently displayed in the collection.
    /// </summary>
    public int PendingRequestCount
    {
        get
        {
            return PendingRequests?.Count ?? 0;
        }
    }

    /// <summary>
    /// Number of pending requests on all pages, shown on the Pending tab and in the menu badge.
    /// </summary>
    public int PendingCount => IsPendingTabSelected ? _allRequests.Count : _statusCounts.Pending;

    /// <summary>
    /// Number of approved requests, shown on the Approved tab.
    /// </summary>
    public int ApprovedCount => _statusCounts.Approved;

    /// <summary>
    /// Number of rejected requests, shown on the Rejected tab.
    /// </summary>
    public int RejectedCount => _statusCounts.Rejected;

    /// <summary>
    /// Number of expired requests, shown on the Expired tab.
    /// </summary>
    public int ExpiredCount => _statusCounts.Expired;

    /// <summary>
    /// Status tab that is shown: PENDING, APPROVED, REJECTED or EXPIRED.
    /// </summary>
    public string SelectedTab => _selectedTab;

    /// <summary>
    /// True while the Pending tab is shown; only pending requests can be approved or rejected.
    /// </summary>
    public bool IsPendingTabSelected
    {
        get => _selectedTab == UiConstants.PENDING_STATUS;
        set { if (value) ShowStatus(UiConstants.PENDING_STATUS); }
    }

    /// <summary>
    /// True while the Approved tab is shown.
    /// </summary>
    public bool IsApprovedTabSelected
    {
        get => _selectedTab == UiConstants.APPROVED_STATUS;
        set { if (value) ShowStatus(UiConstants.APPROVED_STATUS); }
    }

    /// <summary>
    /// True while the Rejected tab is shown.
    /// </summary>
    public bool IsRejectedTabSelected
    {
        get => _selectedTab == UiConstants.REJECTED_STATUS;
        set { if (value) ShowStatus(UiConstants.REJECTED_STATUS); }
    }

    /// <summary>
    /// True while the Expired tab is shown.
    /// </summary>
    public bool IsExpiredTabSelected
    {
        get => _selectedTab == UiConstants.EXPIRED_STATUS;
        set { if (value) ShowStatus(UiConstants.EXPIRED_STATUS); }
    }

    /// <summary>
    /// Text shown when the selected tab has no requests.
    /// </summary>
    public string EmptyListText => _selectedTab switch
    {
        UiConstants.APPROVED_STATUS => UiConstants.NO_APPROVED_REQUESTS_AVAILABLE,
        UiConstants.REJECTED_STATUS => UiConstants.NO_REJECTED_REQUESTS_AVAILABLE,
        UiConstants.EXPIRED_STATUS => UiConstants.NO_EXPIRED_REQUESTS_AVAILABLE,
        _ => UiConstants.NO_PENDING_REQUESTS_AVAILABLE
    };

    #endregion

    #region Public Methods

    /// <summary>
    /// Loads pending requests from the service and refreshes the counts on the status tabs.
    /// </summary>
    public void LoadPendingRequests()
    {
        _allRequests =
            (IsPendingTabSelected
                ? _pendingRequestQueueService.GetPendingRequests()
                : _pendingRequestQueueService.GetRequestsByStatus(_selectedTab) ?? Enumerable.Empty<PendingRequestItem>())
            .ToList();

        LoadStatusCounts();
        ApplyFilters();
    }

    /// <summary>
    /// Shows the requests of the given status tab, starting on the first page.
    /// </summary>
    /// <param name="status">PENDING, APPROVED, REJECTED or EXPIRED.</param>
    public void ShowStatus(string status)
    {
        if (string.Equals(_selectedTab, status, StringComparison.Ordinal))
        {
            return;
        }

        _selectedTab = status;
        _query.PageNumber = PendingRequestQuery.FIRST_PAGE_NUMBER;

        try
        {
            LoadPendingRequests();
        }
        catch (Exception ex)
        {
            _allRequests = new List<PendingRequestItem>();
            ApplyFilters();
            MessageBox.Show(ex.Message);
        }

        OnPropertyChanged(nameof(SelectedTab));
        OnPropertyChanged(nameof(IsPendingTabSelected));
        OnPropertyChanged(nameof(IsApprovedTabSelected));
        OnPropertyChanged(nameof(IsRejectedTabSelected));
        OnPropertyChanged(nameof(IsExpiredTabSelected));
        OnPropertyChanged(nameof(EmptyListText));
        OnPropertyChanged(nameof(PendingCount));
        OnPropertyChanged(nameof(CurrentPage));
    }

    /// <summary>
    /// Refreshes the queue after a request approval.
    /// </summary>
    public void RefreshAfterApproval()
    {
        LoadPendingRequests();
    }

    /// <summary>
    /// Refreshes the queue after a request rejection.
    /// </summary>
    public void RefreshAfterRejection()
    {
        LoadPendingRequests();
    }

    /// <summary>
    /// Moves to the next page of pending requests.
    /// </summary>
    public void NextPage()
    {
        _query.PageNumber++;
        ApplyFilters();
        OnPropertyChanged(nameof(CurrentPage));
    }

    /// <summary>
    /// Moves to the previous page of pending requests.
    /// </summary>
    public void PreviousPage()
    {
        if (_query.PageNumber > PendingRequestQuery.FIRST_PAGE_NUMBER)
        {
            _query.PageNumber--;
            ApplyFilters();
            OnPropertyChanged(nameof(CurrentPage));
        }
    }

    /// <summary>
    /// Sorts by the given field: a click on the field that is already used reverses the direction,
    /// a click on another field sorts that field ascending.
    /// </summary>
    /// <param name="field">Name of the field to sort by.</param>
    public void SortBy(string field)
    {
        if (string.Equals(_query.SortField, field, StringComparison.Ordinal))
        {
            ToggleSort();
            return;
        }

        _query.SortAscending = true;
        SortField = field;
        OnPropertyChanged(nameof(IsSortAscending));
    }

    /// <summary>
    ///  Toggles the sorting direction and refreshes
    ///  the displayed request collection.
    /// </summary>
    public void ToggleSort()
    {
        _query.SortAscending = !_query.SortAscending;
        ApplyFilters();
        OnPropertyChanged(nameof(IsSortAscending));
    }

    /// <summary>
    ///  Clears all applied filters and restores
    ///  default values.
    /// </summary>
    public void ClearFilters()
    {
        SearchText = string.Empty;
        SelectedStatus = RequestStatusConstants.ALL;
        FromDate = null;
        ToDate = null;
        MaxumIpFilter = string.Empty;
        _query.SortAscending = true;
        SortField = RequestStatusConstants.REQUEST_DATE_FIELD;
        _query.PageNumber = PendingRequestQuery.FIRST_PAGE_NUMBER;
        ApplyFilters();
        OnPropertyChanged(nameof(CurrentPage));
        OnPropertyChanged(nameof(IsSortAscending));
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_FILTERS_CLEARED);
    }

    /// <summary>
    /// Refreshes the request list using the
    /// currently selected filters.
    /// </summary>
    public void RefreshFilters()
    {
        ApplyFilters();
        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            UiConstants.LOG_FILTERS_APPLIED,
            SelectedStatus,
            FromDate?.ToString(UiConstants.DATE_TIME_FORMAT, CultureInfo.InvariantCulture) ?? UiConstants.LOG_EMPTY_VALUE,
            ToDate?.ToString(UiConstants.DATE_TIME_FORMAT, CultureInfo.InvariantCulture) ?? UiConstants.LOG_EMPTY_VALUE,
            string.IsNullOrWhiteSpace(MaxumIpFilter) ? UiConstants.LOG_EMPTY_VALUE : MaxumIpFilter);
    }

    /// <summary>
    /// Approves the currently selected request and
    /// removes it from the pending list.
    /// </summary>
    public void ApproveSelectedRequest()
    {
        try
        {
            // Only a pending request can be decided; the other tabs only show requests.
            if (SelectedRequest == null || !IsPendingTabSelected)
            {
                return;
            }
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_APPROVE_CLICKED, SelectedRequest.RequestId, SelectedRequest.DeviceIdentifier);
            _pendingRequestQueueService.ApproveRequest(BuildDecision(SelectedRequest.RequestId, null));
            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), UiConstants.LOG_APPROVE_DONE, SelectedRequest.RequestId);
            RefreshAfterApproval();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_APPROVE_FAILED, SelectedRequest?.RequestId ?? UiConstants.LOG_EMPTY_VALUE, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    /// <summary>
    /// Rejects the currently selected request and
    /// removes it from the pending list.
    /// </summary>
    public void RejectSelectedRequest(string? reason = null)
    {
        try
        {
            // Only a pending request can be decided; the other tabs only show requests.
            if (SelectedRequest == null || !IsPendingTabSelected)
            {
                return;
            }

            try
            {
                DecisionReasonPolicy.ValidateOrThrow(reason);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_REJECT_CLICKED, SelectedRequest.RequestId, SelectedRequest.DeviceIdentifier);
            _pendingRequestQueueService.RejectRequest(BuildDecision(SelectedRequest.RequestId, reason!.Trim()));
            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), UiConstants.LOG_REJECT_DONE, SelectedRequest.RequestId);
            RefreshAfterRejection();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_REJECT_FAILED, SelectedRequest?.RequestId ?? UiConstants.LOG_EMPTY_VALUE, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    /// <summary>
    /// Applies the current sorting and filtering
    /// criteria to the pending request collection.
    /// </summary>
    public void ApplySortAndFilters()
    {
        ApplyFilters();
    }

    #endregion

    #region Private Methods

    private PendingRequestDecision BuildDecision(string requestId, string? reason)
    {
        if (MccTrustSession.IsActive && string.IsNullOrWhiteSpace(MccTrustProof.ActorIdentity))
        {
            throw new InvalidOperationException(
                "MCC trust actions require a Keycloak MCC Administrator and the SBC local administrator credentials.");
        }

        string actor = string.IsNullOrWhiteSpace(MccTrustProof.ActorIdentity)
            ? _actorIdentityProvider()?.Trim() ?? string.Empty
            : MccTrustProof.ActorIdentity;
        if (string.IsNullOrEmpty(actor))
        {
            throw new InvalidOperationException("A signed-in administrator identity is required for this decision.");
        }

        return new PendingRequestDecision
        {
            RequestId = requestId,
            ActorIdentity = actor,
            Reason = reason,
            ApprovalChannel = string.IsNullOrWhiteSpace(MccTrustProof.ActorIdentity)
                ? TrustApprovalChannels.HmiLocal
                : TrustApprovalChannels.Mcc
        };
    }

    /// <summary>
    /// Reads the number of requests in each status. When the counts cannot be read, the tabs keep
    /// their last values, so the request list still loads.
    /// </summary>
    private void LoadStatusCounts()
    {
        try
        {
            _statusCounts = _pendingRequestQueueService.GetRequestStatusCounts() ?? _statusCounts;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.STATUS_COUNTS_LOAD_FAILED, ex.Message);
        }

        OnPropertyChanged(nameof(PendingCount));
        OnPropertyChanged(nameof(ApprovedCount));
        OnPropertyChanged(nameof(RejectedCount));
        OnPropertyChanged(nameof(ExpiredCount));
    }

    /// <summary>
    /// Shows the first page after a filter changed, so the page never points past the filtered
    /// requests, then refreshes the list.
    /// </summary>
    /// <param name="propertyName">Name of the filter property that changed.</param>
    private void ApplyFilterChange([CallerMemberName] string propertyName = "")
    {
        _query.PageNumber = PendingRequestQuery.FIRST_PAGE_NUMBER;
        ApplyFilters();
        OnPropertyChanged(propertyName);
        OnPropertyChanged(nameof(CurrentPage));
    }

    /// <summary>
    /// Applies search, filter, sorting, and pagination
    /// to the pending request collection.
    /// </summary>
    private void ApplyFilters()
    {
        IEnumerable<PendingRequestItem> requests = SortRequests(FilterRequests(_allRequests));

        ApplyPagination(requests);
        OnPropertyChanged(nameof(HasPendingRequests));
    }

    /// <summary>
    /// Keeps the requests that match the search text, the status, the MAXUM IP and the date range.
    /// </summary>
    /// <param name="requests">Requests to filter.</param>
    /// <returns>The requests that match every filter that is set.</returns>
    private IEnumerable<PendingRequestItem> FilterRequests(IEnumerable<PendingRequestItem> requests)
    {
        if (!string.IsNullOrWhiteSpace(SearchText))
        {
            requests = requests.Where(x => MatchesSearchText(x, SearchText));
        }

        if (!string.IsNullOrWhiteSpace(SelectedStatus) && SelectedStatus != RequestStatusConstants.ALL)
        {
            requests = requests.Where(x => x.CurrentStatus.Equals(SelectedStatus, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(MaxumIpFilter))
        {
            requests = requests.Where(x =>
                !string.IsNullOrEmpty(x.MaxumIpAddress) &&
                x.MaxumIpAddress.Contains(MaxumIpFilter, StringComparison.OrdinalIgnoreCase));
        }

        if (FromDate.HasValue)
        {
            requests = requests.Where(x => x.RequestDate >= FromDate.Value);
        }

        if (ToDate.HasValue)
        {
            requests = requests.Where(x => x.RequestDate <= ToDate.Value);
        }

        return requests;
    }

    /// <summary>
    /// Orders the requests by the selected sort field; any other field sorts by request date.
    /// </summary>
    /// <param name="requests">Requests to order.</param>
    /// <returns>The requests in the chosen order.</returns>
    private IEnumerable<PendingRequestItem> SortRequests(IEnumerable<PendingRequestItem> requests)
    {
        return SortField switch
        {
            RequestStatusConstants.REQUEST_ID_FIELD => OrderRequests(requests, x => x.RequestId),
            RequestStatusConstants.REQUESTER_IDENTITY_FIELD => OrderRequests(requests, x => x.RequesterIdentity),
            RequestStatusConstants.REQUEST_TYPE_FIELD => OrderRequests(requests, x => x.RequestType),
            RequestStatusConstants.DEVICE_IDENTIFIER_FIELD => OrderRequests(requests, x => x.DeviceIdentifier),
            RequestStatusConstants.REQUESTED_BY_FIELD => OrderRequests(requests, x => x.RequestedBy),
            RequestStatusConstants.CURRENT_STATUS_FIELD => OrderRequests(requests, x => x.CurrentStatus),
            RequestStatusConstants.MAXUM_IP_ADDRESS_FIELD => OrderRequests(requests, x => x.MaxumIpAddress),
            _ => OrderRequests(requests, x => x.RequestDate)
        };
    }

    /// <summary>
    /// Orders the requests by the given key, ascending or descending as selected.
    /// </summary>
    /// <typeparam name="TKey">Type of the value to order by.</typeparam>
    /// <param name="requests">Requests to order.</param>
    /// <param name="key">Value to order by.</param>
    /// <returns>The ordered requests.</returns>
    private IEnumerable<PendingRequestItem> OrderRequests<TKey>(
        IEnumerable<PendingRequestItem> requests,
        Func<PendingRequestItem, TKey> key)
    {
        return _query.SortAscending ? requests.OrderBy(key) : requests.OrderByDescending(key);
    }

    /// <summary>
    ///  Applies pagination to the filtered
    ///  request collection.
    /// </summary>
    /// <param name="requests">
    /// Collection of requests to paginate.
    /// </param>
    private void ApplyPagination(IEnumerable<PendingRequestItem> requests)
    {
        List<PendingRequestItem> matching = requests.ToList();
        _matchingCount = matching.Count;

        var pageData = matching.Skip((_query.PageNumber - 1) * _query.PageSize).Take(_query.PageSize);
        PendingRequests.Clear();
        foreach (var request in pageData)
        {
            PendingRequests.Add(request);
        }

        OnPropertyChanged(nameof(ShowingText));
    }

    /// <summary>
    /// Raises the PropertyChanged event.
    /// </summary>
    /// <param name="propertyName">
    /// Name of the changed property.
    /// </param>
    private void OnPropertyChanged([CallerMemberName] string propertyName = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    /// <summary>
    /// Determines whether the specified search text matches any
    /// searchable field of a pending request, including request
    /// details, user information, MAXUM IP address, or supported
    /// request date formats.
    /// </summary>
    /// <param name="request">
    ///  Pending request item to evaluate.
    /// </param>
    /// <param name="searchText">
    ///  Search text used to match request properties.
    /// </param>
    /// <returns>
    /// True if the search text matches any request field;
    /// otherwise, false.
    /// </returns>
    private static bool MatchesSearchText(PendingRequestItem request, string searchText)
    {
        return
            (!string.IsNullOrEmpty(request.RequestId) &&
             request.RequestId.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.DeviceIdentifier) &&
             request.DeviceIdentifier.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.RequestType) &&
             request.RequestType.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.RequesterIdentity) &&
             request.RequesterIdentity.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.RequestedBy) &&
             request.RequestedBy.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.MaxumIpAddress) &&
             request.MaxumIpAddress.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.CurrentStatus) &&
             request.CurrentStatus.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            (!string.IsNullOrEmpty(request.CertificateSubject) &&
             request.CertificateSubject.Contains(
                 searchText,
                 StringComparison.OrdinalIgnoreCase))

            ||

            request.RequestDate
                .ToString(RequestStatusConstants.DATE_TIME_FORMAT_ISO, CultureInfo.InvariantCulture)
                .Contains(searchText);
    }

    #endregion

    #region Events

    /// <summary>
    /// Occurs when a property value changes.
    /// </summary>
    public event PropertyChangedEventHandler? PropertyChanged;

    #endregion
}