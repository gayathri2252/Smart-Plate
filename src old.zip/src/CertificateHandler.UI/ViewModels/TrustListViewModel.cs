﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.UI.Commands;
using CertificateHandler.UI.Integration;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.ViewModels;

/// <summary>
/// Holds the active whitelist and blacklist entries for the Whitelist / Blacklist page. A load runs the
/// trust list query once; switching the tab, searching and paging work on the loaded entries without a new
/// query. Only a device administrator gets any rows; for anyone else nothing is queried.
/// </summary>
public sealed class TrustListViewModel : INotifyPropertyChanged
{
    #region Member Variables

    /// <summary>Query that reads the active whitelist and blacklist entries.</summary>
    private readonly ICertificateDashboard _certificateDashboard;

    /// <summary>User the page is shown to; null when no one is signed in.</summary>
    private readonly SignedInUser? _signedInUser;

    private readonly ICertificateBlackList? _certificateBlackList;

    private readonly IReinstatementWorkflowService? _reinstatementWorkflow;

    private readonly IBulkBlacklistService? _bulkBlacklistService;

    private readonly CertificateValidationEngine? _validationEngine;

    private readonly Func<string> _actorIdentityProvider;

    private DashboardTrustListRow? _selectedEntry;

    /// <summary>Active whitelist entries of the last load, newest first.</summary>
    private IReadOnlyList<DashboardTrustListRow> _whitelisted = Array.Empty<DashboardTrustListRow>();

    /// <summary>Active blacklist entries of the last load, newest first.</summary>
    private IReadOnlyList<DashboardTrustListRow> _blacklisted = Array.Empty<DashboardTrustListRow>();

    /// <summary>List shown in the table.</summary>
    private TrustListKind _selectedList = TrustListKind.Whitelist;

    /// <summary>Text the shown list is filtered by; empty shows every entry.</summary>
    private string _searchText = string.Empty;

    /// <summary>True while a load is running.</summary>
    private bool _isLoading;

    /// <summary>Message shown when the last load failed; empty otherwise.</summary>
    private string _errorMessage = string.Empty;

    /// <summary>Counter that lets a newer load replace the result of an older one.</summary>
    private int _loadVersion;

    /// <summary>Compares names and IP addresses with their numbers in number order.</summary>
    private static readonly IComparer<string> NaturalComparer = Comparer<string>.Create(CompareNatural);

    /// <summary>Column the entries are sorted by; newest first until the user picks another column.</summary>
    private string _sortColumn = nameof(DashboardTrustListRow.AddedAt);

    /// <summary>True to sort from low to high.</summary>
    private bool _sortAscending;

    /// <summary>Entries of the selected list that match the search text, newest first; the table shows one page of them.</summary>
    private List<DashboardTrustListRow> _matchingItems = new();

    /// <summary>Number of the page shown in the table, starting at 1.</summary>
    private int _pageNumber = FIRST_PAGE_NUMBER;

    /// <summary>Maximum number of entries on a page.</summary>
    private int _pageSize = DEFAULT_PAGE_SIZE;

    /// <summary>Number of the first page.</summary>
    private const int FIRST_PAGE_NUMBER = 1;

    /// <summary>Number of entries on a page until the user picks another page size.</summary>
    private const int DEFAULT_PAGE_SIZE = 10;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view model on top of the trust list query for the given user. The query must not be
    /// null. A null user is treated as a user who is not authorized.
    /// </summary>
    public TrustListViewModel(
        ICertificateDashboard certificateDashboard,
        SignedInUser? signedInUser,
        ICertificateBlackList? certificateBlackList = null,
        IReinstatementWorkflowService? reinstatementWorkflow = null,
        IBulkBlacklistService? bulkBlacklistService = null,
        CertificateValidationEngine? validationEngine = null,
        Func<string>? actorIdentityProvider = null)
    {
        // Without the query the page cannot load anything.
        if (certificateDashboard is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_QUERY_IS_NULL);
            throw new ArgumentNullException(nameof(certificateDashboard));
        }

        _certificateDashboard = certificateDashboard;
        _signedInUser = signedInUser;
        _certificateBlackList = certificateBlackList;
        _reinstatementWorkflow = reinstatementWorkflow;
        _bulkBlacklistService = bulkBlacklistService;
        _validationEngine = validationEngine;
        _actorIdentityProvider = actorIdentityProvider ?? (() => signedInUser?.UserName ?? string.Empty);
        VisibleItems = new ObservableCollection<DashboardTrustListRow>();
        MoveToBlacklistCommand = new RelayCommand(
            () => MoveSelectedToBlacklistAsync(null).GetAwaiter().GetResult(),
            CanMutateTrustList);
        ReinstateCommand = new RelayCommand(
            () => ReinstateSelectedAsync().GetAwaiter().GetResult(),
            CanReinstate);
    }

    #endregion

    #region ICommands

    public ICommand MoveToBlacklistCommand { get; }

    public ICommand ReinstateCommand { get; }

    #endregion

    #region Public Properties

    public DashboardTrustListRow? SelectedEntry
    {
        get => _selectedEntry;
        set
        {
            _selectedEntry = value;
            OnPropertyChanged();
            (MoveToBlacklistCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (ReinstateCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }
    }

    /// <summary>
    /// Entries of the selected list that match the search text and are on the current page, newest first.
    /// </summary>
    public ObservableCollection<DashboardTrustListRow> VisibleItems { get; }

    /// <summary>
    /// Number of entries of the selected list that match the search text, on all pages together.
    /// </summary>
    public int MatchingCount => _matchingItems.Count;

    /// <summary>
    /// Number of the page shown in the table, starting at 1.
    /// </summary>
    public int PageNumber
    {
        get => _pageNumber;
        private set => SetField(ref _pageNumber, value);
    }

    /// <summary>
    /// Maximum number of entries on a page.
    /// </summary>
    public int PageSize
    {
        get => _pageSize;
        private set => SetField(ref _pageSize, value);
    }

    /// <summary>
    /// Number of pages of matching entries; at least 1, so an empty list still shows page 1.
    /// </summary>
    public int TotalPages => Math.Max(FIRST_PAGE_NUMBER, (MatchingCount + PageSize - 1) / PageSize);

    /// <summary>
    /// True when there is a page before the current one.
    /// </summary>
    public bool CanGoToPreviousPage => PageNumber > FIRST_PAGE_NUMBER;

    /// <summary>
    /// True when there is a page after the current one.
    /// </summary>
    public bool CanGoToNextPage => PageNumber < TotalPages;

    /// <summary>
    /// Text under the table such as "Showing 1 to 10 of 25 entries"; "Showing 0 to 0 of 0 entries" when
    /// nothing matches.
    /// </summary>
    public string ShowingText
    {
        get
        {
            int first = MatchingCount == 0 ? 0 : ((PageNumber - 1) * PageSize) + 1;
            int last = Math.Min(PageNumber * PageSize, MatchingCount);

            return string.Format(UiConstants.SHOWING_ENTRIES_FORMAT, first, last, MatchingCount);
        }
    }

    /// <summary>Column the entries are sorted by, as the column's sort name.</summary>
    public string SortColumn
    {
        get => _sortColumn;
        private set => SetField(ref _sortColumn, value);
    }

    /// <summary>True when the entries are sorted from low to high.</summary>
    public bool IsSortAscending
    {
        get => _sortAscending;
        private set => SetField(ref _sortAscending, value);
    }

    /// <summary>
    /// True when the signed-in user has the device-administrator role, so the lists may be loaded.
    /// </summary>
    public bool IsDeviceAdministrator => _signedInUser?.IsDeviceAdministrator == true;

    /// <summary>
    /// Number of active whitelist entries, shown on the whitelist tab.
    /// </summary>
    public int WhitelistCount => _whitelisted.Count;

    /// <summary>
    /// Number of active blacklist entries, shown on the blacklist tab.
    /// </summary>
    public int BlacklistCount => _blacklisted.Count;

    /// <summary>
    /// List shown in the table.
    /// </summary>
    public TrustListKind SelectedList
    {
        get => _selectedList;
        private set => SetField(ref _selectedList, value);
    }

    /// <summary>
    /// True while the whitelist tab is selected.
    /// </summary>
    public bool IsWhitelistSelected => SelectedList == TrustListKind.Whitelist;

    /// <summary>
    /// True while the blacklist tab is selected.
    /// </summary>
    public bool IsBlacklistSelected => SelectedList == TrustListKind.Blacklist;

    /// <summary>
    /// Status shown in each row of the table: Whitelisted or Blacklisted.
    /// </summary>
    public string StatusText => IsWhitelistSelected ? UiConstants.WHITELISTED : UiConstants.BLACKLISTED;

    /// <summary>
    /// Text the shown list is filtered by; empty shows every entry.
    /// </summary>
    public string SearchText
    {
        get => _searchText;
        private set => SetField(ref _searchText, value);
    }

    /// <summary>
    /// True when the table shows at least one entry.
    /// </summary>
    public bool HasVisibleItems => VisibleItems.Count > 0;

    /// <summary>
    /// Fixed message for an empty table: one text per list, and another when the search hides every entry.
    /// </summary>
    public string EmptyMessage
    {
        get
        {
            if (!string.IsNullOrEmpty(SearchText))
            {
                return UiConstants.NO_MATCHING_TRUST_ITEMS;
            }

            return IsWhitelistSelected ? UiConstants.NO_WHITELISTED_ITEMS : UiConstants.NO_BLACKLISTED_ITEMS;
        }
    }

    /// <summary>
    /// True while the trust list query runs.
    /// </summary>
    public bool IsLoading
    {
        get => _isLoading;
        private set => SetField(ref _isLoading, value);
    }

    /// <summary>
    /// Message shown when the last load failed; empty when it succeeded.
    /// </summary>
    public string ErrorMessage
    {
        get => _errorMessage;
        private set => SetField(ref _errorMessage, value);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Loads the active whitelist and blacklist entries. When the signed-in user is not a device
    /// administrator nothing is queried and no rows are shown. A failed load is logged and shown in
    /// ErrorMessage, and the earlier entries stay; cancellation is passed on.
    /// </summary>
    public async Task LoadAsync(CancellationToken cancellationToken = default)
    {
        int version = Interlocked.Increment(ref _loadVersion);

        // Only a device administrator may see the trust state, so no query runs for anyone else.
        if (!IsDeviceAdministrator)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                UiConstants.TRUST_LISTS_NOT_AUTHORIZED,
                _signedInUser?.UserName ?? UiConstants.NO_SIGNED_IN_USER);
            ShowLists(null);
            ErrorMessage = string.Empty;
            IsLoading = false;
            return;
        }

        IsLoading = true;
        ErrorMessage = string.Empty;

        try
        {
            DashboardTrustLists? trustLists = await _certificateDashboard.GetTrustListsAsync(cancellationToken);

            // A newer load owns the page now, so this older result must not overwrite it.
            if (version == Volatile.Read(ref _loadVersion))
            {
                ShowLists(trustLists);
            }
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LISTS_LOAD_FAILED, ex.Message);

            if (version == Volatile.Read(ref _loadVersion))
            {
                ErrorMessage = UiConstants.TRUST_LISTS_LOAD_FAILED_FOR_USER;
            }
        }
        finally
        {
            if (version == Volatile.Read(ref _loadVersion))
            {
                IsLoading = false;
            }
        }
    }

    /// <summary>
    /// Shows the first page of the given list in the table, keeping the search text.
    /// </summary>
    public void SelectList(TrustListKind list)
    {
        SelectedList = list;
        OnPropertyChanged(nameof(IsWhitelistSelected));
        OnPropertyChanged(nameof(IsBlacklistSelected));
        OnPropertyChanged(nameof(StatusText));
        PageNumber = FIRST_PAGE_NUMBER;
        RefreshVisibleItems();
    }

    /// <summary>
    /// Filters the shown list by the given text and shows the first page of the result. The text is matched,
    /// ignoring case, against the device name, the IP address, the certificate subject and the thumbprint.
    /// Empty or null text shows every entry.
    /// </summary>
    public void ApplySearch(string? searchText)
    {
        SearchText = searchText?.Trim() ?? string.Empty;
        PageNumber = FIRST_PAGE_NUMBER;
        RefreshVisibleItems();
    }

    /// <summary>
    /// Shows the next page; does nothing on the last page.
    /// </summary>
    public void GoToNextPage()
    {
        if (CanGoToNextPage)
        {
            PageNumber++;
            RefreshVisibleItems();
        }
    }

    /// <summary>
    /// Shows the previous page; does nothing on the first page.
    /// </summary>
    public void GoToPreviousPage()
    {
        if (CanGoToPreviousPage)
        {
            PageNumber--;
            RefreshVisibleItems();
        }
    }

    /// <summary>
    /// Changes the number of entries on a page and shows the first page. A size below 1 is ignored.
    /// </summary>
    public void ChangePageSize(int pageSize)
    {
        // A page must hold at least one entry, or the page count cannot be worked out.
        if (pageSize < 1)
        {
            return;
        }

        PageSize = pageSize;
        PageNumber = FIRST_PAGE_NUMBER;
        RefreshVisibleItems();
    }

    /// <summary>
    /// Sorts the entries of both lists by the given column and shows the first page. Choosing the sorted
    /// column again reverses the order; another column starts from low to high. An empty name is ignored.
    /// </summary>
    /// <param name="column">Sort name of the column, such as DeviceIdentifier or AddedAt.</param>
    public void SortBy(string? column)
    {
        if (string.IsNullOrWhiteSpace(column))
        {
            return;
        }

        if (string.Equals(column, SortColumn, StringComparison.Ordinal))
        {
            IsSortAscending = !IsSortAscending;
        }
        else
        {
            IsSortAscending = true;
            SortColumn = column;
        }

        PageNumber = FIRST_PAGE_NUMBER;
        RefreshVisibleItems();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Keeps the loaded entries and refreshes the table. A null result shows no entries.
    /// </summary>
    private void ShowLists(DashboardTrustLists? trustLists)
    {
        _whitelisted = trustLists?.Whitelisted ?? Array.Empty<DashboardTrustListRow>();
        _blacklisted = trustLists?.Blacklisted ?? Array.Empty<DashboardTrustListRow>();

        OnPropertyChanged(nameof(WhitelistCount));
        OnPropertyChanged(nameof(BlacklistCount));
        RefreshVisibleItems();
    }

    /// <summary>
    /// Orders the entries by the sort column: Added On by date, every other column by its text.
    /// </summary>
    /// <param name="rows">Entries to order.</param>
    /// <returns>The entries in the chosen order.</returns>
    private IEnumerable<DashboardTrustListRow> Sort(IEnumerable<DashboardTrustListRow> rows)
    {
        IOrderedEnumerable<DashboardTrustListRow> ordered;
        if (SortColumn == nameof(DashboardTrustListRow.AddedAt))
        {
            ordered = IsSortAscending
                ? rows.OrderBy(row => row.AddedAt)
                : rows.OrderByDescending(row => row.AddedAt);
            return ordered.ThenBy(row => row.DeviceIdentifier, NaturalComparer);
        }

        Func<DashboardTrustListRow, string> key = SortColumn switch
        {
            nameof(DashboardTrustListRow.MaxumIp) => row => row.MaxumIp,
            nameof(DashboardTrustListRow.Subject) => row => row.Subject,
            nameof(DashboardTrustListRow.AddedBy) => row => row.AddedBy,
            _ => row => row.DeviceIdentifier
        };

        ordered = IsSortAscending
            ? rows.OrderBy(key, NaturalComparer)
            : rows.OrderByDescending(key, NaturalComparer);

        // Entries with the same value are shown newest first, then by device name, so the order never looks random.
        return ordered
            .ThenByDescending(row => row.AddedAt)
            .ThenBy(row => row.DeviceIdentifier, NaturalComparer);
    }

    /// <summary>
    /// Compares two texts the way a person reads them: runs of digits are compared as numbers, so
    /// "Device-2" comes before "Device-10" and "10.250.1.7" before "10.250.1.10". Letters are compared
    /// without regard to case.
    /// </summary>
    /// <param name="left">First text; null counts as empty.</param>
    /// <param name="right">Second text; null counts as empty.</param>
    /// <returns>Less than zero when left comes first, zero when equal, more than zero when right comes first.</returns>
    private static int CompareNatural(string? left, string? right)
    {
        left ??= string.Empty;
        right ??= string.Empty;
        int i = 0;
        int j = 0;

        while (i < left.Length && j < right.Length)
        {
            int result = char.IsDigit(left[i]) && char.IsDigit(right[j])
                ? CompareDigitRuns(left, ref i, right, ref j)
                : CompareLetters(left, ref i, right, ref j);

            if (result != 0)
            {
                return result;
            }
        }

        return (left.Length - i).CompareTo(right.Length - j);
    }

    /// <summary>
    /// Compares the runs of digits that start at i and j as numbers and moves both positions past them.
    /// </summary>
    /// <param name="left">First text.</param>
    /// <param name="i">Position in the first text; moved past its run of digits.</param>
    /// <param name="right">Second text.</param>
    /// <param name="j">Position in the second text; moved past its run of digits.</param>
    /// <returns>Less than zero when left comes first, zero when equal, more than zero when right comes first.</returns>
    private static int CompareDigitRuns(string left, ref int i, string right, ref int j)
    {
        int leftStart = i;
        int rightStart = j;
        i = EndOfDigits(left, i);
        j = EndOfDigits(right, j);

        // Leading zeros do not change the value, so they are skipped before comparing.
        string leftNumber = left[leftStart..i].TrimStart('0');
        string rightNumber = right[rightStart..j].TrimStart('0');

        return leftNumber.Length != rightNumber.Length
            ? leftNumber.Length.CompareTo(rightNumber.Length)
            : string.CompareOrdinal(leftNumber, rightNumber);
    }

    /// <summary>
    /// Compares the characters at i and j without regard to case and moves both positions one step.
    /// </summary>
    /// <param name="left">First text.</param>
    /// <param name="i">Position in the first text; moved one step.</param>
    /// <param name="right">Second text.</param>
    /// <param name="j">Position in the second text; moved one step.</param>
    /// <returns>Less than zero when left comes first, zero when equal, more than zero when right comes first.</returns>
    private static int CompareLetters(string left, ref int i, string right, ref int j)
    {
        int result = string.Compare(left[i].ToString(), right[j].ToString(), StringComparison.CurrentCultureIgnoreCase);
        i++;
        j++;
        return result;
    }

    /// <summary>
    /// Returns the position just after the run of digits that starts at the given position.
    /// </summary>
    /// <param name="text">Text to look in.</param>
    /// <param name="start">Position of the first digit.</param>
    /// <returns>Position of the first character after the digits, or the text length.</returns>
    private static int EndOfDigits(string text, int start)
    {
        int end = start;
        while (end < text.Length && char.IsDigit(text[end]))
        {
            end++;
        }

        return end;
    }

    /// <summary>
    /// Fills the table with the current page of the entries of the selected list that match the search
    /// text. When the list became shorter, the last page that still has entries is shown.
    /// </summary>
    private void RefreshVisibleItems()
    {
        IReadOnlyList<DashboardTrustListRow> source = IsWhitelistSelected ? _whitelisted : _blacklisted;
        _matchingItems = Sort(source.Where(row => Matches(row, SearchText))).ToList();

        // After a reload the list can be shorter than before, so the page must still exist.
        if (PageNumber > TotalPages)
        {
            PageNumber = TotalPages;
        }

        VisibleItems.Clear();

        foreach (DashboardTrustListRow row in _matchingItems.Skip((PageNumber - 1) * PageSize).Take(PageSize))
        {
            VisibleItems.Add(row);
        }

        OnPropertyChanged(nameof(HasVisibleItems));
        OnPropertyChanged(nameof(EmptyMessage));
        OnPropertyChanged(nameof(MatchingCount));
        OnPropertyChanged(nameof(TotalPages));
        OnPropertyChanged(nameof(CanGoToPreviousPage));
        OnPropertyChanged(nameof(CanGoToNextPage));
        OnPropertyChanged(nameof(ShowingText));
    }

    /// <summary>
    /// True when the search text is empty or found, ignoring case, in the device name, IP address,
    /// certificate subject or thumbprint of the entry.
    /// </summary>
    private static bool Matches(DashboardTrustListRow row, string searchText)
    {
        if (string.IsNullOrEmpty(searchText))
        {
            return true;
        }

        return row.DeviceIdentifier.Contains(searchText, StringComparison.OrdinalIgnoreCase)
            || row.MaxumIp.Contains(searchText, StringComparison.OrdinalIgnoreCase)
            || row.Subject.Contains(searchText, StringComparison.OrdinalIgnoreCase)
            || row.Thumbprint.Contains(searchText, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Sets the field and raises PropertyChanged when the value changed.
    /// </summary>
    private void SetField<T>(ref T field, T value, [CallerMemberName] string propertyName = "")
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return;
        }

        field = value;
        OnPropertyChanged(propertyName);
    }

    /// <summary>
    /// Raises the PropertyChanged event.
    /// </summary>
    private void OnPropertyChanged([CallerMemberName] string propertyName = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    private bool CanMutateTrustList() =>
        IsWhitelistSelected && SelectedEntry is not null && _certificateBlackList is not null && IsDeviceAdministrator;

    private bool CanReinstate() =>
        IsBlacklistSelected && SelectedEntry is not null && _reinstatementWorkflow is not null && IsDeviceAdministrator;

    public async Task MoveSelectedToBlacklistAsync(string? reason)
    {
        if (!CanMutateTrustList() || SelectedEntry is null || _certificateBlackList is null)
        {
            return;
        }

        string trimmed = reason?.Trim() ?? string.Empty;
        BlacklistReasonPolicy.ValidateOrThrow(trimmed);

        await _certificateBlackList.BlackListAsync(
            new BlackListRequest
            {
                ThumbprintSha256 = SelectedEntry.Thumbprint,
                Reason = trimmed,
                ReasonClass = BlacklistReasonClass.ManualAction,
                SourceComponent = "TrustListView",
                ActorIdentity = MccTrustProof.ActorIdentity ?? string.Empty
            });
        await LoadAsync();
    }

    public async Task BulkBlacklistAsync(IReadOnlyList<string> thumbprints, string reason)
    {
        if (!IsDeviceAdministrator || _bulkBlacklistService is null || !IsWhitelistSelected)
        {
            return;
        }

        string trimmedReason = reason.Trim();
        if (string.IsNullOrEmpty(trimmedReason) || thumbprints.Count == 0)
        {
            throw new InvalidOperationException("Bulk blacklist requires thumbprints and a reason.");
        }

        string actor = string.IsNullOrWhiteSpace(MccTrustProof.ActorIdentity)
            ? _actorIdentityProvider()?.Trim() ?? string.Empty
            : MccTrustProof.ActorIdentity;
        await _bulkBlacklistService.ExecuteAsync(new BulkBlacklistRequest
        {
            ActorIdentity = actor,
            Reason = trimmedReason,
            ThumbprintsSha256 = thumbprints
        });
        await LoadAsync();
    }

    public async Task ReinstateSelectedAsync()
    {
        if (!CanReinstate() || SelectedEntry is null || _reinstatementWorkflow is null)
        {
            return;
        }

        if (_validationEngine is not null)
        {
            TrustValidationResult validation = await _validationEngine.ValidateAsync(SelectedEntry.Thumbprint);
            if (validation.Outcome != TrustValidationOutcome.Passed)
            {
                throw new InvalidOperationException(
                    $"Certificate cannot be reinstated: {validation.FailureReason ?? validation.Outcome.ToString()}");
            }
        }

        string actor = _actorIdentityProvider()?.Trim() ?? string.Empty;
        await _reinstatementWorkflow.RequestReinstatementAsync(SelectedEntry.Thumbprint, actor);
        await LoadAsync();
    }

    #endregion

    #region Events

    /// <summary>
    /// Occurs when a property value changes.
    /// </summary>
    public event PropertyChangedEventHandler? PropertyChanged;

    #endregion
}