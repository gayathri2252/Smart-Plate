﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.UI.Interfaces;
using Microsoft.Win32.SafeHandles;
using System.ComponentModel;
using System.Security.Principal;

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Signs users in with local Windows accounts: Windows checks the password and the user must be in the
/// platform device-administrator group (default: built-in Administrators). Credentials are not stored.
/// </summary>
public sealed class WindowsLocalUserAuthenticator : ILocalUserAuthenticator
{
    #region Member Variables

    /// <summary>
    /// Windows error: wrong user name or password.
    /// </summary>
    private const int ERROR_LOGON_FAILURE = 1326;

    /// <summary>
    /// Windows error: an account restriction, such as a blank password.
    /// </summary>
    private const int ERROR_ACCOUNT_RESTRICTION = 1327;

    /// <summary>
    /// Windows error: the password has expired.
    /// </summary>
    private const int ERROR_PASSWORD_EXPIRED = 1330;

    /// <summary>
    /// Windows error: the account is disabled.
    /// </summary>
    private const int ERROR_ACCOUNT_DISABLED = 1331;

    /// <summary>
    /// Windows error: a policy does not allow this logon type.
    /// </summary>
    private const int ERROR_LOGON_TYPE_NOT_GRANTED = 1385;

    /// <summary>
    /// Windows error: the account has expired.
    /// </summary>
    private const int ERROR_ACCOUNT_EXPIRED = 1793;

    /// <summary>
    /// Windows error: the password must be changed first.
    /// </summary>
    private const int ERROR_PASSWORD_MUST_CHANGE = 1907;

    /// <summary>
    /// Windows error: the account is locked out.
    /// </summary>
    private const int ERROR_ACCOUNT_LOCKED_OUT = 1909;



    /// <summary>
    /// Windows calls used to log the user on and check the group.
    /// </summary>
    private readonly IWindowsLogon _logon;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the authenticator for the given local Windows group, using the real Windows calls.
    /// </summary>
    /// <param name="administratorGroup">Local Windows group whose members may sign in.</param>
    public WindowsLocalUserAuthenticator(string administratorGroup)
        : this(administratorGroup, new WindowsLogon())
    {
    }

    /// <summary>
    /// Creates the authenticator for the given local Windows group and Windows calls.
    /// </summary>
    /// <param name="administratorGroup">Local Windows group whose members may sign in.</param>
    /// <param name="logon">Windows calls used to log the user on and check the group.</param>
    public WindowsLocalUserAuthenticator(string administratorGroup, IWindowsLogon logon)
    {
        if (string.IsNullOrWhiteSpace(administratorGroup))
        {
            throw new ArgumentException(RequestStatusConstants.ADMINISTRATOR_GROUP_IS_BLANK, nameof(administratorGroup));
        }

        AdministratorGroup = administratorGroup.Trim();
        _logon = logon ?? throw new ArgumentNullException(nameof(logon));
    }

    #endregion

    #region Public Properties

    /// <inheritdoc />
    public string AdministratorGroup { get; }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public LocalSignInResult SignIn(string userName, string password)
    {
        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrEmpty(password))
        {
            return LocalSignInResult.InvalidCredentials;
        }

        string name = userName.Trim();

        try
        {
            // A network logon only checks the password; if a policy does not allow it, an interactive logon is tried.
            int error = _logon.LogOn(name, password, WindowsLogon.LOGON32_LOGON_NETWORK, out SafeAccessTokenHandle token);
            if (error == ERROR_LOGON_TYPE_NOT_GRANTED)
            {
                token?.Dispose();
                error = _logon.LogOn(name, password, WindowsLogon.LOGON32_LOGON_INTERACTIVE, out token);
            }

            using (token)
            {
                return error == 0 ? CheckGroup(name, token) : MapLogonError(name, error);
            }
        }
        catch (Exception ex) when (ex is SystemException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), RequestStatusConstants.SIGN_IN_CHECK_FAILED, name, ex.Message);
            return LocalSignInResult.Unavailable;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Turns a Windows logon error into a sign-in result and logs why the sign-in was rejected.
    /// </summary>
    private static LocalSignInResult MapLogonError(string userName, int error)
    {
        switch (error)
        {
            case ERROR_LOGON_FAILURE:
            case ERROR_ACCOUNT_RESTRICTION:
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.SIGN_IN_REJECTED, userName);
                return LocalSignInResult.InvalidCredentials;

            case ERROR_PASSWORD_MUST_CHANGE:
            case ERROR_PASSWORD_EXPIRED:
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.PASSWORD_MUST_CHANGE, userName);
                return LocalSignInResult.PasswordMustChange;

            case ERROR_ACCOUNT_DISABLED:
            case ERROR_ACCOUNT_LOCKED_OUT:
            case ERROR_ACCOUNT_EXPIRED:
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.ACCOUNT_DISABLED, userName, error.ToString());
                return LocalSignInResult.AccountDisabled;

            case ERROR_LOGON_TYPE_NOT_GRANTED:
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.LOGON_NOT_GRANTED, userName);
                return LocalSignInResult.NotAuthorized;

            default:
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    RequestStatusConstants.SIGN_IN_CHECK_FAILED,
                    userName,
                    $"Windows error {error}: {new Win32Exception(error).Message}");
                return LocalSignInResult.Unavailable;
        }
    }

    /// <summary>
    /// Checks whether the logged-on user is in the administrator group, and logs the outcome.
    /// </summary>
    private LocalSignInResult CheckGroup(string userName, SafeAccessTokenHandle token)
    {
        SecurityIdentifier? groupSid = _logon.FindGroup(AdministratorGroup);
        if (groupSid is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), RequestStatusConstants.ADMINISTRATOR_GROUP_NOT_FOUND, AdministratorGroup);
            return LocalSignInResult.NotAuthorized;
        }

        if (!_logon.IsInGroup(token, groupSid))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.USER_NOT_IN_GROUP, userName, AdministratorGroup);
            return LocalSignInResult.NotAuthorized;
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), RequestStatusConstants.SIGN_IN_SUCCEEDED, userName);
        return LocalSignInResult.Success;
    }

    #endregion
}