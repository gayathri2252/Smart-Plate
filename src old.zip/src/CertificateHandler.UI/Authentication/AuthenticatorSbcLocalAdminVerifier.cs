using CertificateHandler.Data;
using CertificateHandler.UI.Interfaces;

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Checks SBC local administrator credentials through the same Windows logon used by the HMI (RS_34).
/// </summary>
public sealed class AuthenticatorSbcLocalAdminVerifier : ISbcLocalAdminCredentialVerifier
{
    private readonly ILocalUserAuthenticator _authenticator;

    public AuthenticatorSbcLocalAdminVerifier(ILocalUserAuthenticator authenticator)
    {
        _authenticator = authenticator ?? throw new ArgumentNullException(nameof(authenticator));
    }

    public Task<bool> ValidateAsync(string userName, string password, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(_authenticator.SignIn(userName, password) == LocalSignInResult.Success);
    }
}
