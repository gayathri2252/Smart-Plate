// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Called when the trust engine finishes. Adds the thumbprint to the blacklist when validation failed because of a bad signature, a revoked certificate, a broken chain or a security incident.
/// </summary>
public class BlackListOnSecurityFailureService
{
    #region Member Variables

    /// <summary>
    /// Used to add certificates to the blacklist.
    /// </summary>
    private readonly ICertificateBlackList _certificateBlackList;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service with the blacklist store. The store must not be null.
    /// </summary>
    /// <param name="certificateBlackList">The blacklist store.</param>
    public BlackListOnSecurityFailureService(ICertificateBlackList certificateBlackList)
    {
        ArgumentNullException.ThrowIfNull(certificateBlackList);

        _certificateBlackList = certificateBlackList;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Handles one validation result. Gives the blacklist result, or null when the check passed or does not add the thumbprint to the blacklist.
    /// </summary>
    /// <param name="validationResult">The validation result.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The blacklist result, or null.</returns>
    public async Task<CertificateBlackList?> HandleValidationResultAsync(
        TrustValidationResult validationResult,
        CancellationToken cancellationToken = default)
    {
        // Guard: without a validation result there is nothing to decide on.
        if (validationResult is null)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.VALIDATION_RESULT_IS_NULL);
            throw new ArgumentNullException(nameof(validationResult));
        }

        // Guard: a passed validation never blacklists the thumbprint.
        if (validationResult.Outcome == TrustValidationOutcome.Passed)
        {
            return null;
        }

        // Guard: expired, not-yet-valid and time-unverified results belong to a separate story.
        if (!TrustFailureClassifier.TryGetBlackListReason(validationResult.Outcome, out var reasonClass))
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.VALIDATION_FAILURE_NOT_BLACK_LISTED,
                validationResult.Outcome.ToString());
            return null;
        }

        BlackListResponse result;

        try
        {
            result = await _certificateBlackList.BlackListAsync(
                new BlackListRequest
                {
                    ThumbprintSha256 = validationResult.ThumbprintSha256,
                    ReasonClass = reasonClass,
                    Reason = BuildReason(validationResult),
                    EvaluatedAt = validationResult.EvaluatedAt
                },
                cancellationToken);
        }
        catch (Exception ex)
        {
            // A failure to blacklist must not be silent, so the error is logged and rethrown.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.BLACK_LIST_FAILED,
                ex.Message);
            throw;
        }

        LogOutcome(reasonClass.ToString(), result.Outcome);
        return result.Outcome;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds the reason saved with the blacklist row. It is the outcome name, then the failure details from the trust engine when there are any.
    /// </summary>
    /// <param name="validationResult">The validation result.</param>
    /// <returns>The reason text.</returns>
    private static string BuildReason(TrustValidationResult validationResult)
    {
        string detail = validationResult.FailureReason?.Trim() ?? string.Empty;

        return detail.Length == 0
            ? validationResult.Outcome.ToString()
            : $"{validationResult.Outcome}: {detail}";
    }

    /// <summary>
    /// Logs the blacklist result. A warning when the thumbprint was added, information when it was already there, and an error when the certificate is not known.
    /// </summary>
    /// <param name="reasonClass">The blacklist reason type.</param>
    /// <param name="outcome">The blacklist result.</param>
    private static void LogOutcome(string reasonClass, CertificateBlackList outcome)
    {
        switch (outcome)
        {
            case CertificateBlackList.Added:
            case CertificateBlackList.Reactivated:
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.THUMBPRINT_BLACK_LISTED,
                    reasonClass);
                break;

            case CertificateBlackList.AlreadyBlackListed:
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.THUMBPRINT_ALREADY_BLACK_LISTED);
                break;

            default:
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.BLACK_LIST_CERTIFICATE_NOT_FOUND);
                break;
        }
    }

    #endregion
}
