// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.DeviceTrust.Interfaces;
using CertificateHandler.DeviceTrust.Security;
using CertificateHandler.Shared.Constants;
using DashboardCH.Interfaces;
using DashboardCH.Models;
using DashboardCH.Models.Enums;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Checks peer certificates, the time, chain, expiry and subject.
/// </summary>
public sealed class CertificateValidationEngine
{
    #region Member Variables

    /// <summary>
    /// Reads the certificate and its chain from the certificate store.
    /// </summary>
    private readonly ICertificateStoreAdapter _storeAdapter;

    /// <summary>
    /// Checks if the system time can be trusted.
    /// </summary>
    private readonly ITimeVerificationService _timeVerification;

    /// <summary>
    /// Saves the result of each validation step.
    /// </summary>
    private readonly IValidationResultWriter _validationWriter;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the validation engine.
    /// </summary>
    /// <param name="storeAdapter">Reads certificates from the certificate store.</param>
    /// <param name="timeVerification">Checks if the system time can be trusted.</param>
    /// <param name="validationWriter">Saves the result of each validation step.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    public CertificateValidationEngine(
        ICertificateStoreAdapter storeAdapter,
        ITimeVerificationService timeVerification,
        IValidationResultWriter validationWriter)
    {
        _storeAdapter = storeAdapter ?? throw new ArgumentNullException(nameof(storeAdapter));
        _timeVerification = timeVerification ?? throw new ArgumentNullException(nameof(timeVerification));
        _validationWriter = validationWriter ?? throw new ArgumentNullException(nameof(validationWriter));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks a certificate in the local store by its thumbprint, used by the admin and renewal screens.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="deviceId">Id of the device, or null.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The validation result.</returns>
    public async Task<TrustValidationResult> ValidateAsync(
        string thumbprintSha256,
        Guid? deviceId = null,
        CancellationToken cancellationToken = default)
    {
        DateTimeOffset evaluatedAt = DateTimeOffset.UtcNow;
        bool timeVerified = _timeVerification.IsTimeVerified();

        await _validationWriter.WriteAsync(
            thumbprintSha256, deviceId, "TIME_VERIFY", timeVerified, timeVerified ? null : "Time not verified",
            timeVerified, false, cancellationToken);

        if (!timeVerified)
        {
            return Failed(thumbprintSha256, TrustValidationOutcome.TimeUnverified, RequestStatusConstants.TIME_UNVERIFIED, evaluatedAt);
        }

        CertificateChainInfo chain = _storeAdapter.GetCertificateChain(thumbprintSha256);
        return await CompleteValidationFromChainAsync(thumbprintSha256, deviceId, chain, evaluatedAt, cancellationToken);
    }

    /// <summary>
    /// Checks a certificate sent by a peer over TLS, not one from the local store.
    /// </summary>
    /// <param name="presentedCertificateDer">Certificate sent by the peer, in DER format.</param>
    /// <param name="expectedThumbprintSha256">SHA256 thumbprint the certificate should have.</param>
    /// <param name="deviceId">Id of the device, or null.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The validation result.</returns>
    public Task<TrustValidationResult> ValidatePresentedCertificateAsync(
        byte[] presentedCertificateDer,
        string? expectedThumbprintSha256 = null,
        Guid? deviceId = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(presentedCertificateDer);

        using var certificate = new X509Certificate2(presentedCertificateDer);
        return ValidatePresentedCertificateAsync(certificate, expectedThumbprintSha256, deviceId, cancellationToken);
    }

    /// <summary>
    /// Checks a peer certificate from the TLS handshake.
    /// </summary>
    /// <param name="leafCertificate">Certificate sent by the peer.</param>
    /// <param name="expectedThumbprintSha256">SHA256 thumbprint the certificate should have.</param>
    /// <param name="deviceId">Id of the device, or null.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The validation result.</returns>
    public async Task<TrustValidationResult> ValidatePresentedCertificateAsync(
        X509Certificate2 leafCertificate,
        string? expectedThumbprintSha256 = null,
        Guid? deviceId = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(leafCertificate);

        string thumbprintSha256 = leafCertificate.GetCertHashString(HashAlgorithmName.SHA256);
        if (!string.IsNullOrWhiteSpace(expectedThumbprintSha256)
            && !string.Equals(
                NormalizeThumbprint(thumbprintSha256),
                NormalizeThumbprint(expectedThumbprintSha256),
                StringComparison.Ordinal))
        {
            return Failed(thumbprintSha256, TrustValidationOutcome.SecurityIncident, "Presented thumbprint mismatch.", DateTimeOffset.UtcNow);
        }

        DateTimeOffset evaluatedAt = DateTimeOffset.UtcNow;
        bool timeVerified = _timeVerification.IsTimeVerified();

        await _validationWriter.WriteAsync(
            thumbprintSha256, deviceId, "TIME_VERIFY", timeVerified, timeVerified ? null : "Time not verified",
            timeVerified, false, cancellationToken);

        if (!timeVerified)
        {
            return Failed(thumbprintSha256, TrustValidationOutcome.TimeUnverified, RequestStatusConstants.TIME_UNVERIFIED, evaluatedAt);
        }

        CertificateChainInfo chain = _storeAdapter.GetCertificateChainFromCertificate(leafCertificate);
        return await CompleteValidationFromChainAsync(thumbprintSha256, deviceId, chain, evaluatedAt, cancellationToken);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Finishes the validation using the certificate chain.
    /// Checks the chain, the subject, the key size and the validity dates, and saves the result of each step.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="deviceId">Id of the device, or null if not known.</param>
    /// <param name="chain">The certificate chain.</param>
    /// <param name="evaluatedAt">Time used to check the validity dates.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The validation result.</returns>
    private async Task<TrustValidationResult> CompleteValidationFromChainAsync(
        string thumbprintSha256,
        Guid? deviceId,
        CertificateChainInfo chain,
        DateTimeOffset evaluatedAt,
        CancellationToken cancellationToken)
    {
        bool chainOk = chain.Status == CertLookupStatus.Found && string.IsNullOrEmpty(chain.ErrorDetail);
        await _validationWriter.WriteAsync(
            thumbprintSha256, deviceId, "CHAIN", chainOk, chain.ErrorDetail, true, false, cancellationToken);

        if (!chainOk)
        {
            TrustValidationOutcome outcome = chain.ErrorDetail?.Contains("revoked", StringComparison.OrdinalIgnoreCase) == true
                ? TrustValidationOutcome.Revoked
                : TrustValidationOutcome.BrokenChain;

            return Failed(thumbprintSha256, outcome, chain.ErrorDetail ?? RequestStatusConstants.CHAIN_INCOMPLETE, evaluatedAt);
        }

        var leaf = chain.LeafCertificate;
        bool subjectOk = !string.IsNullOrWhiteSpace(leaf?.Subject);
        await _validationWriter.WriteAsync(
            thumbprintSha256, deviceId, "SUBJECT", subjectOk, subjectOk ? null : "Missing subject", true, false, cancellationToken);

        if (!subjectOk)
        {
            return Failed(thumbprintSha256, TrustValidationOutcome.SecurityIncident, "Certificate subject is missing.", evaluatedAt);
        }

        try
        {
            CertificateKeyStrengthPolicy.ValidateOrThrow(leaf!);
        }
        catch (ArgumentException ex)
        {
            await _validationWriter.WriteAsync(
                thumbprintSha256, deviceId, "SIGNATURE", false, ex.Message, true, false, cancellationToken);
            return Failed(thumbprintSha256, TrustValidationOutcome.SecurityIncident, ex.Message, evaluatedAt);
        }

        // chain.Build (store adapter) already verified issuer signatures when ErrorDetail is empty.
        await _validationWriter.WriteAsync(
            thumbprintSha256, deviceId, "SIGNATURE", true, null, true, false, cancellationToken);

        if (leaf!.ValidToUtc <= evaluatedAt.UtcDateTime)
        {
            await _validationWriter.WriteAsync(
                thumbprintSha256, deviceId, "EXPIRY", false, "Certificate expired", true, false, cancellationToken);
            return Failed(thumbprintSha256, TrustValidationOutcome.Expired, RequestStatusConstants.REQUEST_EXPIRED_CANNOT_BE_APPROVED, evaluatedAt);
        }

        if (leaf.ValidFromUtc > evaluatedAt.UtcDateTime)
        {
            return Failed(thumbprintSha256, TrustValidationOutcome.NotYetValid, "Certificate is not yet valid.", evaluatedAt);
        }

        return new TrustValidationResult
        {
            ThumbprintSha256 = thumbprintSha256,
            Outcome = TrustValidationOutcome.Passed,
            EvaluatedAt = evaluatedAt
        };
    }

    /// <summary>
    /// Creates a failed validation result.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="outcome">Why the validation failed.</param>
    /// <param name="reason">Message that explains the failure.</param>
    /// <param name="evaluatedAt">Time of the validation.</param>
    /// <returns>The failed validation result.</returns>
    private static TrustValidationResult Failed(
        string thumbprintSha256,
        TrustValidationOutcome outcome,
        string? reason,
        DateTimeOffset evaluatedAt) =>
        new()
        {
            ThumbprintSha256 = thumbprintSha256,
            Outcome = outcome,
            FailureReason = reason,
            EvaluatedAt = evaluatedAt
        };

    /// <summary>
    /// Removes spaces and colons from the thumbprint and makes it upper case.
    /// </summary>
    /// <param name="thumbprint">The thumbprint to clean.</param>
    /// <returns>The cleaned thumbprint.</returns>
    private static string NormalizeThumbprint(string thumbprint) =>
        thumbprint.Replace(" ", string.Empty, StringComparison.Ordinal)
            .Replace(":", string.Empty, StringComparison.Ordinal)
            .ToUpperInvariant();

    #endregion
}
