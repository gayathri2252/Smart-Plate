﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.DeviceTrust.Tls;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides if a peer that sends a certificate request can communicate. The listener calls it for every incoming peer. The checks run in this order.
/// First, the request must have the certificate details and a validation result for the same thumbprint.
/// Second, the certificate must pass validation. A security failure also adds it to the blacklist.
/// Third, the peer must be authenticated, so the connection proved that it holds the private key.
/// Fourth, a certificate on the blacklist is refused.
/// Fifth, a certificate on the whitelist is allowed. One that was removed from the blacklist before is allowed only because it passed the first four checks again on this connection.
/// Sixth, an unknown certificate is refused and added to the pending queue while the queue has room. When the queue is full, the peer is refused before any pending row is made.
/// Any error while reading the lists or the queue refuses the peer.
/// </summary>
public class CertificateRequestAuthorizationService
{
    #region Member Variables

    /// <summary>
    /// Decides if the certificate is trusted, blacklisted or unknown.
    /// </summary>
    private readonly TrustEngine _trustEngine;

    /// <summary>
    /// Adds new requests to the pending queue when there is space.
    /// </summary>
    private readonly PendingQueueCapacityService _queueCapacity;

    /// <summary>
    /// Tells if the certificate was removed from the blacklist before.
    /// </summary>
    private readonly IBlackListHistory _blackListHistory;

    /// <summary>
    /// Holds the TLS handshake while the request waits for approval. Can be null.
    /// </summary>
    private readonly ITlsHandshakeCoordinator? _handshakeCoordinator;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. None of the arguments may be null.
    /// </summary>
    /// <param name="trustEngine">Decides blacklisted, whitelisted or unknown.</param>
    /// <param name="queueCapacity">Adds unknown peers to the pending queue within its limit.</param>
    /// <param name="blackListHistory">Tells whether a certificate was removed from the blacklist.</param>
    /// <param name="handshakeCoordinator">Holds and releases TLS handshakes that wait for an administrator decision.</param>
    public CertificateRequestAuthorizationService(
        TrustEngine trustEngine,
        PendingQueueCapacityService queueCapacity,
        IBlackListHistory blackListHistory,
        ITlsHandshakeCoordinator? handshakeCoordinator = null)
    {
        ArgumentNullException.ThrowIfNull(trustEngine);
        ArgumentNullException.ThrowIfNull(queueCapacity);
        ArgumentNullException.ThrowIfNull(blackListHistory);

        _trustEngine = trustEngine;
        _queueCapacity = queueCapacity;
        _blackListHistory = blackListHistory;
        _handshakeCoordinator = handshakeCoordinator;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if the certificate request of the peer is allowed, and why not when it is not.
    /// </summary>
    /// <param name="request">The peer and the result of validating its certificate.</param>
    /// <param name="cancellationToken">Token to cancel the lookups. A cancel is passed on to the caller.</param>
    /// <returns>The result of the check.</returns>
    public async Task<CertificateRequestAuthorizationResult> AuthorizeAsync(
        CertificateRequest? request,
        CancellationToken cancellationToken = default)
    {
        if (!TryGetThumbprint(request, out string thumbprint))
        {
            return Refuse(CertificateRequestDecision.RefusedInvalidRequest, DeviceTrustConstants.CERTIFICATE_REQUEST_INVALID_REQUEST);
        }

        PeerOnboardingRequest peer = request!.Peer!;
        TrustValidationResult validationResult = request.ValidationResult!;

        try
        {
            if (validationResult.Outcome != TrustValidationOutcome.Passed)
            {
                // A security failure, such as a bad signature, also puts the certificate on the blacklist.
                await _trustEngine.CompleteValidationAsync(validationResult, cancellationToken);
                return Refuse(CertificateRequestDecision.RefusedValidationFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_VALIDATION_FAILED,
                    peer.DeviceCode, validationResult.Outcome.ToString());
            }

            // An unauthenticated peer is neither trusted nor queued, so copied certificates cannot fill the queue.
            if (!request.IsAuthenticated)
            {
                return Refuse(CertificateRequestDecision.RefusedAuthenticationFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_AUTHENTICATION_FAILED,
                    peer.DeviceCode);
            }

            TrustDecision decision = await _trustEngine.EvaluateAsync(thumbprint, cancellationToken);

            switch (decision)
            {
                case TrustDecision.BlackListed:
                    return Refuse(CertificateRequestDecision.RefusedBlackListed, DeviceTrustConstants.CERTIFICATE_REQUEST_BLACK_LISTED, peer.DeviceCode);

                case TrustDecision.Whitelisted:
                    return await AllowWhitelistedAsync(thumbprint, peer, cancellationToken);

                case TrustDecision.Unknown:
                    return await QueueUnknownPeerAsync(thumbprint, peer, cancellationToken);

                default:
                    return Refuse(CertificateRequestDecision.RefusedLookupFailed, DeviceTrustConstants.CERTIFICATE_REQUEST_LOOKUP_FAILED, peer.DeviceCode);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The caller cancelled the certificate request. That is not a lookup failure, so it is passed on.
            throw;
        }
        catch (Exception ex)
        {
            // Fail closed: when the lists or the queue cannot be read, the peer is not trusted.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.CERTIFICATE_REQUEST_CHECK_FAILED,
                peer.DeviceCode,
                ex.Message);
            return new CertificateRequestAuthorizationResult
            {
                Decision = CertificateRequestDecision.RefusedLookupFailed,
                FailureReason = ex.GetBaseException().Message
            };
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Allows a peer on the whitelist. When the certificate was removed from the blacklist before, this is logged as a new check, because it got here only by passing validation and authentication again.
    /// </summary>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="peer">Details of the peer.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The allowed result.</returns>
    private async Task<CertificateRequestAuthorizationResult> AllowWhitelistedAsync(
        string thumbprint,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        bool wasRemovedFromBlackList = await _blackListHistory.WasRemovedFromBlackListAsync(thumbprint, cancellationToken);

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            wasRemovedFromBlackList ? DeviceTrustConstants.CERTIFICATE_REQUEST_REVALIDATED_ALLOWED : DeviceTrustConstants.CERTIFICATE_REQUEST_ALLOWED,
            peer.DeviceCode);

        return new CertificateRequestAuthorizationResult
        {
            Decision = CertificateRequestDecision.Allowed,
            WasRevalidatedAfterBlackList = wasRemovedFromBlackList
        };
    }

    /// <summary>
    /// Refuses an unknown peer and adds it to the pending queue while the queue has room.
    /// A certificate that was removed from the blacklist but is not on the whitelist again also goes this way, so an administrator must approve it before it can communicate.
    /// </summary>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="peer">Details of the peer.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The refused result.</returns>
    private async Task<CertificateRequestAuthorizationResult> QueueUnknownPeerAsync(
        string thumbprint,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        bool wasRemovedFromBlackList = await _blackListHistory.WasRemovedFromBlackListAsync(thumbprint, cancellationToken);

        peer.ThumbprintSha256 = thumbprint;
        PendingQueueAddResult result = await _queueCapacity.TryEnqueueAsync(peer, cancellationToken);
        if (result.Outcome == PendingQueueAddOutcome.Added && result.RequestId is Guid requestId)
        {
            _handshakeCoordinator?.TrySuspend(requestId.ToString(), thumbprint);
        }

        CertificateRequestDecision decision = result.Outcome switch
        {
            PendingQueueAddOutcome.Added => CertificateRequestDecision.RefusedPendingApproval,
            PendingQueueAddOutcome.AlreadyPending => CertificateRequestDecision.RefusedAlreadyPending,
            _ => CertificateRequestDecision.RefusedQueueFull
        };

        return new CertificateRequestAuthorizationResult
        {
            Decision = decision,
            PendingRequestId = result.RequestId,
            WasRevalidatedAfterBlackList = wasRemovedFromBlackList
        };
    }

    /// <summary>
    /// Reads the thumbprint of the peer. It must be valid and the same as the thumbprint of the validation result, so a result for another certificate cannot allow this peer.
    /// </summary>
    /// <param name="request">The certificate request.</param>
    /// <param name="thumbprint">The cleaned thumbprint, or an empty string.</param>
    /// <returns>True if the thumbprint is valid and matches, otherwise false.</returns>
    private static bool TryGetThumbprint(CertificateRequest? request, out string thumbprint)
    {
        thumbprint = string.Empty;

        if (request?.Peer is null || request.ValidationResult is null)
        {
            return false;
        }

        if (!ThumbprintNormalizer.TryNormalizeRequired(request.Peer.ThumbprintSha256, out string peerThumbprint)
            || !ThumbprintNormalizer.TryNormalizeRequired(request.ValidationResult.ThumbprintSha256, out string validatedThumbprint))
        {
            return false;
        }

        if (!string.Equals(peerThumbprint, validatedThumbprint, StringComparison.Ordinal))
        {
            return false;
        }

        thumbprint = peerThumbprint;
        return true;
    }

    /// <summary>
    /// Logs why the peer is refused and gives the refusal.
    /// </summary>
    /// <param name="decision">The refusal decision.</param>
    /// <param name="message">The log message.</param>
    /// <param name="arguments">Values for the log message.</param>
    /// <returns>The refused result.</returns>
    private static CertificateRequestAuthorizationResult Refuse(CertificateRequestDecision decision, string message, params string[] arguments)
    {
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message, arguments);
        return new CertificateRequestAuthorizationResult { Decision = decision };
    }

    #endregion
}
