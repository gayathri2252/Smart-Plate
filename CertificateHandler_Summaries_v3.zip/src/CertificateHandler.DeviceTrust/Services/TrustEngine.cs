// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Constants;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides if a thumbprint is on the blacklist, on the whitelist or unknown, and passes a finished validation result to the blacklist service. The blacklist is checked first.
/// </summary>
public class TrustEngine
{
    #region Member Variables

    /// <summary>
    /// Used to check and update the blacklist.
    /// </summary>
    private readonly ICertificateBlackList _certificateBlackList;

    /// <summary>
    /// Used to check the whitelist.
    /// </summary>
    private readonly ICertificateWhitelist _certificateWhitelist;

    /// <summary>
    /// Adds certificates to the blacklist when they fail a security check.
    /// </summary>
    private readonly BlackListOnSecurityFailureService _blacklistOnSecurityFailureService;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the engine with the blacklist and whitelist stores and the service that adds a thumbprint to the blacklist after a security failure. None of them can be null.
    /// </summary>
    /// <param name="certificateBlackList">The blacklist store.</param>
    /// <param name="certificateWhitelist">The whitelist store.</param>
    /// <param name="blacklistOnSecurityFailureService">Adds a thumbprint to the blacklist after a security failure.</param>
    public TrustEngine(
        ICertificateBlackList certificateBlackList,
        ICertificateWhitelist certificateWhitelist,
        BlackListOnSecurityFailureService blacklistOnSecurityFailureService)
    {
        ArgumentNullException.ThrowIfNull(certificateBlackList);
        ArgumentNullException.ThrowIfNull(certificateWhitelist);
        ArgumentNullException.ThrowIfNull(blacklistOnSecurityFailureService);

        _certificateBlackList = certificateBlackList;
        _certificateWhitelist = certificateWhitelist;
        _blacklistOnSecurityFailureService = blacklistOnSecurityFailureService;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Called when the validation of a certificate is finished. Passes the result to the blacklist service, which adds the thumbprint to the blacklist after a security failure.
    /// Gives the blacklist result, or null when the check passed or does not add the thumbprint to the blacklist.
    /// </summary>
    /// <param name="validationResult">The validation result.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The blacklist result, or null.</returns>
    public Task<CertificateBlackList?> CompleteValidationAsync(
        TrustValidationResult validationResult,
        CancellationToken cancellationToken = default)
    {
        return _blacklistOnSecurityFailureService.HandleValidationResultAsync(validationResult, cancellationToken);
    }

    /// <summary>
    /// Gives the trust decision for the thumbprint. A thumbprint that is not valid, or a list that cannot be read, gives Rejected, because the certificate is not trusted when the lists cannot be checked.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The trust decision.</returns>
    public async Task<TrustDecision> EvaluateAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        // Guard: a missing or malformed thumbprint cannot be looked up, so the certificate is rejected.
        if (!ThumbprintNormalizer.TryNormalizeRequired(thumbprintSha256, out string thumbprint))
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_INVALID_THUMBPRINT);
            return TrustDecision.Rejected;
        }

        try
        {
            // The blacklist comes first, so a blacklisted thumbprint is denied even if it also has a whitelist row.
            if (await _certificateBlackList.IsBlackListedAsync(thumbprint, cancellationToken))
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.TRUST_DECISION_BLACK_LISTED);
                return TrustDecision.BlackListed;
            }

            if (await _certificateWhitelist.IsWhitelistedAsync(thumbprint, cancellationToken))
            {
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    DeviceTrustConstants.TRUST_DECISION_WHITELISTED);
                return TrustDecision.Whitelisted;
            }

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_UNKNOWN);
            return TrustDecision.Unknown;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // The caller cancelled the lookup. That is not a lookup failure, so it is passed on.
            throw;
        }
        catch (Exception ex)
        {
            // Fail closed: if the lists cannot be read, the certificate is not trusted.
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                DeviceTrustConstants.TRUST_DECISION_LOOKUP_FAILED,
                ex.Message);
            return TrustDecision.Rejected;
        }
    }

    #endregion
}
