// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Enums;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Decides which validation results add a thumbprint to the blacklist. A bad signature, a revoked certificate, a broken chain and a security incident do.
/// Expired, not yet valid and time not checked results do not.
/// </summary>
public static class TrustFailureClassifier
{
    #region Public Methods

    /// <summary>
    /// Returns true and the blacklist reason when the outcome must blacklist the thumbprint.
    /// </summary>
    /// <param name="outcome">The validation outcome.</param>
    /// <param name="reason">The blacklist reason type.</param>
    /// <returns>True if the thumbprint must be added to the blacklist, otherwise false.</returns>
    public static bool TryGetBlackListReason(TrustValidationOutcome outcome, out BlacklistReasonClass reason)
    {
        switch (outcome)
        {
            case TrustValidationOutcome.BadSignature:
                reason = BlacklistReasonClass.SignatureFailure;
                return true;

            case TrustValidationOutcome.Revoked:
                reason = BlacklistReasonClass.RevokedCertificate;
                return true;

            case TrustValidationOutcome.BrokenChain:
                reason = BlacklistReasonClass.BrokenChain;
                return true;

            case TrustValidationOutcome.SecurityIncident:
                reason = BlacklistReasonClass.SecurityIncident;
                return true;

            default:
                reason = default;
                return false;
        }
    }

    #endregion
}
