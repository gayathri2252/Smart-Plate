// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Tls;

/// <summary>
/// One TLS handshake coordinator for the whole process, so the UI, the listener and the trust checks share the same hold and release state.
/// </summary>
public static class TlsHandshakeCoordinatorRegistry
{
    #region Member Variables

    /// <summary>
    /// The shared coordinator. It is created the first time it is used.
    /// </summary>
    private static readonly Lazy<TlsHandshakeCoordinator> Shared = new(() => new TlsHandshakeCoordinator());

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets the shared TLS handshake coordinator.
    /// </summary>
    public static TlsHandshakeCoordinator Current => Shared.Value;

    #endregion
}
