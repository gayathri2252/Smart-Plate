// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.Concurrent;

namespace CertificateHandler.DeviceTrust.Tls;

/// <summary>
/// Keeps track of the TLS handshakes that are on hold while a certificate request waits for approval.
/// </summary>
public sealed class TlsHandshakeCoordinator : ITlsHandshakeCoordinator
{
    #region Member Variables

    /// <summary>
    /// Handshakes on hold. The key is the connection id and the value is the peer certificate thumbprint.
    /// </summary>
    private readonly ConcurrentDictionary<string, string> _suspended = new();

    #endregion

    #region Public Methods

    /// <summary>
    /// Holds the TLS handshake of a connection.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the peer certificate.</param>
    /// <returns>True if the handshake is now on hold, false if the id is empty or it is already on hold.</returns>
    public bool TrySuspend(string correlationId, string thumbprintSha256)
    {
        if (string.IsNullOrWhiteSpace(correlationId))
        {
            return false;
        }

        return _suspended.TryAdd(correlationId, thumbprintSha256 ?? string.Empty);
    }

    /// <summary>
    /// Releases the TLS handshake of a connection.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    public void Resume(string correlationId)
    {
        if (!string.IsNullOrWhiteSpace(correlationId))
        {
            _suspended.TryRemove(correlationId, out _);
        }
    }

    /// <summary>
    /// Checks if the TLS handshake of a connection is on hold.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    /// <returns>True if the handshake is on hold, otherwise false.</returns>
    public bool IsSuspended(string correlationId) =>
        !string.IsNullOrWhiteSpace(correlationId) && _suspended.ContainsKey(correlationId);

    #endregion
}
