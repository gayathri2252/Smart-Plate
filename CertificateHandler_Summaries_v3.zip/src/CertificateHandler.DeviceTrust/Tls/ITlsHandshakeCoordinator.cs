// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Tls;

/// <summary>
/// Holds and releases TLS handshakes while a certificate request waits for approval.
/// </summary>
public interface ITlsHandshakeCoordinator
{
    /// <summary>
    /// Holds the TLS handshake of a connection.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the peer certificate.</param>
    /// <returns>True if the handshake is now on hold, otherwise false.</returns>
    bool TrySuspend(string correlationId, string thumbprintSha256);

    /// <summary>
    /// Releases the TLS handshake of a connection.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    void Resume(string correlationId);

    /// <summary>
    /// Checks if the TLS handshake of a connection is on hold.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    /// <returns>True if the handshake is on hold, otherwise false.</returns>
    bool IsSuspended(string correlationId);
}
