// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Interfaces;

/// <summary>
/// Tells if the system time can be trusted for certificate validity checks.
/// </summary>
public interface ITimeVerificationService
{
    /// <summary>
    /// Checks if the system time can be trusted.
    /// </summary>
    /// <returns>True if the system time can be trusted, otherwise false.</returns>
    bool IsTimeVerified();
}
