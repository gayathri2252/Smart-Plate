// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Security;
using DashboardCH.Models;

namespace CertificateHandler.DeviceTrust.Security;

/// <summary>
/// Least public key strength allowed, so weak peer or local certificates are rejected.
/// </summary>
public static class CertificateKeyStrengthPolicy
{
    /// <summary>
    /// Checks that the public key of the certificate is strong enough.
    /// RSA and EC keys must have at least the minimum number of bits.
    /// </summary>
    /// <param name="leaf">The certificate to check.</param>
    /// <exception cref="ArgumentNullException">Thrown when the certificate is null.</exception>
    /// <exception cref="ArgumentException">Thrown when the key is missing, the key type or size is not known, or the key is too small.</exception>
    public static void ValidateOrThrow(CertificateMetadata leaf)
    {
        ArgumentNullException.ThrowIfNull(leaf);
        CertificatePublicKeyInfo key = leaf.PublicKey ?? throw new ArgumentException("Certificate has no public key.");

        if (string.IsNullOrWhiteSpace(key.Algorithm))
        {
            throw new ArgumentException("Certificate public key algorithm is missing.");
        }

        if (key.KeyBits <= 0)
        {
            throw new ArgumentException("Certificate public key size is unknown.");
        }

        if (key.Algorithm.Contains("RSA", StringComparison.OrdinalIgnoreCase))
        {
            if (key.KeyBits < CertificatePublicKeyStrengthPolicy.MinimumRsaKeyBits)
            {
                throw new ArgumentException($"RSA key must be at least {CertificatePublicKeyStrengthPolicy.MinimumRsaKeyBits} bits.");
            }

            return;
        }

        if (key.Algorithm.Contains("EC", StringComparison.OrdinalIgnoreCase)
            || key.Algorithm.Contains("ECDsa", StringComparison.OrdinalIgnoreCase))
        {
            if (key.KeyBits < CertificatePublicKeyStrengthPolicy.MinimumEcdsaKeyBits)
            {
                throw new ArgumentException($"ECDSA key must be at least {CertificatePublicKeyStrengthPolicy.MinimumEcdsaKeyBits} bits.");
            }
        }
    }
}
