﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Data.Models;

namespace CertificateHandler.DeviceTrust.Models;

/// <summary>
/// A peer that sends a certificate request, with the certificate it sent and the result of checking it.
/// </summary>
public sealed class CertificateRequest
{
    #region Public Properties

    /// <summary>Certificate and device details of the peer.</summary>
    public PeerOnboardingRequest? Peer { get; init; }

    /// <summary>Result of checking the peer certificate, its signature, chain, revocation and dates.</summary>
    public TrustValidationResult? ValidationResult { get; init; }

    /// <summary>
    /// True when the connection proved that the peer holds the private key of the certificate, like SslStream.IsMutuallyAuthenticated. A certificate alone can be copied, so it is not enough.
    /// </summary>
    public bool IsAuthenticated { get; init; }

    /// <summary>The peer certificate in DER format, used when the check should not use the local store.</summary>
    public byte[]? PresentedCertificateDer { get; init; }

    #endregion
}
