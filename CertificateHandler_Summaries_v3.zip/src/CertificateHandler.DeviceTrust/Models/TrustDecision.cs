// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Models;

/// <summary>
/// The decision of the trust engine for a presented thumbprint.
/// </summary>
public enum TrustDecision
{
    /// <summary>
    /// The thumbprint is on the blacklist. The connection is denied.
    /// </summary>
    BlackListed,

    /// <summary>
    /// The thumbprint is on the whitelist and not on the blacklist. The certificate is trusted.
    /// </summary>
    Whitelisted,

    /// <summary>
    /// The thumbprint is on neither list. The certificate is unknown and needs an administrator decision.
    /// </summary>
    Unknown,

    /// <summary>
    /// The thumbprint is not valid or the lists could not be read. The certificate is not trusted.
    /// </summary>
    Rejected
}
