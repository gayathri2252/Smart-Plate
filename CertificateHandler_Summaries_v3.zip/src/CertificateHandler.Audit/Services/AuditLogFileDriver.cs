﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Audit.Interface;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Audit.Services;

/// <summary>
/// Saves audit logs to a file and reads them back.
/// </summary>
public class AuditLogFileDriver : IAuditLogDriver
{
    #region Member Variables

    /// <summary>
    /// Path of the audit log file.
    /// </summary>
    private readonly string _logFileName = @"Logs\AuditLog.tsv";

    #endregion

    #region Public Methods

    /// <summary>
    /// Writes a new audit log entry to the file.
    /// </summary>
    /// <param name="message">
    /// Audit log message to store.
    /// </param>
    public void WriteLog(string message)
    {
        Directory.CreateDirectory("Logs");
        if (!File.Exists(_logFileName))
        {
            File.WriteAllText(
                _logFileName,
                "\"AuditId\"\t" +
                "\"RequestId\"\t" +
                "\"DeviceId\"\t" +
                "\"DeviceName\"\t" +
                "\"CertificateThumbprint\"\t" +
                "\"ApproverName\"\t" +
                "\"ActionTimestamp\"\t" +
                "\"Reason\"\t" +
                "\"ActionType\"\t" +
                "\"ActionStatus\"\t" +
                "\"CertificateSubject\"\t" +
                "\"Comments\"" +
                "\"Comments\"" +
                Environment.NewLine);
        }

        File.AppendAllText(_logFileName, message + Environment.NewLine);
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), RequestStatusConstants.AUDIT_LOG_RECORD_STORED_MESSAGE, message);
    }

    /// <summary>
    /// Reads all audit log entries from the file.
    /// </summary>
    /// <returns>
    /// Collection of stored audit log records.
    /// </returns>
    public IEnumerable<string> ReadLogs()
    {
        if (!File.Exists(_logFileName))
        {
            return new List<string>();
        }

        return File.ReadAllLines(_logFileName);
    }

    #endregion
}
