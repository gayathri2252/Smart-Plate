﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Audit.Constants;
using CertificateHandler.Audit.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using System.Globalization;

namespace CertificateHandler.Audit.Services;

/// <summary>
/// Saves and reads audit records for certificate approval and rejection actions.
/// </summary>
public class AuditLogService
{
    #region Member Variables

    /// <summary>
    /// Writes and reads the audit log file.
    /// </summary>
    private readonly AuditLogFileDriver _auditLogDriver;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the audit log service.
    /// </summary>
    public AuditLogService()
    {
        _auditLogDriver = new AuditLogFileDriver();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Saves an audit log record.
    /// </summary>
    /// <param name="auditLog">
    /// Audit log to be stored.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the audit log is null.
    /// </exception>
    public void SaveAuditLog(AuditLog auditLog)
    {
        try
        {
            if (auditLog != null)
            {
                string auditLogMessage =
                    $"\"{auditLog.AuditId}\"\t" +
                    $"\"{auditLog.RequestId}\"\t" +
                    $"\"{auditLog.DeviceId}\"\t" +
                    $"\"{auditLog.DeviceName}\"\t" +
                    $"\"{auditLog.CertificateThumbprint}\"\t" +
                    $"\"{auditLog.ApproverName}\"\t" +
                    $"\"{auditLog.ActionTimestamp:yyyy-MM-dd'T'HH:mm:ss'Z'}\"\t" +
                    $"\"{auditLog.Reason}\"\t" +
                    $"\"{auditLog.ActionType}\"\t" +
                    $"\"{auditLog.ActionStatus}\"\t" +
                    $"\"{auditLog.CertificateSubject}\"\t" +
                    $"\"{auditLog.Comments}\"";

                _auditLogDriver.WriteLog(auditLogMessage);
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), RequestStatusConstants.AUDIT_LOG_RECORD_STORED_MESSAGE, auditLog.RequestId ?? string.Empty, auditLog.ActionStatus ?? string.Empty);
            }
            else
            {
                throw new ArgumentNullException(nameof(auditLog));
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), AuditServiceLogConstants.AUDIT_RECORD_SAVE_FAILED, auditLog?.RequestId ?? string.Empty, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Stores an audit log record for an approval, rejection or expiry action.
    /// The action time is set to the current UTC time.
    /// </summary>
    /// <param name="auditLog">
    /// Audit record with the request, device, certificate and action details.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the audit log is null.
    /// </exception>
    public void CreateAuditLog(AuditLog auditLog)
    {
        ArgumentNullException.ThrowIfNull(auditLog);

        auditLog.ActionTimestamp = DateTime.UtcNow;
        SaveAuditLog(auditLog);
    }

    /// <summary>
    /// Reads the audit history, ordered by action time.
    /// </summary>
    /// <returns>
    /// The audit log records.
    /// </returns>
    public IEnumerable<AuditLog> GetAuditHistory()
    {
        try
        {
            IEnumerable<string> logs = _auditLogDriver.ReadLogs();

            List<AuditLog> parsedLogs = new();

            int skippedLines = 0;

            foreach (string line in logs.Skip(1))
            {
                if (TryParseAuditLogLine(line, out AuditLog? auditLog))
                {
                    parsedLogs.Add(auditLog);
                }
                else
                {
                    skippedLines++;
                }
            }

            if (skippedLines > 0)
            {
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), AuditServiceLogConstants.AUDIT_LINE_SKIPPED, skippedLines.ToString());
            }

            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), AuditServiceLogConstants.AUDIT_HISTORY_READ, parsedLogs.Count.ToString());

            return parsedLogs
                .OrderBy(log => log.ActionTimestamp)
                .ToList();
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), AuditServiceLogConstants.AUDIT_HISTORY_READ_FAILED, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads one line of the audit log file into an audit log object.
    /// </summary>
    /// <param name="line">The audit log line to read.</param>
    /// <param name="auditLog">
    /// The audit log read from the line, or null when it cannot be read.
    /// </param>
    /// <returns>
    /// True if the line was read, otherwise false.
    /// </returns>
    private static bool TryParseAuditLogLine(string line, out AuditLog auditLog)
    {
        auditLog = null!;

        if (string.IsNullOrWhiteSpace(line))
        {
            return false;
        }

        string[] fields = line.Split('\t');
        if (fields.Length < 12)
        {
            return false;
        }

        if (!int.TryParse(fields[0].Trim('"'), out int auditId))
        {
            return false;
        }

        if (!DateTime.TryParse(fields[6].Trim('"'), CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime actionTimestamp))
        {
            return false;
        }

        auditLog = new AuditLog
        {
            AuditId = auditId,
            RequestId = fields[1].Trim('"'),
            DeviceId = fields[2].Trim('"'),
            DeviceName = fields[3].Trim('"'),
            CertificateThumbprint = fields[4].Trim('"'),
            ApproverName = fields[5].Trim('"'),
            ActionTimestamp = actionTimestamp,
            Reason = fields[7].Trim('"'),
            ActionType = fields[8].Trim('"'),
            ActionStatus = fields[9].Trim('"'),
            CertificateSubject = fields[10].Trim('"'),
            Comments = fields[11].Trim('"')
        };

        return true;
    }

    #endregion
}