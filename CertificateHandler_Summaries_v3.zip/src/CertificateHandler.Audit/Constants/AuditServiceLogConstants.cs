﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Audit.Constants;

/// <summary>
/// Texts written to the Log Monitor by the audit services. The logger fills in the values in the given order.
/// </summary>
public static class AuditServiceLogConstants
{
    #region Whitelist Decisions

    /// <summary>Success message when a whitelist request is approved. The values are the request id, the device and the approver.</summary>
    public const string WHITELIST_APPROVED = "Whitelist request %s for device %s was approved by %s.";

    /// <summary>Success message when a whitelist request is rejected. The values are the request id, the device and the approver.</summary>
    public const string WHITELIST_REJECTED = "Whitelist request %s for device %s was rejected by %s.";

    /// <summary>Error message when the whitelist decision cannot be saved. The values are the decision, the request id and the error.</summary>
    public const string WHITELIST_DECISION_FAILED = "The whitelist %s of request %s could not be recorded: %s";

    /// <summary>Decision name for an approval.</summary>
    public const string DECISION_APPROVAL = "approval";

    /// <summary>Decision name for a rejection.</summary>
    public const string DECISION_REJECTION = "rejection";

    #endregion

    #region Audit History

    /// <summary>Information message when the audit history is read. The value is the number of records.</summary>
    public const string AUDIT_HISTORY_READ = "Audit history read: %s record(s).";

    /// <summary>Error message when the audit history cannot be read. The value is the error.</summary>
    public const string AUDIT_HISTORY_READ_FAILED = "The audit history could not be read: %s";

    /// <summary>Error message when an audit record cannot be saved. The values are the request id and the error.</summary>
    public const string AUDIT_RECORD_SAVE_FAILED = "The audit record of request %s could not be saved: %s";

    /// <summary>Warning message when audit lines cannot be read and are skipped. The value is the number of lines.</summary>
    public const string AUDIT_LINE_SKIPPED = "%s audit line(s) could not be read and were skipped.";

    #endregion
}
