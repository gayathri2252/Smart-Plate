// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Constants;

/// <summary>
/// Platform mapping for local MAXUM device administrators (Windows local group).
/// </summary>
public static class DeviceAdministratorConstants
{
    /// <summary>
    /// Built-in local Administrators group used when no platform group is configured.
    /// </summary>
    public const string DefaultWindowsGroup = "Administrators";

    /// <summary>
    /// MAXUM platform override: local Windows group for device administrators.
    /// </summary>
    public const string PlatformGroupEnvironmentVariable = "MAXUM_DEVICE_ADMINISTRATOR_GROUP";

    /// <summary>
    /// Legacy override for the platform device-administrator group name.
    /// </summary>
    public const string LegacyGroupEnvironmentVariable = "CH_ADMINISTRATOR_GROUP";
}
