﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Constants;

/// <summary>
/// Generates unique message IDs and persists the last generated ID
/// to a file so that numbering continues across application restarts.
/// </summary>
public static class MessageIdGenerator
{
    #region Member Variables

    /// <summary>File that stores the last message ID, so the numbering continues after the application restarts.</summary>
    private const string MESSAGE_ID_FILE = "MessageId.txt";

    /// <summary>Lock that lets only one thread at a time take the next ID and save it to the file.</summary>
    private static readonly object _syncLock = new();

    /// <summary>Last message ID handed out; read from the file at startup, or 1000 when the file is missing or not valid.</summary>
    private static int _currentMessageId = LoadLastMessageId();

    #endregion

    #region Private Methods
    /// <summary>
    /// Loads the last generated message ID from the storage file.
    /// Returns the default value if the file does not exist or contains invalid data.
    /// </summary>
    /// <returns>
    /// The last generated message ID.
    /// </returns>
    private static int LoadLastMessageId()
    {
        if (File.Exists(MESSAGE_ID_FILE))
        {
            string content = File.ReadAllText(MESSAGE_ID_FILE);

            if (int.TryParse(content, out int lastMessageId))
            {
                return lastMessageId;
            }
        }

        return 1000;
    }

    #endregion

    #region Public Methods
    /// <summary>
    /// Generates the next unique message ID, saves it to the storage file,
    /// and returns the generated value.
    /// </summary>
    /// <returns>
    /// The next message ID
    /// </returns>
    public static int Next()
    {
        lock (_syncLock)
        {
            _currentMessageId++;
            int nextMessageId = _currentMessageId;

            try
            {
                File.WriteAllText(
                     MESSAGE_ID_FILE,
                    nextMessageId.ToString());
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                System.Console.WriteLine(ex.Message);
            }

            return nextMessageId;
        }
    }

    #endregion
}