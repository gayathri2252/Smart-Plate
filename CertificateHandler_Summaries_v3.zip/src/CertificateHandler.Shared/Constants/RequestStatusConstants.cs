﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Constants;

/// <summary>
/// Defines status values for certificate requests.
/// </summary>
public static class RequestStatusConstants
{
    #region Member Variables

    /// <summary>
    /// Represents the pending request status.
    /// </summary>
    public const string PENDING = "Pending";

    /// <summary>
    /// Represents the approved request status.
    /// </summary>
    public const string APPROVED = "Approved";

    /// <summary>
    /// Represents the rejected request status.
    /// </summary>
    public const string REJECTED = "Rejected";

    /// <summary>
    /// Represents the expired request status.
    /// </summary>
    public const string EXPIRED = "Expired";

    /// <summary>
    /// Represents the system user.
    /// </summary>
    public const string SYSTEM = "System";

    /// <summary>
    /// Represents the automatic expiry operation.
    /// </summary>
    public const string AUTO_EXPIRY = "AutoExpiry";

    /// <summary>
    /// Indicates that a pending request has expired.
    /// </summary>
    public const string PENDING_REQUEST_EXPIRED = "Pending request expired";

    /// <summary>
    /// Indicates that a request expired automatically.
    /// </summary>
    public const string REQUEST_AUTOMATICALLY_EXPIRED = "Request automatically expired";

    /// <summary>
    /// Message displayed when a request expires due to timeout.
    /// </summary>
    public const string PENDING_REQUEST_EXPIRED_MESSAGE = "The certificate request has been rejected due to timeout with certificate name %s";

    /// <summary>Shown in the expiry message when the request has no certificate name.</summary>
    public const string UNKNOWN_CERTIFICATE_NAME = "Unknown";

    /// <summary>
    /// Message logged when an audit record is stored.
    /// </summary>
    public const string AUDIT_LOG_RECORD_STORED_MESSAGE = "Audit log record stored: %s";

    /// <summary>
    /// Represents a whitelist approval action.
    /// </summary>
    public const string WHITELIST_APPROVAL = "WhitelistApproval";

    /// <summary>
    /// Represents a whitelist rejection action.
    /// </summary>
    public const string WHITELIST_REJECTION = "WhitelistRejection";

    /// <summary>Shown when a rejection is attempted without a reason.</summary>
    public const string REJECTION_REASON_IS_REQUIRED = "Enter a rejection reason before rejecting the request.";

    /// <summary>
    /// Indicates that a request was approved.
    /// </summary>
    public const string REQUEST_APPROVED = "Request approved";

    /// <summary>
    /// Indicates that a request was rejected.
    /// </summary>
    public const string REQUEST_REJECTED = "Request rejected";

    /// <summary>
    /// Message logged when approval is blocked for an expired request.
    /// </summary>
    public const string APPROVAL_BLOCKED_FOR_EXPIRED_REQUEST_MESSAGE = "Approval blocked for expired request. RequestId=%s";

    /// <summary>
    /// Message logged when rejection is blocked for an expired request.
    /// </summary>
    public const string REJECTION_BLOCKED_FOR_EXPIRED_REQUEST_MESSAGE = "Rejection blocked for expired request. RequestId=%s";

    /// <summary>
    /// Error message displayed when approval is not allowed.
    /// </summary>
    public const string REQUEST_EXPIRED_CANNOT_BE_APPROVED = "Request has expired and cannot be approved.";

    /// <summary>
    /// Error message displayed when rejection is not allowed.
    /// </summary>
    public const string REQUEST_EXPIRED_CANNOT_BE_REJECTED = "Request has expired and cannot be rejected";

    /// <summary>Certificate validity cannot be judged when system time is not verified.</summary>
    public const string TIME_UNVERIFIED = "System time could not be verified.";

    /// <summary>
    /// Field name for requester identity.
    /// </summary>
    public const string REQUESTER_IDENTITY_FIELD = "RequesterIdentity";

    /// <summary>
    /// Field name for requested by.
    /// </summary>
    public const string REQUESTED_BY_FIELD = "RequestedBy";

    /// <summary>
    /// Field name for current status.
    /// </summary>
    public const string CURRENT_STATUS_FIELD = "CurrentStatus";

    /// <summary>
    /// Field name for MAXUM IP address.
    /// </summary>
    public const string MAXUM_IP_ADDRESS_FIELD = "MaxumIpAddress";

    /// <summary>
    /// Field name for request date.
    /// </summary>
    public const string REQUEST_DATE_FIELD = "RequestDate";

    /// <summary>
    /// Message displayed when the user is not authorized to search.
    /// </summary>
    public const string UNAUTHORIZED_SEARCH_MESSAGE = "You are not authorized to perform search operations.";

    /// <summary>
    /// Represents all status values.
    /// </summary>
    public const string ALL = "All";

    /// <summary>
    /// Field name for request identifier.
    /// </summary>
    public const string REQUEST_ID_FIELD = "RequestId";

    /// <summary>
    /// Field name for device identifier.
    /// </summary>
    public const string DEVICE_IDENTIFIER_FIELD = "DeviceIdentifier";

    /// <summary>
    /// Field name for request type.
    /// </summary>
    public const string REQUEST_TYPE_FIELD = "RequestType";

    /// <summary>
    /// Date format in ISO yyyy-MM-dd format.
    /// </summary>
    public const string DATE_FORMAT_ISO = "yyyy-MM-dd";

    /// <summary>
    /// Date and time in ISO 8601 format, such as 2026-10-14T10:30:00; used to search on the request date as shown.
    /// </summary>
    public const string DATE_TIME_FORMAT_ISO = "yyyy-MM-dd'T'HH:mm:ss";

    /// <summary>
    /// Error message displayed for invalid credentials.
    /// </summary>
    public const string INVALID_CREDENTIALS_MESSAGE = "Invalid username or password.";

    // Local Windows sign-in. The password is never part of any message.

    /// <summary>Logged when a user signs in successfully.</summary>
    public const string SIGN_IN_SUCCEEDED = "User %s signed in with a local Windows account.";

    /// <summary>Logged when the user name or password is wrong.</summary>
    public const string SIGN_IN_REJECTED = "Sign-in rejected for user %s: wrong user name or password.";

    /// <summary>Logged when Windows requires the user to change the password first.</summary>
    public const string PASSWORD_MUST_CHANGE = "Sign-in rejected for user %s: Windows requires the password to be changed first.";

    /// <summary>Logged when the account is disabled, locked out or expired; the text carries the Windows error code.</summary>
    public const string ACCOUNT_DISABLED = "Sign-in rejected for user %s: the account is disabled, locked out or expired (Windows error %s).";

    /// <summary>Logged when a Windows policy does not allow the user to log on to this machine.</summary>
    public const string LOGON_NOT_GRANTED = "Sign-in rejected for user %s: a Windows policy does not allow this account to log on to this machine.";

    /// <summary>Logged when the password is correct but the user is not in the administrator group.</summary>
    public const string USER_NOT_IN_GROUP = "Sign-in rejected for user %s: the user is not in the local group %s.";

    /// <summary>Logged when the configured administrator group does not exist on this machine.</summary>
    public const string ADMINISTRATOR_GROUP_NOT_FOUND = "Sign-in rejected: the local group %s does not exist on this machine.";

    /// <summary>Logged when Windows could not check the sign-in; the text carries the error.</summary>
    public const string SIGN_IN_CHECK_FAILED = "The sign-in of user %s could not be checked because of an error: %s";

    /// <summary>Thrown when the authenticator is created without a group name.</summary>
    public const string ADMINISTRATOR_GROUP_IS_BLANK = "The administrator group must not be blank.";

    /// <summary>Shown when the password is correct but the user is not a local device administrator.</summary>
    public const string NOT_AUTHORIZED_FOR_USER = "This user is not a local device administrator. The account must be in the {0} Windows group on this device.";

    /// <summary>Shown when Windows requires the password to be changed first.</summary>
    public const string PASSWORD_MUST_CHANGE_FOR_USER = "Windows requires this user to change the password first. Change it, then sign in again.";

    /// <summary>Shown when the account is disabled, locked out or expired.</summary>
    public const string ACCOUNT_DISABLED_FOR_USER = "This Windows account is disabled or locked. Ask your administrator to enable it.";

    /// <summary>Shown when Windows could not check the sign-in.</summary>
    public const string SIGN_IN_UNAVAILABLE_FOR_USER = "The sign-in could not be checked. Please try again.";

    /// <summary>
    /// Error message used when a signed-in user is created without a name.
    /// </summary>
    public const string SIGNED_IN_USER_NAME_IS_BLANK = "The signed-in user must have a name.";

    /// <summary>
    /// Default title used for error dialogs.
    /// </summary>
    public const string ERROR_TITLE = "Error";

    /// <summary>
    /// Logger facility name.
    /// </summary>
    public const string FACILITY_NAME = "CertificateHandler";

    /// <summary>
    /// Error message when certificate selector is null.
    /// </summary>
    public const string SELECTOR_IS_NULL = "Certificate selector is null.";

    /// <summary>
    /// Error message when thumbprint is missing.
    /// </summary>
    public const string THUMBPRINT_IS_REQUIRED = "Certificate thumbprint is required.";

    /// <summary>
    /// Indicates TPM certificate retrieval is not implemented.
    /// </summary>
    public const string TPM_RETRIEVAL_NOT_IMPLEMENTED = "TPM certificate retrieval is not implemented.";

    /// <summary>
    /// Indicates TPM chain retrieval is not implemented.
    /// </summary>
    public const string TPM_CHAIN_RETRIEVAL_NOT_IMPLEMENTED = "TPM certificate-chain retrieval is not implemented.";

    /// <summary>
    /// Indicates certificate listing is not applicable for TPM.
    /// </summary>
    public const string TPM_LIST_NOT_APPLICABLE = "ListCertificates is not applicable to the TPM backend.";

    /// <summary>
    /// Error message when chain thumbprint is required.
    /// </summary>
    public const string CHAIN_THUMBPRINT_IS_REQUIRED = "Thumbprint is required.";

    /// <summary>
    /// Error message when certificate chain verification fails.
    /// </summary>
    public const string CHAIN_INCOMPLETE = "Certificate chain is incomplete or could not be fully verified.";

    /// <summary>
    /// Message displayed when no pending requests are found.
    /// </summary>
    public const string NO_PENDING_REQUESTS_FOUND = "There is no pending certificate request found in the last %s hours.";

    /// <summary>
    /// Message displayed when a request was already processed.
    /// </summary>
    public const string REQUEST_ALREADY_DECIDED = "Request %s was already decided before it could be expired.";

    /// <summary>
    /// Message displayed when request data is missing.
    /// </summary>
    public const string REQUEST_DATA_MISSING = "A stored pending request had no data and was skipped.";

    /// <summary>
    /// Error message when request expiry processing fails.
    /// </summary>
    public const string REQUEST_EXPIRY_FAILED = "Pending request %s could not be expired: %s";

    /// <summary>
    /// Error message when expiry check fails.
    /// </summary>
    public const string EXPIRY_CHECK_FAILED = "Pending request expiry check failed: %s";

    #endregion
}