﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Constants;

/// <summary>
/// Constants (including message texts) for the signed-in user, so wording can be changed in one place.
/// </summary>
public static class UserConstants
{
    #region Member Variables

    /// <summary>Thrown when a signed-in user is created without a name.</summary>
    public const string SIGNED_IN_USER_NAME_IS_BLANK = "The signed-in user must have a name.";

    #endregion
}