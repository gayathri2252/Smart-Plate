// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Administrator decision on one pending onboarding request.
/// </summary>
public sealed class PendingRequestDecision
{
    #region Public Properties

    /// <summary>Pending request identifier.</summary>
    public string RequestId { get; init; } = string.Empty;

    /// <summary>Signed-in administrator identity.</summary>
    public string ActorIdentity { get; init; } = string.Empty;

    /// <summary>Optional reason (required for rejection per RS_19).</summary>
    public string? Reason { get; init; }

    #endregion
}
