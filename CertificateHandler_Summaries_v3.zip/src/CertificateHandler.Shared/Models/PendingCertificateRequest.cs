﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Represents a pending certificate request.
/// </summary>
public class PendingCertificateRequest
{
    #region Public Properties

    /// <summary>
    /// Gets or sets the unique identifier of the certificate request.
    /// </summary>
    public string RequestID { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the identifier of the device associated with the request.
    /// </summary>
    public string DeviceID { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the name of the certificate being requested.
    /// </summary>
    public string CertificateName { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the current status of the certificate request.
    /// </summary>
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the date and time when the request was created.
    /// </summary>
    public DateTime CreatedTime { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Gets or sets the certificate expiry date and time, if available.
    /// </summary>
    public DateTime? ExpiryTime { get; set; }

    #endregion


}