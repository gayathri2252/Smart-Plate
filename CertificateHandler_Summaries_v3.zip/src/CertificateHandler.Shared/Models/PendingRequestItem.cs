﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Represents a pending certificate request displayed
/// in the request screen.
/// </summary>
public class PendingRequestItem
{
    #region Public Properties
    /// <summary>
    /// Unique identifier of the pending request.
    /// </summary>
    public string RequestId { get; set; } = string.Empty;

    /// <summary>
    /// Identifier of the device associated with the request.
    /// </summary>
    public string DeviceIdentifier { get; set; } = string.Empty;

    /// <summary>
    /// Type of pending request.
    /// </summary>
    public string RequestType { get; set; } = string.Empty;

    /// <summary>
    /// Identity of the user who initiated the request.
    /// </summary>
    public string RequesterIdentity { get; set; } = string.Empty;

    /// <summary>
    /// Name of the user who submitted the request.
    /// </summary>
    public string RequestedBy { get; set; } = string.Empty;

    /// <summary>
    /// Date and time when the request was created.
    /// </summary>
    public DateTime RequestDate { get; set; }

    /// <summary>
    /// Current status of the request.
    /// </summary>
    public string CurrentStatus { get; set; } = string.Empty;

    /// <summary>
    /// MAXUM device IP address.
    /// </summary>
    public string MaxumIpAddress { get; set; } = string.Empty;

    /// <summary>
    /// SHA-256 thumbprint of the certificate.
    /// </summary>
    public string CertificateThumbprint { get; set; } = string.Empty;

    /// <summary>
    /// Subject distinguished name of the certificate.
    /// </summary>
    public string CertificateSubject { get; set; } = string.Empty;

    /// <summary>
    /// Expiration date of the pending request.
    /// </summary>
    public DateTime? ExpirationDate { get; set; }

    /// <summary>
    /// Start of the certificate validity period (not before), in UTC; null when unknown.
    /// </summary>
    public DateTime? CertificateValidFrom { get; set; }

    /// <summary>
    /// End of the certificate validity period (not after), in UTC; null when unknown.
    /// </summary>
    public DateTime? CertificateValidTo { get; set; }

    /// <summary>
    /// True when the certificate validity period has already ended.
    /// </summary>
    public bool IsCertificateExpired => CertificateValidTo.HasValue && CertificateValidTo.Value < DateTime.UtcNow;

    #endregion
}
