﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Shared.Models;

/// <summary>
/// The user who signed in to the Certificate Handler UI and the role that decides what the user may see.
/// It is created once at login and passed to the screens that check the role.
/// </summary>
public sealed class SignedInUser
{
    #region Constructor

    /// <summary>
    /// Creates the signed-in user with the given name and role. The name must not be null or blank.
    /// </summary>
    /// <param name="userName">Name the user signed in with.</param>
    /// <param name="isDeviceAdministrator">True when the user has the device-administrator role.</param>
    public SignedInUser(string userName, bool isDeviceAdministrator)
    {
        // A user without a name cannot be shown in the log or traced back.
        if (string.IsNullOrWhiteSpace(userName))
        {
            throw new ArgumentException(RequestStatusConstants.SIGNED_IN_USER_NAME_IS_BLANK, nameof(userName));
        }

        UserName = userName.Trim();
        IsDeviceAdministrator = isDeviceAdministrator;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Name the user signed in with.
    /// </summary>
    public string UserName { get; }

    /// <summary>
    /// True when the user has the device-administrator role and may see the trust state of the device.
    /// </summary>
    public bool IsDeviceAdministrator { get; }

    #endregion
}