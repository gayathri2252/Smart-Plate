﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Represents the timeout configuration used to determine
/// when a pending certificate request should be automatically
/// marked as expired.
/// </summary>
public class TimeoutConfiguration
{
    #region Public Properties

    /// <summary>
    /// Gets or sets the pending request expiry timeout in hours.
    /// Default value is 24 hours.
    /// </summary>
    public int PendingRequestExpiryTimeout { get; set; } = 24;

    /// <summary>
    /// Gets or sets how often, in milliseconds, the expiry timer looks for expired requests.
    /// Default value is 60000 (one minute).
    /// </summary>
    public double ExpiryCheckIntervalMilliseconds { get; set; } = 60000;

    #endregion
}
