﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Number of certificate requests in each status, shown on the status tabs of the Request Queue screen.
/// </summary>
public class RequestStatusCounts
{
    #region Public Properties

    /// <summary>
    /// Requests that wait for a decision and whose certificate is still valid.
    /// </summary>
    public int Pending { get; set; }

    /// <summary>
    /// Requests that were approved.
    /// </summary>
    public int Approved { get; set; }

    /// <summary>
    /// Requests that were rejected.
    /// </summary>
    public int Rejected { get; set; }

    /// <summary>
    /// Requests that expired, including pending requests whose certificate is no longer valid.
    /// </summary>
    public int Expired { get; set; }

    #endregion
}
