﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Models;

/// <summary>
/// Settings of the pending queue that holds unknown peers until an administrator decides on them.
/// Read from the "CertificateHandler:PendingQueue" section of appsettings.json.
/// </summary>
public sealed class PendingQueueOptions
{
    #region Member Variables

    /// <summary>Configuration section that holds these settings.</summary>
    public const string SECTION_NAME = "CertificateHandler:PendingQueue";

    /// <summary>Number of open requests allowed when nothing, or a value below 1, is configured.</summary>
    public const int DEFAULT_MAX_PENDING_CONNECTIONS = 10;

    /// <summary>Smallest number of open requests that can be configured.</summary>
    public const int MIN_PENDING_CONNECTIONS = 1;

    #endregion

    #region Public Properties

    /// <summary>
    /// Most open requests from unknown peers the queue holds at the same time. A new unknown peer is
    /// refused while this many requests wait for a decision, so many new certificates cannot exhaust
    /// the listener. Default 10.
    /// </summary>
    public int MaxPendingConnections { get; set; } = DEFAULT_MAX_PENDING_CONNECTIONS;

    /// <summary>True when the configured limit can be used; false when it is below 1.</summary>
    public bool IsMaxPendingConnectionsValid => MaxPendingConnections >= MIN_PENDING_CONNECTIONS;

    /// <summary>The configured limit, or the default of 10 when the configured value is below 1.</summary>
    public int EffectiveMaxPendingConnections => IsMaxPendingConnectionsValid ? MaxPendingConnections : DEFAULT_MAX_PENDING_CONNECTIONS;

    #endregion
}
