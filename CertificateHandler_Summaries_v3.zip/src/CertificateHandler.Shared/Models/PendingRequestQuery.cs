﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Shared.Models;

/// <summary>
/// The filter, sort and paging settings of the request queue, kept together so that sorting
/// and moving between pages always use the same active filters.
/// </summary>
public sealed class PendingRequestQuery
{
    #region Member Variables

    /// <summary>Number of the first page.</summary>
    public const int FIRST_PAGE_NUMBER = 1;

    /// <summary>Number of requests on a page until the user picks another page size.</summary>
    public const int DEFAULT_PAGE_SIZE = 10;

    #endregion

    #region Public Properties

    /// <summary>Text searched for in the request fields; empty for no search.</summary>
    public string SearchText { get; set; } = string.Empty;

    /// <summary>Status the requests must have; <see cref="RequestStatusConstants.ALL"/> for any status.</summary>
    public string Status { get; set; } = RequestStatusConstants.ALL;

    /// <summary>Earliest request date and time; null for no lower limit.</summary>
    public DateTime? FromDate { get; set; }

    /// <summary>Latest request date and time; null for no upper limit.</summary>
    public DateTime? ToDate { get; set; }

    /// <summary>Text the MAXUM IP address must contain; empty for any address.</summary>
    public string MaxumIp { get; set; } = string.Empty;

    /// <summary>Name of the field the requests are sorted by.</summary>
    public string SortField { get; set; } = RequestStatusConstants.REQUEST_DATE_FIELD;

    /// <summary>True to sort from low to high.</summary>
    public bool SortAscending { get; set; } = true;

    /// <summary>Number of the page shown, starting at <see cref="FIRST_PAGE_NUMBER"/>.</summary>
    public int PageNumber { get; set; } = FIRST_PAGE_NUMBER;

    /// <summary>Maximum number of requests on a page.</summary>
    public int PageSize { get; set; } = DEFAULT_PAGE_SIZE;

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns a copy of this query, so a caller can read the active settings without changing them.
    /// </summary>
    /// <returns>A new query with the same settings.</returns>
    public PendingRequestQuery Copy()
    {
        return new PendingRequestQuery
        {
            SearchText = SearchText,
            Status = Status,
            FromDate = FromDate,
            ToDate = ToDate,
            MaxumIp = MaxumIp,
            SortField = SortField,
            SortAscending = SortAscending,
            PageNumber = PageNumber,
            PageSize = PageSize
        };
    }

    #endregion
}
