// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Security;

/// <summary>
/// Production builds ignore dangerous CH_* bypass environment variables (unless compiling DEBUG).
/// </summary>
public static class DevelopmentBypassGuard
{
    public static bool IsBypassEnabled(string environmentVariableName)
    {
        ArgumentException.ThrowIfNullOrEmpty(environmentVariableName);

        string? value = Environment.GetEnvironmentVariable(environmentVariableName);
        if (string.IsNullOrEmpty(value))
        {
            return false;
        }

        bool flag = string.Equals(value, "1", StringComparison.Ordinal)
                    || string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);

        if (!flag)
        {
            return false;
        }

#if DEBUG
        return true;
#else
        return false;
#endif
    }
}
