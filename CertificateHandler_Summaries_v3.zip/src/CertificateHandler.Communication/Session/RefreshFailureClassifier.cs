﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using System.Net.Sockets;

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Checks if a refresh error was caused by a lost or weak network connection. These errors keep the session and are tried again. All other errors are not tried again.
/// </summary>
public static class RefreshFailureClassifier
{
    #region Member Variables

    /// <summary>
    /// HTTP status codes that count as a network failure, so the refresh is tried again later.
    /// </summary>
    private static readonly HashSet<HttpStatusCode> _transientStatusCodes = new()
    {
        HttpStatusCode.RequestTimeout,
        HttpStatusCode.BadGateway,
        HttpStatusCode.ServiceUnavailable,
        HttpStatusCode.GatewayTimeout
    };

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if the error, or any inner error, shows that the server could not be reached.
    /// This covers no connection, DNS errors, socket or network errors, timeouts and gateway or service unavailable answers.
    /// </summary>
    /// <param name="exception">The error to check.</param>
    /// <returns>True if it is a network error, otherwise false.</returns>
    public static bool IsNetworkFailure(Exception? exception)
    {
        for (Exception? current = exception; current is not null; current = current.InnerException)
        {
            switch (current)
            {
                case SessionRejectedException:
                    return false;

                case HttpRequestException httpException:
                    if (httpException.StatusCode is null ||
                        _transientStatusCodes.Contains(httpException.StatusCode.Value))
                    {
                        return true;
                    }

                    return false;

                case SocketException:
                case IOException:
                case TimeoutException:
                case TaskCanceledException:
                    return true;
            }
        }

        return false;
    }

    #endregion
}
