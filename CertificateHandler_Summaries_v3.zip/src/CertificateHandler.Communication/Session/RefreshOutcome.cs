﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Result of one session refresh request.
/// </summary>
public enum RefreshOutcome
{
    /// <summary>The tokens were refreshed.</summary>
    Succeeded,

    /// <summary>The network was lost. The session is kept and the retries have started.</summary>
    NetworkFailure,

    /// <summary>Retries are already running, so this request was not sent.</summary>
    RecoveryInProgress,

    /// <summary>The server refused the refresh and the session has ended.</summary>
    SessionRejected,

    /// <summary>An error that was not expected happened. The session is kept.</summary>
    Failed,

    /// <summary>No user is signed in.</summary>
    NoSession,

    /// <summary>The user signed out or signed in again while the request ran, so the result was ignored.</summary>
    SessionChanged
}
