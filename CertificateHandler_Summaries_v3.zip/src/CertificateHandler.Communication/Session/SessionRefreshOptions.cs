﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Communication.Constants;

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Settings for the session refresh, read from the session refresh section of appsettings.json.
/// </summary>
public sealed class SessionRefreshOptions
{
    #region Public Properties

    /// <summary>
    /// URL of the token refresh endpoint.
    /// </summary>
    public string RefreshEndpoint { get; set; } = string.Empty;

    /// <summary>
    /// Number of seconds before the access token expires when the refresh starts.
    /// </summary>
    public int RefreshBeforeExpirySeconds { get; set; } = SessionRefreshConstants.DEFAULT_REFRESH_BEFORE_EXPIRY_SECONDS;

    /// <summary>
    /// Wait in seconds before the first retry after a network failure.
    /// </summary>
    public int RetryInitialDelaySeconds { get; set; } = SessionRefreshConstants.DEFAULT_RETRY_INITIAL_DELAY_SECONDS;

    /// <summary>
    /// Longest wait in seconds between two retries.
    /// </summary>
    public int RetryMaxDelaySeconds { get; set; } = SessionRefreshConstants.DEFAULT_RETRY_MAX_DELAY_SECONDS;

    /// <summary>
    /// Timeout in seconds for one refresh call.
    /// </summary>
    public int RequestTimeoutSeconds { get; set; } = SessionRefreshConstants.DEFAULT_REQUEST_TIMEOUT_SECONDS;

    /// <summary>
    /// Number of seconds the connection restored message stays on the screen.
    /// </summary>
    public int NotificationDisplaySeconds { get; set; } = SessionRefreshConstants.DEFAULT_NOTIFICATION_DISPLAY_SECONDS;

    #endregion
}
