﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Communication.Session;

namespace CertificateHandler.Communication.Interface;

/// <summary>
/// Calls the service that gives a new access token for a refresh token.
/// </summary>
public interface ITokenRefreshClient
{
    /// <summary>
    /// Asks for new tokens for the given session.
    /// Throws SessionRejectedException when the server refuses the refresh, and a network error when the server cannot be reached.
    /// </summary>
    /// <param name="current">The current session token.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The new session token.</returns>
    Task<SessionToken> RefreshAsync(SessionToken current, CancellationToken cancellationToken);
}
