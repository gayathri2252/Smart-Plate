﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Interface;

/// <summary>
/// Shows session refresh messages to the user. The UI gives the code for it.
/// </summary>
public interface ISessionNotifier
{
    /// <summary>
    /// Shows that the refresh failed because the network was lost and that the session is kept.
    /// </summary>
    /// <param name="message">Message to show.</param>
    void NotifyRefreshFailed(string message);

    /// <summary>
    /// Shows that the refresh worked after the network came back.
    /// </summary>
    /// <param name="message">Message to show.</param>
    void NotifyRefreshRecovered(string message);
}
