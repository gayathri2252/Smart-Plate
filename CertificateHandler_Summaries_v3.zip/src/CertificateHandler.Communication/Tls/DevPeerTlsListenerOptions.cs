// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Older environment settings for the peer listener. They are turned into MaxumConnectionManagerOptions.
/// </summary>
public sealed class DevPeerTlsListenerOptions
{
    #region Public Properties

    /// <summary>
    /// IP address the listener uses.
    /// </summary>
    public IPAddress BindAddress { get; init; } = IPAddress.Loopback;

    /// <summary>
    /// Port the listener listens on.
    /// </summary>
    public int Port { get; init; } = 17443;

    /// <summary>
    /// SHA256 thumbprint of the server certificate.
    /// </summary>
    public string ServerThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>
    /// Certificate store location that has the server certificate.
    /// </summary>
    public StoreLocationName StoreLocation { get; init; } = StoreLocationName.LocalMachine;

    /// <summary>
    /// Most connections that can be handled at the same time.
    /// </summary>
    public int MaxConcurrentConnections { get; init; } = 32;

    /// <summary>
    /// True to check if certificates are revoked during the TLS handshake.
    /// </summary>
    public bool CheckCertificateRevocation { get; init; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the settings from the environment variables.
    /// </summary>
    /// <returns>The listener settings.</returns>
    public static DevPeerTlsListenerOptions FromEnvironment()
    {
        MaxumConnectionManagerOptions options = MaxumConnectionManagerOptions.FromEnvironment();
        return new DevPeerTlsListenerOptions
        {
            BindAddress = options.BindAddress,
            Port = options.ListenPort,
            ServerThumbprintSha256 = options.DeviceCertThumbprintSha256,
            StoreLocation = options.StoreLocation,
            MaxConcurrentConnections = options.MaxConcurrentConnections,
            CheckCertificateRevocation = options.CheckCertificateRevocation
        };
    }

    /// <summary>
    /// Copies these settings into connection manager settings.
    /// </summary>
    /// <returns>The connection manager settings.</returns>
    internal MaxumConnectionManagerOptions ToConnectionManagerOptions() =>
        new()
        {
            ListenEnabled = true,
            BindAddress = BindAddress,
            ListenPort = Port,
            DefaultPeerPort = Port,
            DeviceCertThumbprintSha256 = ServerThumbprintSha256,
            StoreLocation = StoreLocation,
            MaxConcurrentConnections = MaxConcurrentConnections,
            CheckCertificateRevocation = CheckCertificateRevocation
        };

    #endregion
}

/// <summary>
/// Places where the device certificate can be stored.
/// </summary>
public enum StoreLocationName
{
    /// <summary>
    /// Store of the local machine.
    /// </summary>
    LocalMachine,

    /// <summary>
    /// Store of the current user.
    /// </summary>
    CurrentUser
}
