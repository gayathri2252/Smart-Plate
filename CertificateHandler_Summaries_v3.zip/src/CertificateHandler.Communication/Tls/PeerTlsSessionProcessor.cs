// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using PeerCertificateRequest = CertificateHandler.DeviceTrust.Models.CertificateRequest;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Sends a TLS session through PeerConnectionPipeline after mutual TLS is done.
/// </summary>
public static class PeerTlsSessionProcessor
{
    #region Public Methods

    /// <summary>
    /// Runs the trust check for an incoming TLS session.
    /// When asked, it sends CH OK or CH DENY back to the peer.
    /// </summary>
    /// <param name="sslStream">TLS stream of the session.</param>
    /// <param name="pipeline">Checks and approves the peer certificate.</param>
    /// <param name="remoteIp">IP address of the peer, or null if not known.</param>
    /// <param name="correlationId">Id of the connection.</param>
    /// <param name="sendStatusLine">True to send the result to the peer.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the trust check.</returns>
    /// <exception cref="ArgumentNullException">Thrown when the stream or the pipeline is null.</exception>
    public static async Task<PeerTlsGateOutcome> ProcessInboundAsync(
        SslStream sslStream,
        IPeerConnectionPipeline pipeline,
        string? remoteIp,
        string correlationId,
        bool sendStatusLine,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);
        ArgumentNullException.ThrowIfNull(pipeline);

        if (sslStream.RemoteCertificate is null)
        {
            return PeerTlsGateOutcome.Denied("No peer certificate presented.");
        }

        using var clientCertificate = new X509Certificate2(sslStream.RemoteCertificate);
        PeerCertificateRequest request = DevPeerTlsRequestFactory.FromClientCertificate(
            clientCertificate,
            remoteIp,
            sslStream.IsMutuallyAuthenticated);

        PeerConnectionPipelineResult result = await pipeline
            .ProcessAsync(request, correlationId, cancellationToken)
            .ConfigureAwait(false);

        if (sendStatusLine)
        {
            string line = result.TlsAllowed ? "CH-OK" : "CH-DENY";
            byte[] payload = Encoding.ASCII.GetBytes(line + "\r\n");
            await sslStream.WriteAsync(payload, cancellationToken).ConfigureAwait(false);
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Peer TLS gate %s from %s thumbprint %s decision %s tls=%s",
            correlationId,
            remoteIp ?? "?",
            request.Peer?.ThumbprintSha256 ?? "?",
            result.Authorization.Decision.ToString(),
            result.TlsAllowed.ToString());

        return new PeerTlsGateOutcome
        {
            Allowed = result.TlsAllowed,
            PipelineResult = result,
            ThumbprintSha256 = request.Peer?.ThumbprintSha256 ?? string.Empty
        };
    }

    /// <summary>
    /// Runs the trust check for an outgoing TLS session.
    /// </summary>
    /// <param name="sslStream">TLS stream of the session.</param>
    /// <param name="pipeline">Checks and approves the peer certificate.</param>
    /// <param name="peerHost">Host name or IP address of the peer.</param>
    /// <param name="correlationId">Id of the connection.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the trust check.</returns>
    /// <exception cref="ArgumentNullException">Thrown when the stream or the pipeline is null.</exception>
    public static async Task<PeerTlsGateOutcome> ProcessOutboundPeerAsync(
        SslStream sslStream,
        IPeerConnectionPipeline pipeline,
        string peerHost,
        string correlationId,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);
        ArgumentNullException.ThrowIfNull(pipeline);

        if (sslStream.RemoteCertificate is null)
        {
            return PeerTlsGateOutcome.Denied("No peer certificate in TLS handshake.");
        }

        using var peerCertificate = new X509Certificate2(sslStream.RemoteCertificate);
        PeerCertificateRequest request = DevPeerTlsRequestFactory.FromClientCertificate(
            peerCertificate,
            peerHost,
            sslStream.IsMutuallyAuthenticated);

        PeerConnectionPipelineResult result = await pipeline
            .ProcessAsync(request, correlationId, cancellationToken)
            .ConfigureAwait(false);

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Outbound peer TLS gate %s to %s thumbprint %s decision %s tls=%s",
            correlationId,
            peerHost,
            request.Peer?.ThumbprintSha256 ?? "?",
            result.Authorization.Decision.ToString(),
            result.TlsAllowed.ToString());

        return new PeerTlsGateOutcome
        {
            Allowed = result.TlsAllowed,
            PipelineResult = result,
            ThumbprintSha256 = request.Peer?.ThumbprintSha256 ?? string.Empty
        };
    }

    #endregion
}

/// <summary>
/// Result of the trust check for a TLS session.
/// </summary>
public sealed class PeerTlsGateOutcome
{
    /// <summary>
    /// True when the connection is allowed.
    /// </summary>
    public bool Allowed { get; init; }

    /// <summary>
    /// Result of the connection pipeline. Null when the check did not run.
    /// </summary>
    public PeerConnectionPipelineResult? PipelineResult { get; init; }

    /// <summary>
    /// SHA256 thumbprint of the peer certificate.
    /// </summary>
    public string ThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>
    /// Why the connection was denied. Null when it is allowed.
    /// </summary>
    public string? DenyReason { get; init; }

    /// <summary>
    /// Creates a denied result.
    /// </summary>
    /// <param name="reason">Why the connection was denied.</param>
    /// <returns>The denied result.</returns>
    public static PeerTlsGateOutcome Denied(string reason) =>
        new() { Allowed = false, DenyReason = reason };
}
