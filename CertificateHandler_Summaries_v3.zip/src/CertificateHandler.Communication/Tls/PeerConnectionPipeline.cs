// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.DeviceTrust.Services;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Entry point for the MAXUM listener. It checks the certificate, decides if the peer is trusted and controls the TLS connection.
/// </summary>
public sealed class PeerConnectionPipeline : IPeerConnectionPipeline
{
    #region Member Variables

    /// <summary>
    /// Checks the certificate sent by the peer.
    /// </summary>
    private readonly CertificateValidationEngine _validationEngine;

    /// <summary>
    /// Decides if the certificate request is allowed.
    /// </summary>
    private readonly CertificateRequestAuthorizationService _authorizationService;

    /// <summary>
    /// Decides if the TLS session can start.
    /// </summary>
    private readonly TlsConnectionManager _tlsConnectionManager;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the connection pipeline.
    /// </summary>
    /// <param name="validationEngine">Checks the certificate sent by the peer.</param>
    /// <param name="authorizationService">Decides if the certificate request is allowed.</param>
    /// <param name="tlsConnectionManager">Decides if the TLS session can start.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    public PeerConnectionPipeline(
        CertificateValidationEngine validationEngine,
        CertificateRequestAuthorizationService authorizationService,
        TlsConnectionManager tlsConnectionManager)
    {
        _validationEngine = validationEngine ?? throw new ArgumentNullException(nameof(validationEngine));
        _authorizationService = authorizationService ?? throw new ArgumentNullException(nameof(authorizationService));
        _tlsConnectionManager = tlsConnectionManager ?? throw new ArgumentNullException(nameof(tlsConnectionManager));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks the peer certificate, decides if it is allowed, and tells if TLS can go on.
    /// TLS is allowed only when the request is allowed and the connection is let in.
    /// </summary>
    /// <param name="request">The certificate request of the peer.</param>
    /// <param name="correlationId">Id of the connection, or null if not known.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the check.</returns>
    /// <exception cref="ArgumentNullException">Thrown when the request is null.</exception>
    public async Task<PeerConnectionPipelineResult> ProcessAsync(
        CertificateRequest request,
        string? correlationId,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        string thumbprint = request.Peer?.ThumbprintSha256 ?? request.ValidationResult?.ThumbprintSha256 ?? string.Empty;
        TrustValidationResult validation = request.ValidationResult ?? await RunValidationAsync(request, thumbprint, cancellationToken);

        var enriched = new CertificateRequest
        {
            Peer = request.Peer,
            IsAuthenticated = request.IsAuthenticated,
            ValidationResult = validation,
            PresentedCertificateDer = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer
        };

        CertificateRequestAuthorizationResult auth = await _authorizationService.AuthorizeAsync(enriched, cancellationToken);
        bool tlsAllowed = await _tlsConnectionManager.MayStartTlsAsync(thumbprint, correlationId, cancellationToken);

        return new PeerConnectionPipelineResult
        {
            Validation = validation,
            Authorization = auth,
            TlsAllowed = tlsAllowed && auth.Decision == CertificateRequestDecision.Allowed
        };
    }

    /// <summary>
    /// Checks the certificate the peer sent. When no certificate data was sent, the certificate is read from the store by its thumbprint.
    /// </summary>
    /// <param name="request">The certificate request of the peer.</param>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The validation result.</returns>
    private Task<TrustValidationResult> RunValidationAsync(
        CertificateRequest request,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        byte[]? der = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer;
        if (der is { Length: > 0 })
        {
            return _validationEngine.ValidatePresentedCertificateAsync(der, expectedThumbprintSha256: thumbprint, deviceId: null, cancellationToken);
        }

        return _validationEngine.ValidateAsync(thumbprint, null, cancellationToken);
    }

    #endregion
}

/// <summary>
/// Result of the connection pipeline.
/// </summary>
public sealed class PeerConnectionPipelineResult
{
    /// <summary>
    /// Result of the certificate check.
    /// </summary>
    public TrustValidationResult Validation { get; init; } = new();

    /// <summary>
    /// Result of the request approval.
    /// </summary>
    public CertificateRequestAuthorizationResult Authorization { get; init; } = new();

    /// <summary>
    /// True when the TLS session is allowed.
    /// </summary>
    public bool TlsAllowed { get; init; }
}
