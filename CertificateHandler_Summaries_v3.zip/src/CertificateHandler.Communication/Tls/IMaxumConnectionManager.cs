// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Runs the incoming listener and the outgoing connector for TLS between MAXUM devices.
/// </summary>
public interface IMaxumConnectionManager : IDisposable
{
    /// <summary>
    /// True when the listener is running.
    /// </summary>
    bool IsListening { get; }

    /// <summary>
    /// Starts listening for connections from other devices.
    /// </summary>
    void StartListener();

    /// <summary>
    /// Stops listening for connections from other devices.
    /// </summary>
    void StopListener();

    /// <summary>
    /// Connects to another MAXUM device over TLS.
    /// </summary>
    /// <param name="host">Host name or IP address of the peer.</param>
    /// <param name="port">Port of the peer, or null to use the default port.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The connection, or null when the peer is not trusted.</returns>
    Task<PeerTlsConnection?> ConnectToPeerAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default);
}
