﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Constants;

/// <summary>
/// Default settings, user messages and log messages used by the session refresh.
/// </summary>
public static class SessionRefreshConstants
{
    #region Member Variables

    /// <summary>Section in appsettings.json that holds the session refresh settings.</summary>
    public const string SESSION_REFRESH_SECTION = "CertificateHandler:SessionRefresh";

    /// <summary>Seconds before the session expires when the refresh starts, when nothing is set.</summary>
    public const int DEFAULT_REFRESH_BEFORE_EXPIRY_SECONDS = 60;

    /// <summary>Seconds to wait before the first retry after a failed refresh, when nothing is set.</summary>
    public const int DEFAULT_RETRY_INITIAL_DELAY_SECONDS = 2;

    /// <summary>Longest wait in seconds between two retries, when nothing is set.</summary>
    public const int DEFAULT_RETRY_MAX_DELAY_SECONDS = 30;

    /// <summary>Seconds a refresh request can take before it is cancelled, when nothing is set.</summary>
    public const int DEFAULT_REQUEST_TIMEOUT_SECONDS = 15;

    /// <summary>Seconds a session message stays on the screen, when nothing is set.</summary>
    public const int DEFAULT_NOTIFICATION_DISPLAY_SECONDS = 5;

    /// <summary>How many times longer the wait gets after each failed retry, up to the longest wait.</summary>
    public const int RETRY_BACKOFF_MULTIPLIER = 2;

    /// <summary>Content type of the refresh request and response body.</summary>
    public const string JSON_MEDIA_TYPE = "application/json";

    /// <summary>Name of the JSON field that holds the refresh token.</summary>
    public const string REFRESH_TOKEN_FIELD = "refreshToken";

    /// <summary>Name of the JSON field that holds the new access token.</summary>
    public const string ACCESS_TOKEN_FIELD = "accessToken";

    /// <summary>Name of the JSON field that holds the lifetime of the new access token in seconds.</summary>
    public const string EXPIRES_IN_FIELD = "expiresIn";

    /// <summary>Shown to the user when the refresh failed but the session is kept while the app tries again.</summary>
    public const string REFRESH_FAILED_NOTIFICATION = "Connection to the server was lost. You are still signed in; reconnecting...";

    /// <summary>Shown to the user when a retry worked and the current view was reloaded.</summary>
    public const string REFRESH_RECOVERED_NOTIFICATION = "Connection restored. Your session is active and the view has been refreshed.";

    /// <summary>Logged when a refresh starts. The value is the user name.</summary>
    public const string LOG_REFRESH_STARTED = "Session refresh started for user %s.";

    /// <summary>Logged when a refresh works. The values are the user name and the new expiry time.</summary>
    public const string LOG_REFRESH_SUCCEEDED = "Session refresh succeeded for user %s. New expiry: %s.";

    /// <summary>Logged as an error when the connection to the server is lost during a refresh. The values are the user name and the error.</summary>
    public const string LOG_REFRESH_NETWORK_FAILURE = "Connection to the server was lost for user %s. The user stays signed in and the application keeps retrying. Reason: %s";

    /// <summary>Logged when a refresh fails with an error that was not expected. The values are the user name and the error.</summary>
    public const string LOG_REFRESH_UNEXPECTED_FAILURE = "Session refresh failed for user %s with an unexpected error. Session kept. Reason: %s";

    /// <summary>Logged when the server refuses the refresh and the user must sign in again. The value is the user name.</summary>
    public const string LOG_REFRESH_REJECTED = "Session refresh was rejected by the server for user %s. The user must sign in again.";

    /// <summary>Logged when a refresh result is ignored because the session changed in the meantime. The value is the user name.</summary>
    public const string LOG_REFRESH_STALE = "The session refresh result for user %s was ignored because the session changed while the request was running.";

    /// <summary>Logged when the retries start after a failed refresh. The value is the wait before the first retry in seconds.</summary>
    public const string LOG_RECOVERY_STARTED = "Session refresh recovery started. First retry in %s seconds.";

    /// <summary>Logged before each retry. The value is the retry number.</summary>
    public const string LOG_RECOVERY_ATTEMPT = "Session refresh retry attempt %s.";

    /// <summary>Logged when a retry fails. The values are the retry number, the wait before the next retry in seconds and the error.</summary>
    public const string LOG_RECOVERY_ATTEMPT_FAILED = "Session refresh retry attempt %s failed. Next retry in %s seconds. Reason: %s";

    /// <summary>Logged when the connection to the server is back after the retries. The values are the number of retries and the user name.</summary>
    public const string LOG_RECOVERY_SUCCEEDED = "Connection to the server was restored after %s retry attempt(s) for user %s. Reloading the current view.";

    /// <summary>Logged when the network comes back and the refresh is tried again at once.</summary>
    public const string LOG_NETWORK_AVAILABLE = "Network became available. Retrying the session refresh now.";

    /// <summary>Logged when the retries stop, like after sign out or a refresh that worked.</summary>
    public const string LOG_RECOVERY_STOPPED = "Session refresh recovery stopped.";

    /// <summary>Logged when a message or an event handler of the refresh throws an error. The value is the error.</summary>
    public const string LOG_CALLBACK_FAILED = "A session refresh notification or event handler failed: %s";

    /// <summary>Error text when the new token belongs to another user. The first value is the token user and the second is the session user.</summary>
    public const string SESSION_USER_MISMATCH_MESSAGE = "Refreshed token belongs to user {0} but the session belongs to user {1}.";

    /// <summary>Error text when no refresh endpoint is set in the configuration.</summary>
    public const string REFRESH_ENDPOINT_MISSING_MESSAGE = "The session refresh endpoint is not configured (CertificateHandler:SessionRefresh:RefreshEndpoint).";

    /// <summary>Error text when the server refuses the refresh. The value is the HTTP status code.</summary>
    public const string REFRESH_REJECTED_MESSAGE = "The server rejected the session refresh with status code {0}.";

    /// <summary>Error text when the server answers with an error. The value is the HTTP status code.</summary>
    public const string REFRESH_SERVER_ERROR_MESSAGE = "The session refresh failed with status code {0}.";

    /// <summary>Error text when the refresh response holds no valid token.</summary>
    public const string REFRESH_RESPONSE_INVALID_MESSAGE = "The session refresh response did not contain a valid token.";

    /// <summary>Error text when the answer has a success status but an empty body. The value is the HTTP status code.</summary>
    public const string REFRESH_RESPONSE_EMPTY_MESSAGE = "The session refresh answered with status code {0} but no token in the response body.";

    #endregion

    #region Server And Session Log Texts

    /// <summary>Information message when the refresh request is sent to the server. The value is the endpoint.</summary>
    public const string LOG_SERVER_REQUEST_SENT = "Session refresh request sent to the server %s.";

    /// <summary>Information message when the server answered. The values are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_ANSWERED = "The server %s answered the session refresh with status code %s.";

    /// <summary>Warning message when the server refused the refresh. The values are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_REFUSED = "The server %s refused the session refresh with status code %s.";

    /// <summary>Error message when the server gave an error. The values are the endpoint and the HTTP status code.</summary>
    public const string LOG_SERVER_ERROR = "The server %s returned an error for the session refresh, status code %s.";

    /// <summary>Error message when the server could not be reached. The values are the endpoint and the error.</summary>
    public const string LOG_SERVER_UNREACHABLE = "The server %s could not be reached for the session refresh: %s";

    /// <summary>Warning message when the server did not answer in time. The values are the endpoint and the timeout in seconds.</summary>
    public const string LOG_SERVER_TIMEOUT = "The server %s did not answer the session refresh within %s second(s).";

    /// <summary>Error message when the server answer could not be read. The values are the endpoint and the error.</summary>
    public const string LOG_SERVER_INVALID_RESPONSE = "The session refresh answer from the server %s could not be read: %s";

    /// <summary>Error message when no refresh endpoint is set.</summary>
    public const string LOG_SERVER_ENDPOINT_MISSING = "No server address is configured for the session refresh.";

    /// <summary>Information message when a session is started. The value is the user name.</summary>
    public const string LOG_SESSION_STARTED = "Session started for user %s.";

    /// <summary>Information message when the session tokens are replaced. The value is the user name.</summary>
    public const string LOG_SESSION_TOKENS_REPLACED = "Session tokens renewed for user %s.";

    /// <summary>Information message when the session is ended. The value is the user name.</summary>
    public const string LOG_SESSION_ENDED = "Session ended for user %s.";

    /// <summary>Information message when the network came back after the retry wait had already ended, so there was nothing to wake up.</summary>
    public const string LOG_RETRY_WAIT_ALREADY_FINISHED = "The network is back, but the session retry wait had already finished.";

    /// <summary>Information message when the retry wait was ended early because the network is back.</summary>
    public const string LOG_RETRY_WAIT_ENDED_EARLY = "The session retry wait was ended early because the network is back.";

    /// <summary>Information message when the automatic session refresh stopped because the app is closing or the user signed out.</summary>
    public const string LOG_AUTO_REFRESH_STOPPED = "Automatic session refresh stopped.";

    #endregion
}
