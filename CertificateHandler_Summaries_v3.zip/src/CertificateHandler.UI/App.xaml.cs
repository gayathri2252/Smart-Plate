﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.NetworkInformation;
using System.Windows;
using CertificateHandler.Communication.Constants;
using CertificateHandler.Communication.Session;
using CertificateHandler.Data;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
using CertificateHandler.Data.Security;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Security;
using CertificateHandler.LaunchGuard;
using CertificateHandler.LaunchGuard.Enums;
using CertificateHandler.LaunchGuard.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.UI.Integration;
using CertificateHandler.UI.Services;
using CertificateHandler.UI.ViewModels;
using CertificateHandler.UI.Views;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using CertificateHandler.Communication.Interface;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI;

/// <summary>
/// Application entry point. Prepares the database, sets up the session refresh
/// and shows the login window.
/// </summary>
public partial class App : Application
{
    #region Member Variables

    private const string APP_SETTINGS_FILE = "appsettings.json";

    private const string APP_SETTINGS_DEVELOPMENT_FILE = "appsettings.Development.json";

    private const string DATABASE_ERROR_MESSAGE = "Unable to connect to the Trust database:\n\n{0}";

    private const string APPLICATION_TITLE = "Certificate Handler";

    private const int STARTUP_FAILED_EXIT_CODE = -1;

    private const string SECURITY_MODE_BYPASS_ENV = "CH_SKIP_SECURITY_MODE";

    private const string COMMISSIONING_GATE_BYPASS_ENV = "CH_SKIP_COMMISSIONING_GATE";

    private CertificateHandlerDataAccess? _dataAccess;

    private TrustStoreDatabase? _trustStoreDatabase;

    /// <summary>
    /// Shared database access for views opened after startup (same pool and TLS as the main window).
    /// </summary>
    internal static CertificateHandlerDataAccess? SharedDataAccess =>
        (Current as App)?._dataAccess;

    private HttpClient? _httpClient;

    private SessionNotifier? _sessionNotifier;

    private BackgroundMaintenanceService? _backgroundMaintenance;

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the session store, or null before startup (for example in unit tests).
    /// </summary>
    public static ISessionStore? SessionStore { get; private set; }

    /// <summary>
    /// Gets the session refresh service, or null before startup.
    /// </summary>
    public static SessionRefreshService? SessionRefresh { get; private set; }

    /// <summary>
    /// Gets the session notification banner state shared by all views.
    /// </summary>
    public static SessionNotificationViewModel SessionNotification { get; } = new();

    /// <summary>
    /// Gets the encrypted local trust store (whitelist, blacklist and pending rows), or null before startup.
    /// </summary>
    public static ITrustStoreRepository? TrustStore { get; private set; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts the session with the tokens from the sign-in and begins the automatic refresh.
    /// Does nothing before startup.
    /// </summary>
    /// <param name="token">
    /// Tokens of the signed-in user.
    /// </param>
    public static void StartSession(SessionToken token)
    {
        ArgumentNullException.ThrowIfNull(token);

        SessionStore?.Start(token);
        SessionRefresh?.Start();
    }

    /// <summary>
    /// Stops the automatic refresh and ends the current session, for example when the user logs out.
    /// </summary>
    public static void EndSession()
    {
        SessionRefresh?.Stop();
        SessionStore?.End();
        SessionNotification.Hide();
    }

    #endregion

    #region Override Methods

    /// <summary>
    /// Initializes the database, sets up the session refresh and shows the login window.
    /// Shuts the application down when the database cannot be reached.
    /// </summary>
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        SubscribeToUnhandledErrors();
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_APP_STARTING);

        try
        {
            if (!IsSecurityModeBypassed())
            {
                ISecurityModeReader securityModeReader = new RegistrySecurityModeReader();
                SecurityMode registryMode = securityModeReader.Read();
                LaunchGuardResult launchGuard = new ApplicationLaunchGuard(securityModeReader).Evaluate();
                if (!launchGuard.MayStart)
                {
                    MessageBox.Show(
                        launchGuard.Message,
                        APPLICATION_TITLE,
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    Shutdown(STARTUP_FAILED_EXIT_CODE);
                    return;
                }

                if (registryMode == SecurityMode.Unknown)
                {
                    CertificateHandlerLogger.Warning(
                        MessageIdGenerator.Next(),
                        "MCP SecurityMode registry value is missing or invalid; starting with TLS as Secure (RS_31).");
                }
            }

            DatabaseOptions databaseOptions = LoadDatabaseOptions();
            DatabaseSetup.EnsureReady(
                databaseOptions,
                new DpapiKeyProtector(),
                LoadTrustStoreOptions().AdditionalAccounts);

            if (!await CertificateHandler.Data.CertificateHandlerData.TestConnectionAsync(databaseOptions))
            {
                MessageBox.Show(
                    "Unable to connect to the Trust database. Check PostgreSQL on localhost, CH_DB_PASSWORD (or CH_DB_PASSWORD_PROTECTED), SSL, and the client certificate.",
                    APPLICATION_TITLE,
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown(STARTUP_FAILED_EXIT_CODE);
                return;
            }

            _dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);

            if (!IsCommissioningGateBypassed())
            {
                CommissioningHaltResult halt = await new CommissioningGateService(_dataAccess.DataSource)
                    .EvaluateAsync();
                if (halt.ShouldHalt)
                {
                    MessageBox.Show(halt.Message, APPLICATION_TITLE, MessageBoxButton.OK, MessageBoxImage.Stop);
                    Shutdown(STARTUP_FAILED_EXIT_CODE);
                    return;
                }
            }

            InitializeTrustStore();
            InitializeSessionRefresh();

            _backgroundMaintenance = new BackgroundMaintenanceService(_dataAccess.DataSource);
            _backgroundMaintenance.Start();

            if (MaxumHmiHostBridge.TryCreateEmbeddedUser(out Shared.Models.SignedInUser embeddedUser))
            {
                PendingRequestQueueView mainWindow = new(_dataAccess.DataSource, embeddedUser);
                MainWindow = mainWindow;
                mainWindow.Show();
            }
            else
            {
                LoginView loginWindow = new(_dataAccess.DataSource);
                loginWindow.Title += MaxumHmiHostBridge.WindowTitleSuffix;
                MainWindow = loginWindow;
                loginWindow.Show();
            }

            CertificateHandlerLogger.Success(MessageIdGenerator.Next(), UiConstants.LOG_APP_STARTED);
        }
        catch (TrustStoreException ex)
        {
            MessageBox.Show(ex.Message, APPLICATION_TITLE, MessageBoxButton.OK, MessageBoxImage.Error);

            Shutdown(STARTUP_FAILED_EXIT_CODE);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_APP_START_FAILED, ex.Message);
            MessageBox.Show(
                string.Format(DATABASE_ERROR_MESSAGE, ex.Message),
                APPLICATION_TITLE,
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            Shutdown(STARTUP_FAILED_EXIT_CODE);
        }
    }

    /// <summary>
    /// Stops the session refresh and releases the notifier, database and HTTP resources.
    /// </summary>
    protected override void OnExit(ExitEventArgs e)
    {
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_APP_EXITING, e.ApplicationExitCode.ToString());
        NetworkChange.NetworkAvailabilityChanged -= OnNetworkAvailabilityChanged;
        _backgroundMaintenance?.Dispose();
        SessionRefresh?.Dispose();
        _sessionNotifier?.Dispose();
        _httpClient?.Dispose();
        _dataAccess?.Dispose();
        base.OnExit(e);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Returns true when RS_31 launch checks are skipped (development and automated UI tests).
    /// </summary>
    private static bool IsSecurityModeBypassed() =>
        DevelopmentBypassGuard.IsBypassEnabled(SECURITY_MODE_BYPASS_ENV);

    private static bool IsCommissioningGateBypassed() =>
        DevelopmentBypassGuard.IsBypassEnabled(COMMISSIONING_GATE_BYPASS_ENV);

    /// <summary>
    /// Writes every unexpected error to the Log Monitor: errors on the screen, errors in background
    /// threads and errors of tasks nobody waited for. The errors are only logged, not handled.
    /// </summary>
    private void SubscribeToUnhandledErrors()
    {
        DispatcherUnhandledException += (_, args) =>
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_UNHANDLED_UI_ERROR, args.Exception.Message);

        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_UNHANDLED_ERROR, (args.ExceptionObject as Exception)?.Message ?? UiConstants.LOG_EMPTY_VALUE);

        TaskScheduler.UnobservedTaskException += (_, args) =>
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_UNHANDLED_ERROR, args.Exception.Message);
    }

    /// <summary>
    /// Reads the configuration from appsettings.json and the environment variables.
    /// </summary>
    private static IConfigurationRoot LoadConfiguration()
    {
        return new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile(APP_SETTINGS_FILE, optional: true)
            .AddJsonFile(APP_SETTINGS_DEVELOPMENT_FILE, optional: true)
            .AddEnvironmentVariables()
            .Build();
    }

    /// <summary>
    /// Reads the database options from the CertificateHandler:Database section.
    /// </summary>
    internal static DatabaseOptions LoadDatabaseOptions()
    {
        DatabaseOptions options = LoadConfiguration().GetSection(DatabaseOptions.SectionName).Get<DatabaseOptions>()
            ?? new DatabaseOptions();
        DatabaseOptionsEnvironmentOverrides.Apply(options);
        return options;
    }

    /// <summary>
    /// Reads the trust store options from the CertificateHandler:TrustStore section.
    /// </summary>
    private static TrustStoreOptions LoadTrustStoreOptions()
    {
        return LoadConfiguration().GetSection(TrustStoreOptions.SectionName).Get<TrustStoreOptions>()
            ?? new TrustStoreOptions();
    }

    /// <summary>
    /// Opens the encrypted local trust store, creating its key and file on the first run.
    /// Throws TrustStoreException with a message for the user when it cannot be opened.
    /// </summary>
    private void InitializeTrustStore()
    {
        TrustStoreOptions trustStoreOptions = LoadTrustStoreOptions();

        _trustStoreDatabase = new TrustStoreDatabase(trustStoreOptions, new DpapiKeyProtector());
        _trustStoreDatabase.EnsureInitialized();
        TrustStore = new TrustStoreRepository(_trustStoreDatabase);
    }

    /// <summary>
    /// Reads the session refresh options from the CertificateHandler:SessionRefresh section.
    /// </summary>
    private static SessionRefreshOptions LoadSessionRefreshOptions()
    {
        return LoadConfiguration().GetSection(SessionRefreshConstants.SESSION_REFRESH_SECTION).Get<SessionRefreshOptions>()
            ?? new SessionRefreshOptions();
    }

    /// <summary>
    /// Creates the session store, the HTTP refresh client and the refresh service,
    /// and listens for network changes and session expiry.
    /// </summary>
    private void InitializeSessionRefresh()
    {
        SessionRefreshOptions refreshOptions = LoadSessionRefreshOptions();

        _httpClient = new HttpClient();
        ITokenRefreshClient refreshClient = new HttpTokenRefreshClient(_httpClient, refreshOptions);

        // Full name needed: inside App, "SessionStore" means the property above.
        SessionStore = new CertificateHandler.Communication.Session.SessionStore();
        _sessionNotifier = new SessionNotifier(SessionNotification, Dispatcher, refreshOptions);
        SessionRefresh = new SessionRefreshService(SessionStore, refreshClient, _sessionNotifier, refreshOptions);

        SessionRefresh.SessionExpired += OnSessionExpired;
        NetworkChange.NetworkAvailabilityChanged += OnNetworkAvailabilityChanged;
    }

    /// <summary>
    /// Retries the refresh at once when Windows reports that the network is back.
    /// </summary>
    private static void OnNetworkAvailabilityChanged(object? sender, NetworkAvailabilityEventArgs e)
    {
        if (e.IsAvailable)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.LOG_NETWORK_AVAILABLE);
            SessionRefresh?.NotifyNetworkAvailable();
        }
        else
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_NETWORK_LOST);
        }
    }

    /// <summary>
    /// Shows the login window only when the server refused the refresh, and closes every other window.
    /// Network failures never reach this method.
    /// </summary>
    private void OnSessionExpired(object? sender, EventArgs e)
    {
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_SESSION_EXPIRED);

        Dispatcher.Invoke(() =>
        {
            EndSession();

            LoginView loginWindow = new(_dataAccess!.DataSource);
            foreach (Window window in Windows.Cast<Window>().Where(window => window != loginWindow).ToList())
            {
                window.Close();
            }

            MainWindow = loginWindow;
            loginWindow.Show();
        });
    }

    #endregion
}