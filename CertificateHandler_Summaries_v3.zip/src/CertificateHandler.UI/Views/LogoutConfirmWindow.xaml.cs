﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Input;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Dialog that asks the administrator to confirm the log out, in the same style as the request details dialog.
/// The dialog only records the choice; the caller carries out the log out.
/// </summary>
public partial class LogoutConfirmWindow : Window
{
    #region Constructor

    /// <summary>
    /// Creates the dialog. Cancel is the default button, so Enter keeps the user signed in.
    /// </summary>
    public LogoutConfirmWindow()
    {
        InitializeComponent();
        MouseLeftButtonDown += OnWindowMouseLeftButtonDown;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// True only when the administrator pressed Log out; false until then, and when the dialog is cancelled or closed.
    /// </summary>
    public bool IsLogoutConfirmed { get; private set; }

    #endregion

    #region Private Methods

    /// <summary>
    /// Records the log out choice and closes the dialog.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void LogoutButton_Click(object sender, RoutedEventArgs e)
    {
        IsLogoutConfirmed = true;
        Close();
    }

    /// <summary>
    /// Closes the dialog and keeps the user signed in. Escape and the close button do the same.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        IsLogoutConfirmed = false;
        Close();
    }

    /// <summary>
    /// Lets the borderless dialog be moved by dragging it.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Mouse event arguments.</param>
    private void OnWindowMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            DragMove();
        }
    }

    #endregion
}
