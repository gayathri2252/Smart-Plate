﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using CertificateHandler.Data;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using CertificateHandler.UI.ViewModels;
using Npgsql;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Dashboard page with the certificate and device cards and the request queue overview (the pending
/// area) with search, filter, sorting and paging. Only a device administrator sees the pending requests. It is shown inside the request queue window, so the menu stays the same.
/// Logs the seconds from creating the page until the first page is rendered.
/// </summary>
public partial class DashboardView : UserControl
{
    #region Member Variables

    /// <summary>Number format used when the render time is written in seconds.</summary>
    private const string SECONDS_FORMAT = "F2";

    /// <summary>Time to wait after the last key press before the search is applied.</summary>
    private const int SEARCH_DELAY_MILLISECONDS = 300;

    /// <summary>Text of the request type filter when no type is selected.</summary>
    private const string ALL_REQUESTS_TEXT = "Filter";

    /// <summary>Measures the time from creating the view until it is rendered.</summary>
    private readonly Stopwatch _renderStopwatch = Stopwatch.StartNew();

    /// <summary>View model that holds the dashboard data.</summary>
    private readonly DashboardViewModel _viewModel;

    /// <summary>Timer that delays the search until typing has paused.</summary>
    private readonly DispatcherTimer _searchTimer;

    /// <summary>Request type chosen in the filter; null means all types.</summary>
    private PendingRequestType? _selectedType;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view and its view model on top of the given database connection, for the given user.
    /// A null user sees no dashboard data.
    /// </summary>
    public DashboardView(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
        : this(CreateViewModel(dataSource, signedInUser))
    {
    }

    /// <summary>
    /// Creates the view for the given view model. The first page is loaded when the page
    /// is first shown. The view model must not be null.
    /// </summary>
    public DashboardView(DashboardViewModel viewModel)
    {
        if (viewModel is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_VIEW_MODEL_IS_NULL);
            throw new ArgumentNullException(nameof(viewModel));
        }

        _viewModel = viewModel;
        InitializeComponent();
        DataContext = viewModel;

        _searchTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(SEARCH_DELAY_MILLISECONDS) };
        _searchTimer.Tick += SearchTimer_Tick;
        Loaded += DashboardView_Loaded;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Time from creating the view until the first page was rendered; null until then.
    /// </summary>
    public TimeSpan? RenderDuration { get; private set; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Loads the first page again, so the cards and the request overview show the current data.
    /// A failure is logged and does not reach the caller.
    /// </summary>
    public async Task ReloadAsync()
    {
        try
        {
            await _viewModel.LoadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_LOAD_FAILED, ex.Message);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Creates the view model with the dashboard query on top of the given database connection, for the
    /// given user. The connection must not be null.
    /// </summary>
    private static DashboardViewModel CreateViewModel(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
    {
        if (dataSource is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_DATA_SOURCE_IS_NULL);
            throw new ArgumentNullException(nameof(dataSource));
        }

        return new DashboardViewModel(new CertificateDashboard(dataSource), signedInUser);
    }

    /// <summary>
    /// Loads the first page, waits until WPF has rendered it, then records and logs the
    /// render time. The time is not logged when the load failed.
    /// </summary>
    private async void DashboardView_Loaded(object sender, RoutedEventArgs e)
    {
        Loaded -= DashboardView_Loaded;

        try
        {
            await _viewModel.LoadAsync();
            await Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ContextIdle);

            _renderStopwatch.Stop();
            RenderDuration = _renderStopwatch.Elapsed;

            if (string.IsNullOrEmpty(_viewModel.ErrorMessage))
            {
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    UiConstants.DASHBOARD_RENDERED,
                    RenderDuration.Value.TotalSeconds.ToString(SECONDS_FORMAT, CultureInfo.InvariantCulture),
                    _viewModel.TotalCertificates.ToString(CultureInfo.InvariantCulture));
            }
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_LOAD_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Restarts the short delay after each key press, so the query runs once the typing pauses.
    /// </summary>
    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        _searchTimer.Stop();
        _searchTimer.Start();
    }

    /// <summary>
    /// Applies the search text and the selected request type once the typing has paused.
    /// </summary>
    private async void SearchTimer_Tick(object? sender, EventArgs e)
    {
        _searchTimer.Stop();
        await ApplyFilterAsync();
    }

    /// <summary>
    /// Opens the request type menu below the filter button.
    /// </summary>
    private void Filter_Click(object sender, RoutedEventArgs e)
    {
        FilterMenu.PlacementTarget = FilterButton;
        FilterMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
        FilterMenu.IsOpen = true;
    }

    /// <summary>
    /// Takes the request type of the chosen menu entry; an empty tag means every type.
    /// </summary>
    private async void FilterItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem item)
        {
            return;
        }

        string tag = item.Tag as string ?? string.Empty;

        _selectedType = Enum.TryParse(tag, ignoreCase: true, out PendingRequestType type) ? type : null;

        string selectedHeader = item.Header?.ToString() ?? UiConstants.ALL_REQUEST_TYPES;
        FilterButtonText.Text = _selectedType is null ? ALL_REQUESTS_TEXT : selectedHeader;

        _searchTimer.Stop();
        await ApplyFilterAsync();
    }

    /// <summary>
    /// Loads the first page of the requests that match the search text and request type.
    /// </summary>
    private async Task ApplyFilterAsync()
    {
        try
        {
            await _viewModel.ApplyFilterAsync(SearchBox.Text, _selectedType);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_FILTER_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Sorts the request overview by the clicked column. The sort runs in the database over all pending
    /// requests, not only the visible page, so the grid's own sorting is turned off for the event.
    /// </summary>
    private async void RequestsGrid_Sorting(object sender, DataGridSortingEventArgs e)
    {
        e.Handled = true;
        if (!Enum.TryParse(e.Column.SortMemberPath, out DashboardSortColumn column))
        {
            return;
        }

        try
        {
            await _viewModel.SortByAsync(column);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_SORT_FAILED, ex.Message);
        }

        ShowSortArrow();
    }

    /// <summary>
    /// Shows the sort arrow on the column the overview is sorted by and clears it on the others.
    /// </summary>
    private void ShowSortArrow()
    {
        string sortedMember = _viewModel.SortColumn.ToString();

        foreach (DataGridColumn gridColumn in RequestsGrid.Columns)
        {
            if (gridColumn.SortMemberPath != sortedMember)
            {
                gridColumn.SortDirection = null;
                continue;
            }

            gridColumn.SortDirection = _viewModel.SortDescending
                ? ListSortDirection.Descending
                : ListSortDirection.Ascending;
        }
    }

    /// <summary>
    /// Loads the page before the visible one.
    /// </summary>
    private async void PreviousPage_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            await _viewModel.PreviousPageAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_PAGE_CHANGE_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Shows the chosen number of rows on a page, starting on the first page. The Tag of each item holds the size as text.
    /// </summary>
    private async void PageSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (sender is not ComboBox { SelectedItem: ComboBoxItem { Tag: string tag } }
            || !int.TryParse(tag, NumberStyles.Integer, CultureInfo.InvariantCulture, out int pageSize))
        {
            return;
        }

        try
        {
            await _viewModel.ChangePageSizeAsync(pageSize);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_PAGE_CHANGE_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Loads the page after the visible one.
    /// </summary>
    private async void NextPage_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            await _viewModel.NextPageAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_PAGE_CHANGE_FAILED, ex.Message);
        }
    }

    #endregion
}