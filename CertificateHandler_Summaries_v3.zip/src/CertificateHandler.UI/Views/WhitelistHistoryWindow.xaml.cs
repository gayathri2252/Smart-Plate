// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using CertificateHandler.Data;
using CertificateHandler.Data.Models;
using Npgsql;

namespace CertificateHandler.UI.Views;

public partial class WhitelistHistoryWindow : Window
{
    public WhitelistHistoryWindow(NpgsqlDataSource dataSource)
    {
        InitializeComponent();
        Loaded += async (_, _) => await LoadAsync(dataSource);
    }

    private async Task LoadAsync(NpgsqlDataSource dataSource)
    {
        try
        {
            IReadOnlyList<WhitelistAuditEntry> rows =
                await new WhitelistAuditHistoryService(dataSource).GetWhitelistHistoryAsync();
            HistoryGrid.ItemsSource = rows;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
