﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Controls;
using CertificateHandler.CertificateManagement.Services;
using CertificateHandler.Data;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using CertificateHandler.UI.ViewModels;
using Npgsql;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Read-only Certificate Management page that shows the SBC and MIB certificate subject, thumbprint,
/// not-after date and expiry status. It is shown inside the request queue window, so the menu stays
/// the same. It has no renew or change action.
/// </summary>
public partial class CertificateInformationView : UserControl
{
    #region Member Variables

    private readonly CertificateInformationViewModel _viewModel;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view on top of the given database connection. The administrator check uses the
    /// signed-in user; without one the user of the current session is used.
    /// </summary>
    public CertificateInformationView(NpgsqlDataSource dataSource, SignedInUser? signedInUser = null)
        : this(CreateViewModel(dataSource, signedInUser))
    {
    }

    /// <summary>
    /// Creates the view for the given view model, which must not be null.
    /// </summary>
    /// <param name="viewModel">
    /// View model used to load, filter, and present certificate information.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the view model is null.
    /// </exception>
    public CertificateInformationView(CertificateInformationViewModel viewModel)
    {
        if (viewModel is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.VIEW_MODEL_IS_NULL);
            throw new ArgumentNullException(nameof(viewModel));
        }

        _viewModel = viewModel;
        InitializeComponent();
        DataContext = viewModel;
        Loaded += CertificateInformationView_Loaded;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Loads the certificates again, so the page shows the current data. A failure is logged and does
    /// not reach the caller.
    /// </summary>
    public async Task ReloadAsync()
    {
        try
        {
            await _viewModel.LoadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Loads the certificates the first time the page is shown; later visits call ReloadAsync.
    /// </summary>
    private async void CertificateInformationView_Loaded(object sender, RoutedEventArgs e)
    {
        Loaded -= CertificateInformationView_Loaded;
        await ReloadAsync();
    }

    /// <summary>
    /// Navigates to the previous page of certificates.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Event arguments.</param>
    private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is CertificateInformationViewModel viewModel)
        {
            viewModel.PreviousPage();
        }
    }

    /// <summary>
    /// Navigates to the next page of certificates.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Event arguments.</param>
    private void NextPageButton_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is CertificateInformationViewModel viewModel)
        {
            viewModel.NextPage();
        }
    }

    /// <summary>
    /// Changes the number of certificates on a page to the size stored in the Tag of the chosen item.
    /// </summary>
    private void PageSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_viewModel is null)
        {
            return;
        }

        if (PageSizeComboBox.SelectedItem is ComboBoxItem { Tag: string tag } && int.TryParse(tag, out int pageSize))
        {
            _viewModel.ChangePageSize(pageSize);
        }
    }

    /// <summary>
    /// Creates the certificate information view model using the required services
    /// and the current signed-in user context.
    /// </summary>
    /// <param name="dataSource">
    /// Database connection used to retrieve certificate information.
    /// </param>
    /// <param name="signedInUser">
    /// Signed-in user used for authorization checks. If null, the current session user is used.
    /// </param>
    /// <returns>
    /// Configured certificate information view model instance.
    /// </returns>
    private static CertificateInformationViewModel CreateViewModel(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
    {
        CertificateInformationService service = new(
            new CertificateExpiryReader(dataSource),
            new AdministratorAuthorizer(),
            new CertificateExpiryStatusCalculator());

        return new CertificateInformationViewModel(
            service,
            () => signedInUser?.UserName ?? App.SessionStore?.Current?.UserName,
            new CertificateExpiryMonitorService(new CertificateExpiryReader(dataSource)),
            new WefCertificateEventWriter(),
            new CertificateRenewalWorkflowService(dataSource, new WindowsStoreRenewalImporter()),
            TpmCsrExportServiceFactory.Create(),
            new MccRenewalExportWriter());
    }

    /// <summary>
    /// Opens the certificate filter menu.
    /// </summary>
    /// <param name="sender">Control that initiated the action.</param>
    /// <param name="e">Event arguments.</param>
    private void Filter_Click(object sender, RoutedEventArgs e) => OpenMenu(sender);

    /// <summary>
    /// Applies the selected certificate filter.
    /// </summary>
    /// <param name="sender">Selected menu item.</param>
    /// <param name="e">Event arguments.</param>
    private void FilterItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is MenuItem item)
        {
            _viewModel.ApplyFilter(item.Tag as string);
        }
    }

    /// <summary>
    /// Opens the actions menu for certificate operations.
    /// </summary>
    /// <param name="sender">Control that initiated the action.</param>
    /// <param name="e">Event arguments.</param>
    private void Actions_Click(object sender, RoutedEventArgs e) => OpenMenu(sender);

    /// <summary>
    /// Displays the details dialog for the selected certificate.
    /// </summary>
    /// <param name="sender">
    /// Menu item or UI element associated with the selected certificate.
    /// </param>
    /// <param name="e">Event arguments.</param>
    private void ViewDetails_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is not null)
        {
            ShowDetails(row);
        }
    }

    private async void ExportCsr_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is null)
        {
            return;
        }

        DeviceAdminCredentialDialog credentials = new() { Owner = Window.GetWindow(this) };
        if (credentials.ShowDialog() != true)
        {
            return;
        }

        try
        {
            await _viewModel.ExportCsrAsync(row.Role);
            MessageBox.Show("CSR exported from TPM and recorded.", UiConstants.CERTIFICATE_MANAGEMENT, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            MessageBoxResult retry = MessageBox.Show(
                $"{ex.Message}\n\nRecord CSR PEM manually instead?",
                UiConstants.CERTIFICATE_MANAGEMENT,
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (retry == MessageBoxResult.Yes)
            {
                await RecordManualCsrForRowAsync(row);
            }
        }
    }

    private async void RecordManualCsr_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is null)
        {
            return;
        }

        await RecordManualCsrForRowAsync(row);
    }

    private async Task RecordManualCsrForRowAsync(CertificateRowViewModel row)
    {
        CsrPemDialog dialog = new()
        {
            Owner = Window.GetWindow(this),
            Title = "Record CSR (PEM)"
        };
        if (dialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            await _viewModel.RecordManualCsrAsync(row.Role, dialog.Pem);
            MessageBox.Show("CSR PEM recorded.", UiConstants.CERTIFICATE_MANAGEMENT, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    private async void ImportSignedCertificate_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is null)
        {
            return;
        }

        CsrPemDialog dialog = new() { Owner = Window.GetWindow(this) };
        if (dialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            await _viewModel.ImportSignedCertificateAsync(row.Role, dialog.Pem);
            MessageBox.Show("Signed certificate recorded as imported.", UiConstants.CERTIFICATE_MANAGEMENT, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    private async void ActivateRenewal_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is null)
        {
            return;
        }

        try
        {
            await _viewModel.ActivateRenewalAsync(row.Role);
            MessageBox.Show("Renewal activated in the workflow store.", UiConstants.CERTIFICATE_MANAGEMENT, MessageBoxButton.OK, MessageBoxImage.Information);
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    private async void RequestRenewal_Click(object sender, RoutedEventArgs e)
    {
        CertificateRowViewModel? row = ResolveRow(sender);
        if (row is null)
        {
            return;
        }

        try
        {
            Guid renewalId = await _viewModel.RequestRenewalAsync(row.Role);
            MessageBox.Show(
                $"Renewal request {renewalId:N} created for {row.Type}. Complete CA signing and activation before use.",
                UiConstants.CERTIFICATE_MANAGEMENT,
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    private static CertificateRowViewModel? ResolveRow(object sender)
    {
        if (sender is MenuItem item && item.Parent is ContextMenu menu)
        {
            return (menu.PlacementTarget as FrameworkElement)?.DataContext as CertificateRowViewModel;
        }

        if (sender is FrameworkElement element)
        {
            return element.DataContext as CertificateRowViewModel;
        }

        return null;
    }

    /// <summary>
    /// Opens the context menu associated with the specified button.
    /// </summary>
    /// <param name="sender">
    /// Button containing the context menu to display.
    /// </param>
    private static void OpenMenu(object sender)
    {
        if (sender is Button button && button.ContextMenu is { } menu)
        {
            menu.PlacementTarget = button;
            menu.IsOpen = true;
        }
    }

    /// <summary>
    /// Opens a dialog displaying the complete details of the selected certificate.
    /// </summary>
    /// <param name="row">
    /// Certificate row whose details are to be displayed.
    /// </param>
    private void ShowDetails(CertificateRowViewModel row)
    {
        (string Label, string Value)[] lines =
        {
            (UiConstants.LABEL_TYPE, row.Type),
            (UiConstants.LABEL_ISSUER, row.Issuer),
            (UiConstants.LABEL_SUBJECT, row.Subject),
            (UiConstants.LABEL_THUMBPRINT, row.Thumbprint),
            (UiConstants.LABEL_NOT_AFTER, row.NotAfter),
            (UiConstants.LABEL_STATUS, row.Status),
            ("Public key algorithm", string.IsNullOrEmpty(row.PublicKeyAlgorithm) ? UiConstants.STATUS_NOT_AVAILABLE : row.PublicKeyAlgorithm),
            ("Public key (PEM)", string.IsNullOrEmpty(row.PublicKeyPem) ? UiConstants.STATUS_NOT_AVAILABLE : row.PublicKeyPem)
        };

        Grid grid = new() { Margin = new Thickness(24) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        for (int i = 0; i < lines.Length; i++)
        {
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            TextBlock label = new()
            {
                Text = lines[i].Label,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 24, 10)
            };
            TextBox value = new()
            {
                Text = lines[i].Value,
                IsReadOnly = true,
                BorderThickness = new Thickness(0),
                Background = System.Windows.Media.Brushes.Transparent,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            };

            Grid.SetRow(label, i);
            Grid.SetRow(value, i);
            Grid.SetColumn(value, 1);
            grid.Children.Add(label);
            grid.Children.Add(value);
        }

        Button close = new()
        {
            Content = UiConstants.CLOSE_TEXT,
            Padding = new Thickness(24, 6, 24, 6),
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 12, 0, 0),
            IsCancel = true
        };
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        Grid.SetRow(close, lines.Length);
        Grid.SetColumnSpan(close, 2);
        grid.Children.Add(close);

        Window window = new()
        {
            Title = UiConstants.DETAILS_TITLE,
            Content = grid,
            Width = 680,
            SizeToContent = SizeToContent.Height,
            ResizeMode = ResizeMode.NoResize,
            Owner = Window.GetWindow(this),
            WindowStartupLocation = WindowStartupLocation.CenterOwner
        };
        close.Click += (_, _) => window.Close();
        window.ShowDialog();
    }

    #endregion
}
