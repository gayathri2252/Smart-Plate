// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;

namespace CertificateHandler.UI.Views;

public partial class BulkBlacklistDialog : Window
{
    public IReadOnlyList<string> Thumbprints { get; private set; } = Array.Empty<string>();

    public string Reason { get; private set; } = string.Empty;

    public BulkBlacklistDialog()
    {
        InitializeComponent();
    }

    private void BlacklistButton_Click(object sender, RoutedEventArgs e)
    {
        Reason = ReasonTextBox.Text?.Trim() ?? string.Empty;
        Thumbprints = (ThumbprintsTextBox.Text ?? string.Empty)
            .Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(line => !string.IsNullOrWhiteSpace(line))
            .ToArray();

        if (Thumbprints.Count == 0 || string.IsNullOrEmpty(Reason))
        {
            MessageBox.Show(this, "At least one thumbprint and a reason are required.", Title, MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DialogResult = true;
    }
}
