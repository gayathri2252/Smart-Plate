﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using CertificateHandler.Shared.Models;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Dialog that shows the details of one pending certificate request, including the certificate
/// thumbprint, so the administrator can check the device and certificate before approving or
/// rejecting it. The dialog only records the choice; the caller carries it out.
/// </summary>
public partial class RequestDetailsWindow : Window
{
    #region Public Properties

    /// <summary>
    /// Choice the administrator made in the dialog.
    /// </summary>
    public enum RequestDecision
    {
        /// <summary>The dialog was closed without a decision.</summary>
        None,

        /// <summary>The administrator chose to approve the request.</summary>
        Approve,

        /// <summary>The administrator chose to reject the request.</summary>
        Reject
    }

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the dialog for the given request. The request must not be null.
    /// </summary>
    /// <param name="request">Request whose details are shown.</param>
    public RequestDetailsWindow(PendingRequestItem request)
    {
        Request = request ?? throw new ArgumentNullException(nameof(request));
        InitializeComponent();

        // Never taller than the screen; the body scrolls on a small display such as the analyzer panel.
        MaxHeight = SystemParameters.WorkArea.Height;
        DataContext = request;
        MouseLeftButtonDown += OnWindowMouseLeftButtonDown;
        if (IsDecided(request.CurrentStatus))
        {
            ApproveButton.Visibility = Visibility.Collapsed;
            RejectButton.Visibility = Visibility.Collapsed;
        }
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Request whose details are shown.
    /// </summary>
    public PendingRequestItem Request { get; }

    /// <summary>
    /// Choice the administrator made; None until a button is pressed.
    /// </summary>
    public RequestDecision Decision { get; private set; } = RequestDecision.None;

    #endregion

    #region Private Methods

    /// <summary>
    /// Tells whether the request was already approved or rejected, or has expired.
    /// </summary>
    /// <param name="status">Status of the request.</param>
    /// <returns>True for APPROVED, REJECTED or EXPIRED; otherwise false.</returns>
    private static bool IsDecided(string? status)
    {
        return string.Equals(status, UiConstants.APPROVED_STATUS, StringComparison.OrdinalIgnoreCase)
            || string.Equals(status, UiConstants.REJECTED_STATUS, StringComparison.OrdinalIgnoreCase)
            || string.Equals(status, UiConstants.EXPIRED_STATUS, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Records the approve choice and closes the dialog.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void ApproveButton_Click(object sender, RoutedEventArgs e)
    {
        CloseWith(RequestDecision.Approve);
    }

    /// <summary>
    /// Records the reject choice and closes the dialog.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void RejectButton_Click(object sender, RoutedEventArgs e)
    {
        CloseWith(RequestDecision.Reject);
    }

    /// <summary>
    /// Closes the dialog without a decision. Escape does the same.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        CloseWith(RequestDecision.None);
    }

    /// <summary>
    /// Lets the borderless dialog be moved by dragging it.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Mouse event arguments.</param>
    private void OnWindowMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed && e.OriginalSource is not TextBoxBase)
        {
            DragMove();
        }
    }

    /// <summary>
    /// Stores the decision and closes the dialog. The caller reads Decision afterwards.
    /// </summary>
    /// <param name="decision">Choice to record.</param>
    private void CloseWith(RequestDecision decision)
    {
        Decision = decision;
        Close();
    }

    #endregion
}
