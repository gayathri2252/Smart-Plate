﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Input;
using CertificateHandler.Data.Models;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Dialog that shows the trust status, identity and onboarding information of one whitelist or
/// blacklist entry. It only shows the entry; nothing is changed.
/// </summary>
public partial class DeviceDetailsWindow : Window
{
    #region Constructor

    /// <summary>
    /// Creates the dialog for the given entry with the given status text. The entry must not be null.
    /// </summary>
    /// <param name="entry">Whitelist or blacklist entry whose details are shown.</param>
    /// <param name="status">Status shown for the entry, such as Whitelisted or Blacklisted.</param>
    public DeviceDetailsWindow(DashboardTrustListRow entry, string status)
    {
        Entry = entry ?? throw new ArgumentNullException(nameof(entry));
        Status = status ?? string.Empty;
        InitializeComponent();

        // Never taller than the screen; the body scrolls on a small display such as the analyzer panel.
        MaxHeight = SystemParameters.WorkArea.Height;
        DataContext = entry;
        CurrentStatusText.Text = Status;
        MouseLeftButtonDown += OnWindowMouseLeftButtonDown;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Entry whose details are shown.
    /// </summary>
    public DashboardTrustListRow Entry { get; }

    /// <summary>
    /// Status shown for the entry.
    /// </summary>
    public string Status { get; }

    #endregion

    #region Private Methods

    /// <summary>
    /// Closes the dialog. Escape does the same.
    /// </summary>
    /// <param name="sender">Button that triggered the event.</param>
    /// <param name="e">Event arguments.</param>
    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    /// <summary>
    /// Lets the borderless dialog be moved by dragging it.
    /// </summary>
    /// <param name="sender">Source of the event.</param>
    /// <param name="e">Mouse event arguments.</param>
    private void OnWindowMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            DragMove();
        }
    }

    #endregion
}
