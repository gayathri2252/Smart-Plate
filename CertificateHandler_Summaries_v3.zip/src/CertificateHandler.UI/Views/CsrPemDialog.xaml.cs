// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;

namespace CertificateHandler.UI.Views;

public partial class CsrPemDialog : Window
{
    public string Pem { get; private set; } = string.Empty;

    public CsrPemDialog()
    {
        InitializeComponent();
    }

    private void ImportButton_Click(object sender, RoutedEventArgs e)
    {
        Pem = PemTextBox.Text?.Trim() ?? string.Empty;
        if (string.IsNullOrEmpty(Pem))
        {
            MessageBox.Show(this, "PEM text is required.");
            return;
        }

        DialogResult = true;
    }
}
