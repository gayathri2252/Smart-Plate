﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using CertificateHandler.UI.ViewModels;
using Calendar = System.Windows.Controls.Calendar;
using UiConstants = CertificateHandler.UI.Constants.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Filter panel of the request queue. It opens under the filter button, shows the filters
/// that are in use, and changes the queue only when Apply Filters or Clear is chosen.
/// It closes when the user clicks outside it or presses Escape.
/// </summary>
public partial class FilterWindow : Window
{
    #region Member Variables

    /// <summary>Space between the filter button and the panel, in device-independent pixels.</summary>
    private const double ANCHOR_GAP = 4;

    /// <summary>Formats a user may type: the date, as shown in the field; a date with a time is still accepted.</summary>
    private static readonly string[] AcceptedDateFormats =
    {
        UiConstants.DATE_TIME_FORMAT,
        UiConstants.DATE_TIME_FORMAT_NO_SECONDS,
        UiConstants.DATE_ONLY_FORMAT
    };

    /// <summary>Lowest screen position the panel may reach, in device-independent pixels.</summary>
    private double _bottomLimit = double.PositiveInfinity;

    /// <summary>Highest screen position the panel may reach, in device-independent pixels.</summary>
    private double _topLimit;

    /// <summary>True once the panel has started closing, so it is not closed twice.</summary>
    private bool _isClosing;

    /// <summary>True while a calendar is being reset before it opens, so the reset does not fill the field.</summary>
    private bool _isPreparingCalendar;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the <see cref="FilterWindow"/> class.
    /// </summary>
    public FilterWindow()
    {
        InitializeComponent();
        Loaded += FilterWindow_Loaded;
        SizeChanged += FilterWindow_SizeChanged;
        Deactivated += FilterWindow_Deactivated;
        Closing += FilterWindow_Closing;
        PreviewKeyDown += FilterWindow_PreviewKeyDown;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Shows the panel just below the given element, with its right edge in line with the
    /// element's right edge, and kept inside the screen work area.
    /// </summary>
    /// <param name="anchor">Element the panel opens under, normally the filter button.</param>
    public void ShowBelow(FrameworkElement anchor)
    {
        ArgumentNullException.ThrowIfNull(anchor);

        PresentationSource? source = PresentationSource.FromVisual(anchor);
        if (source?.CompositionTarget is not null)
        {
            // PointToScreen gives device pixels; the window position is in device-independent pixels.
            Matrix fromDevice = source.CompositionTarget.TransformFromDevice;
            Point bottomRight = fromDevice.Transform(anchor.PointToScreen(new Point(anchor.ActualWidth, anchor.ActualHeight)));

            Rect workArea = SystemParameters.WorkArea;
            _topLimit = workArea.Top;
            _bottomLimit = workArea.Bottom;

            // Stay inside the request queue window too, unless it fills the screen.
            if (Owner is not null && Owner.WindowState == WindowState.Normal)
            {
                _bottomLimit = Math.Min(_bottomLimit, Owner.Top + Owner.ActualHeight);
            }

            Left = Math.Max(workArea.Left, Math.Min(bottomRight.X - Width, workArea.Right - Width));
            Top = bottomRight.Y + ANCHOR_GAP;

            // When the panel does not fit below the button, move it up until its bottom is on screen.
            KeepInsideLimits(MeasurePanelHeight());
        }
        else
        {
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
        }

        Show();
        Activate();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Measures the height the panel needs before it is shown.
    /// </summary>
    /// <returns>Height of the panel, in device-independent pixels.</returns>
    private double MeasurePanelHeight()
    {
        if (Content is UIElement content)
        {
            content.Measure(new Size(Width, double.PositiveInfinity));
            return content.DesiredSize.Height;
        }

        return ActualHeight;
    }

    /// <summary>
    /// Moves the panel up when its bottom is below the limit, but never above the top of the screen.
    /// </summary>
    /// <param name="height">Height of the panel.</param>
    private void KeepInsideLimits(double height)
    {
        if (Top + height > _bottomLimit)
        {
            Top = _bottomLimit - height;
        }

        Top = Math.Max(_topLimit, Top);
    }

    /// <summary>
    /// Keeps the panel on screen when it grows, for example when an error message appears.
    /// </summary>
    private void FilterWindow_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (e.HeightChanged)
        {
            KeepInsideLimits(e.NewSize.Height);
        }
    }

    /// <summary>
    /// Fills the fields with the filters that are in use in the queue.
    /// </summary>
    private void FilterWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (DataContext is not PendingRequestQueueViewModel viewModel)
        {
            return;
        }

        StartDateTextBox.Text = FormatDate(viewModel.FromDate);
        EndDateTextBox.Text = FormatDate(viewModel.ToDate);
        MaxumIpTextBox.Text = viewModel.MaxumIpFilter ?? string.Empty;
        SelectStatusChip(viewModel.SelectedStatus);
    }

    /// <summary>
    /// Closes the panel when the user clicks outside it, unless a calendar is open. The close waits
    /// until Windows has finished moving the focus; closing during the switch makes Windows send the
    /// whole application behind other windows.
    /// </summary>
    private void FilterWindow_Deactivated(object? sender, EventArgs e)
    {
        if (_isClosing || StartCalendarPopup.IsOpen || EndCalendarPopup.IsOpen)
        {
            return;
        }

        Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            if (!_isClosing)
            {
                Close();
            }
        }));
    }

    /// <summary>
    /// Remembers that the panel is closing, so the deactivation that follows does not close it again,
    /// and returns the focus to the request queue window.
    /// </summary>
    private void FilterWindow_Closing(object? sender, CancelEventArgs e)
    {
        _isClosing = true;

        // When the panel closes while it has the focus (Apply, Clear, Escape), give the focus back to
        // the request queue window; otherwise Windows may bring another application to the front.
        if (IsActive)
        {
            Owner?.Activate();
        }
    }

    /// <summary>
    /// Closes the panel without changing the filters when Escape is pressed.
    /// </summary>
    private void FilterWindow_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            Close();
        }
    }

    /// <summary>
    /// Checks the dates, applies every filter to the queue and closes the panel. When a date
    /// cannot be read, or the start is after the end, the panel stays open and shows why.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">Event data associated with the click event.</param>
    private void OnApplyButtonClicked(object sender, RoutedEventArgs e)
    {
        ClearErrors();

        bool startValid = TryReadDate(StartDateTextBox.Text, isEndOfRange: false, out DateTime? fromDate);
        bool endValid = TryReadDate(EndDateTextBox.Text, isEndOfRange: true, out DateTime? toDate);

        if (!startValid)
        {
            ShowError(StartDateTextBox, StartDateErrorText, UiConstants.INVALID_DATE_TIME_TEXT);
        }

        if (!endValid)
        {
            ShowError(EndDateTextBox, EndDateErrorText, UiConstants.INVALID_DATE_TIME_TEXT);
        }

        if (startValid && endValid && fromDate.HasValue && toDate.HasValue && fromDate > toDate)
        {
            ShowError(EndDateTextBox, EndDateErrorText, UiConstants.END_BEFORE_START_TEXT);
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_FILTERS_INVALID);
            return;
        }

        if (!startValid || !endValid)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_FILTERS_INVALID);
            return;
        }

        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.FromDate = fromDate;
            viewModel.ToDate = toDate;
            viewModel.SelectedStatus = GetSelectedStatus();
            viewModel.MaxumIpFilter = MaxumIpTextBox.Text.Trim();
            viewModel.RefreshFilters();
        }

        Close();
    }

    /// <summary>
    /// Clears all filters and closes the panel.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">Event data associated with the click event.</param>
    private void OnFilterClearButtonClicked(object sender, RoutedEventArgs e)
    {
        if (DataContext is PendingRequestQueueViewModel viewModel)
        {
            viewModel.ClearFilters();
        }

        Close();
    }

    /// <summary>
    /// Opens the calendar of the start date.
    /// </summary>
    private void StartCalendarButton_Click(object sender, RoutedEventArgs e)
    {
        OpenCalendar(StartCalendarPopup, StartCalendar, StartDateTextBox.Text);
    }

    /// <summary>
    /// Opens the calendar of the end date.
    /// </summary>
    private void EndCalendarButton_Click(object sender, RoutedEventArgs e)
    {
        OpenCalendar(EndCalendarPopup, EndCalendar, EndDateTextBox.Text);
    }

    /// <summary>
    /// Puts the chosen day in the start field, from the start of that day.
    /// </summary>
    private void StartCalendar_SelectedDatesChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (!_isPreparingCalendar && StartCalendar.SelectedDate is DateTime day)
        {
            StartDateTextBox.Text = FormatDate(day.Date);
            StartCalendarPopup.IsOpen = false;
            ReleaseCalendarMouse();
            ClearError(StartDateTextBox, StartDateErrorText);
        }
    }

    /// <summary>
    /// Puts the chosen day in the end field, up to the end of that day.
    /// </summary>
    private void EndCalendar_SelectedDatesChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (!_isPreparingCalendar && EndCalendar.SelectedDate is DateTime day)
        {
            EndDateTextBox.Text = FormatDate(day.Date);
            EndCalendarPopup.IsOpen = false;
            ReleaseCalendarMouse();
            ClearError(EndDateTextBox, EndDateErrorText);
        }
    }

    /// <summary>
    /// Opens a calendar on the day already in its field, or on today when the field is empty.
    /// </summary>
    /// <param name="popup">Popup that holds the calendar.</param>
    /// <param name="calendar">Calendar to open.</param>
    /// <param name="currentText">Text of the date field the calendar belongs to.</param>
    private void OpenCalendar(Popup popup, Calendar calendar, string currentText)
    {
        // Clear the old selection without filling the field, so choosing the same day again still fills it.
        _isPreparingCalendar = true;
        calendar.SelectedDate = null;
        calendar.DisplayDate = TryReadDate(currentText, isEndOfRange: false, out DateTime? shown) && shown.HasValue
            ? shown.Value
            : DateTime.Today;
        _isPreparingCalendar = false;

        popup.IsOpen = true;
    }

    /// <summary>
    /// The calendar keeps the mouse after a day is chosen, so the next click would be lost; this frees it.
    /// </summary>
    private static void ReleaseCalendarMouse()
    {
        Mouse.Capture(null);
    }

    /// <summary>
    /// Reads a date from a field. An empty field means no limit. A date without a time
    /// means the start of that day, or the end of that day for the end of the range.
    /// </summary>
    /// <param name="text">Text of the field.</param>
    /// <param name="isEndOfRange">True for the end date field.</param>
    /// <param name="value">The date read, or null for an empty field.</param>
    /// <returns>True when the field is empty or holds a date in an accepted format.</returns>
    private static bool TryReadDate(string? text, bool isEndOfRange, out DateTime? value)
    {
        value = null;
        string trimmed = text?.Trim() ?? string.Empty;
        if (trimmed.Length == 0)
        {
            return true;
        }

        if (!DateTime.TryParseExact(trimmed, AcceptedDateFormats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out DateTime parsed))
        {
            return false;
        }

        bool dateOnly = trimmed.Length == UiConstants.DATE_ONLY_FORMAT.Length;
        value = dateOnly && isEndOfRange ? parsed.Date.AddDays(1).AddSeconds(-1) : parsed;
        return true;
    }

    /// <summary>
    /// Formats a date for a date field, without the time; an empty text for no date. The end date is
    /// read back as the end of that day, so the whole day stays included.
    /// </summary>
    private static string FormatDate(DateTime? value)
        => value?.ToString(UiConstants.DATE_ONLY_FORMAT, CultureInfo.InvariantCulture) ?? string.Empty;

    /// <summary>
    /// Checks the status chip whose status matches the given one, or All when none matches.
    /// </summary>
    /// <param name="status">Status in use in the queue.</param>
    private void SelectStatusChip(string? status)
    {
        RadioButton? match = StatusChipPanel.Children.OfType<RadioButton>()
            .FirstOrDefault(chip => string.Equals(chip.Tag as string, status, StringComparison.OrdinalIgnoreCase));

        (match ?? StatusChipPanel.Children.OfType<RadioButton>().First()).IsChecked = true;
    }

    /// <summary>
    /// Returns the status of the checked chip, or All when none is checked.
    /// </summary>
    private string GetSelectedStatus()
    {
        RadioButton? selected = StatusChipPanel.Children.OfType<RadioButton>()
            .FirstOrDefault(chip => chip.IsChecked == true);

        return selected?.Tag as string ?? UiConstants.ALL_STATUS;
    }

    /// <summary>
    /// Marks a field as wrong and shows the message under it.
    /// </summary>
    private void ShowError(TextBox field, TextBlock errorText, string message)
    {
        field.BorderBrush = (Brush)FindResource(UiConstants.FILTER_ERROR_BORDER_BRUSH_KEY);
        errorText.Text = message;
        errorText.Visibility = Visibility.Visible;
    }

    /// <summary>
    /// Removes the error mark and message of a field.
    /// </summary>
    private static void ClearError(TextBox field, TextBlock errorText)
    {
        field.ClearValue(BorderBrushProperty);
        errorText.Text = string.Empty;
        errorText.Visibility = Visibility.Collapsed;
    }

    /// <summary>
    /// Removes the error marks and messages of both date fields.
    /// </summary>
    private void ClearErrors()
    {
        ClearError(StartDateTextBox, StartDateErrorText);
        ClearError(EndDateTextBox, EndDateErrorText);
    }

    #endregion
}
