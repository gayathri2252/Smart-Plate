﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using CertificateHandler.Data;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Options;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.UI.ViewModels;
using DashboardCH.Models.Enums;
using DashboardCH.Services;
using Npgsql;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Views;

/// <summary>
/// Whitelist / Blacklist page: a switch between the active whitelist and blacklist entries, a device
/// search, the table of the selected list with paging, and a dialog with the details of an entry. It is
/// shown inside the request queue window, so the menu stays the same. Only a device administrator sees
/// the lists.
/// </summary>
public partial class TrustListView : UserControl
{
    #region Member Variables

    /// <summary>View model that holds the whitelist and blacklist entries.</summary>
    private readonly TrustListViewModel _viewModel;

    /// <summary>Database source for auxiliary RS_09 history.</summary>
    private readonly NpgsqlDataSource? _dataSource;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view and its view model on top of the given database connection, for the given user.
    /// A null user sees no entries.
    /// </summary>
    public TrustListView(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
        : this(CreateViewModel(dataSource, signedInUser))
    {
        _dataSource = dataSource;
    }

    /// <summary>
    /// Creates the view for the given view model. The lists are loaded when the page is first shown.
    /// The view model must not be null.
    /// </summary>
    public TrustListView(TrustListViewModel viewModel)
    {
        // Without a view model there is nothing to show.
        if (viewModel is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LIST_VIEW_MODEL_IS_NULL);
            throw new ArgumentNullException(nameof(viewModel));
        }

        _viewModel = viewModel;
        InitializeComponent();
        DataContext = viewModel;
        viewModel.PropertyChanged += ViewModel_PropertyChanged;

        // Binding the rows resets the sort state of the grid columns, so the arrow is shown again once loaded.
        TrustListGrid.Loaded += (_, _) => ShowSortArrow();
        Loaded += TrustListView_Loaded;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// True once the first load has finished, whether it worked or not.
    /// </summary>
    public bool IsFirstLoadDone { get; private set; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Loads the lists again, so the page shows the current entries. A failure is logged and does not
    /// reach the caller.
    /// </summary>
    public async Task ReloadAsync()
    {
        try
        {
            await _viewModel.LoadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LISTS_LOAD_FAILED, ex.Message);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Creates the view model with the trust list query on top of the given database connection, for the
    /// given user. The connection must not be null.
    /// </summary>
    private static TrustListViewModel CreateViewModel(NpgsqlDataSource dataSource, SignedInUser? signedInUser)
    {
        // Without a connection the trust list query cannot run.
        if (dataSource is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LIST_DATA_SOURCE_IS_NULL);
            throw new ArgumentNullException(nameof(dataSource));
        }

        CertificateHandlerDataAccess access = App.SharedDataAccess
            ?? CertificateHandlerDataAccess.Create(App.LoadDatabaseOptions());
        CertificateHandlerDbContext dbContext = access.CreateDbContext();
        ICertificateBlackList blackList = new PublishingCertificateBlackList(
            new Data.CertificateBlackList(dbContext),
            new TrustUpdatePublishService(
                TrustUpdatePublisherFactory.Create(access),
                new PublishFailureAuditWriter(dbContext),
                new NoOpAdministratorNotifier()));

        var validationEngine = new CertificateValidationEngine(
            new CertificateStoreAdapterFactory().Create(CertificateStorageMedium.WindowsCertificateStore),
            new SystemTimeVerificationService(),
            new ValidationResultWriter(dbContext));

        return new TrustListViewModel(
            new CertificateDashboard(dataSource),
            signedInUser,
            blackList,
            new ReinstatementWorkflowService(dataSource),
            new BulkBlacklistService(dataSource, blackList),
            validationEngine,
            () => signedInUser?.UserName ?? string.Empty);
    }

    /// <summary>
    /// Loads the lists the first time the page is shown.
    /// </summary>
    private async void TrustListView_Loaded(object sender, RoutedEventArgs e)
    {
        Loaded -= TrustListView_Loaded;
        await ReloadAsync();
        IsFirstLoadDone = true;
    }

    /// <summary>
    /// Shows the whitelist in the table.
    /// </summary>
    private void WhitelistTab_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.SelectList(TrustListKind.Whitelist);
    }

    /// <summary>
    /// Shows the blacklist in the table.
    /// </summary>
    private void BlacklistTab_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.SelectList(TrustListKind.Blacklist);
    }

    /// <summary>
    /// Filters the shown list as the user types. The entries are already loaded, so no query runs.
    /// </summary>
    private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        _viewModel.ApplySearch(SearchTextBox.Text);
    }

    /// <summary>
    /// Shows the next page of the table.
    /// </summary>
    private void NextPageButton_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.GoToNextPage();
    }

    /// <summary>
    /// Shows the previous page of the table.
    /// </summary>
    private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
    {
        _viewModel.GoToPreviousPage();
    }

    /// <summary>
    /// Changes the number of entries on a page to the size stored in the Tag of the chosen item.
    /// </summary>
    private void PageSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // The Tag holds the page size as text, such as "10".
        if (PageSizeComboBox.SelectedItem is ComboBoxItem { Tag: string tag } && int.TryParse(tag, out int pageSize))
        {
            _viewModel.ChangePageSize(pageSize);
        }
    }

    /// <summary>
    /// Opens the device details dialog for the entry of the row whose eye button was pressed. A failure is
    /// logged and does not reach the user.
    /// </summary>
    private void ViewDeviceButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: DashboardTrustListRow entry })
        {
            return;
        }

        try
        {
            var dialog = new DeviceDetailsWindow(entry, _viewModel.StatusText);
            Window? owner = Window.GetWindow(this);
            if (owner is not null)
            {
                dialog.Owner = owner;
            }

            dialog.ShowDialog();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DEVICE_DETAILS_OPEN_FAILED, ex.Message);
        }
    }

    /// <summary>
    /// Move to blacklist button of a whitelist row. Changing the trust state is not part of this page yet,
    /// so the press is only logged and nothing changes.
    /// </summary>
    private async void MoveToBlacklistButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: DashboardTrustListRow entry })
        {
            return;
        }

        _viewModel.SelectedEntry = entry;
        RejectReasonDialog dialog = new() { Title = "Blacklist reason", Owner = Window.GetWindow(this) };
        if (dialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            await _viewModel.MoveSelectedToBlacklistAsync(dialog.Reason);
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LISTS_LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    /// <summary>
    /// Reinstate button of a blacklist row.
    /// </summary>
    private async void BulkBlacklistButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_viewModel.IsDeviceAdministrator)
        {
            return;
        }

        BulkBlacklistDialog dialog = new() { Owner = Window.GetWindow(this) };
        if (dialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            await _viewModel.BulkBlacklistAsync(dialog.Thumbprints, dialog.Reason);
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LISTS_LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    private async void ReinstateButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: DashboardTrustListRow entry })
        {
            _viewModel.SelectedEntry = entry;
        }

        try
        {
            await _viewModel.ReinstateSelectedAsync();
            await ReloadAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.TRUST_LISTS_LOAD_FAILED, ex.Message);
            MessageBox.Show(ex.Message);
        }
    }

    /// <summary>
    /// Moves the sort arrow when the sort column or direction changes.
    /// </summary>
    /// <param name="sender">The view model.</param>
    /// <param name="e">Name of the property that changed.</param>
    private void ViewModel_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(TrustListViewModel.SortColumn) or nameof(TrustListViewModel.IsSortAscending))
        {
            ShowSortArrow();
        }
    }

    /// <summary>
    /// Sorts by the clicked column header; the same column again reverses the order.
    /// </summary>
    /// <param name="sender">The grid.</param>
    /// <param name="e">The column that was clicked.</param>
    private void TrustListGrid_Sorting(object sender, DataGridSortingEventArgs e)
    {
        // The view model sorts all rows, not only the visible page, so the grid's own sorting is turned off.
        e.Handled = true;
        _viewModel.SortBy(e.Column.SortMemberPath);
    }

    /// <summary>
    /// Shows the sort arrow on the column the rows are sorted by and clears it on every other column.
    /// </summary>
    private void WhitelistHistoryButton_Click(object sender, RoutedEventArgs e)
    {
        if (_dataSource is null)
        {
            MessageBox.Show("Database is not available.", UiConstants.WHITELIST_BLACKLIST);
            return;
        }

        WhitelistHistoryWindow window = new(_dataSource) { Owner = Window.GetWindow(this) };
        window.ShowDialog();
    }

    private void ShowSortArrow()
    {
        foreach (DataGridColumn column in TrustListGrid.Columns)
        {
            if (column.SortMemberPath != _viewModel.SortColumn)
            {
                column.SortDirection = null;
                continue;
            }

            column.SortDirection = _viewModel.IsSortAscending
                ? ListSortDirection.Ascending
                : ListSortDirection.Descending;
        }
    }

    #endregion
}
