﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;

namespace CertificateHandler.UI.Services;

/// <summary>
/// Tells every element of a window that the window is small, for example on the analyzer HMI panel.
/// The value is inherited, so the styles of the pages inside the window can react to it with a trigger
/// and show a smaller header, a lower table row and no footer. On a normal laptop screen it stays false
/// and nothing changes.
/// </summary>
public static class CompactLayout
{
    #region Member Variables

    /// <summary>Window width, in device independent pixels, below which the compact layout is used.</summary>
    public const double COMPACT_WIDTH = 1000;

    /// <summary>Window height, in device independent pixels, below which the compact layout is used.</summary>
    public const double COMPACT_HEIGHT = 640;

    #endregion

    #region Public Properties

    /// <summary>
    /// True when the window is small and the pages use the compact layout. Inherited by all child elements.
    /// </summary>
    public static readonly DependencyProperty IsCompactProperty = DependencyProperty.RegisterAttached(
        "IsCompact",
        typeof(bool),
        typeof(CompactLayout),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.Inherits));

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns whether the element uses the compact layout.
    /// </summary>
    public static bool GetIsCompact(DependencyObject element)
    {
        ArgumentNullException.ThrowIfNull(element);
        return (bool)element.GetValue(IsCompactProperty);
    }

    /// <summary>
    /// Sets whether the element and its children use the compact layout.
    /// </summary>
    public static void SetIsCompact(DependencyObject element, bool value)
    {
        ArgumentNullException.ThrowIfNull(element);
        element.SetValue(IsCompactProperty, value);
    }

    /// <summary>
    /// Returns true when a window of the given size should use the compact layout.
    /// </summary>
    public static bool IsCompactSize(double width, double height)
    {
        return width < COMPACT_WIDTH || height < COMPACT_HEIGHT;
    }

    #endregion
}
