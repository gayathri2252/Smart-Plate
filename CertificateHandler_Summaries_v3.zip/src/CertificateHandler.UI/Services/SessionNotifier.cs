﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows.Threading;
using CertificateHandler.Communication.Interface;
using CertificateHandler.Communication.Session;
using CertificateHandler.UI.ViewModels;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Services;

/// <summary>
/// Shows session refresh notifications in the banner on the UI thread.
/// The failure message stays until recovery; the recovery message hides itself after the configured time.
/// Dispose stops the hide timer and releases its event handler.
/// </summary>
public sealed class SessionNotifier : ISessionNotifier, IDisposable
{
    #region Member Variables

    private readonly SessionNotificationViewModel _viewModel;

    private readonly Dispatcher _dispatcher;

    private readonly DispatcherTimer _hideTimer;

    private bool _disposed;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the notifier for the banner view model, the UI dispatcher and the refresh settings.
    /// </summary>
    public SessionNotifier(SessionNotificationViewModel viewModel, Dispatcher dispatcher, SessionRefreshOptions options)
    {
        _viewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));
        _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
        ArgumentNullException.ThrowIfNull(options);

        _hideTimer = new DispatcherTimer(DispatcherPriority.Normal, _dispatcher)
        {
            Interval = TimeSpan.FromSeconds(options.NotificationDisplaySeconds)
        };
        _hideTimer.Tick += OnHideTimerTick;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Displays a refresh failure notification and keeps it visible until recovery occurs.
    /// </summary>
    /// <param name="message">
    /// Failure message displayed to the user.
    /// </param>
    public void NotifyRefreshFailed(string message)
    {
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), UiConstants.LOG_SESSION_BANNER_SHOWN, message);

        RunOnUiThread(() =>
        {
            if (_disposed)
            {
                return;
            }

            _hideTimer.Stop();
            _viewModel.ShowWarning(message);
        });
    }

    /// <summary>
    /// Displays a refresh recovery notification and starts the timer used
    /// to automatically hide the message after the configured interval.
    /// </summary>
    /// <param name="message">
    /// Recovery message displayed to the user.
    /// </param>
    public void NotifyRefreshRecovered(string message)
    {
        RunOnUiThread(() =>
        {
            if (_disposed)
            {
                return;
            }

            _viewModel.ShowInformation(message);
            _hideTimer.Stop();
            _hideTimer.Start();
        });
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Runs the action on the UI thread without blocking the calling thread.
    /// </summary>
    private void RunOnUiThread(Action action)
    {
        if (_dispatcher.CheckAccess())
        {
            action();
            return;
        }
        _dispatcher.BeginInvoke(action);
    }

    /// <summary>
    /// Hides the recovery message when its display time is over.
    /// </summary>
    private void OnHideTimerTick(object? sender, EventArgs e)
    {
        _hideTimer.Stop();
        _viewModel.Hide();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Stops the hide timer and unsubscribes from its Tick event. Later notifications are ignored.
    /// Calling it more than once is safe.
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _hideTimer.Stop();
        _hideTimer.Tick -= OnHideTimerTick;
    }

    #endregion
}
