﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows.Threading;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.UI.ViewModels;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.Services;

/// <summary>
/// Shows a publish failure in the notification banner of the administrator screen, on the UI thread.
/// The warning stays until the administrator or a later message replaces it.
/// </summary>
public sealed class AdministratorNotifier : IAdministratorNotifier
{
    #region Member Variables

    private readonly SessionNotificationViewModel _viewModel;
    private readonly Dispatcher _dispatcher;

    #endregion

    #region Constructors

    /// <summary>
    /// Creates the notifier for the banner view model and the UI dispatcher.
    /// </summary>
    /// <param name="viewModel">
    /// View model used to display notifications in the administrator banner.
    /// </param>
    /// <param name="dispatcher">
    /// UI dispatcher used to marshal notification updates to the UI thread.
    /// </param>
    public AdministratorNotifier(SessionNotificationViewModel viewModel, Dispatcher dispatcher)
    {
        _viewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));
        _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Displays a publish-failure warning in the administrator notification banner.
    /// If called from a background thread, the update is marshalled to the UI thread.
    /// </summary>
    /// <param name="message">
    /// Warning message shown to the administrator.
    /// </param>
    public void NotifyPublishFailed(string message)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOG_PUBLISH_FAILED_SHOWN, message);

        if (_dispatcher.CheckAccess())
        {
            _viewModel.ShowWarning(message);
            return;
        }
        _dispatcher.BeginInvoke(() => _viewModel.ShowWarning(message));
    }

    #endregion
}
