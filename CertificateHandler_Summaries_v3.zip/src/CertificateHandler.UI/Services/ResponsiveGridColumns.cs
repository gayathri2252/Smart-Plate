﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;

namespace CertificateHandler.UI.Services;

/// <summary>
/// Keeps every grid readable in a small window. A column marked with HideOrder is hidden when the grid is too narrow
/// for the minimum widths of its columns, and shown again when the window is wide enough. The columns with
/// HideOrder 0 (or no HideOrder) are never hidden. A higher HideOrder is hidden first. The details of a row stay
/// available through its view button.
/// </summary>
public static class ResponsiveGridColumns
{
    #region Member Variables

    /// <summary>Space kept free for the vertical scroll bar of the grid.</summary>
    private const double SCROLL_BAR_ALLOWANCE = 24;

    /// <summary>Smallest width used for a column that has no minimum width.</summary>
    private const double DEFAULT_MIN_WIDTH = 20;

    #endregion

    #region Public Properties

    /// <summary>
    /// Turns the automatic hiding of columns on for a grid.
    /// </summary>
    public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached(
        "IsEnabled",
        typeof(bool),
        typeof(ResponsiveGridColumns),
        new PropertyMetadata(false, OnIsEnabledChanged));

    /// <summary>
    /// Order in which a column is hidden: 0 never, a higher number earlier.
    /// </summary>
    public static readonly DependencyProperty HideOrderProperty = DependencyProperty.RegisterAttached(
        "HideOrder",
        typeof(int),
        typeof(ResponsiveGridColumns),
        new PropertyMetadata(0));

    /// <summary>
    /// Smaller minimum width of a column, used while the window is in the compact layout (see
    /// <see cref="CompactLayout"/>), so more columns fit on a small screen such as the analyzer HMI panel.
    /// A column with a fixed width gets this width too. Not set means the column keeps its normal width.
    /// </summary>
    public static readonly DependencyProperty CompactMinWidthProperty = DependencyProperty.RegisterAttached(
        "CompactMinWidth",
        typeof(double),
        typeof(ResponsiveGridColumns),
        new PropertyMetadata(double.NaN));

    /// <summary>Normal minimum width of a column, remembered the first time the compact width is used.</summary>
    private static readonly DependencyProperty NormalMinWidthProperty = DependencyProperty.RegisterAttached(
        "NormalMinWidth",
        typeof(double),
        typeof(ResponsiveGridColumns),
        new PropertyMetadata(double.NaN));

    /// <summary>Normal width of a column, remembered the first time the compact width is used.</summary>
    private static readonly DependencyProperty NormalWidthProperty = DependencyProperty.RegisterAttached(
        "NormalWidth",
        typeof(DataGridLength?),
        typeof(ResponsiveGridColumns),
        new PropertyMetadata(null));

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets whether the automatic hiding of columns is on for the grid.
    /// </summary>
    /// <param name="element">Grid to ask.</param>
    public static bool GetIsEnabled(DependencyObject element)
    {
        ArgumentNullException.ThrowIfNull(element);
        return (bool)element.GetValue(IsEnabledProperty);
    }

    /// <summary>
    /// Turns the automatic hiding of columns on or off for the grid.
    /// </summary>
    /// <param name="element">Grid to change.</param>
    /// <param name="value">True to turn it on.</param>
    public static void SetIsEnabled(DependencyObject element, bool value)
    {
        ArgumentNullException.ThrowIfNull(element);
        element.SetValue(IsEnabledProperty, value);
    }

    /// <summary>
    /// Gets the order in which the column is hidden.
    /// </summary>
    /// <param name="element">Column to ask.</param>
    public static int GetHideOrder(DependencyObject element)
    {
        ArgumentNullException.ThrowIfNull(element);
        return (int)element.GetValue(HideOrderProperty);
    }

    /// <summary>
    /// Sets the order in which the column is hidden.
    /// </summary>
    /// <param name="element">Column to change.</param>
    /// <param name="value">0 to never hide it, a higher number to hide it earlier.</param>
    public static void SetHideOrder(DependencyObject element, int value)
    {
        ArgumentNullException.ThrowIfNull(element);
        element.SetValue(HideOrderProperty, value);
    }

    /// <summary>
    /// Shows as many columns as fit into the given width. The columns that are never hidden always stay; the others
    /// are kept in order of their HideOrder, lowest first, until one does not fit; that one and all after it are hidden.
    /// </summary>
    /// <param name="columns">Columns of the grid.</param>
    /// <param name="availableWidth">Width the columns may use, without the scroll bar.</param>
    /// <summary>
    /// Returns the smaller minimum width of the column for the compact layout, or NaN when it has none.
    /// </summary>
    public static double GetCompactMinWidth(DependencyObject element)
    {
        ArgumentNullException.ThrowIfNull(element);
        return (double)element.GetValue(CompactMinWidthProperty);
    }

    /// <summary>
    /// Sets the smaller minimum width of the column for the compact layout.
    /// </summary>
    public static void SetCompactMinWidth(DependencyObject element, double value)
    {
        ArgumentNullException.ThrowIfNull(element);
        element.SetValue(CompactMinWidthProperty, value);
    }

    /// <summary>
    /// Gives every column that has a compact minimum width either its compact or its normal width.
    /// </summary>
    /// <param name="columns">Columns of the grid.</param>
    /// <param name="isCompact">True when the window uses the compact layout.</param>
    public static void ApplyCompactWidths(IEnumerable<DataGridColumn> columns, bool isCompact)
    {
        ArgumentNullException.ThrowIfNull(columns);

        foreach (DataGridColumn column in columns)
        {
            double compactMinWidth = GetCompactMinWidth(column);
            if (double.IsNaN(compactMinWidth))
            {
                continue;
            }

            if (double.IsNaN((double)column.GetValue(NormalMinWidthProperty)))
            {
                column.SetValue(NormalMinWidthProperty, column.MinWidth);
                column.SetValue(NormalWidthProperty, column.Width);
            }

            double normalMinWidth = (double)column.GetValue(NormalMinWidthProperty);
            DataGridLength normalWidth = (DataGridLength?)column.GetValue(NormalWidthProperty) ?? column.Width;

            column.MinWidth = isCompact ? compactMinWidth : normalMinWidth;
            if (normalWidth.IsAbsolute)
            {
                column.Width = isCompact ? new DataGridLength(compactMinWidth) : normalWidth;
            }
        }
    }

    /// <summary>
    /// Shows the columns that fit in the given width and hides the others, in the order of their hide order.
    /// </summary>
    public static void ApplyWidth(IEnumerable<DataGridColumn> columns, double availableWidth)
    {
        ArgumentNullException.ThrowIfNull(columns);

        List<DataGridColumn> all = columns.ToList();
        double used = all.Where(c => GetHideOrder(c) <= 0).Sum(MinimumWidthOf);
        bool full = false;

        foreach (DataGridColumn column in all.Where(c => GetHideOrder(c) > 0).OrderBy(GetHideOrder))
        {
            double needed = MinimumWidthOf(column);
            bool show = !full && used + needed <= availableWidth;

            if (show)
            {
                used += needed;
            }
            else
            {
                full = true;
            }

            Visibility wanted = show ? Visibility.Visible : Visibility.Collapsed;
            if (column.Visibility != wanted)
            {
                column.Visibility = wanted;
            }
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Starts or stops listening to the size of the grid.
    /// </summary>
    /// <param name="d">Grid whose property changed.</param>
    /// <param name="e">Change details.</param>
    private static void OnIsEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not DataGrid grid)
        {
            return;
        }

        DependencyPropertyDescriptor compactDescriptor =
            DependencyPropertyDescriptor.FromProperty(CompactLayout.IsCompactProperty, typeof(DataGrid));

        grid.SizeChanged -= OnGridSizeChanged;
        grid.Loaded -= OnGridLoaded;
        compactDescriptor.RemoveValueChanged(grid, OnGridCompactChanged);

        if ((bool)e.NewValue)
        {
            grid.SizeChanged += OnGridSizeChanged;
            grid.Loaded += OnGridLoaded;
            compactDescriptor.AddValueChanged(grid, OnGridCompactChanged);
        }
    }

    /// <summary>
    /// Fits the columns when the grid appears.
    /// </summary>
    /// <param name="sender">The grid.</param>
    /// <param name="e">Event arguments.</param>
    private static void OnGridLoaded(object sender, RoutedEventArgs e)
    {
        if (sender is DataGrid grid)
        {
            Apply(grid);
        }
    }

    /// <summary>
    /// Fits the columns when the width of the grid changes.
    /// </summary>
    /// <param name="sender">The grid.</param>
    /// <param name="e">Event arguments.</param>
    private static void OnGridSizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (e.WidthChanged && sender is DataGrid grid)
        {
            Apply(grid);
        }
    }

    /// <summary>
    /// Fits the columns of the grid to its current width.
    /// </summary>
    /// <param name="grid">Grid to fit.</param>
    /// <summary>
    /// Applies the column widths again when the window switches to or from the compact layout.
    /// </summary>
    private static void OnGridCompactChanged(object? sender, EventArgs e)
    {
        if (sender is DataGrid grid)
        {
            Apply(grid);
        }
    }

    private static void Apply(DataGrid grid)
    {
        ApplyCompactWidths(grid.Columns, CompactLayout.GetIsCompact(grid));

        double available = grid.ActualWidth - SCROLL_BAR_ALLOWANCE;
        if (available > 0)
        {
            ApplyWidth(grid.Columns, available);
        }
    }

    /// <summary>
    /// Smallest width of the column.
    /// </summary>
    /// <param name="column">Column to measure.</param>
    private static double MinimumWidthOf(DataGridColumn column)
    {
        return Math.Max(column.MinWidth, DEFAULT_MIN_WIDTH);
    }

    #endregion
}
