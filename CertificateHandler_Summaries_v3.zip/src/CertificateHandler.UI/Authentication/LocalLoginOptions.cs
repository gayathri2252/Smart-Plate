﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;
using Microsoft.Extensions.Configuration;

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Login settings read from the "CertificateHandler:Login" section of appsettings.json.
/// </summary>
public sealed class LocalLoginOptions
{
    #region Member Variables

    /// <summary>Section in appsettings.json that holds the login settings.</summary>
    public const string SectionName = "CertificateHandler:Login";

    /// <summary>Local Windows group for device administrators when nothing else is configured.</summary>
    public const string DEFAULT_ADMINISTRATOR_GROUP = DeviceAdministratorConstants.DefaultWindowsGroup;



    private const string APP_SETTINGS_FILE = "appsettings.json";

    #endregion

    #region Public Properties

    /// <summary>
    /// Platform-defined local Windows group whose members are MAXUM device administrators.
    /// Defaults to built-in <see cref="DeviceAdministratorConstants.DefaultWindowsGroup"/>.
    /// </summary>
    public string AdministratorGroup { get; set; } = DEFAULT_ADMINISTRATOR_GROUP;

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the login settings from appsettings.json and the environment variables.
    /// A missing file, section or blank group name falls back to the default group.
    /// </summary>
    /// <returns>The login settings.</returns>
    public static LocalLoginOptions Load()
    {
        string? fromPlatform = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.PlatformGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromPlatform))
        {
            return new LocalLoginOptions { AdministratorGroup = fromPlatform.Trim() };
        }

        string? fromLegacy = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.LegacyGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromLegacy))
        {
            return new LocalLoginOptions { AdministratorGroup = fromLegacy.Trim() };
        }

        IConfigurationRoot configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile(APP_SETTINGS_FILE, optional: true)
            .AddEnvironmentVariables()
            .Build();

        LocalLoginOptions options = configuration.GetSection(SectionName).Get<LocalLoginOptions>()
            ?? new LocalLoginOptions();

        if (string.IsNullOrWhiteSpace(options.AdministratorGroup))
        {
            options.AdministratorGroup = DEFAULT_ADMINISTRATOR_GROUP;
        }

        options.AdministratorGroup = options.AdministratorGroup.Trim();
        return options;
    }

    #endregion
}
