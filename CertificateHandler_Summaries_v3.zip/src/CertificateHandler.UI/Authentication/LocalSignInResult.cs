﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Outcome of checking a user name and password against the local Windows accounts.
/// </summary>
public enum LocalSignInResult
{
    /// <summary>The password is correct and the user is in the administrator group.</summary>
    Success,

    /// <summary>The user does not exist or the password is wrong.</summary>
    InvalidCredentials,

    /// <summary>The password is correct, but the user is not in the administrator group.</summary>
    NotAuthorized,

    /// <summary>Windows requires the user to change the password, or the password has expired.</summary>
    PasswordMustChange,

    /// <summary>The account is disabled, locked out or expired.</summary>
    AccountDisabled,

    /// <summary>Windows could not check the sign-in because of another error.</summary>
    Unavailable
}