﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.UI.Interfaces;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Calls Windows to log a local user on, find a local group and check group membership.
/// </summary>
public sealed partial class WindowsLogon : IWindowsLogon
{
    #region Member Variables

    /// <summary>
    /// Interactive logon, used when a policy does not allow a network logon.
    /// </summary>
    public const int LOGON32_LOGON_INTERACTIVE = 2;

    /// <summary>
    /// Network logon, which only checks the password.
    /// </summary>
    public const int LOGON32_LOGON_NETWORK = 3;

    /// <summary>
    /// Domain "." tells Windows to use the local accounts of this machine.
    /// </summary>
    private const string LOCAL_MACHINE_DOMAIN = ".";

    /// <summary>
    /// Default Windows logon provider.
    /// </summary>
    private const int LOGON32_PROVIDER_DEFAULT = 0;

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public int LogOn(string userName, string password, int logonType, out SafeAccessTokenHandle token)
    {
        bool loggedOn = LogonUser(userName, LOCAL_MACHINE_DOMAIN, password, logonType, LOGON32_PROVIDER_DEFAULT, out token);
        return loggedOn ? 0 : Marshal.GetLastWin32Error();
    }

    /// <inheritdoc />
    public SecurityIdentifier? FindGroup(string groupName)
    {
        // "MACHINE\Group" finds a local group; the name alone finds a built-in group such as Administrators.
        foreach (NTAccount account in new[] { new NTAccount(Environment.MachineName, groupName), new NTAccount(groupName) })
        {
            try
            {
                return (SecurityIdentifier)account.Translate(typeof(SecurityIdentifier));
            }
            catch (IdentityNotMappedException)
            {
                // Try the next form of the name.
            }
        }

        return null;
    }

    /// <inheritdoc />
    public bool IsInGroup(SafeAccessTokenHandle token, SecurityIdentifier group)
    {
        return WindowsIdentity.RunImpersonated(token, () =>
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            return new WindowsPrincipal(identity).IsInRole(group);
        });
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Windows LogonUser: checks the user name and password and returns a logon token.
    /// </summary>
    [LibraryImport("advapi32.dll", EntryPoint = "LogonUserW", StringMarshalling = StringMarshalling.Utf16, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool LogonUser(
        string lpszUsername,
        string lpszDomain,
        string lpszPassword,
        int dwLogonType,
        int dwLogonProvider,
        out SafeAccessTokenHandle phToken);

    #endregion
}