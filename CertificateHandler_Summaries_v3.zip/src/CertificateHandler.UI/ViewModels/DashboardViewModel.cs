﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using DataConstants = CertificateHandler.Data.Constants.Constants;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.ViewModels;

/// <summary>
/// Holds the dashboard card numbers and the visible page of the request queue overview, which is the
/// pending area. Each load runs the dashboard query once for the counts and one page, and does not build
/// certificate chains. Only a device administrator gets any rows; for anyone else nothing is queried.
/// </summary>
public sealed class DashboardViewModel : INotifyPropertyChanged
{
    #region Member Variables

    /// <summary>Number of pages moved by the previous and next commands.</summary>
    private const int PAGE_STEP = 1;

    /// <summary>Query that reads the counts and the page of pending requests.</summary>
    private readonly ICertificateDashboard _certificateDashboard;

    /// <summary>Number of whitelisted devices shown on the dashboard.</summary>
    private long _whitelistedDevices;

    /// <summary>Number of blacklisted devices shown on the dashboard.</summary>
    private long _blacklistedDevices;

    /// <summary>Number of pending requests shown on the dashboard.</summary>
    private long _pendingRequests;

    /// <summary>Number of expired certificates shown on the dashboard.</summary>
    private long _expiredCertificates;

    /// <summary>Number of active certificates shown on the dashboard.</summary>
    private long _totalCertificates;

    /// <summary>Number of certificates that expire within 30 days.</summary>
    private long _expiringWithin30Days;

    /// <summary>Number of certificates that expire within 90 days.</summary>
    private long _expiringWithin90Days;

    /// <summary>Number of failed validations inside the configured window.</summary>
    private long _validationFailures;

    /// <summary>Length in hours of the window used for the validation failure count.</summary>
    private int _validationFailureWindowHours = DataConstants.DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS;

    /// <summary>Number of the page that is shown.</summary>
    private int _pageNumber = DataConstants.FIRST_PAGE_NUMBER;

    /// <summary>Number of pages that match the current filter.</summary>
    private int _totalPages = DataConstants.FIRST_PAGE_NUMBER;

    /// <summary>Maximum number of rows on a page.</summary>
    private int _pageSize = DataConstants.DEFAULT_PAGE_SIZE;

    /// <summary>Number of pending requests that match the search and the filter, on all pages.</summary>
    private long _matchingRequests;

    /// <summary>True while a load is running.</summary>
    private bool _isLoading;

    /// <summary>Message shown when the last load failed; empty otherwise.</summary>
    private string _errorMessage = string.Empty;

    /// <summary>Time the last load took.</summary>
    private TimeSpan _lastLoadDuration;

    /// <summary>Search text that filters the pending requests.</summary>
    private string _searchText = string.Empty;

    /// <summary>Request type that filters the pending requests; null shows all types.</summary>
    private PendingRequestType? _selectedRequestType;

    /// <summary>Counter that lets a newer load replace the result of an older one.</summary>
    private int _loadVersion;

    /// <summary>Column the request overview is sorted by.</summary>
    private DashboardSortColumn _sortColumn = DashboardSortColumn.RequestDate;

    /// <summary>True when the request overview is sorted from the highest value down.</summary>
    private bool _sortDescending = true;

    /// <summary>User the dashboard is shown to; null when no one is signed in.</summary>
    private readonly SignedInUser? _signedInUser;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view model on top of the dashboard query for the given user, with the default page size.
    /// A null user is treated as a user who is not authorized.
    /// </summary>
    public DashboardViewModel(ICertificateDashboard certificateDashboard, SignedInUser? signedInUser)
        : this(certificateDashboard, signedInUser, DataConstants.DEFAULT_PAGE_SIZE)
    {
    }

    /// <summary>
    /// Creates the view model on top of the dashboard query for the given user, with the given page size.
    /// The query must not be null and the page size must be within the allowed range. A null user is
    /// treated as a user who is not authorized.
    /// </summary>
    public DashboardViewModel(ICertificateDashboard certificateDashboard, SignedInUser? signedInUser, int pageSize)
    {
        // Without the query the dashboard cannot load anything.
        if (certificateDashboard is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_QUERY_IS_NULL);
            throw new ArgumentNullException(nameof(certificateDashboard));
        }

        // The page size keeps each load small, so it must stay within the allowed range.
        if (pageSize < DataConstants.MIN_PAGE_SIZE || pageSize > DataConstants.MAX_PAGE_SIZE)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                UiConstants.PAGE_SIZE_OUT_OF_RANGE,
                pageSize.ToString(CultureInfo.InvariantCulture),
                DataConstants.MIN_PAGE_SIZE.ToString(CultureInfo.InvariantCulture),
                DataConstants.MAX_PAGE_SIZE.ToString(CultureInfo.InvariantCulture));
            throw new ArgumentOutOfRangeException(nameof(pageSize));
        }

        _certificateDashboard = certificateDashboard;
        _signedInUser = signedInUser;
        PageSize = pageSize;
        Requests = new ObservableCollection<DashboardRequestRow>();
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Pending requests of the visible page, newest first.
    /// </summary>
    public ObservableCollection<DashboardRequestRow> Requests { get; }

    /// <summary>
    /// True when the signed-in user has the device-administrator role, so the dashboard data may be loaded.
    /// </summary>
    public bool IsDeviceAdministrator => _signedInUser?.IsDeviceAdministrator == true;

    /// <summary>
    /// Fixed message for an empty pending area: one text when there are no pending requests at all,
    /// another when a search or request type filter hides them.
    /// </summary>
    public string PendingEmptyMessage =>
        string.IsNullOrEmpty(SearchText) && SelectedRequestType is null
            ? UiConstants.NO_PENDING_ITEMS
            : UiConstants.NO_MATCHING_PENDING_ITEMS;

    /// <summary>
    /// Maximum number of rows on a page; changed with the page size box under the table.
    /// </summary>
    public int PageSize
    {
        get => _pageSize;
        private set => SetField(ref _pageSize, value);
    }

    /// <summary>
    /// Number of pending requests that match the search and the filter, on all pages together.
    /// </summary>
    public long MatchingRequests
    {
        get => _matchingRequests;
        private set => SetField(ref _matchingRequests, value);
    }

    /// <summary>
    /// Text under the table, such as "Showing 1 to 10 of 24 entries", the same as on the other pages.
    /// </summary>
    public string ShowingText
    {
        get
        {
            int shown = Requests.Count;
            long first = shown == 0 ? 0 : ((long)(PageNumber - DataConstants.FIRST_PAGE_NUMBER) * PageSize) + 1;
            long last = shown == 0 ? 0 : first + shown - 1;

            return string.Format(CultureInfo.CurrentCulture, UiConstants.SHOWING_ENTRIES_FORMAT, first, last, MatchingRequests);
        }
    }

    /// <summary>
    /// Active whitelist entries.
    /// </summary>
    public long WhitelistedDevices
    {
        get => _whitelistedDevices;
        private set => SetField(ref _whitelistedDevices, value);
    }

    /// <summary>
    /// Active blacklist entries.
    /// </summary>
    public long BlacklistedDevices
    {
        get => _blacklistedDevices;
        private set => SetField(ref _blacklistedDevices, value);
    }

    /// <summary>
    /// Requests that are waiting for a decision.
    /// </summary>
    public long PendingRequests
    {
        get => _pendingRequests;
        private set => SetField(ref _pendingRequests, value);
    }

    /// <summary>
    /// Active certificates that have expired.
    /// </summary>
    public long ExpiredCertificates
    {
        get => _expiredCertificates;
        private set => SetField(ref _expiredCertificates, value);
    }

    /// <summary>
    /// Number of active certificates.
    /// </summary>
    public long TotalCertificates
    {
        get => _totalCertificates;
        private set => SetField(ref _totalCertificates, value);
    }

    /// <summary>
    /// Active certificates that expire within 30 days.
    /// </summary>
    public long ExpiringWithin30Days
    {
        get => _expiringWithin30Days;
        private set => SetField(ref _expiringWithin30Days, value);
    }

    /// <summary>
    /// Active certificates that expire within 90 days, including those within 30 days.
    /// </summary>
    public long ExpiringWithin90Days
    {
        get => _expiringWithin90Days;
        private set => SetField(ref _expiringWithin90Days, value);
    }

    /// <summary>
    /// Failed validations inside the configured window.
    /// </summary>
    public long ValidationFailures
    {
        get => _validationFailures;
        private set => SetField(ref _validationFailures, value);
    }

    /// <summary>
    /// Length in hours of the window used for the validation failure count.
    /// </summary>
    public int ValidationFailureWindowHours
    {
        get => _validationFailureWindowHours;
        private set => SetField(ref _validationFailureWindowHours, value);
    }

    /// <summary>
    /// Number of the visible page, starting at 1.
    /// </summary>
    public int PageNumber
    {
        get => _pageNumber;
        private set => SetField(ref _pageNumber, value);
    }

    /// <summary>
    /// Number of pages for the requests that match the filter; at least 1.
    /// </summary>
    public int TotalPages
    {
        get => _totalPages;
        private set => SetField(ref _totalPages, value);
    }

    /// <summary>
    /// True when a page after the visible one exists.
    /// </summary>
    public bool CanGoToNextPage => PageNumber < TotalPages;

    /// <summary>
    /// True when a page before the visible one exists.
    /// </summary>
    public bool CanGoToPreviousPage => PageNumber > DataConstants.FIRST_PAGE_NUMBER;

    /// <summary>
    /// True when the visible page has at least one request.
    /// </summary>
    public bool HasRequests => Requests.Count > 0;

    /// <summary>
    /// True while the dashboard query runs.
    /// </summary>
    public bool IsLoading
    {
        get => _isLoading;
        private set => SetField(ref _isLoading, value);
    }

    /// <summary>
    /// Message shown when the last load failed; empty when it succeeded.
    /// </summary>
    public string ErrorMessage
    {
        get => _errorMessage;
        private set => SetField(ref _errorMessage, value);
    }

    /// <summary>
    /// Time the last load took, from the start of the query until the values were set.
    /// </summary>
    public TimeSpan LastLoadDuration
    {
        get => _lastLoadDuration;
        private set => SetField(ref _lastLoadDuration, value);
    }

    /// <summary>
    /// Text the request overview is filtered by; empty shows every request.
    /// </summary>
    public string SearchText
    {
        get => _searchText;
        private set => SetField(ref _searchText, value);
    }

    /// <summary>
    /// Request type the overview is filtered by; null shows every type.
    /// </summary>
    public PendingRequestType? SelectedRequestType
    {
        get => _selectedRequestType;
        private set => SetField(ref _selectedRequestType, value);
    }

    /// <summary>
    /// Column the request overview is sorted by; the request date by default.
    /// </summary>
    public DashboardSortColumn SortColumn
    {
        get => _sortColumn;
        private set => SetField(ref _sortColumn, value);
    }

    /// <summary>
    /// True when the request overview is sorted from the highest value down; newest first by default.
    /// </summary>
    public bool SortDescending
    {
        get => _sortDescending;
        private set => SetField(ref _sortDescending, value);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// The dashboard load method: loads the counts and the first page of pending requests in one query.
    /// When the signed-in user is not a device administrator nothing is queried and no rows are shown.
    /// A failed load is logged and shown in ErrorMessage; cancellation is passed on.
    /// </summary>
    public Task LoadAsync(CancellationToken cancellationToken = default)
    {
        return LoadPageAsync(DataConstants.FIRST_PAGE_NUMBER, cancellationToken);
    }

    /// <summary>
    /// Filters the request overview by the given text and request type and shows its first page.
    /// Empty text and a null type show every pending request.
    /// </summary>
    public Task ApplyFilterAsync(
        string? searchText,
        PendingRequestType? requestType,
        CancellationToken cancellationToken = default)
    {
        SearchText = searchText?.Trim() ?? string.Empty;
        SelectedRequestType = requestType;
        OnPropertyChanged(nameof(PendingEmptyMessage));

        return LoadPageAsync(DataConstants.FIRST_PAGE_NUMBER, cancellationToken);
    }

    /// <summary>
    /// Sorts the request overview by the given column and shows its first page. Choosing the column that is
    /// already sorted reverses the order; a new column starts with the newest date first, or A to Z for text.
    /// </summary>
    public Task SortByAsync(DashboardSortColumn column, CancellationToken cancellationToken = default)
    {
        SortDescending = column == SortColumn
            ? !SortDescending
            : column == DashboardSortColumn.RequestDate;
        SortColumn = column;

        return LoadPageAsync(DataConstants.FIRST_PAGE_NUMBER, cancellationToken);
    }

    /// <summary>
    /// Loads the page after the visible one. Does nothing on the last page.
    /// </summary>
    public Task NextPageAsync(CancellationToken cancellationToken = default)
    {
        // On the last page there is nothing more to load.
        if (!CanGoToNextPage)
        {
            return Task.CompletedTask;
        }

        return LoadPageAsync(PageNumber + PAGE_STEP, cancellationToken);
    }

    /// <summary>
    /// Shows the given number of rows on a page, starting again on the first page. A size outside the
    /// allowed range, or the size already in use, changes nothing.
    /// </summary>
    /// <param name="pageSize">Number of rows on a page, such as 10, 25 or 50.</param>
    /// <param name="cancellationToken">Stops the load.</param>
    public Task ChangePageSizeAsync(int pageSize, CancellationToken cancellationToken = default)
    {
        if (pageSize == PageSize || pageSize < DataConstants.MIN_PAGE_SIZE || pageSize > DataConstants.MAX_PAGE_SIZE)
        {
            return Task.CompletedTask;
        }

        PageSize = pageSize;
        return LoadPageAsync(DataConstants.FIRST_PAGE_NUMBER, cancellationToken);
    }

    /// <summary>
    /// Loads the page before the visible one. Does nothing on the first page.
    /// </summary>
    public Task PreviousPageAsync(CancellationToken cancellationToken = default)
    {
        // On the first page there is no earlier page to load.
        if (!CanGoToPreviousPage)
        {
            return Task.CompletedTask;
        }

        return LoadPageAsync(PageNumber - PAGE_STEP, cancellationToken);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Runs the dashboard query for the given page and shows the result. The device-administrator role is
    /// checked first: for any other user, or no user, nothing is queried, no rows are shown and a warning
    /// is logged. On an error the earlier values stay, the error is logged and ErrorMessage is set. When a
    /// newer load has started in the meantime, the result of this one is dropped.
    /// </summary>
    private async Task LoadPageAsync(int pageNumber, CancellationToken cancellationToken)
    {
        int version = Interlocked.Increment(ref _loadVersion);
        if (!IsDeviceAdministrator)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                UiConstants.DASHBOARD_LOAD_NOT_AUTHORIZED,
                _signedInUser?.UserName ?? UiConstants.NO_SIGNED_IN_USER);
            ShowNoRows();
            return;
        }

        Stopwatch stopwatch = Stopwatch.StartNew();
        IsLoading = true;
        ErrorMessage = string.Empty;

        try
        {
            var filter = new DashboardRequestFilter
            {
                SearchText = SearchText,
                RequestType = SelectedRequestType,
                SortColumn = SortColumn,
                SortDescending = SortDescending
            };
            DashboardPage? page = await _certificateDashboard.GetDashboardPageAsync(
                pageNumber, PageSize, filter, cancellationToken);
            if (page is null)
            {
                throw new InvalidOperationException(UiConstants.DASHBOARD_QUERY_RETURNED_NOTHING);
            }
            if (version == Volatile.Read(ref _loadVersion))
            {
                ShowPage(page);
            }
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.DASHBOARD_LOAD_FAILED, ex.Message);

            if (version == Volatile.Read(ref _loadVersion))
            {
                ErrorMessage = UiConstants.DASHBOARD_LOAD_FAILED_FOR_USER;
            }
        }
        finally
        {
            stopwatch.Stop();

            if (version == Volatile.Read(ref _loadVersion))
            {
                LastLoadDuration = stopwatch.Elapsed;
                IsLoading = false;
            }
        }
    }

    /// <summary>
    /// Copies the counts, the page position and the rows of the loaded page.
    /// </summary>
    private void ShowPage(DashboardPage page)
    {
        WhitelistedDevices = page.Counts.Whitelisted;
        BlacklistedDevices = page.Counts.Blacklisted;
        PendingRequests = page.Counts.Pending;
        ExpiredCertificates = page.Counts.Expired;
        TotalCertificates = page.Counts.Total;
        ExpiringWithin30Days = page.Counts.ExpiringWithin30Days;
        ExpiringWithin90Days = page.Counts.ExpiringWithin90Days;
        ValidationFailures = page.Counts.ValidationFailures;
        ValidationFailureWindowHours = page.Counts.ValidationFailureWindowHours;
        PageNumber = page.PageNumber;
        TotalPages = page.TotalPages;
        MatchingRequests = page.MatchingRequests;

        Requests.Clear();

        foreach (DashboardRequestRow row in page.Rows)
        {
            Requests.Add(row);
        }

        OnPropertyChanged(nameof(CanGoToNextPage));
        OnPropertyChanged(nameof(CanGoToPreviousPage));
        OnPropertyChanged(nameof(HasRequests));
        OnPropertyChanged(nameof(ShowingText));
    }

    /// <summary>
    /// Empties the request overview and stops the load, for a user who may not see the dashboard data.
    /// </summary>
    private void ShowNoRows()
    {
        Requests.Clear();
        MatchingRequests = 0;
        ErrorMessage = string.Empty;
        IsLoading = false;

        OnPropertyChanged(nameof(HasRequests));
        OnPropertyChanged(nameof(ShowingText));
    }

    /// <summary>
    /// Sets the field and raises PropertyChanged when the value changed.
    /// </summary>
    private void SetField<T>(ref T field, T value, [CallerMemberName] string propertyName = "")
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return;
        }

        field = value;
        OnPropertyChanged(propertyName);
    }

    /// <summary>
    /// Raises the PropertyChanged event.
    /// </summary>
    private void OnPropertyChanged([CallerMemberName] string propertyName = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    #endregion

    #region Events

    /// <summary>
    /// Occurs when a property value changes.
    /// </summary>
    public event PropertyChangedEventHandler? PropertyChanged;

    #endregion
}
