﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using UiConstants = CertificateHandler.UI.Constants.Constants;

namespace CertificateHandler.UI.ViewModels;

/// <summary>
/// One row of the certificate view: a certificate with its text ready to show.
/// </summary>
public sealed class CertificateRowViewModel
{
    #region Public Properties

    /// <summary>Name of the certificate, SBC or MIB.</summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>Issuer of the certificate.</summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>Short type of the certificate: SBC or MIB.</summary>
    public string Type { get; init; } = string.Empty;

    /// <summary>Subject of the certificate.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>Thumbprint of the certificate.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>Not-after date as text, in local time.</summary>
    public string NotAfter { get; init; } = string.Empty;

    /// <summary>Result of the daily check; not available until daily validation exists.</summary>
    public string DailyCheck { get; init; } = string.Empty;

    /// <summary>WEF forwarding status; not available until WEF reporting exists.</summary>
    public string WefStatus { get; init; } = string.Empty;

    /// <summary>Status text: Valid, Nearing expiration, Expired or Not available.</summary>
    public string Status { get; init; } = string.Empty;

    /// <summary>Status value, used to colour the row.</summary>
    public CertificateExpiryStatus StatusValue { get; init; }

    /// <summary>Certificate role for renewal workflow.</summary>
    public CertificateRole Role { get; init; }

    public string PublicKeyAlgorithm { get; init; } = string.Empty;

    public string PublicKeyPem { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Holds the SBC and MIB certificate rows of the read-only certificate view. Nothing here
/// changes a certificate.
/// </summary>
public sealed class CertificateInformationViewModel : INotifyPropertyChanged
{
    #region Member Variables

    private readonly ICertificateInformationService _service;
    private readonly Func<string?> _userNameProvider;
    private readonly ICertificateExpiryMonitorService? _expiryMonitor;
    private readonly IWefCertificateEventWriter? _wefWriter;

    private readonly ICertificateRenewalWorkflowService? _renewalWorkflow;

    private readonly ITpmCsrExportService? _tpmCsrExport;

    private readonly IMccRenewalExportWriter? _mccExport;
    private bool _isLoading;
    private string _errorMessage = string.Empty;
    private bool _isAuthorized;
    private string _searchText = string.Empty;
    private string _filterKey = CertificateHandler.UI.Constants.Constants.ALL_STATUS;

    /// <summary>Rows that match the search text and the filter, on all pages together.</summary>
    private List<CertificateRowViewModel> _matchingCertificates = new();

    /// <summary>Number of the page shown in the grid, starting at 1.</summary>
    private int _pageNumber = FIRST_PAGE_NUMBER;

    /// <summary>Maximum number of rows on a page.</summary>
    private int _pageSize = DEFAULT_PAGE_SIZE;

    /// <summary>Number of the first page.</summary>
    private const int FIRST_PAGE_NUMBER = 1;

    /// <summary>Number of rows on a page until the user picks another page size.</summary>
    private const int DEFAULT_PAGE_SIZE = 10;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the view model. The user name provider returns the name of the signed-in user.
    /// Neither argument may be null.
    /// </summary>
    public CertificateInformationViewModel(
        ICertificateInformationService service,
        Func<string?> userNameProvider,
        ICertificateExpiryMonitorService? expiryMonitor = null,
        IWefCertificateEventWriter? wefWriter = null,
        ICertificateRenewalWorkflowService? renewalWorkflow = null,
        ITpmCsrExportService? tpmCsrExport = null,
        IMccRenewalExportWriter? mccExport = null)
    {
        if (service is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.SERVICE_IS_NULL);
            throw new ArgumentNullException(nameof(service));
        }

        if (userNameProvider is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.USER_PROVIDER_IS_NULL);
            throw new ArgumentNullException(nameof(userNameProvider));
        }

        _service = service;
        _userNameProvider = userNameProvider;
        _expiryMonitor = expiryMonitor;
        _wefWriter = wefWriter;
        _renewalWorkflow = renewalWorkflow;
        _tpmCsrExport = tpmCsrExport;
        _mccExport = mccExport;
    }

    #endregion

    #region Events

    public event PropertyChangedEventHandler? PropertyChanged;

    #endregion

    #region Public Properties

    /// <summary>Rows for the SBC and MIB certificates; empty when the user is not an administrator.</summary>
    public ObservableCollection<CertificateRowViewModel> Certificates { get; } = new();

    /// <summary>Rows that match the search text and the filter and are on the current page; this is what the grid shows.</summary>
    public ObservableCollection<CertificateRowViewModel> VisibleCertificates { get; } = new();

    /// <summary>Search text; the visible rows update on every change and the first page is shown.</summary>
    public string SearchText
    {
        get => _searchText;
        set
        {
            if (SetField(ref _searchText, value ?? string.Empty))
            {
                CurrentPage = FIRST_PAGE_NUMBER;
                Refresh();
            }
        }
    }

    /// <summary>Number of rows that match the search text and the filter, on all pages together.</summary>
    public int MatchingCount => _matchingCertificates.Count;

    /// <summary>Number of the page shown in the grid, starting at 1.</summary>
    public int CurrentPage
    {
        get => _pageNumber;
        private set => SetField(ref _pageNumber, value);
    }

    /// <summary>Maximum number of rows on a page.</summary>
    public int PageSize
    {
        get => _pageSize;
        private set => SetField(ref _pageSize, value);
    }

    /// <summary>Number of pages of matching rows; at least 1, so an empty grid still shows page 1.</summary>
    public int TotalPages => Math.Max(FIRST_PAGE_NUMBER, (MatchingCount + PageSize - 1) / PageSize);

    /// <summary>True when there is a page before the current one.</summary>
    public bool CanGoToPreviousPage => CurrentPage > FIRST_PAGE_NUMBER;

    /// <summary>True when there is a page after the current one.</summary>
    public bool CanGoToNextPage => CurrentPage < TotalPages;

    /// <summary>
    /// Text under the grid such as "Showing 11 to 20 of 25 entries"; "Showing 0 to 0 of 0 entries" when
    /// nothing matches.
    /// </summary>
    public string ShowingText
    {
        get
        {
            int shown = VisibleCertificates.Count;
            int first = shown == 0 ? 0 : ((CurrentPage - 1) * PageSize) + 1;
            int last = shown == 0 ? 0 : first + shown - 1;

            return string.Format(CultureInfo.CurrentCulture, UiConstants.SHOWING_ENTRIES_FORMAT, first, last, MatchingCount);
        }
    }

    /// <summary>Current filter: All, SBC, MIB or a status name such as Expired.</summary>
    public string FilterKey => _filterKey;

    /// <summary>True while a load is running.</summary>
    public bool IsLoading
    {
        get => _isLoading;
        private set => SetField(ref _isLoading, value);
    }

    /// <summary>Message shown instead of the rows when loading failed or the user is not allowed; empty otherwise.</summary>
    public string ErrorMessage
    {
        get => _errorMessage;
        private set
        {
            if (SetField(ref _errorMessage, value))
            {
                OnPropertyChanged(nameof(HasError));
            }
        }
    }

    /// <summary>True when there is a message to show instead of the rows.</summary>
    public bool HasError => !string.IsNullOrEmpty(_errorMessage);

    /// <summary>True when the signed-in user is an administrator.</summary>
    public bool IsAuthorized
    {
        get => _isAuthorized;
        private set => SetField(ref _isAuthorized, value);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Sets the filter (All, SBC, MIB, Valid, NearingExpiration, Expired or NotAvailable).
    /// A null or empty key shows every certificate.
    /// </summary>
    public void ApplyFilter(string? key)
    {
        _filterKey = string.IsNullOrWhiteSpace(key) ? CertificateHandler.UI.Constants.Constants.ALL_STATUS : key;
        OnPropertyChanged(nameof(FilterKey));
        CurrentPage = FIRST_PAGE_NUMBER;
        Refresh();
    }

    /// <summary>
    /// Moves to the next page, like the request queue does. A page after the last one shows no rows.
    /// </summary>
    public void NextPage()
    {
        CurrentPage++;
        Refresh(keepCurrentPage: true);
    }

    /// <summary>
    /// Shows the previous page; does nothing on the first page.
    /// </summary>
    public void PreviousPage()
    {
        if (CanGoToPreviousPage)
        {
            CurrentPage--;
            Refresh();
        }
    }

    /// <summary>
    /// Changes the number of rows on a page and shows the first page. A size below 1 is ignored.
    /// </summary>
    public void ChangePageSize(int pageSize)
    {
        if (pageSize < 1)
        {
            return;
        }

        PageSize = pageSize;
        CurrentPage = FIRST_PAGE_NUMBER;
        Refresh();
    }

    /// <summary>
    /// Loads the certificate rows for the signed-in user. Never throws: a failure becomes the
    /// error message and the rows are cleared.
    /// </summary>
    public async Task<Guid> RequestRenewalAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        if (!IsAuthorized || _renewalWorkflow is null)
        {
            throw new InvalidOperationException("Renewal is not available.");
        }

        return await _renewalWorkflow.StartLocalRenewalAsync(role, cancellationToken);
    }

    public async Task ExportCsrAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        if (!IsAuthorized || _renewalWorkflow is null)
        {
            throw new InvalidOperationException("Renewal is not available.");
        }

        RenewalWorkflowState? state = await _renewalWorkflow.GetLatestRenewalForRoleAsync(role, cancellationToken)
            ?? throw new InvalidOperationException("Create a renewal request first.");

        if (_tpmCsrExport is null)
        {
            throw new InvalidOperationException("TPM CSR export is not configured.");
        }

        string pem = await _tpmCsrExport.ExportCsrPemAsync(state.KeyId, cancellationToken);
        await _renewalWorkflow.RecordCsrPemAsync(state.RenewalRequestId, pem, markExported: true, cancellationToken);
        _mccExport?.ExportCsrPem(state.KeyId, pem);
    }

    public async Task RecordManualCsrAsync(CertificateRole role, string csrPem, CancellationToken cancellationToken = default)
    {
        if (!IsAuthorized || _renewalWorkflow is null)
        {
            throw new InvalidOperationException("Renewal is not available.");
        }

        RenewalWorkflowState? state = await _renewalWorkflow.GetLatestRenewalForRoleAsync(role, cancellationToken)
            ?? throw new InvalidOperationException("Create a renewal request first.");

        await _renewalWorkflow.RecordCsrPemAsync(state.RenewalRequestId, csrPem, markExported: false, cancellationToken);
    }

    public async Task ImportSignedCertificateAsync(CertificateRole role, string pem, CancellationToken cancellationToken = default)
    {
        if (!IsAuthorized || _renewalWorkflow is null)
        {
            throw new InvalidOperationException("Renewal is not available.");
        }

        RenewalWorkflowState? state = await _renewalWorkflow.GetLatestRenewalForRoleAsync(role, cancellationToken)
            ?? throw new InvalidOperationException("Create a renewal request first.");

        await _renewalWorkflow.RecordImportedAsync(state.RenewalRequestId, pem, cancellationToken);
    }

    public async Task ActivateRenewalAsync(CertificateRole role, CancellationToken cancellationToken = default)
    {
        if (!IsAuthorized || _renewalWorkflow is null)
        {
            throw new InvalidOperationException("Renewal is not available.");
        }

        await _renewalWorkflow.ActivateRenewalForRoleAsync(role, cancellationToken);
    }

    public async Task LoadAsync(CancellationToken cancellationToken = default)
    {
        IsLoading = true;
        ErrorMessage = string.Empty;
        Certificates.Clear();

        try
        {
            CertificateInformationResult result = await _service.GetCertificateInformationAsync(_userNameProvider(), cancellationToken);

            IsAuthorized = result.IsAuthorized;
            if (!result.IsAuthorized)
            {
                ErrorMessage = UiConstants.NOT_AUTHORIZED_TEXT;
                return;
            }

            foreach (CertificateDetails details in result.Certificates)
            {
                string daily = _expiryMonitor is null
                    ? UiConstants.STATUS_NOT_AVAILABLE
                    : await _expiryMonitor.GetDailyCheckStatusAsync(details.Thumbprint, cancellationToken);

                string wef = UiConstants.STATUS_NOT_AVAILABLE;
                if (_wefWriter is not null && details.NotAfter is not null)
                {
                    if (details.Status == CertificateExpiryStatus.NearingExpiration)
                    {
                        _wefWriter.WriteExpiryAlert(details.Role.ToString(), details.Thumbprint, details.NotAfter.Value);
                        wef = "Forwarded";
                    }
                    else
                    {
                        wef = "OK";
                    }
                }

                Certificates.Add(ToRow(details, daily, wef));
            }
        }
        catch (OperationCanceledException)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), UiConstants.CERTIFICATE_LOAD_CANCELLED);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), UiConstants.LOAD_FAILED, ex.Message);
            IsAuthorized = false;
            Certificates.Clear();
            ErrorMessage = UiConstants.LOAD_FAILED_TEXT;
        }
        finally
        {
            Refresh();
            IsLoading = false;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Refreshes the visible certificate collection: applies the current search text and selected
    /// filter to all loaded rows, then shows only the rows of the current page. When the result
    /// became shorter, the last page that still has rows is shown.
    /// </summary>
    /// <param name="keepCurrentPage">True to stay on the current page even when it has no rows.</param>
    private void Refresh(bool keepCurrentPage = false)
    {
        string term = _searchText.Trim();

        _matchingCertificates = Certificates
            .Where(row => MatchesSearch(row, term) && MatchesFilter(row))
            .ToList();
        if (!keepCurrentPage && CurrentPage > TotalPages)
        {
            CurrentPage = TotalPages;
        }

        VisibleCertificates.Clear();
        foreach (CertificateRowViewModel row in _matchingCertificates.Skip((CurrentPage - 1) * PageSize).Take(PageSize))
        {
            VisibleCertificates.Add(row);
        }

        OnPropertyChanged(nameof(MatchingCount));
        OnPropertyChanged(nameof(TotalPages));
        OnPropertyChanged(nameof(CanGoToPreviousPage));
        OnPropertyChanged(nameof(CanGoToNextPage));
        OnPropertyChanged(nameof(ShowingText));
    }

    /// <summary>
    /// Determines whether the certificate row matches the entered search text.
    /// Returns true when the search text is empty or when any searchable
    /// certificate field contains the search term.
    /// </summary>
    /// <param name="row">Certificate row to evaluate.</param>
    /// <param name="term">Search text entered by the user.</param>
    /// <returns>
    /// True if the row matches the search criteria; otherwise false.
    /// </returns>
    private static bool MatchesSearch(CertificateRowViewModel row, string term)
    {
        if (term.Length == 0)
        {
            return true;
        }

        return Contains(row.Name, term) || Contains(row.Type, term) || Contains(row.Issuer, term)
            || Contains(row.Subject, term) || Contains(row.Thumbprint, term) || Contains(row.Status, term);
    }

    /// <summary>
    /// Determines whether the certificate row matches the currently selected filter.
    /// Returns true when the All filter is selected, when the certificate type
    /// matches the selected SBC or MIB filter, or when the certificate status
    /// matches the selected status filter.
    /// </summary>
    /// <param name="row">Certificate row to evaluate.</param>
    /// <returns>
    /// True if the row satisfies the active filter; otherwise false.
    /// </returns>
    private bool MatchesFilter(CertificateRowViewModel row)
    {
        if (_filterKey == CertificateHandler.UI.Constants.Constants.ALL_STATUS)
        {
            return true;
        }

        if (_filterKey == CertificateHandler.UI.Constants.Constants.SBC_TYPE || _filterKey == CertificateHandler.UI.Constants.Constants.MIB_TYPE)
        {
            return string.Equals(row.Type, _filterKey, StringComparison.Ordinal);
        }

        return string.Equals(row.StatusValue.ToString(), _filterKey, StringComparison.Ordinal);
    }

    /// <summary>
    /// Determines whether the specified text contains the provided search term,
    /// using a case-insensitive comparison.
    /// </summary>
    /// <param name="text">Text to search within.</param>
    /// <param name="term">Search term to look for.</param>
    /// <returns>
    /// True if the search term is found in the text; otherwise false.
    /// </returns>
    private static bool Contains(string text, string term)
        => text.Contains(term, StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Converts certificate details returned by the service into a view model row
    /// that is ready to be displayed in the certificate information view.
    /// </summary>
    /// <param name="details">Certificate details to convert.</param>
    /// <returns>
    /// A populated <see cref="CertificateRowViewModel"/> containing formatted
    /// certificate information and status values.
    /// </returns>
    private static CertificateRowViewModel ToRow(CertificateDetails details, string dailyCheck, string wefStatus)
    {
        return new CertificateRowViewModel
        {
            Name = details.Role == CertificateRole.LocalSbc
                ? UiConstants.SBC_NAME
                : UiConstants.MIB_NAME,
            Type = details.Role == CertificateRole.LocalSbc ? CertificateHandler.UI.Constants.Constants.SBC_TYPE : CertificateHandler.UI.Constants.Constants.MIB_TYPE,
            Issuer = details.Issuer,
            Subject = details.Subject,
            Thumbprint = details.Thumbprint,
            NotAfter = details.NotAfter is null
                ? UiConstants.NO_DATE_TEXT
                : details.NotAfter.Value.ToLocalTime().ToString(UiConstants.DATE_FORMAT, CultureInfo.CurrentCulture),
            DailyCheck = dailyCheck,
            WefStatus = wefStatus,
            Status = ToStatusText(details.Status),
            StatusValue = details.Status,
            Role = details.Role,
            PublicKeyAlgorithm = details.PublicKeyAlgorithm,
            PublicKeyPem = details.PublicKeyPem
        };
    }

    /// <summary>
    /// Converts a certificate expiry status value to the corresponding
    /// user-facing status text displayed in the certificate view.
    /// </summary>
    /// <param name="status">Certificate expiry status.</param>
    /// <returns>
    /// Localized status text for the specified certificate status.
    /// </returns>
    private static string ToStatusText(CertificateExpiryStatus status) => status switch
    {
        CertificateExpiryStatus.Valid => UiConstants.STATUS_VALID,
        CertificateExpiryStatus.NearingExpiration => UiConstants.STATUS_NEARING_EXPIRATION,
        CertificateExpiryStatus.Expired => UiConstants.STATUS_EXPIRED,
        _ => UiConstants.STATUS_NOT_AVAILABLE
    };

    /// <summary>
    /// Sets the specified field value and raises a property changed notification
    /// when the value has changed.
    /// </summary>
    /// <typeparam name="T">Type of the property value.</typeparam>
    /// <param name="field">Reference to the backing field.</param>
    /// <param name="value">New value to assign.</param>
    /// <param name="propertyName">Name of the property being updated.</param>
    /// <returns>
    /// True if the field value was changed; otherwise false.
    /// </returns>
    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    /// <summary>
    /// Raises the <see cref="PropertyChanged"/> event to notify the UI that
    /// the value of a property has changed.
    /// </summary>
    /// <param name="propertyName">
    /// Name of the property that changed.
    /// </param>
    private void OnPropertyChanged(string? propertyName)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    #endregion
}
