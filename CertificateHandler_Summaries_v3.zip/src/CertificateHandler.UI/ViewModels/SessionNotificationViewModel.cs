﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CertificateHandler.UI.ViewModels;

/// <summary>
/// Holds the text and visibility of the session notification banner.
/// The banner is non-blocking, so the user can keep working while the connection recovers.
/// </summary>
public sealed class SessionNotificationViewModel : INotifyPropertyChanged
{
    #region Member Variables

    private string _message = string.Empty;
    private bool _isVisible;
    private bool _isWarning;

    #endregion

    #region Events

    public event PropertyChangedEventHandler? PropertyChanged;

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the text shown in the banner.
    /// </summary>
    public string Message
    {
        get => _message;
        private set => SetField(ref _message, value);
    }

    /// <summary>
    /// Gets a value indicating whether the banner is shown.
    /// </summary>
    public bool IsVisible
    {
        get => _isVisible;
        private set => SetField(ref _isVisible, value);
    }

    /// <summary>
    /// Gets a value indicating whether the banner shows a warning (true) or information (false).
    /// </summary>
    public bool IsWarning
    {
        get => _isWarning;
        private set => SetField(ref _isWarning, value);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Shows a warning message in the banner.
    /// </summary>
    public void ShowWarning(string message)
    {
        Show(message, isWarning: true);
    }

    /// <summary>
    /// Shows an information message in the banner.
    /// </summary>
    public void ShowInformation(string message)
    {
        Show(message, isWarning: false);
    }

    /// <summary>
    /// Hides the banner and clears its text.
    /// </summary>
    public void Hide()
    {
        IsVisible = false;
        Message = string.Empty;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Sets the message and type and makes the banner visible.
    /// </summary>
    private void Show(string message, bool isWarning)
    {
        Message = message ?? string.Empty;
        IsWarning = isWarning;
        IsVisible = true;
    }

    /// <summary>
    /// Updates a field and raises PropertyChanged when its value changes.
    /// </summary>
    private void SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return;
        }

        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    #endregion
}
