﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.UI.Authentication;

namespace CertificateHandler.UI.Interfaces;

/// <summary>
/// Checks a user name and password against the local Windows accounts of this machine.
/// </summary>
public interface ILocalUserAuthenticator
{
    /// <summary>
    /// Platform local Windows group that defines MAXUM device administrators (default: built-in Administrators).
    /// </summary>
    string AdministratorGroup { get; }

    /// <summary>
    /// Checks the user name and password, and whether the user is a local device administrator.
    /// The password is only passed to Windows; it is never stored or logged.
    /// </summary>
    /// <param name="userName">Local Windows user name, for example "DeviceAdmin".</param>
    /// <param name="password">Password of that Windows user.</param>
    /// <returns>The outcome of the check.</returns>
    LocalSignInResult SignIn(string userName, string password);
}