﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using Microsoft.Win32.SafeHandles;
using System.Security.Principal;

namespace CertificateHandler.UI.Interfaces;

/// <summary>
/// The Windows calls the sign-in needs, kept behind an interface so the sign-in rules can be unit tested.
/// </summary>
public interface IWindowsLogon
{
    /// <summary>
    /// Logs the user on to this machine with the given logon type.
    /// </summary>
    /// <returns>0 when the logon succeeded, otherwise the Windows error code.</returns>
    int LogOn(string userName, string password, int logonType, out SafeAccessTokenHandle token);

    /// <summary>
    /// Finds the security identifier of a local group, or null when the group does not exist.
    /// </summary>
    SecurityIdentifier? FindGroup(string groupName);

    /// <summary>
    /// Checks whether the identity of the logon token is a member of the group.
    /// </summary>
    bool IsInGroup(SafeAccessTokenHandle token, SecurityIdentifier group);
}