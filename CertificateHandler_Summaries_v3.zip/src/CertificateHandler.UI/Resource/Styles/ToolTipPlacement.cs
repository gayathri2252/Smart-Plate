﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Threading;

namespace CertificateHandler.UI.Resource.Styles;

/// <summary>
/// Places a tooltip right above the element it belongs to, centred on it, and moves the small arrow of
/// the tooltip so it points at the middle of that element. A tooltip that would go past the left or right
/// edge of the application window is moved back inside it, and its arrow still points at the element.
/// It is switched on for every tooltip by the tooltip style in Styles.xaml.
/// </summary>
public static class ToolTipPlacement
{
    #region Member Variables

    /// <summary>
    /// When true on a tooltip, the tooltip is centred above its element and its arrow points at it.
    /// </summary>
    public static readonly DependencyProperty CenterAboveOwnerProperty = DependencyProperty.RegisterAttached(
        "CenterAboveOwner",
        typeof(bool),
        typeof(ToolTipPlacement),
        new PropertyMetadata(false, OnCenterAboveOwnerChanged));

    /// <summary>Name of the arrow in the tooltip template.</summary>
    private const string ARROW_PART_NAME = "Arrow";

    /// <summary>Smallest space kept between the arrow and the rounded corners of the tooltip.</summary>
    private const double ARROW_EDGE_GAP = 6;

    /// <summary>Smallest space kept between the tooltip and the left or right edge of the application window.</summary>
    private const double WINDOW_EDGE_GAP = 8;

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets whether the tooltip is centred above its element.
    /// </summary>
    /// <param name="element">The tooltip.</param>
    /// <returns>True when the tooltip is centred above its element.</returns>
    public static bool GetCenterAboveOwner(DependencyObject element)
    {
        return (bool)element.GetValue(CenterAboveOwnerProperty);
    }

    /// <summary>
    /// Sets whether the tooltip is centred above its element.
    /// </summary>
    /// <param name="element">The tooltip.</param>
    /// <param name="value">True to centre the tooltip above its element.</param>
    public static void SetCenterAboveOwner(DependencyObject element, bool value)
    {
        element.SetValue(CenterAboveOwnerProperty, value);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Starts or stops listening for the tooltip being opened.
    /// </summary>
    private static void OnCenterAboveOwnerChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not ToolTip toolTip)
        {
            return;
        }

        toolTip.Opened -= OnToolTipOpened;
        if (e.NewValue is true)
        {
            toolTip.Opened += OnToolTipOpened;
        }
    }

    /// <summary>
    /// Centres the opened tooltip above its element, then points the arrow once the tooltip has its final place.
    /// </summary>
    private static void OnToolTipOpened(object sender, RoutedEventArgs e)
    {
        if (sender is not ToolTip toolTip)
        {
            return;
        }

        FrameworkElement? owner = toolTip.PlacementTarget as FrameworkElement ?? FindOwner(toolTip);
        if (owner is null)
        {
            return;
        }

        if (!ReferenceEquals(toolTip.PlacementTarget, owner))
        {
            toolTip.PlacementTarget = owner;
        }

        toolTip.Placement = PlacementMode.Top;
        toolTip.HorizontalOffset = GetHorizontalOffset(toolTip, owner);

        toolTip.Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() => PointArrowAtOwner(toolTip, owner)));
    }

    /// <summary>
    /// Gives the shift of the tooltip from the left edge of its element: centred on the element, but moved
    /// left or right when needed so the whole tooltip stays inside the application window.
    /// </summary>
    /// <param name="toolTip">The opened tooltip.</param>
    /// <param name="owner">Element the tooltip belongs to.</param>
    /// <returns>The horizontal offset, in device-independent pixels.</returns>
    private static double GetHorizontalOffset(ToolTip toolTip, FrameworkElement owner)
    {
        double centred = (owner.ActualWidth - toolTip.ActualWidth) / 2;

        if (Window.GetWindow(owner) is not { Content: FrameworkElement windowContent }
            || !windowContent.IsAncestorOf(owner))
        {
            return centred;
        }

        // All values below are in device-independent pixels, measured from the left edge of the window content.
        double ownerLeft = owner.TranslatePoint(new Point(0, 0), windowContent).X;
        double toolTipLeft = ownerLeft + centred;
        double maxLeft = windowContent.ActualWidth - toolTip.ActualWidth - WINDOW_EDGE_GAP;

        if (toolTipLeft > maxLeft)
        {
            toolTipLeft = maxLeft;
        }

        if (toolTipLeft < WINDOW_EDGE_GAP)
        {
            toolTipLeft = WINDOW_EDGE_GAP;
        }

        return toolTipLeft - ownerLeft;
    }

    /// <summary>
    /// Finds the element the tooltip belongs to: the element under the mouse, or its nearest parent, whose tooltip it is.
    /// </summary>
    private static FrameworkElement? FindOwner(ToolTip toolTip)
    {
        DependencyObject? element = Mouse.DirectlyOver as DependencyObject;
        while (element is not null)
        {
            if (element is FrameworkElement candidate && candidate.ToolTip is not null
                && (ReferenceEquals(candidate.ToolTip, toolTip) || Equals(candidate.ToolTip, toolTip.Content)))
            {
                return candidate;
            }

            element = element is Visual or Visual3D
                ? VisualTreeHelper.GetParent(element)
                : LogicalTreeHelper.GetParent(element);
        }

        return null;
    }

    /// <summary>
    /// Moves the arrow of the tooltip under the middle of its element.
    /// </summary>
    private static void PointArrowAtOwner(ToolTip toolTip, FrameworkElement owner)
    {
        if (!toolTip.IsOpen
            || toolTip.Template?.FindName(ARROW_PART_NAME, toolTip) is not FrameworkElement arrow
            || PresentationSource.FromVisual(toolTip) is not { CompositionTarget: { } compositionTarget }
            || PresentationSource.FromVisual(owner) is null)
        {
            return;
        }

        // Screen positions are in device pixels; the arrow margin is in device-independent pixels.
        double scale = compositionTarget.TransformToDevice.M11 > 0 ? compositionTarget.TransformToDevice.M11 : 1;
        Point ownerMiddle = owner.PointToScreen(new Point(owner.ActualWidth / 2, 0));
        Point toolTipLeft = toolTip.PointToScreen(new Point(0, 0));

        double left = ((ownerMiddle.X - toolTipLeft.X) / scale) - (arrow.ActualWidth / 2);
        double maxLeft = Math.Max(ARROW_EDGE_GAP, toolTip.ActualWidth - arrow.ActualWidth - ARROW_EDGE_GAP);

        arrow.HorizontalAlignment = HorizontalAlignment.Left;
        arrow.Margin = new Thickness(Math.Clamp(left, ARROW_EDGE_GAP, maxLeft), 0, 0, 0);
    }

    #endregion
}
