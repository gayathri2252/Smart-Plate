﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.UI.Constants;

/// <summary>
/// Contains UI display text constants.
/// </summary>
/// 
public static class Constants
{
    #region Member Variables

    /// <summary>
    /// Displays the CertAdmin console title.
    /// </summary>
    public const string CERT_ADMIN_CONSOLE = "CertAdmin Console";

    /// <summary>
    /// Product family shown in green at the top of the side bar.
    /// </summary>
    public const string PRODUCT_FAMILY = "MAXUM";

    /// <summary>
    /// Product name shown next to the product family at the top of the side bar.
    /// </summary>
    public const string PRODUCT_NAME = "Certificate Handler";

    /// <summary>
    /// Displays the request queue title.
    /// </summary>
    public const string REQUEST_QUEUE = "Request Queue";

    /// <summary>
    /// Describes the request queue page.
    /// </summary>
    public const string REQUEST_QUEUE_DESCRIPTION = "Review, validate, and action certificate approval requests";

    /// <summary>
    /// Placeholder text for the search box.
    /// </summary>
    public const string SEARCH_REQUESTS_PLACEHOLDER = "Search by device, IP address, certificate subject or requester...";

    /// <summary>
    /// Message shown when no requests exist.
    /// </summary>
    public const string NO_PENDING_REQUESTS_AVAILABLE = "No pending requests available.";

    /// <summary>
    /// Shown on the Approved tab when there are no approved requests.
    /// </summary>
    public const string NO_APPROVED_REQUESTS_AVAILABLE = "No approved requests available.";

    /// <summary>
    /// Shown on the Rejected tab when there are no rejected requests.
    /// </summary>
    public const string NO_REJECTED_REQUESTS_AVAILABLE = "No rejected requests available.";

    /// <summary>
    /// Shown on the Expired tab when there are no expired requests.
    /// </summary>
    public const string NO_EXPIRED_REQUESTS_AVAILABLE = "No expired requests available.";

    /// <summary>
    /// Header text for request ID.
    /// </summary>
    public const string REQUEST_ID_HEADER = "Request ID";

    /// <summary>
    /// Header text for device identifier.
    /// </summary>
    public const string DEVICE_IDENTIFIER_HEADER = "Device Identifier";

    /// <summary>
    /// Header text for request type.
    /// </summary>
    public const string REQUEST_TYPE_HEADER = "Request Type";

    /// <summary>
    /// Header text for requester information.
    /// </summary>
    public const string REQUESTER_HEADER = "Requester";

    /// <summary>
    /// Header text for requester source.
    /// </summary>
    public const string REQUESTED_BY_HEADER = "Requested By";

    /// <summary>
    /// Header text for request date.
    /// </summary>
    public const string REQUEST_DATE_HEADER = "Request Date";

    /// <summary>
    /// Header text for request status.
    /// </summary>
    public const string STATUS_HEADER = "Status";

    /// <summary>
    /// Header text for available actions.
    /// </summary>
    public const string ACTIONS_HEADER = "Actions";

    /// <summary>
    /// Label for MAXUM IP information.
    /// </summary>
    public const string MAXUM_IP = "MAXUM IP";

    /// <summary>
    /// Default pagination information text.
    /// </summary>
    public const string DEFAULT_PAGE_INFO = "Showing 1 to 3 of 3 entries";

    /// <summary>
    /// Display text for pending status.
    /// </summary>
    public const string PENDING = "Pending";

    /// <summary>
    /// Display text for approved status.
    /// </summary>
    public const string APPROVED = "Approved";

    /// <summary>
    /// Display text for rejected status.
    /// </summary>
    public const string REJECTED = "Rejected";

    /// <summary>
    /// Display text for expired status.
    /// </summary>
    public const string EXPIRED = "Expired";

    /// <summary>
    /// Page size option for ten records.
    /// </summary>
    public const string PAGE_SIZE_10 = "10 / page";

    /// <summary>
    /// Page size option for twenty-five records.
    /// </summary>
    public const string PAGE_SIZE_25 = "25 / page";

    /// <summary>
    /// Page size option for fifty records.
    /// </summary>
    public const string PAGE_SIZE_50 = "50 / page";

    /// <summary>
    /// Shield icon used in the sidebar.
    /// </summary>
    public const string SHIELD_ICON = "🛡";

    /// <summary>
    /// Icon representing the request queue.
    /// </summary>
    public const string REQUEST_QUEUE_ICON = "📋";

    /// <summary>
    /// Search icon displayed in the search box.
    /// </summary>
    public const string SEARCH_ICON = "🔍";

    /// <summary>
    /// Previous navigation icon.
    /// </summary>
    public const string PREVIOUS_ICON = "❮";

    /// <summary>
    /// Next navigation icon.
    /// </summary>
    public const string NEXT_ICON = "❯";

    /// <summary>
    /// Icon used for approve action.
    /// </summary>
    public const string APPROVE_ICON = "✔";

    /// <summary>
    /// Icon used for reject action.
    /// </summary>
    public const string REJECT_ICON = "✖";

    /// <summary>
    /// Window title for pending request queue view.
    /// </summary>
    public const string PENDING_REQUEST_QUEUE_VIEW_TITLE = "PendingRequestQueueView";

    /// <summary>
    /// Default pending request count text.
    /// </summary>
    public const string PENDING_REQUEST_COUNT_TEXT = "3";

    /// <summary>
    /// Default approved request count text.
    /// </summary>
    public const string APPROVED_REQUEST_COUNT_TEXT = "1";

    /// <summary>
    /// Default rejected request count text.
    /// </summary>
    public const string REJECTED_REQUEST_COUNT_TEXT = "0";

    /// <summary>
    /// Default expired request count text.
    /// </summary>
    public const string EXPIRED_REQUEST_COUNT_TEXT = "1";

    /// <summary>
    /// Title displayed on the filter window.
    /// </summary>
    public const string FILTERS_TITLE = "Filters";

    /// <summary>
    /// Option representing all statuses.
    /// </summary>
    public const string ALL_STATUS = "All";

    /// <summary>
    /// Internal pending status value.
    /// </summary>
    public const string PENDING_STATUS = "PENDING";

    /// <summary>
    /// Internal approved status value.
    /// </summary>
    public const string APPROVED_STATUS = "APPROVED";

    /// <summary>
    /// Internal rejected status value.
    /// </summary>
    public const string REJECTED_STATUS = "REJECTED";

    /// <summary>
    /// Internal expired status value.
    /// </summary>
    public const string EXPIRED_STATUS = "EXPIRED";

    /// <summary>
    /// Filter section heading.
    /// </summary>
    public const string FILTERS = "Filters";

    /// <summary>
    /// Label for start date and time.
    /// </summary>
    public const string START_DATE_TIME = "Start Date";

    /// <summary>
    /// Label for end date and time.
    /// </summary>
    public const string END_DATE_TIME = "End Date";

    /// <summary>
    /// Label for status selection.
    /// </summary>
    public const string STATUS = STATUS_HEADER;

    /// <summary>
    /// Text displayed on the apply button.
    /// </summary>
    public const string APPLY_FILTERS = "Apply Filters";

    /// <summary>
    /// Text displayed on the clear button.
    /// </summary>
    public const string CLEAR = "Clear";

    /// <summary>
    /// Window title for login page.
    /// </summary>
    public const string LOGIN_TITLE = "CertAdmin Login";

    /// <summary>
    /// Login page header text.
    /// </summary>
    public const string LOGIN_HEADER = "CertAdmin Login";

    /// <summary>
    /// Login page description text.
    /// </summary>
    public const string LOGIN_DESCRIPTION = "Sign in to access Certificate Handler";

    /// <summary>
    /// Label for username field.
    /// </summary>
    public const string USERNAME = "Username";

    /// <summary>
    /// Label for password field.
    /// </summary>
    public const string PASSWORD = "Password";

    /// <summary>
    /// Login button text.
    /// </summary>
    public const string LOGIN = "Login";

    /// <summary>
    /// Icon used for password visibility toggle.
    /// </summary>
    public const string REVEAL_ICON = "👁";

    /// <summary>
    /// Application name shown in the header bar of the login page.
    /// </summary>
    public const string APP_HEADER = "VALMET MAXUM CERTIFICATE HANDLER";

    /// <summary>
    /// Company name shown next to the logo on the login page.
    /// </summary>
    public const string COMPANY_NAME = "Valmet";

    /// <summary>
    /// Placeholder text for the user name box.
    /// </summary>
    public const string USERNAME_PLACEHOLDER = "Enter username";

    /// <summary>
    /// Placeholder text for the password box.
    /// </summary>
    public const string PASSWORD_PLACEHOLDER = "Enter password";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a person, shown in the user name box.
    /// </summary>
    public const string USER_GLYPH = "\uE77B";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a lock, shown in the password box.
    /// </summary>
    public const string LOCK_GLYPH = "\uE72E";

    /// <summary>
    /// Title of the dashboard menu item.
    /// </summary>
    public const string DASHBOARD = "Dashboard";

    /// <summary>
    /// Title of the Certificate Management menu item.
    /// </summary>
    public const string CERTIFICATE_MANAGEMENT = "Certificate Management";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a document, shown next to the Certificate Management menu item.
    /// </summary>
    public const string CERTIFICATE_MANAGEMENT_GLYPH = "\uE8A5";

    /// <summary>
    /// Certificate type of the SBC certificate, shown and filtered on the Certificate Management page.
    /// </summary>
    public const string SBC_TYPE = "SBC";

    /// <summary>
    /// Certificate type of the MIB certificate, shown and filtered on the Certificate Management page.
    /// </summary>
    public const string MIB_TYPE = "MIB";

    /// <summary>
    /// Icon representing the dashboard.
    /// </summary>
    public const string HOME_ICON = "\U0001F3E0";

    /// <summary>
    /// Title of the log out menu item.
    /// </summary>
    public const string LOG_OUT = "Log out";

    /// <summary>
    /// Question shown before the user is logged out.
    /// </summary>
    public const string LOGOUT_CONFIRM_MESSAGE = "Are you sure you want to log out?";

    /// <summary>
    /// Title of the log out confirmation box.
    /// </summary>
    public const string LOGOUT_CONFIRM_TITLE = "Confirm log out";

    /// <summary>
    /// Explanation under the log out question.
    /// </summary>
    public const string LOGOUT_CONFIRM_DESCRIPTION = "You will need to sign in again to use the application.";

    /// <summary>
    /// Text of the button that keeps the user signed in.
    /// </summary>
    public const string LOGOUT_CANCEL = "Cancel";

    /// <summary>
    /// Icon representing log out.
    /// </summary>
    public const string LOGOUT_ICON = "\U0001F6AA";

    /// <summary>
    /// Header text for the device name column of the request queue.
    /// </summary>
    public const string DEVICE_NAME_HEADER = "Device Name";

    /// <summary>
    /// Header text for the IP address column of the request queue.
    /// </summary>
    public const string IP_ADDRESS_HEADER = "IP Address";

    /// <summary>
    /// Header text for the certificate subject column of the request queue.
    /// </summary>
    public const string CERTIFICATE_SUBJECT_HEADER = "Certificate Subject";

    /// <summary>
    /// Header text for the request date column of the request queue.
    /// </summary>
    public const string REQUESTED_ON_HEADER = "Requested On";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a magnifying glass, shown in the request search box.
    /// </summary>
    public const string SEARCH_GLYPH = "\uE721";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a check mark, used by the approve button.
    /// </summary>
    public const string APPROVE_GLYPH = "\uE73E";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a cross, used by the reject button.
    /// </summary>
    public const string REJECT_GLYPH = "\uE711";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a left chevron, used by the previous page button.
    /// </summary>
    public const string PREVIOUS_GLYPH = "\uE76B";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a right chevron, used by the next page button.
    /// </summary>
    public const string NEXT_GLYPH = "\uE76C";


    /// <summary>
    /// Outline funnel of the filter buttons (Segoe MDL2 Assets), the same on every page.
    /// </summary>
    public const string FILTER_GLYPH = "\uE71C";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a house, shown next to the Dashboard menu item.
    /// </summary>
    public const string HOME_GLYPH = "\uE80F";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a check list, shown next to the Request Queue menu item.
    /// </summary>
    public const string REQUEST_QUEUE_GLYPH = "\uE9D5";

    /// <summary>
    /// Segoe MDL2 Assets glyph of an arrow leaving a door, shown on the log out button in the top bar.
    /// </summary>
    public const string LOGOUT_GLYPH = "\uF3B1";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a cross, used by the close button of a dialog.
    /// </summary>
    public const string CLOSE_GLYPH = "\uE8BB";

    /// <summary>
    /// Tooltip of the view details button.
    /// </summary>
    public const string VIEW_DETAILS = "View details";

    /// <summary>
    /// Title of the certificate request details dialog.
    /// </summary>
    public const string REQUEST_DETAILS_TITLE = "Certificate Request Details";

    /// <summary>
    /// Description of the certificate request details dialog.
    /// </summary>
    public const string REQUEST_DETAILS_DESCRIPTION = "Validate the device identity and certificate before taking action.";

    /// <summary>
    /// Label of the device in the request details dialog.
    /// </summary>
    public const string DETAILS_DEVICE = "Device";

    /// <summary>
    /// Label of the IP address in the request details dialog.
    /// </summary>
    public const string DETAILS_IP_ADDRESS = "IP address";

    /// <summary>
    /// Label of the certificate subject in the request details dialog.
    /// </summary>
    public const string DETAILS_CERTIFICATE_SUBJECT = "Certificate subject";

    /// <summary>
    /// Label of the requesting user in the request details dialog.
    /// </summary>
    public const string DETAILS_REQUESTED_BY = "Requested by";

    /// <summary>
    /// Label of the request date in the request details dialog.
    /// </summary>
    public const string DETAILS_REQUESTED_ON = "Requested on";

    /// <summary>
    /// Label of the status in the request details dialog.
    /// </summary>
    public const string DETAILS_STATUS = STATUS_HEADER;

    /// <summary>
    /// Label of the request type in the request details dialog.
    /// </summary>
    public const string DETAILS_REQUEST_TYPE = "Request type";

    /// <summary>
    /// Label of the certificate thumbprint in the request details dialog.
    /// </summary>
    public const string DETAILS_THUMBPRINT = "Certificate thumbprint";

    /// <summary>
    /// Text of the reject button in the request details dialog.
    /// </summary>
    public const string REJECT = "Reject";

    /// <summary>
    /// Text of the approve button in the request details dialog.
    /// </summary>
    public const string APPROVE_REQUEST = "Approve Request";

    /// <summary>
    /// Label of the start of the certificate validity in the request details dialog.
    /// </summary>
    public const string DETAILS_VALID_FROM = "Certificate valid from";

    /// <summary>
    /// Label of the end of the certificate validity in the request details dialog.
    /// </summary>
    public const string DETAILS_VALID_UNTIL = "Certificate valid until";

    /// <summary>
    /// Shown in the request details dialog when a value is not known.
    /// </summary>
    public const string NOT_AVAILABLE = "Not available";

    /// <summary>
    /// Text of the button that collapses the side bar.
    /// </summary>
    public const string COLLAPSE = "Collapse";

    /// <summary>
    /// Tooltip of the approve button in a row of the Request Queue.
    /// </summary>
    public const string APPROVE_TOOLTIP = "Approve this certificate request";

    /// <summary>
    /// Tooltip of the reject button in a row of the Request Queue.
    /// </summary>
    public const string REJECT_TOOLTIP = "Reject this certificate request";

    /// <summary>
    /// Tooltip of the view button in a row of the Request Queue.
    /// </summary>
    public const string VIEW_REQUEST_DETAILS_TOOLTIP = "View the certificate request details";

    /// <summary>
    /// Tooltip of the view button in a row of the Whitelist / Blacklist page.
    /// </summary>
    public const string VIEW_DEVICE_DETAILS_TOOLTIP = "View the device details";

    /// <summary>
    /// Tooltip of the view button in a row of the Certificate Management page.
    /// </summary>
    public const string VIEW_CERTIFICATE_DETAILS_TOOLTIP = "View the certificate details";

    /// <summary>
    /// Tooltip of the button with three dots in a row of the Certificate Management page.
    /// </summary>
    public const string MORE_ACTIONS_TOOLTIP = "More actions";


    public const string DETAILS_REQUEST_ID = "Request ID";

    /// <summary>
    /// Title of the Whitelist / Blacklist page and its menu item.
    /// </summary>
    public const string WHITELIST_BLACKLIST = "Whitelist / Blacklist";

    /// <summary>
    /// Describes the Whitelist / Blacklist page.
    /// </summary>
    public const string WHITELIST_BLACKLIST_DESCRIPTION = "Manage device trust, onboarding, and security status";

    /// <summary>
    /// Shown in the Whitelist / Blacklist table while the lists are being loaded.
    /// </summary>
    public const string TRUST_LIST_LOADING = "Loading...";

    /// <summary>
    /// Title of the whitelist tab.
    /// </summary>
    public const string WHITELIST = "Whitelist";

    /// <summary>
    /// Title of the blacklist tab.
    /// </summary>
    public const string BLACKLIST = "Blacklist";

    /// <summary>
    /// Status shown for an entry on the whitelist.
    /// </summary>
    public const string WHITELISTED = "Whitelisted";

    /// <summary>
    /// Status shown for an entry on the blacklist.
    /// </summary>
    public const string BLACKLISTED = "Blacklisted";

    /// <summary>
    /// Placeholder text for the device search box.
    /// </summary>
    public const string SEARCH_DEVICES_PLACEHOLDER = "Search by device, IP address, certificate subject or thumbprint...";

    /// <summary>
    /// Message shown on the whitelist tab when there are no active whitelist entries.
    /// </summary>
    public const string NO_WHITELISTED_ITEMS = "There are no whitelisted devices.";

    /// <summary>
    /// Message shown on the blacklist tab when there are no active blacklist entries.
    /// </summary>
    public const string NO_BLACKLISTED_ITEMS = "There are no blacklisted devices.";

    /// <summary>
    /// Message shown on either tab when no entry matches the search text.
    /// </summary>
    public const string NO_MATCHING_TRUST_ITEMS = "No devices match the search.";

    /// <summary>
    /// Message shown in the pending area of the dashboard when there are no pending requests at all.
    /// </summary>
    public const string NO_PENDING_ITEMS = "There are no pending requests.";

    /// <summary>
    /// Message shown in the pending area of the dashboard when no pending request matches the search or filter.
    /// </summary>
    public const string NO_MATCHING_PENDING_ITEMS = "No pending requests match.";

    /// <summary>
    /// Message shown when the signed-in user is not a device administrator.
    /// </summary>
    public const string DASHBOARD_NOT_AUTHORIZED = "Only a device administrator can see the trust state of this device.";

    /// <summary>
    /// Header text for the time an entry was added.
    /// </summary>
    public const string ADDED_ON_HEADER = "Added On";

    /// <summary>
    /// Header text for the user who added an entry.
    /// </summary>
    public const string ADDED_BY_HEADER = "Added By";

    /// <summary>
    /// Text under the tabs that tells how many entries are shown; filled with the first and last entry
    /// numbers of the page and the number of matching entries.
    /// </summary>
    public const string SHOWING_ENTRIES_FORMAT = "Showing {0} to {1} of {2} entries";

    /// <summary>
    /// Tooltip of the button that moves a whitelisted device to the blacklist.
    /// </summary>
    public const string MOVE_TO_BLACKLIST_TOOLTIP = "Move this device to the blacklist";

    /// <summary>
    /// Tooltip of the button that reinstates a blacklisted device to the whitelist.
    /// </summary>
    public const string REINSTATE_TOOLTIP = "Reinstate this device to the whitelist";

    /// <summary>
    /// Tooltip of the button that opens the device details; filled with the device name.
    /// </summary>
    public const string VIEW_DEVICE_TOOLTIP_FORMAT = "View {0} details";

    /// <summary>
    /// Tooltip format for moving a named device to the blacklist.
    /// </summary>
    public const string MOVE_TO_BLACKLIST_TOOLTIP_FORMAT = "Move {0} to blacklist";

    /// <summary>
    /// Tooltip format for reinstating a named device to the whitelist.
    /// </summary>
    public const string REINSTATE_TOOLTIP_FORMAT = "Reinstate {0}";

    /// <summary>
    /// Segoe MDL2 Assets glyph for view/open actions in trust lists.
    /// </summary>
    public const string VIEW_GLYPH = "\uE7B3";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a shield. It is no longer used by the Whitelist / Blacklist screens.
    /// </summary>
    public const string SHIELD_GLYPH = "\uEA18";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a lock, shown next to the Whitelist / Blacklist menu item.
    /// </summary>
    public const string TRUST_MENU_GLYPH = "\uE72E";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a circle with a slash, shown on the move to blacklist button.
    /// </summary>
    public const string BLACKLIST_GLYPH = "\uE8F8";

    /// <summary>
    /// Segoe MDL2 Assets glyph of a circle with a check mark, shown on the reinstate button.
    /// </summary>
    public const string REINSTATE_GLYPH = "\uE930";

    /// <summary>
    /// Title of the device details dialog.
    /// </summary>
    public const string DEVICE_DETAILS_TITLE = "Device Details";

    /// <summary>
    /// Description under the title of the device details dialog.
    /// </summary>
    public const string DEVICE_DETAILS_DESCRIPTION = "Trust status, identity, and certificate onboarding information.";

    /// <summary>
    /// Label of the current status in the device details dialog.
    /// </summary>
    public const string CURRENT_STATUS = "Current Status";

    /// <summary>
    /// Copyright text shown on the left of the footer.
    /// </summary>
    public const string COPYRIGHT_TEXT = "Copyright \u00A9 2026 Valmet Corporation. All rights reserved.";

    /// <summary>
    /// Product name and version shown on the right of the footer; filled with the version number.
    /// </summary>
    public const string PRODUCT_VERSION_FORMAT = "Valmet MAXUM Certificate Handler v{0}";

    /// <summary>Logged when the view model is created without a dashboard query.</summary>
    public const string DASHBOARD_QUERY_IS_NULL = "The dashboard cannot be created because no dashboard query was given.";

    /// <summary>Logged when the page size given to the view model is outside the allowed range.</summary>
    public const string PAGE_SIZE_OUT_OF_RANGE = "The dashboard page size %s is not allowed. It must be between %s and %s.";

    /// <summary>Logged when loading the dashboard fails; the text carries the error.</summary>
    public const string DASHBOARD_LOAD_FAILED = "The dashboard could not be loaded because of an error: %s";

    /// <summary>Shown to the user when the dashboard could not be loaded.</summary>
    public const string DASHBOARD_LOAD_FAILED_FOR_USER = "The dashboard could not be loaded. Please try again.";

    /// <summary>Logged when the dashboard query returns no result.</summary>
    public const string DASHBOARD_QUERY_RETURNED_NOTHING = "The dashboard query returned no result.";

    /// <summary>Logged with the render time and the number of certificates once the dashboard is shown.</summary>
    public const string DASHBOARD_RENDERED = "The dashboard was rendered in %s seconds for %s certificates.";

    /// <summary>Logged when the dashboard view is created without a view model.</summary>
    public const string DASHBOARD_VIEW_MODEL_IS_NULL = "The dashboard view cannot be created because no view model was given.";

    /// <summary>Logged when the dashboard view is created without a database connection.</summary>
    public const string DASHBOARD_DATA_SOURCE_IS_NULL = "The dashboard view cannot be created because no database connection was given.";

    /// <summary>Logged when the dashboard is opened from a window that has no database connection.</summary>
    public const string DASHBOARD_NOT_AVAILABLE = "The dashboard cannot be opened because this window has no database connection.";

    /// <summary>Logged when opening the dashboard fails; the text carries the error.</summary>
    public const string DASHBOARD_OPEN_FAILED = "The dashboard could not be opened because of an error: %s";

    /// <summary>Logged when changing the page fails; the text carries the error.</summary>
    public const string DASHBOARD_PAGE_CHANGE_FAILED = "The dashboard page could not be changed because of an error: %s";

    /// <summary>Logged when filtering the request overview fails; the text carries the error.</summary>
    public const string DASHBOARD_FILTER_FAILED = "The request overview could not be filtered because of an error: %s";

    /// <summary>Logged when sorting the request overview fails; the text carries the error.</summary>
    public const string DASHBOARD_SORT_FAILED = "The request overview could not be sorted because of an error: %s";

    /// <summary>Logged when a screen is opened from the dashboard without a database connection.</summary>
    public const string NAVIGATION_NOT_AVAILABLE = "The screen cannot be opened because this window has no database connection.";

    /// <summary>Logged when opening a screen from the dashboard fails; the text carries the error.</summary>
    public const string NAVIGATION_FAILED = "The screen could not be opened because of an error: %s";

    /// <summary>Logged when a user who is not a device administrator asks for the dashboard data; the text carries the user name.</summary>
    public const string DASHBOARD_LOAD_NOT_AUTHORIZED = "The dashboard data was not loaded because the user %s is not a device administrator.";

    /// <summary>Name written to the log when the dashboard data is asked for without a signed-in user.</summary>
    public const string NO_SIGNED_IN_USER = "(no signed-in user)";

    /// <summary>Logged when a user who is not a device administrator asks for the whitelist and blacklist; the text carries the user name.</summary>
    public const string TRUST_LISTS_NOT_AUTHORIZED = "The whitelist and blacklist were not loaded because the user %s is not a device administrator.";

    /// <summary>Logged when loading the whitelist and blacklist fails; the text carries the error.</summary>
    public const string TRUST_LISTS_LOAD_FAILED = "The whitelist and blacklist could not be loaded because of an error: %s";

    /// <summary>Shown to the user when the whitelist and blacklist could not be loaded.</summary>
    public const string TRUST_LISTS_LOAD_FAILED_FOR_USER = "The whitelist and blacklist could not be loaded. Please try again.";

    /// <summary>Logged when the Whitelist / Blacklist view is created without a view model.</summary>
    public const string TRUST_LIST_VIEW_MODEL_IS_NULL = "The Whitelist / Blacklist view cannot be created because no view model was given.";

    /// <summary>Logged when the Whitelist / Blacklist view is created without a database connection.</summary>
    public const string TRUST_LIST_DATA_SOURCE_IS_NULL = "The Whitelist / Blacklist view cannot be created because no database connection was given.";

    /// <summary>Logged when the Whitelist / Blacklist page is opened from a window that has no database connection.</summary>
    public const string TRUST_LIST_NOT_AVAILABLE = "The Whitelist / Blacklist page cannot be opened because this window has no database connection.";

    /// <summary>Logged when opening the Whitelist / Blacklist page fails; the text carries the error.</summary>
    public const string TRUST_LIST_OPEN_FAILED = "The Whitelist / Blacklist page could not be opened because of an error: %s";

    /// <summary>Logged when the device details dialog cannot be shown; the text carries the error.</summary>
    public const string DEVICE_DETAILS_OPEN_FAILED = "The device details could not be shown because of an error: %s";

    /// <summary>Logged when the move to blacklist or reinstate button is pressed; these changes are not part of the listing yet. The text carries the device.</summary>
    public const string TRUST_LIST_CHANGE_NOT_AVAILABLE = "The trust state of device %s was not changed because changing it from this page is not available yet.";

    /// <summary>
    /// Text displayed when no specific request type is selected.
    /// </summary>
    public const string ALL_REQUEST_TYPES = "All Request Types";
    /// <summary>Shown in the table while the whitelist and blacklist are being loaded.</summary>
    public const string LOADING = "Loading...";
    /// <summary>Logged when the view model is created without a service.</summary>
    public const string SERVICE_IS_NULL = "The certificate view cannot be created because no certificate information service was given.";

    /// <summary>Logged when the view model is created without a user name provider.</summary>
    public const string USER_PROVIDER_IS_NULL = "The certificate view cannot be created because no user name provider was given.";

    /// <summary>Logged when the view is created without a view model.</summary>
    public const string VIEW_MODEL_IS_NULL = "The certificate view cannot be created because no view model was given.";

    /// <summary>Logged when loading the certificate information fails; the text carries the error.</summary>
    public const string LOAD_FAILED = "Loading the certificate information failed: %s";

    /// <summary>Shown when the signed-in user is not an administrator.</summary>
    public const string NOT_AUTHORIZED_TEXT = "Only an administrator can view the certificate information.";

    /// <summary>Shown when the certificates could not be read.</summary>
    public const string LOAD_FAILED_TEXT = "The certificate information could not be loaded. Try again later.";

    /// <summary>Shown in the status column for a missing certificate.</summary>
    public const string STATUS_NOT_AVAILABLE = "Not available";

    /// <summary>Shown in the status column for a valid certificate.</summary>
    public const string STATUS_VALID = "Valid";

    /// <summary>Shown in the status column for a certificate inside the warning window.</summary>
    public const string STATUS_NEARING_EXPIRATION = "Expiring";

    /// <summary>Shown in the status column for an expired certificate.</summary>
    public const string STATUS_EXPIRED = "Expired";

    /// <summary>Name of the SBC certificate row.</summary>
    public const string SBC_NAME = "SBC certificate";

    /// <summary>Name of the MIB certificate row.</summary>
    public const string MIB_NAME = "MIB certificate";

    /// <summary>Text shown instead of a date when there is no certificate.</summary>
    public const string NO_DATE_TEXT = "-";

    /// <summary>Format of the not-after date: ISO 8601 date, such as 2026-10-14.</summary>
    public const string DATE_FORMAT = "yyyy-MM-dd";

    /// <summary>
    /// Binding format of every date and time shown on the screens: ISO 8601, such as 2026-10-14T10:30:00.
    /// </summary>
    public const string ISO_DATE_TIME_STRING_FORMAT = "{0:yyyy-MM-dd'T'HH:mm:ss}";

    /// <summary>Title of the details window.</summary>
    public const string DETAILS_TITLE = "Certificate details";

    /// <summary>Label of the type line in the details window.</summary>
    public const string LABEL_TYPE = "Type";

    /// <summary>Label of the issuer line in the details window.</summary>
    public const string LABEL_ISSUER = "Issuer";

    /// <summary>Label of the subject line in the details window.</summary>
    public const string LABEL_SUBJECT = "Subject";

    /// <summary>Label of the thumbprint line in the details window.</summary>
    public const string LABEL_THUMBPRINT = "Thumbprint";

    /// <summary>Label of the not-after line in the details window.</summary>
    public const string LABEL_NOT_AFTER = "Valid to";

    /// <summary>Label of the status line in the details window.</summary>
    public const string LABEL_STATUS = STATUS_HEADER;

    /// <summary>Text of the close button in the details window.</summary>
    public const string CLOSE_TEXT = "Close";

    /// <summary>Placeholder of the date fields of the filter panel; only a date is entered, no time.</summary>
    public const string DATE_TIME_PLACEHOLDER = "YYYY-MM-DD";

    /// <summary>Format of a date and time typed in the filter panel.</summary>
    public const string DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

    /// <summary>Format of a date and time without seconds, also accepted by the filter panel.</summary>
    public const string DATE_TIME_FORMAT_NO_SECONDS = "yyyy-MM-dd'T'HH:mm";

    /// <summary>Format of a date without a time, also accepted by the filter panel.</summary>
    public const string DATE_ONLY_FORMAT = "yyyy-MM-dd";

    /// <summary>Shown under a date field of the filter panel that cannot be read.</summary>
    public const string INVALID_DATE_TIME_TEXT = "Enter the date as YYYY-MM-DD.";

    /// <summary>Shown under the end date when it is before the start date.</summary>
    public const string END_BEFORE_START_TEXT = "End date must be after the start date.";

    /// <summary>Placeholder of the MAXUM IP field of the filter panel.</summary>
    public const string MAXUM_IP_PLACEHOLDER = "e.g. 10.0.0.1";

    /// <summary>Calendar icon of the date fields (Segoe MDL2 Assets).</summary>
    public const string CALENDAR_GLYPH = "\uE787";

    /// <summary>Text of the All status chip of the filter panel.</summary>
    public const string FILTER_STATUS_ALL = "All";

    /// <summary>Text of the Pending status chip of the filter panel.</summary>
    public const string FILTER_STATUS_PENDING = "Pending";

    /// <summary>Text of the Approved status chip of the filter panel.</summary>
    public const string FILTER_STATUS_APPROVED = "Approved";

    /// <summary>Text of the Rejected status chip of the filter panel.</summary>
    public const string FILTER_STATUS_REJECTED = "Rejected";

    /// <summary>Text of the Expired status chip of the filter panel.</summary>
    public const string FILTER_STATUS_EXPIRED = "Expired";

    /// <summary>Resource key of the border brush of a filter field that holds a wrong value.</summary>
    public const string FILTER_ERROR_BORDER_BRUSH_KEY = "FilterErrorBorderBrush";

    #endregion

    #region Button Tooltips

    /// <summary>
    /// Tooltip that tells what the button does: open the dashboard with the certificate overview.
    /// </summary>
    public const string TOOLTIP_DASHBOARD = "Open the dashboard with the certificate overview";

    /// <summary>
    /// Tooltip that tells what the button does: open the whitelist and blacklist of devices.
    /// </summary>
    public const string TOOLTIP_TRUST_LIST = "Open the whitelist and blacklist of devices";

    /// <summary>
    /// Tooltip that tells what the button does: open the SBC and MIB certificates.
    /// </summary>
    public const string TOOLTIP_CERTIFICATE_MANAGEMENT = "Open the SBC and MIB certificates";

    /// <summary>
    /// Tooltip that tells what the button does: collapse or expand the side menu.
    /// </summary>
    public const string TOOLTIP_COLLAPSE_MENU = "Collapse or expand the side menu";

    /// <summary>
    /// Tooltip that tells what the button does: show the requests that wait for a decision.
    /// </summary>
    public const string TOOLTIP_PENDING_TAB = "Show the requests that wait for a decision";

    /// <summary>
    /// Tooltip that tells what the button does: show the approved requests.
    /// </summary>
    public const string TOOLTIP_APPROVED_TAB = "Show the approved requests";

    /// <summary>
    /// Tooltip that tells what the button does: show the rejected requests.
    /// </summary>
    public const string TOOLTIP_REJECTED_TAB = "Show the rejected requests";

    /// <summary>
    /// Tooltip that tells what the button does: show the expired requests.
    /// </summary>
    public const string TOOLTIP_EXPIRED_TAB = "Show the expired requests";

    /// <summary>
    /// Tooltip that tells what the button does: filter the requests by date, status and MAXUM IP.
    /// </summary>
    public const string TOOLTIP_FILTER_REQUESTS = "Filter the requests by date, status and MAXUM IP";

    /// <summary>
    /// Tooltip that tells what the button does: filter the certificates by type or status.
    /// </summary>
    public const string TOOLTIP_FILTER_CERTIFICATES = "Filter the certificates by type or status";

    /// <summary>
    /// Tooltip that tells what the button does: go to the previous page.
    /// </summary>
    public const string TOOLTIP_PREVIOUS_PAGE = "Go to the previous page";

    /// <summary>
    /// Tooltip that tells what the button does: go to the next page.
    /// </summary>
    public const string TOOLTIP_NEXT_PAGE = "Go to the next page";

    /// <summary>
    /// Tooltip that tells what the button does: choose how many rows are shown on one page.
    /// </summary>
    public const string TOOLTIP_PAGE_SIZE = "Choose how many rows are shown on one page";

    /// <summary>
    /// Tooltip that tells what the button does: show the whitelisted devices.
    /// </summary>
    public const string TOOLTIP_WHITELIST_TAB = "Show the whitelisted devices";

    /// <summary>
    /// Tooltip that tells what the button does: show the blacklisted devices.
    /// </summary>
    public const string TOOLTIP_BLACKLIST_TAB = "Show the blacklisted devices";

    /// <summary>
    /// Tooltip that tells what the button does: close this window.
    /// </summary>
    public const string TOOLTIP_CLOSE_WINDOW = "Close this window";

    /// <summary>
    /// Tooltip that tells what the button does: clear all filters.
    /// </summary>
    public const string TOOLTIP_CLEAR_FILTERS = "Clear all filters";

    /// <summary>
    /// Tooltip that tells what the button does: pick a date from the calendar.
    /// </summary>
    public const string TOOLTIP_PICK_DATE = "Pick a date from the calendar";

    /// <summary>
    /// Tooltip that tells what the button does: show only the requests with this status.
    /// </summary>
    public const string TOOLTIP_STATUS_CHIP = "Show only the requests with this status";

    /// <summary>
    /// Tooltip that tells what the button does: apply the chosen filters to the list.
    /// </summary>
    public const string TOOLTIP_APPLY_FILTERS = "Apply the chosen filters to the list";


    /// <summary>
    /// Tooltip that tells what the button does: open the request type filter of the dashboard.
    /// </summary>
    public const string TOOLTIP_FILTER_DASHBOARD = "Filter the pending requests by request type: peer onboarding, reinstatement or whitelist to blacklist";

    /// <summary>
    /// Placeholder of the dashboard search box; names the fields the search looks in.
    /// </summary>
    public const string DASHBOARD_SEARCH_PLACEHOLDER = "Search by device name, device code, IP address, requested by or status...";


    /// <summary>
    /// Tooltip of the Login button.
    /// </summary>
    public const string TOOLTIP_LOGIN = "Login";

    /// <summary>
    /// Tooltip of the eye button while the password is hidden.
    /// </summary>
    public const string TOOLTIP_SHOW_PASSWORD = "Show the password";

    /// <summary>
    /// Tooltip of the eye button while the password is shown.
    /// </summary>
    public const string TOOLTIP_HIDE_PASSWORD = "Hide the password";

    /// <summary>
    /// Tooltip of the user button in the top bar; filled with the user name.
    /// </summary>
    public const string TOOLTIP_USER_MENU_FORMAT = "Signed in as {0}. Click to log out";

    #endregion

    #region Login Screen

    /// <summary>
    /// Title above the login fields.
    /// </summary>
    public const string LOGIN_CARD_TITLE = "Log in to Certificate Handler";

    /// <summary>
    /// Text shown while the user is being signed in; filled with the user name.
    /// </summary>
    public const string LOGGING_IN_FORMAT = "Logging in as {0}...";

    /// <summary>
    /// Time in milliseconds the login screen shows the "Logging in" text before the next screen opens.
    /// </summary>
    public const int LOGIN_LOADING_DELAY_MILLISECONDS = 2000;

    /// <summary>
    /// How long the loading panel stays over the content after login, in milliseconds.
    /// </summary>
    public const int CONTENT_LOADING_DELAY_MILLISECONDS = 1800;

    /// <summary>
    /// How long the loading panel takes to fade out, in milliseconds.
    /// </summary>
    public const int CONTENT_LOADING_FADE_MILLISECONDS = 400;

    /// <summary>
    /// Time of one turn of the loading circle, in milliseconds.
    /// </summary>
    public const int SPINNER_TURN_MILLISECONDS = 900;

    /// <summary>
    /// Heading of the loading panel shown after login.
    /// </summary>
    public const string CONTENT_LOADING_TITLE = "Loading certificate data";

    /// <summary>
    /// Text under the heading of the loading panel.
    /// </summary>
    public const string CONTENT_LOADING_MESSAGE = "Please wait while the dashboard is prepared.";

    /// <summary>
    /// Segoe MDL2 Assets glyph of an arrow pointing down into a tray, shown on the Import Certificate button.
    /// </summary>
    public const string IMPORT_GLYPH = "\uE896";
    /// <summary>
    /// Time in milliseconds of the opening animation of the main window after login, like opening a book.
    /// </summary>
    public const int BOOK_OPEN_ANIMATION_MILLISECONDS = 700;

    /// <summary>
    /// Error icon of the login error box (Segoe MDL2 Assets).
    /// </summary>
    public const string ERROR_GLYPH = "\uE783";

    /// <summary>
    /// Person icon of the user button in the top bar (Segoe MDL2 Assets).
    /// </summary>
    public const string PERSON_GLYPH = "\uE77B";

    /// <summary>Information: loading the certificates was cancelled, for example because the page was closed.</summary>
    public const string CERTIFICATE_LOAD_CANCELLED = "Loading the certificates was cancelled.";

    /// <summary>Warning: the request counts for the status tabs could not be read; the argument is the error. The tabs keep their last values.</summary>
    public const string STATUS_COUNTS_LOAD_FAILED = "The request counts for the status tabs could not be read: %s";

    #endregion

    #region Log Monitor Texts

    /// <summary>Information: the application is starting.</summary>
    public const string LOG_APP_STARTING = "Certificate Handler is starting.";

    /// <summary>Success: start-up finished and the login screen is shown.</summary>
    public const string LOG_APP_STARTED = "Certificate Handler started. The login screen is shown.";

    /// <summary>Error: start-up failed; the argument is the error.</summary>
    public const string LOG_APP_START_FAILED = "Certificate Handler could not start, the Trust database could not be reached: %s";

    /// <summary>Information: the application is closing; the argument is the exit code.</summary>
    public const string LOG_APP_EXITING = "Certificate Handler is closing (exit code %s).";

    /// <summary>Information: Windows reports that the network is available again.</summary>
    public const string LOG_NETWORK_AVAILABLE = "The network is available again.";

    /// <summary>Warning: Windows reports that the network was lost.</summary>
    public const string LOG_NETWORK_LOST = "The network connection was lost.";

    /// <summary>Warning: the server refused the session, so the login screen is shown again.</summary>
    public const string LOG_SESSION_EXPIRED = "The session expired. The login screen is shown again.";

    /// <summary>Error: an unexpected error happened on the screen; the argument is the error.</summary>
    public const string LOG_UNHANDLED_UI_ERROR = "Unexpected error on the screen: %s";

    /// <summary>Error: an unexpected error happened in the background; the argument is the error.</summary>
    public const string LOG_UNHANDLED_ERROR = "Unexpected error in Certificate Handler: %s";

    /// <summary>Information: a user pressed Login; the argument is the user name. The password is never logged.</summary>
    public const string LOG_LOGIN_ATTEMPT = "Login attempt by user %s.";

    /// <summary>Success: the login succeeded; the argument is the user name.</summary>
    public const string LOG_LOGIN_SUCCEEDED = "User %s logged in.";

    /// <summary>Warning: the login was refused; the arguments are the user name and the reason.</summary>
    public const string LOG_LOGIN_REFUSED = "Login refused for user %s: %s.";

    /// <summary>Error: the login failed with an error; the arguments are the user name and the error.</summary>
    public const string LOG_LOGIN_FAILED = "Login of user %s failed: %s";

    /// <summary>Information: a user logged out; the argument is the user name.</summary>
    public const string LOG_LOGOUT = "User %s logged out.";

    /// <summary>Information: the user cancelled the log out; the argument is the user name.</summary>
    public const string LOG_LOGOUT_CANCELLED = "User %s cancelled the log out and stays signed in.";

    /// <summary>Information: the administrator pressed Approve; the arguments are the request id and the device.</summary>
    public const string LOG_APPROVE_CLICKED = "Approve requested for request %s (device %s).";

    /// <summary>Success: the request was approved and removed from the queue; the argument is the request id.</summary>
    public const string LOG_APPROVE_DONE = "Request %s was approved and removed from the pending queue.";

    /// <summary>Error: the approval failed; the arguments are the request id and the error.</summary>
    public const string LOG_APPROVE_FAILED = "Request %s could not be approved: %s";

    /// <summary>Information: the administrator pressed Reject; the arguments are the request id and the device.</summary>
    public const string LOG_REJECT_CLICKED = "Reject requested for request %s (device %s).";

    /// <summary>Success: the request was rejected and removed from the queue; the argument is the request id.</summary>
    public const string LOG_REJECT_DONE = "Request %s was rejected and removed from the pending queue.";

    /// <summary>Error: the rejection failed; the arguments are the request id and the error.</summary>
    public const string LOG_REJECT_FAILED = "Request %s could not be rejected: %s";

    /// <summary>Information: the request details were opened; the argument is the request id.</summary>
    public const string LOG_DETAILS_OPENED = "Details opened for request %s.";

    /// <summary>Information: the request details were closed; the arguments are the request id and the decision.</summary>
    public const string LOG_DETAILS_CLOSED = "Details of request %s closed with decision: %s.";

    /// <summary>Information: filters were applied; the arguments are status, from date, to date and MAXUM IP.</summary>
    public const string LOG_FILTERS_APPLIED = "Request Queue filters applied: status %s, from %s, to %s, MAXUM IP %s.";

    /// <summary>Warning: the filter dates were wrong, so the filters were not applied.</summary>
    public const string LOG_FILTERS_INVALID = "Request Queue filters were not applied because a date is not valid.";

    /// <summary>Information: all filters were cleared.</summary>
    public const string LOG_FILTERS_CLEARED = "Request Queue filters cleared.";

    /// <summary>Warning: the session refresh failure banner is shown; the argument is the message.</summary>
    public const string LOG_SESSION_BANNER_SHOWN = "Session warning shown to the user: %s";

    /// <summary>Error: the trust update could not be published; the argument is the message.</summary>
    public const string LOG_PUBLISH_FAILED_SHOWN = "Trust update publish failed, warning shown to the administrator: %s";

    /// <summary>Placeholder written for an empty value.</summary>
    public const string LOG_EMPTY_VALUE = "-";

    #endregion
}
