// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Logs the trust event delivery until the subscribers in the device are connected.
/// </summary>
public sealed class LoggingInDeviceTrustSubscriberChannel : IInDeviceTrustSubscriberChannel
{
    /// <summary>
    /// Delivers the trust event by writing it to the log.
    /// Returns false when the test delivery failure setting is on.
    /// </summary>
    /// <param name="eventId">Id of the trust event.</param>
    /// <param name="subscriberName">Name of the subscriber.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the event is delivered, otherwise false.</returns>
    public Task<bool> TryDeliverAsync(Guid eventId, string subscriberName, CancellationToken cancellationToken = default)
    {
        if (string.Equals(Environment.GetEnvironmentVariable("CH_TRUST_DELIVERY_FAIL"), "1", StringComparison.Ordinal))
        {
            return Task.FromResult(false);
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            $"Trust event {eventId} delivered to subscriber {subscriberName} (RS_27 stub).");
        return Task.FromResult(true);
    }
}
