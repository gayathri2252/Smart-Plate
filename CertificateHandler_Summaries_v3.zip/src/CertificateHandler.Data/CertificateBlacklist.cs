﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Writes and reads the certificate blacklist with plain SQL that casts the enum parameters.
/// </summary>
public sealed class CertificateBlackList : ICertificateBlackList
{
    #region Member Variables

    /// <summary>
    /// Casts the list type parameter to the trust list type enum.
    /// </summary>
    private const string TRUST_KIND_CAST = $"CAST(@{DatabaseConstants.KIND_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.TRUST_LIST_KIND_TYPE})";

    /// <summary>
    /// Reads the certificate details for a thumbprint.
    /// </summary>
    private const string FIND_CERTIFICATE_SQL = $"SELECT certificate_id, device_id, subject_dn, issuer_dn, serial_number, not_before, not_after " +
        $"FROM {DatabaseConstants.SchemaName}.ch_certificate WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} LIMIT 1";

    /// <summary>
    /// Turns off the active whitelist row of a thumbprint.
    /// </summary>
    private const string DEACTIVATE_WHITELIST_SQL = $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"SET is_active = FALSE, deactivated_at = @{DatabaseConstants.NOW_PARAMETER}, deactivated_by = @{DatabaseConstants.ACTOR_PARAMETER} " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND is_active AND list_kind = {TRUST_KIND_CAST}";

    /// <summary>
    /// Finds the newest blacklist row of a thumbprint, active or not.
    /// </summary>
    private const string FIND_BLACK_LIST_ROW_SQL = $"SELECT id, is_active FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND list_kind = {TRUST_KIND_CAST} " +
        "ORDER BY id DESC LIMIT 1";

    /// <summary>
    /// Adds an active blacklist row.
    /// </summary>
    private const string INSERT_BLACK_LIST_ROW_SQL = $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        "(list_kind, certificate_id, thumbprint_sha256, device_id, subject_dn, serial_number, " +
        "not_before, not_after, added_by, added_at, comment, blacklist_reason_class, is_active) " +
        $"VALUES ({TRUST_KIND_CAST}, @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.THUMBPRINT_PARAMETER}, @{DatabaseConstants.DEVICE_ID_PARAMETER}, @{DatabaseConstants.SUBJECT_DN_PARAMETER}, @{DatabaseConstants.SERIAL_NUMBER_PARAMETER}, " +
        $"@{DatabaseConstants.NOT_BEFORE_PARAMETER}, @{DatabaseConstants.NOT_AFTER_PARAMETER}, @{DatabaseConstants.ACTOR_PARAMETER}, @{DatabaseConstants.NOW_PARAMETER}, @{DatabaseConstants.REASON_PARAMETER}, " +
        $"CAST(@{DatabaseConstants.REASON_CLASS_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.BLACK_LIST_REASON_CLASS_TYPE}), TRUE)";

    /// <summary>
    /// Makes an older blacklist row active again.
    /// </summary>
    private const string REACTIVATE_BLACK_LIST_ROW_SQL = $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        "SET is_active = TRUE, deactivated_at = NULL, deactivated_by = NULL, " +
        $"added_by = @{DatabaseConstants.ACTOR_PARAMETER}, added_at = @{DatabaseConstants.NOW_PARAMETER}, comment = @{DatabaseConstants.REASON_PARAMETER}, " +
        $"blacklist_reason_class = CAST(@{DatabaseConstants.REASON_CLASS_PARAMETER} AS {DatabaseConstants.SchemaName}.{DatabaseConstants.BLACK_LIST_REASON_CLASS_TYPE}) " +
        $"WHERE id = @{DatabaseConstants.ID_PARAMETER} AND NOT is_active";

    /// <summary>
    /// Writes the audit row of a blacklist write.
    /// </summary>
    private const string INSERT_AUDIT_SQL = $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
        "(event_type, event_timestamp, actor_identity, device_id, certificate_id, thumbprint_sha256, " +
        "previous_status, new_status, action_status, reason, details_json, result, source_component) " +
        $"VALUES (@{DatabaseConstants.EVENT_TYPE_PARAMETER}, @{DatabaseConstants.NOW_PARAMETER}, @{DatabaseConstants.ACTOR_PARAMETER}, @{DatabaseConstants.DEVICE_ID_PARAMETER}, @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.THUMBPRINT_PARAMETER}, " +
        $"@{DatabaseConstants.PREVIOUS_STATUS_PARAMETER}, @{DatabaseConstants.NEW_STATUS_PARAMETER}, @{DatabaseConstants.ACTION_STATUS_PARAMETER}, @{DatabaseConstants.REASON_PARAMETER}, CAST(@{DatabaseConstants.DETAILS_PARAMETER} AS jsonb), '{DatabaseConstants.RESULT_SUCCESS}', @{DatabaseConstants.SOURCE_PARAMETER})";

    /// <summary>
    /// Checks if a thumbprint has an active blacklist row.
    /// </summary>
    private const string IS_BLACK_LISTED_SQL = $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND is_active AND list_kind = {TRUST_KIND_CAST})";

    /// <summary>
    /// Database context used to read and change the trust list entries.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the blacklist with the given database context. The context must not be null.
    /// </summary>
    /// <param name="dbContext">Database context used to read and write the blacklist.</param>
    public CertificateBlackList(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Adds an active blacklist row for the thumbprint or makes an older one active again, turns off any active whitelist row and writes one audit row, all in one transaction.
    /// </summary>
    /// <param name="request">The thumbprint, the reason and the user.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the blacklist change.</returns>
    public async Task<BlackListResponse> BlackListAsync(
        BlackListRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(request.ThumbprintSha256);
            string reason = request.Reason?.Trim() ?? string.Empty;

            // Guard: the audit row must always say why the thumbprint was blacklisted.
            BlacklistReasonPolicy.ValidateOrThrow(reason);

            DateTimeOffset now = request.EvaluatedAt.ToUniversalTime();

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

                CertificateRow? certificate = await FindCertificateAsync(connection, transaction, thumbprint, cancellationToken);

                // Guard: a blacklist row needs the certificate details, so an unknown thumbprint writes nothing.
                if (certificate is null)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_CERTIFICATE_NOT_FOUND, thumbprint);
                    return new BlackListResponse { Outcome = Models.CertificateBlackList.CertificateNotFound };
                }

                // One active trust decision is allowed per thumbprint, so an active whitelist
                // row has to be ended before a blacklist row can be active.
                int whitelistRowsEnded = await ExecuteAsync(
                    connection, transaction, DEACTIVATE_WHITELIST_SQL, cancellationToken,
                    (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                    (DatabaseConstants.NOW_PARAMETER, now),
                    (DatabaseConstants.ACTOR_PARAMETER, DatabaseConstants.SystemActor),
                    (DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Whitelist)));

                (long Id, bool IsActive)? existing = await FindBlackListRowAsync(connection, transaction, thumbprint, cancellationToken);

                Models.CertificateBlackList outcome;
                string previousStatus;

                if (existing is { IsActive: true })
                {
                    outcome = Models.CertificateBlackList.AlreadyBlackListed;
                    previousStatus = DatabaseConstants.STATUS_BLACK_LISTED;
                }
                else if (existing is not null)
                {
                    outcome = Models.CertificateBlackList.Reactivated;
                    previousStatus = whitelistRowsEnded > 0 ? DatabaseConstants.STATUS_WHITELISTED : DatabaseConstants.STATUS_BLACK_LIST_INACTIVE;

                    await ExecuteAsync(
                        connection, transaction, REACTIVATE_BLACK_LIST_ROW_SQL, cancellationToken,
                        (DatabaseConstants.ID_PARAMETER, existing.Value.Id),
                        (DatabaseConstants.ACTOR_PARAMETER, DatabaseConstants.SystemActor),
                        (DatabaseConstants.NOW_PARAMETER, now),
                        (DatabaseConstants.REASON_PARAMETER, reason),
                        (DatabaseConstants.REASON_CLASS_PARAMETER, PostgresEnumNames.ToPgName(request.ReasonClass)));
                }
                else
                {
                    outcome = Models.CertificateBlackList.Added;
                    previousStatus = whitelistRowsEnded > 0 ? DatabaseConstants.STATUS_WHITELISTED : DatabaseConstants.STATUS_NOT_LISTED;

                    await ExecuteAsync(
                        connection, transaction, INSERT_BLACK_LIST_ROW_SQL, cancellationToken,
                        (DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)),
                        (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificate.CertificateId),
                        (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                        (DatabaseConstants.DEVICE_ID_PARAMETER, certificate.DeviceId),
                        (DatabaseConstants.SUBJECT_DN_PARAMETER, certificate.SubjectDn),
                        (DatabaseConstants.SERIAL_NUMBER_PARAMETER, certificate.SerialNumber),
                        (DatabaseConstants.NOT_BEFORE_PARAMETER, certificate.NotBefore),
                        (DatabaseConstants.NOT_AFTER_PARAMETER, certificate.NotAfter),
                        (DatabaseConstants.ACTOR_PARAMETER, DatabaseConstants.SystemActor),
                        (DatabaseConstants.NOW_PARAMETER, now),
                        (DatabaseConstants.REASON_PARAMETER, reason),
                        (DatabaseConstants.REASON_CLASS_PARAMETER, PostgresEnumNames.ToPgName(request.ReasonClass)));
                }

                await ExecuteAsync(
                    connection, transaction, INSERT_AUDIT_SQL, cancellationToken,
                    (DatabaseConstants.EVENT_TYPE_PARAMETER, DatabaseConstants.AUDIT_EVENT_TYPE),
                    (DatabaseConstants.NOW_PARAMETER, now),
                    (DatabaseConstants.ACTOR_PARAMETER, DatabaseConstants.SystemActor),
                    (DatabaseConstants.DEVICE_ID_PARAMETER, certificate.DeviceId),
                    (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificate.CertificateId),
                    (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                    (DatabaseConstants.PREVIOUS_STATUS_PARAMETER, previousStatus),
                    (DatabaseConstants.NEW_STATUS_PARAMETER, DatabaseConstants.STATUS_BLACK_LISTED),
                    (DatabaseConstants.ACTION_STATUS_PARAMETER, ToActionStatus(outcome)),
                    (DatabaseConstants.REASON_PARAMETER, reason),
                    (DatabaseConstants.DETAILS_PARAMETER, BuildDetailsJson(certificate, request, now)),
                    (DatabaseConstants.SOURCE_PARAMETER, request.SourceComponent));

                await transaction.CommitAsync(cancellationToken);

                if (outcome == Models.CertificateBlackList.AlreadyBlackListed)
                {
                    CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_ALREADY_ACTIVE, thumbprint);
                }
                else
                {
                    CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_SAVED, thumbprint, outcome.ToString(), reason);
                }

                return new BlackListResponse { Outcome = outcome, CertificateId = certificate.CertificateId };
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_SAVE_FAILED, request.ThumbprintSha256, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Returns true when the thumbprint has an active blacklist row. The connection is opened for the check and closed again if it was closed before.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the certificate is on the blacklist, otherwise false.</returns>
    public async Task<bool> IsBlackListedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(thumbprintSha256);

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using var command = new NpgsqlCommand(IS_BLACK_LISTED_SQL, connection);
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)));

                object? result = await command.ExecuteScalarAsync(cancellationToken);
                bool isBlackListed = result is true;
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_CHECKED, thumbprint, isBlackListed.ToString());
                return isBlackListed;
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.BLACK_LIST_LOOKUP_FAILED, thumbprintSha256 ?? string.Empty, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the certificate details for the thumbprint from the certificate table. Returns null when no certificate has this thumbprint.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The certificate details, or null.</returns>
    private static async Task<CertificateRow?> FindCertificateAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(FIND_CERTIFICATE_SQL, connection, transaction);
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        Guid? deviceId = await reader.IsDBNullAsync(DatabaseConstants.DEVICE_ID_COLUMN, cancellationToken)
            ? null
            : reader.GetGuid(DatabaseConstants.DEVICE_ID_COLUMN);

        string? serialNumber = await reader.IsDBNullAsync(DatabaseConstants.SERIAL_NUMBER_COLUMN, cancellationToken)
            ? null
            : reader.GetString(DatabaseConstants.SERIAL_NUMBER_COLUMN);

        return new CertificateRow(
            reader.GetGuid(DatabaseConstants.CERTIFICATE_ID_COLUMN),
            deviceId,
            reader.GetString(DatabaseConstants.SUBJECT_DN_COLUMN),
            reader.GetString(DatabaseConstants.ISSUER_DN_COLUMN),
            serialNumber,
            await reader.GetFieldValueAsync<DateTimeOffset>(DatabaseConstants.NOT_BEFORE_COLUMN, cancellationToken),
            await reader.GetFieldValueAsync<DateTimeOffset>(DatabaseConstants.NOT_AFTER_COLUMN, cancellationToken));
    }

    /// <summary>
    /// Finds the newest blacklist row for the thumbprint, active or not. Returns null when the thumbprint was never on the blacklist.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The id and active flag of the row, or null.</returns>
    private static async Task<(long Id, bool IsActive)?> FindBlackListRowAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(FIND_BLACK_LIST_ROW_SQL, connection, transaction);
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
        command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)));

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return (reader.GetInt64(DatabaseConstants.BLACK_LIST_ROW_ID_COLUMN), reader.GetBoolean(DatabaseConstants.BLACK_LIST_ROW_IS_ACTIVE_COLUMN));
    }

    /// <summary>
    /// Runs one SQL statement in the transaction with the given named parameters.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="sql">The SQL to run.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <param name="parameters">Names and values of the parameters.</param>
    /// <returns>Number of rows changed.</returns>
    private static async Task<int> ExecuteAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string sql,
        CancellationToken cancellationToken,
        params (string Name, object? Value)[] parameters)
    {
        await using var command = new NpgsqlCommand(sql, connection, transaction);

        foreach ((string name, object? value) in parameters)
        {
            command.Parameters.Add(new NpgsqlParameter(name, value ?? DBNull.Value));
        }

        return await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Turns the blacklist result into the action status saved in the audit row.
    /// </summary>
    /// <param name="outcome">Result of the blacklist change.</param>
    /// <returns>The action status.</returns>
    private static string ToActionStatus(Models.CertificateBlackList outcome)
    {
        return outcome switch
        {
            Models.CertificateBlackList.Added => DatabaseConstants.ACTION_ADDED,
            Models.CertificateBlackList.Reactivated => DatabaseConstants.ACTION_REACTIVATED,
            _ => DatabaseConstants.ACTION_ALREADY_BLACK_LISTED
        };
    }

    /// <summary>
    /// Builds the JSON saved in the audit row, with the certificate details, the reason type and the time in UTC.
    /// </summary>
    /// <param name="certificate">The certificate details.</param>
    /// <param name="request">The blacklist request.</param>
    /// <param name="now">The current time.</param>
    /// <returns>The details in JSON format.</returns>
    private static string BuildDetailsJson(CertificateRow certificate, BlackListRequest request, DateTimeOffset now)
    {
        return JsonSerializer.Serialize(new
        {
            subjectDn = certificate.SubjectDn,
            issuerDn = certificate.IssuerDn,
            serialNumber = certificate.SerialNumber,
            notBefore = certificate.NotBefore,
            notAfter = certificate.NotAfter,
            blacklistReasonClass = PostgresEnumNames.ToPgName(request.ReasonClass),
            evaluatedAtUtc = now
        });
    }

    #endregion

    #region Member Variables

    /// <summary>
    /// The certificate columns read from the certificate table and written to the blacklist and audit rows.
    /// </summary>
    /// <param name="CertificateId">Id of the certificate.</param>
    /// <param name="DeviceId">Id of the device, or null if not known.</param>
    /// <param name="SubjectDn">Subject name of the certificate.</param>
    /// <param name="IssuerDn">Issuer name of the certificate.</param>
    /// <param name="SerialNumber">Serial number of the certificate, or null.</param>
    /// <param name="NotBefore">Date from which the certificate is valid.</param>
    /// <param name="NotAfter">Date until which the certificate is valid.</param>
    private sealed record CertificateRow(
        Guid CertificateId,
        Guid? DeviceId,
        string SubjectDn,
        string IssuerDn,
        string? SerialNumber,
        DateTimeOffset NotBefore,
        DateTimeOffset NotAfter);

    #endregion
}