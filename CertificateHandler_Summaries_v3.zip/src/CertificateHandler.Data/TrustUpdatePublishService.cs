﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Sends a trust update that was already saved. If sending fails, the error is logged, written to the audit log and shown to the administrator.
/// Each of these steps runs on its own, so one failing step cannot stop the others, and the saved trust row is never changed.
/// </summary>
public sealed class TrustUpdatePublishService : ITrustUpdatePublishService
{
    #region Private Fields

    /// <summary>
    /// Sends the trust updates.
    /// </summary>
    private readonly ITrustUpdatePublisher _publisher;

    /// <summary>
    /// Writes the audit row when sending fails.
    /// </summary>
    private readonly IPublishFailureAuditWriter _auditWriter;

    /// <summary>
    /// Tells the administrator when sending fails.
    /// </summary>
    private readonly IAdministratorNotifier _notifier;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. None of the values can be null.
    /// </summary>
    /// <param name="publisher">Sends the trust updates.</param>
    /// <param name="auditWriter">Writes the audit row when sending fails.</param>
    /// <param name="notifier">Tells the administrator when sending fails.</param>
    public TrustUpdatePublishService(ITrustUpdatePublisher publisher, IPublishFailureAuditWriter auditWriter, IAdministratorNotifier notifier)
    {
        _publisher = Require(publisher, TrustPublishConstants.PUBLISHER_IS_NULL, nameof(publisher));
        _auditWriter = Require(auditWriter, TrustPublishConstants.AUDIT_WRITER_IS_NULL, nameof(auditWriter));
        _notifier = Require(notifier, TrustPublishConstants.NOTIFIER_IS_NULL, nameof(notifier));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Sends the trust update. If sending fails, the error is logged, written to the audit log and shown to the administrator.
    /// </summary>
    /// <param name="update">
    /// Trust update that is already saved.
    /// </param>
    /// <param name="cancellationToken">
    /// Token to cancel the work.
    /// </param>
    /// <returns>
    /// The result of the send, with the audit and message status.
    /// </returns>
    public async Task<PublishResult> PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(update);

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_STARTED, update.ThumbprintSha256);

        try
        {
            await _publisher.PublishAsync(update, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_CANCELLED, update.ThumbprintSha256);
            throw;
        }
        catch (Exception ex)
        {
            return await HandleFailureAsync(update, ex);
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_SUCCEEDED, update.ThumbprintSha256);
        return new PublishResult { Published = true };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Handles a failed send. It logs the error, writes an audit record and tells the administrator.
    /// </summary>
    /// <param name="update">
    /// Trust update that could not be sent.
    /// </param>
    /// <param name="error">
    /// The error that happened.
    /// </param>
    /// <returns>
    /// The result of the error handling steps.
    /// </returns>
    private async Task<PublishResult> HandleFailureAsync(TrustUpdate update, Exception error)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_FAILED, update.ThumbprintSha256, error.Message);

        bool auditWritten = false;
        try
        {
            await _auditWriter.WriteAsync(update, error, CancellationToken.None);
            auditWritten = true;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.AUDIT_WRITTEN, update.ThumbprintSha256);
        }
        catch (Exception auditError)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.AUDIT_FAILED, update.ThumbprintSha256, auditError.Message);
        }

        bool notified = false;
        try
        {
            _notifier.NotifyPublishFailed(BuildNotice(update.ThumbprintSha256));
            notified = true;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.NOTIFICATION_SENT, update.ThumbprintSha256);
        }
        catch (Exception notifyError)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.NOTIFICATION_FAILED, update.ThumbprintSha256, notifyError.Message);
        }

        return new PublishResult
        {
            Published = false,
            AuditWritten = auditWritten,
            AdministratorNotified = notified,
            Error = error
        };
    }

    /// <summary>
    /// Builds the message for the administrator with a short form of the thumbprint.
    /// </summary>
    /// <param name="thumbprint">
    /// Thumbprint of the certificate.
    /// </param>
    /// <returns>
    /// The message for the administrator.
    /// </returns>
    private static string BuildNotice(string thumbprint)
    {
        string shortThumbprint = thumbprint.Length > TrustPublishConstants.SHORT_THUMBPRINT_LENGTH
            ? thumbprint[..TrustPublishConstants.SHORT_THUMBPRINT_LENGTH]
            : thumbprint;
        return TrustPublishConstants.ADMIN_NOTICE.Replace(TrustPublishConstants.MESSAGE_PLACEHOLDER, shortThumbprint);
    }

    /// <summary>
    /// Checks that the value is not null. When it is null, an error is logged and an exception is thrown.
    /// </summary>
    /// <typeparam name="T">
    /// Type of the value.
    /// </typeparam>
    /// <param name="value">
    /// The value to check.
    /// </param>
    /// <param name="message">
    /// Log message written when the value is null.
    /// </param>
    /// <param name="name">
    /// Name of the parameter.
    /// </param>
    /// <returns>
    /// The value that was checked.
    /// </returns>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the value is null.
    /// </exception>
    private static T Require<T>(T value, string message, string name) where T : class
    {
        if (value is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), message);
            throw new ArgumentNullException(name);
        }
        return value;
    }

    #endregion
}
