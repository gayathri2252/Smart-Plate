// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Checks the signed certificate before the renewed certificate is activated.
/// </summary>
public static class RenewalSignedCertificateValidator
{
    /// <summary>
    /// Checks that the signed certificate is valid and matches the certificate signing request.
    /// </summary>
    /// <param name="signedCertificatePem">The signed certificate in PEM format.</param>
    /// <param name="csrPem">The certificate signing request in PEM format, or null to skip the key check.</param>
    /// <exception cref="ArgumentException">Thrown when the signed certificate is null or empty.</exception>
    /// <exception cref="InvalidOperationException">Thrown when the certificate cannot be read, is not valid yet, has expired, or its public key does not match the request.</exception>
    public static void ValidateOrThrow(string? signedCertificatePem, string? csrPem = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(signedCertificatePem);

        X509Certificate2 certificate;
        try
        {
            certificate = X509Certificate2.CreateFromPem(signedCertificatePem);
        }
        catch (CryptographicException ex)
        {
            throw new InvalidOperationException("Signed certificate PEM is not a valid X.509 certificate.", ex);
        }

        using (certificate)
        {
            DateTimeOffset now = DateTimeOffset.UtcNow;
            if (now < certificate.NotBefore.ToUniversalTime())
            {
                throw new InvalidOperationException("Signed certificate is not yet valid.");
            }

            if (now > certificate.NotAfter.ToUniversalTime())
            {
                throw new InvalidOperationException("Signed certificate has expired.");
            }

            if (!string.IsNullOrWhiteSpace(csrPem))
            {
                ValidatePublicKeyMatchesCsr(certificate, csrPem);
            }
        }
    }

    /// <summary>
    /// Checks that the public key of the certificate is the same as in the certificate signing request.
    /// </summary>
    /// <param name="certificate">The signed certificate.</param>
    /// <param name="csrPem">The certificate signing request in PEM format.</param>
    /// <exception cref="InvalidOperationException">Thrown when the keys do not match or the request cannot be read.</exception>
    private static void ValidatePublicKeyMatchesCsr(X509Certificate2 certificate, string csrPem)
    {
        try
        {
            byte[] csrSpki = ExtractSubjectPublicKeyInfoFromCsrPem(csrPem);
            byte[] certSpki = certificate.PublicKey.ExportSubjectPublicKeyInfo();
            if (!csrSpki.AsSpan().SequenceEqual(certSpki))
            {
                throw new InvalidOperationException("Signed certificate public key does not match the recorded CSR.");
            }
        }
        catch (InvalidOperationException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("Unable to validate CSR against signed certificate.", ex);
        }
    }

    /// <summary>
    /// Reads the public key from the certificate signing request.
    /// </summary>
    /// <param name="csrPem">The certificate signing request in PEM format.</param>
    /// <returns>The public key in DER format.</returns>
    private static byte[] ExtractSubjectPublicKeyInfoFromCsrPem(string csrPem)
    {
        byte[] der = DecodePem(csrPem, "CERTIFICATE REQUEST");
        var reader = new AsnReader(der, AsnEncodingRules.DER);
        AsnReader outer = reader.ReadSequence();
        AsnReader certificationRequestInfo = outer.ReadSequence();
        certificationRequestInfo.ReadInteger();
        certificationRequestInfo.ReadEncodedValue();
        return certificationRequestInfo.ReadEncodedValue().ToArray();
    }

    /// <summary>
    /// Reads the data of the PEM block with the given label.
    /// </summary>
    /// <param name="pem">Text in PEM format.</param>
    /// <param name="label">Label of the PEM block.</param>
    /// <returns>The data of the block.</returns>
    /// <exception cref="InvalidOperationException">Thrown when the PEM block is missing.</exception>
    private static byte[] DecodePem(string pem, string label)
    {
        var data = new StringBuilder();
        bool capture = false;
        foreach (string rawLine in pem.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            string line = rawLine.Trim();
            if (line.Contains($"BEGIN {label}", StringComparison.Ordinal))
            {
                capture = true;
                continue;
            }

            if (line.Contains($"END {label}", StringComparison.Ordinal))
            {
                break;
            }

            if (capture)
            {
                data.Append(line);
            }
        }

        if (data.Length == 0)
        {
            throw new InvalidOperationException("CSR PEM block is missing.");
        }

        return Convert.FromBase64String(data.ToString());
    }
}
