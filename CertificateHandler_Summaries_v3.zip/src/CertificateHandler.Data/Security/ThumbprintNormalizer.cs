// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.RegularExpressions;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Changes certificate thumbprints to upper case SHA256 hex before they are saved in the database.
/// </summary>
public static partial class ThumbprintNormalizer
{
    #region Member Variables

    /// <summary>
    /// Pattern for a SHA256 thumbprint of 64 hex characters.
    /// </summary>
    private static readonly Regex Sha256HexPattern = Sha256Hex();

    #endregion

    #region Public Methods

    /// <summary>
    /// Gives the thumbprint trimmed and in upper case. Throws ArgumentException when it is missing or is not 64 hex characters.
    /// </summary>
    /// <param name="raw">The thumbprint to clean.</param>
    /// <returns>The cleaned thumbprint.</returns>
    public static string NormalizeRequired(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
        {
            throw new ArgumentException("Thumbprint is required.", nameof(raw));
        }

        var trimmed = raw.Trim();
        if (!Sha256HexPattern.IsMatch(trimmed))
        {
            throw new ArgumentException("Thumbprint must be 64 hexadecimal characters (SHA-256).", nameof(raw));
        }

        return trimmed.ToUpperInvariant();
    }

    /// <summary>
    /// Cleans the thumbprint without throwing. Returns false and an empty string when the thumbprint is missing or is not 64 hex characters.
    /// </summary>
    /// <param name="raw">The thumbprint to clean.</param>
    /// <param name="thumbprint">The cleaned thumbprint, or an empty string.</param>
    /// <returns>True if the thumbprint is valid, otherwise false.</returns>
    public static bool TryNormalizeRequired(string? raw, out string thumbprint)
    {
        if (string.IsNullOrWhiteSpace(raw) || !Sha256HexPattern.IsMatch(raw.Trim()))
        {
            thumbprint = string.Empty;
            return false;
        }

        thumbprint = raw.Trim().ToUpperInvariant();
        return true;
    }

    /// <summary>
    /// Gives null when the thumbprint is missing, otherwise the result of NormalizeRequired.
    /// </summary>
    /// <param name="raw">The thumbprint to clean, or null.</param>
    /// <returns>The cleaned thumbprint, or null.</returns>
    public static string? NormalizeOptional(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
        {
            return null;
        }

        return NormalizeRequired(raw);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Pattern for exactly 64 hex characters, upper or lower case.
    /// </summary>
    /// <returns>The thumbprint pattern.</returns>
    [GeneratedRegex("^[0-9A-Fa-f]{64}$", RegexOptions.CultureInvariant)]
    private static partial Regex Sha256Hex();

    #endregion
}
