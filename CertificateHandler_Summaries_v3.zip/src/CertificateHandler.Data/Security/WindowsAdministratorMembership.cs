// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Principal;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Checks if the current Windows user is in a local Windows group.
/// </summary>
public static class WindowsAdministratorMembership
{
    /// <summary>
    /// Checks if the current Windows user is in the group.
    /// </summary>
    /// <param name="groupName">Name of the Windows group.</param>
    /// <returns>True if the user is in the group, otherwise false.</returns>
    public static bool IsCurrentUserInGroup(string groupName)
    {
        if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        try
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(groupName.Trim());
        }
        catch (Exception)
        {
            return false;
        }
    }
}
