// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Enums;

/// <summary>
/// The list a row of the local trust store belongs to. The name is stored as text in the database.
/// </summary>
public enum TrustListType
{
    /// <summary>Certificates that are allowed to connect.</summary>
    Whitelist,

    /// <summary>Certificates that are refused.</summary>
    Blacklist,

    /// <summary>Certificates that wait for an administrator decision.</summary>
    Pending
}
