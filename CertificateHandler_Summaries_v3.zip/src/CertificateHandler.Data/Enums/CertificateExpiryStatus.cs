﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Enums;

/// <summary>
/// Expiry state of a certificate, as shown to an administrator.
/// </summary>
public enum CertificateExpiryStatus
{
    /// <summary>No active certificate was found, so there is no expiry to check.</summary>
    NotAvailable = 0,

    /// <summary>The certificate is valid and its end date is outside the warning window.</summary>
    Valid = 1,

    /// <summary>The certificate is still valid but its end date is inside the warning window.</summary>
    NearingExpiration = 2,

    /// <summary>The end date has passed.</summary>
    Expired = 3
}
