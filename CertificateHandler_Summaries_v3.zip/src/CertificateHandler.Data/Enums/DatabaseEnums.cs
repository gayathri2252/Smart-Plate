// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using NpgsqlTypes;

namespace CertificateHandler.Data.Enums;

/// <summary>
/// Types of devices.
/// </summary>
public enum DeviceType
{
    /// <summary>
    /// Another MAXUM device.
    /// </summary>
    [PgName("MAXUM_PEER")]
    MaxumPeer,

    /// <summary>
    /// Local single board computer.
    /// </summary>
    [PgName("LOCAL_SBC")]
    LocalSbc,

    /// <summary>
    /// Local MIB device.
    /// </summary>
    [PgName("LOCAL_MIB")]
    LocalMib,

    /// <summary>
    /// GCP workstation.
    /// </summary>
    [PgName("GCP_WORKSTATION")]
    GcpWorkstation,

    /// <summary>
    /// Any other device type.
    /// </summary>
    [PgName("OTHER")]
    Other
}

/// <summary>
/// Working status of a device.
/// </summary>
public enum DeviceOperationalStatus
{
    /// <summary>
    /// The device is active.
    /// </summary>
    [PgName("ACTIVE")]
    Active,

    /// <summary>
    /// Factory provisioning of the device failed.
    /// </summary>
    [PgName("PROVISIONING_FAILED")]
    ProvisioningFailed,

    /// <summary>
    /// The secure storage of the device is not available.
    /// </summary>
    [PgName("STORAGE_UNAVAILABLE")]
    StorageUnavailable,

    /// <summary>
    /// The device is no longer in use.
    /// </summary>
    [PgName("DECOMMISSIONED")]
    Decommissioned
}

/// <summary>
/// Roles of certificates.
/// </summary>
public enum CertificateRole
{
    /// <summary>
    /// Certificate of a peer device.
    /// </summary>
    [PgName("PEER")]
    Peer,

    /// <summary>
    /// Certificate of the local SBC.
    /// </summary>
    [PgName("LOCAL_SBC")]
    LocalSbc,

    /// <summary>
    /// Certificate of the local MIB.
    /// </summary>
    [PgName("LOCAL_MIB")]
    LocalMib,

    /// <summary>
    /// Certificate of the GCP application.
    /// </summary>
    [PgName("GCP_APPLICATION")]
    GcpApplication,

    /// <summary>
    /// Factory default certificate.
    /// </summary>
    [PgName("FACTORY_DEFAULT")]
    FactoryDefault,

    /// <summary>
    /// Short term certificate used after a security breach.
    /// </summary>
    [PgName("TEMPORARY_POST_COMPROMISE")]
    TemporaryPostCompromise
}

/// <summary>
/// Trust lists.
/// </summary>
public enum TrustListKind
{
    /// <summary>
    /// Whitelist of trusted certificates.
    /// </summary>
    [PgName("WHITELIST")]
    Whitelist,

    /// <summary>
    /// Blacklist of blocked certificates.
    /// </summary>
    [PgName("BLACKLIST")]
    Blacklist
}

/// <summary>
/// Types of pending requests.
/// </summary>
public enum PendingRequestType
{
    /// <summary>
    /// Onboarding request of a peer device.
    /// </summary>
    [PgName("PEER_ONBOARDING")]
    PeerOnboarding,

    /// <summary>
    /// Request to move a certificate from the blacklist to the whitelist.
    /// </summary>
    [PgName("REINSTATEMENT")]
    Reinstatement,

    /// <summary>
    /// Request to move a certificate from the whitelist to the blacklist.
    /// </summary>
    [PgName("WHITELIST_TO_BLACKLIST")]
    WhitelistToBlacklist
}

/// <summary>
/// Status of a pending request.
/// </summary>
public enum PendingRequestStatus
{
    /// <summary>
    /// The request waits for a decision.
    /// </summary>
    [PgName("PENDING")]
    Pending,

    /// <summary>
    /// The request was approved.
    /// </summary>
    [PgName("APPROVED")]
    Approved,

    /// <summary>
    /// The request was rejected.
    /// </summary>
    [PgName("REJECTED")]
    Rejected,

    /// <summary>
    /// The request expired with no decision.
    /// </summary>
    [PgName("EXPIRED")]
    Expired
}

/// <summary>
/// Reason types for a blacklist entry.
/// </summary>
public enum BlacklistReasonClass
{
    /// <summary>
    /// The signature of the certificate is not valid.
    /// </summary>
    [PgName("SIGNATURE_FAILURE")]
    SignatureFailure,

    /// <summary>
    /// The certificate is revoked.
    /// </summary>
    [PgName("REVOKED_CERTIFICATE")]
    RevokedCertificate,

    /// <summary>
    /// The certificate chain is broken.
    /// </summary>
    [PgName("BROKEN_CHAIN")]
    BrokenChain,

    /// <summary>
    /// An administrator added it to the blacklist.
    /// </summary>
    [PgName("MANUAL_ACTION")]
    ManualAction,

    /// <summary>
    /// It was added to the blacklist because of a security incident.
    /// </summary>
    [PgName("SECURITY_INCIDENT")]
    SecurityIncident
}

/// <summary>
/// Status of a renewal request.
/// </summary>
public enum RenewalRequestStatus
{
    /// <summary>
    /// The request was created.
    /// </summary>
    [PgName("CREATED")]
    Created,

    /// <summary>
    /// The request was exported.
    /// </summary>
    [PgName("EXPORTED")]
    Exported,

    /// <summary>
    /// The signed certificate was imported.
    /// </summary>
    [PgName("IMPORTED")]
    Imported,

    /// <summary>
    /// The signed certificate was checked.
    /// </summary>
    [PgName("VALIDATED")]
    Validated,

    /// <summary>
    /// The renewed certificate was activated.
    /// </summary>
    [PgName("ACTIVATED")]
    Activated,

    /// <summary>
    /// The renewal failed.
    /// </summary>
    [PgName("FAILED")]
    Failed,

    /// <summary>
    /// The renewal was rolled back.
    /// </summary>
    [PgName("ROLLED_BACK")]
    RolledBack
}

/// <summary>
/// Status of a bulk operation.
/// </summary>
public enum BulkOperationStatus
{
    /// <summary>
    /// The operation is running.
    /// </summary>
    [PgName("RUNNING")]
    Running,

    /// <summary>
    /// The operation finished.
    /// </summary>
    [PgName("COMPLETED")]
    Completed,

    /// <summary>
    /// The operation finished, but some items failed.
    /// </summary>
    [PgName("COMPLETED_WITH_ERRORS")]
    CompletedWithErrors,

    /// <summary>
    /// The operation took longer than allowed.
    /// </summary>
    [PgName("TIMED_OUT")]
    TimedOut,

    /// <summary>
    /// The operation was cancelled.
    /// </summary>
    [PgName("CANCELLED")]
    Cancelled
}

/// <summary>
/// Status of a trust event delivery.
/// </summary>
public enum TrustEventDeliveryStatus
{
    /// <summary>
    /// The delivery is waiting.
    /// </summary>
    [PgName("PENDING")]
    Pending,

    /// <summary>
    /// The event was delivered.
    /// </summary>
    [PgName("DELIVERED")]
    Delivered,

    /// <summary>
    /// The delivery failed.
    /// </summary>
    [PgName("FAILED")]
    Failed,

    /// <summary>
    /// The delivery is being tried again.
    /// </summary>
    [PgName("RETRYING")]
    Retrying
}

/// <summary>
/// Results of a factory provisioning attempt.
/// </summary>
public enum ProvisioningOutcome
{
    /// <summary>
    /// The attempt is running.
    /// </summary>
    [PgName("IN_PROGRESS")]
    InProgress,

    /// <summary>
    /// The provisioning worked.
    /// </summary>
    [PgName("SUCCESS")]
    Success,

    /// <summary>
    /// The provisioning failed.
    /// </summary>
    [PgName("FAILED")]
    Failed,

    /// <summary>
    /// Someone has to fix it by hand.
    /// </summary>
    [PgName("MANUAL_INTERVENTION_REQUIRED")]
    ManualInterventionRequired
}

/// <summary>
/// Status sent in a peer notification.
/// </summary>
public enum PeerNotificationStatus
{
    /// <summary>
    /// The request is pending.
    /// </summary>
    [PgName("PENDING")]
    Pending,

    /// <summary>
    /// The request was approved.
    /// </summary>
    [PgName("APPROVED")]
    Approved,

    /// <summary>
    /// The request was rejected.
    /// </summary>
    [PgName("REJECTED")]
    Rejected
}

/// <summary>
/// Results of a delivery.
/// </summary>
public enum DeliveryResult
{
    /// <summary>
    /// The delivery worked.
    /// </summary>
    [PgName("SUCCESS")]
    Success,

    /// <summary>
    /// The delivery failed.
    /// </summary>
    [PgName("FAILED")]
    Failed
}

/// <summary>
/// Decisions on a reinstatement request.
/// </summary>
public enum ReinstatementDecision
{
    /// <summary>
    /// The request was approved.
    /// </summary>
    Approved,

    /// <summary>
    /// The request was rejected.
    /// </summary>
    Rejected
}
