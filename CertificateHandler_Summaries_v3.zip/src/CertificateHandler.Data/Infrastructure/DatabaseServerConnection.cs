﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Opens connections to the database server. When the server cannot be reached, the server address and the reason are written to the Log Monitor before the error is passed on.
/// So a lost database server is always seen in the logs.
/// </summary>
public static class DatabaseServerConnection
{
    #region Public Methods

    /// <summary>Opens the given connection. Logs the server and the reason when it fails.</summary>
    /// <param name="connection">The connection to open.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A task that ends when the connection is open.</returns>
    public static async Task OpenAsync(NpgsqlConnection connection, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(connection);

        try
        {
            await connection.OpenAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            LogUnreachable(connection.Host, connection.Port, ex);
            throw;
        }
    }

    /// <summary>Opens a connection from the data source. Logs the server and the reason when it fails.</summary>
    /// <param name="dataSource">Data source to open the connection from.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The open connection.</returns>
    public static async Task<NpgsqlConnection> OpenAsync(NpgsqlDataSource dataSource, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(dataSource);

        try
        {
            return await dataSource.OpenConnectionAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            LogUnreachable(dataSource, ex);
            throw;
        }
    }

    /// <summary>Opens the given connection and waits for it. Logs the server and the reason when it fails.</summary>
    /// <param name="connection">The connection to open.</param>
    public static void Open(NpgsqlConnection connection)
    {
        ArgumentNullException.ThrowIfNull(connection);

        try
        {
            connection.Open();
        }
        catch (Exception ex)
        {
            LogUnreachable(connection.Host, connection.Port, ex);
            throw;
        }
    }

    /// <summary>Opens a connection from the data source and waits for it. Logs the server and the reason when it fails.</summary>
    /// <param name="dataSource">Data source to open the connection from.</param>
    /// <returns>The open connection.</returns>
    public static NpgsqlConnection Open(NpgsqlDataSource dataSource)
    {
        ArgumentNullException.ThrowIfNull(dataSource);

        try
        {
            return dataSource.OpenConnection();
        }
        catch (Exception ex)
        {
            LogUnreachable(dataSource, ex);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>Logs the server of the data source and the reason.</summary>
    /// <param name="dataSource">The data source that failed.</param>
    /// <param name="error">The error.</param>
    private static void LogUnreachable(NpgsqlDataSource dataSource, Exception error)
    {
        string? host = null;
        int port = 0;
        try
        {
            var builder = new NpgsqlConnectionStringBuilder(dataSource.ConnectionString);
            host = builder.Host;
            port = builder.Port;
        }
        catch (ArgumentException)
        {
            // The server stays unknown in the log line.
        }

        LogUnreachable(host, port, error);
    }

    /// <summary>Writes the error line with the host, the port and the reason.</summary>
    /// <param name="host">Host of the database server.</param>
    /// <param name="port">Port of the database server.</param>
    /// <param name="error">The error.</param>
    private static void LogUnreachable(string? host, int port, Exception error)
    {
        string server = string.IsNullOrWhiteSpace(host) ? DatabaseConstants.UNKNOWN_SERVER : host + ":" + port;
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.DB_SERVER_UNREACHABLE, server, error.Message);
    }

    #endregion
}