﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Options;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Owns the shared NpgsqlDataSource and creates CertificateHandlerDbContext objects. Dispose it once when the app closes to free the connection pool.
/// </summary>
public sealed class CertificateHandlerDataAccess : IAsyncDisposable, IDisposable
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Client certificate used for the database connection. Null when not used.
    /// </summary>
    private readonly X509Certificate2? _clientCertificate;

    /// <summary>
    /// Settings used to create the database contexts.
    /// </summary>
    private readonly DbContextOptions<CertificateHandlerDbContext> _contextOptions;

    /// <summary>
    /// True when the data access is disposed.
    /// </summary>
    private bool _disposed;

    #endregion

    #region Public Properties

    /// <summary>
    /// Shared connection pool used by Entity Framework Core and by plain SQL code.
    /// </summary>
    public NpgsqlDataSource DataSource
    {
        get
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            return _dataSource;
        }
    }

    #endregion

    #region Constructor

    /// <summary>
    /// Keeps the data source, the context settings and the client certificate that this object owns.
    /// </summary>
    /// <param name="dataSource">The shared data source.</param>
    /// <param name="contextOptions">Settings used to create the database contexts.</param>
    /// <param name="clientCertificate">The client certificate, or null.</param>
    private CertificateHandlerDataAccess(
        NpgsqlDataSource dataSource,
        DbContextOptions<CertificateHandlerDbContext> contextOptions,
        X509Certificate2? clientCertificate)
    {
        _dataSource = dataSource;
        _contextOptions = contextOptions;
        _clientCertificate = clientCertificate;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Builds the data source from the settings, with the enum mappings and the TLS client certificate.
    /// Reads the certificates from the given store location, LocalMachine by default. Gives the data access object that owns them.
    /// </summary>
    /// <param name="options">The database settings.</param>
    /// <param name="certificateStoreLocation">Certificate store location to read from.</param>
    /// <returns>The data access object.</returns>
    public static CertificateHandlerDataAccess Create(
        DatabaseOptions options,
        StoreLocation certificateStoreLocation = StoreLocation.LocalMachine)
    {
        ArgumentNullException.ThrowIfNull(options);
        options.Validate();

        var dataSourceBuilder = new NpgsqlDataSourceBuilder(options.BuildConnectionString());
        PostgresEnumRegistration.Configure(dataSourceBuilder);
        X509Certificate2? clientCertificate = PostgresTlsConfiguration.Apply(dataSourceBuilder, options, certificateStoreLocation);

        try
        {
            var dataSource = dataSourceBuilder.Build();

            var contextOptions = new DbContextOptionsBuilder<CertificateHandlerDbContext>()
                .UseNpgsql(dataSource, npgsql => npgsql.EnableRetryOnFailure(maxRetryCount: 3))
                .UseSnakeCaseNamingConvention()
                .Options;

            return new CertificateHandlerDataAccess(dataSource, contextOptions, clientCertificate);
        }
        catch
        {
            clientCertificate?.Dispose();
            throw;
        }
    }

    /// <summary>
    /// Creates a new database context that uses the shared data source.
    /// </summary>
    /// <returns>The new database context.</returns>
    public CertificateHandlerDbContext CreateDbContext()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        return new CertificateHandlerDbContext(_contextOptions);
    }

    /// <summary>
    /// Opens a plain connection with the same data source the app uses, so the TLS settings and certificate checks run exactly as in production.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The open connection.</returns>
    public ValueTask<NpgsqlConnection> OpenConnectionAsync(CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        return new ValueTask<NpgsqlConnection>(DatabaseServerConnection.OpenAsync(_dataSource, cancellationToken));
    }

    #endregion

    #region Dispose Methods

    /// <summary>
    /// Frees the data source and the client certificate.
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _dataSource.Dispose();
        _clientCertificate?.Dispose();
        _disposed = true;
    }

    /// <inheritdoc />
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        await _dataSource.DisposeAsync().ConfigureAwait(false);
        _clientCertificate?.Dispose();
        _disposed = true;
    }

    #endregion
}