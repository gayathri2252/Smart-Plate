// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Microsoft.Data.Sqlite;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// The encrypted local trust store file. It opens the file with SQLCipher AES256 and the key protected by the key protector, and creates the trust entry table on the first run.
/// </summary>
public sealed class TrustStoreDatabase
{
    #region Member Variables

    /// <summary>Name of the table that holds the whitelist, blacklist and pending rows.</summary>
    internal const string TABLE_NAME = "trust_entry";

    /// <summary>
    /// Name of the unique index on the thumbprint.
    /// </summary>
    private const string THUMBPRINT_INDEX_NAME = "ux_trust_entry_thumbprint";

    /// <summary>
    /// Name of the index on the list type and the active flag.
    /// </summary>
    private const string LIST_INDEX_NAME = "ix_trust_entry_list_active";

    /// <summary>
    /// SQL used to check that the key opens the database.
    /// </summary>
    private const string VERIFY_KEY_SQL = "SELECT count(*) FROM sqlite_master;";

    /// <summary>
    /// SQL that creates the trust entry table.
    /// </summary>
    private const string CREATE_TABLE_SQL =
        $"CREATE TABLE IF NOT EXISTS {TABLE_NAME} (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
        "thumbprint TEXT NOT NULL, " +
        "list_type TEXT NOT NULL CHECK (list_type IN ('Whitelist', 'Blacklist', 'Pending')), " +
        "subject_dn TEXT NOT NULL, " +
        "serial_number TEXT NOT NULL, " +
        "not_before TEXT NOT NULL, " +
        "not_after TEXT NOT NULL, " +
        "added_by TEXT NOT NULL, " +
        "added_at TEXT NOT NULL, " +
        "comment TEXT NULL, " +
        "is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)));";

    /// <summary>
    /// SQL that creates the unique index on the thumbprint.
    /// </summary>
    private const string CREATE_THUMBPRINT_INDEX_SQL =
        $"CREATE UNIQUE INDEX IF NOT EXISTS {THUMBPRINT_INDEX_NAME} ON {TABLE_NAME} (thumbprint);";

    /// <summary>
    /// SQL that creates the index on the list type and the active flag.
    /// </summary>
    private const string CREATE_LIST_INDEX_SQL =
        $"CREATE INDEX IF NOT EXISTS {LIST_INDEX_NAME} ON {TABLE_NAME} (list_type, is_active);";

    /// <summary>SQLite result code that means the file is not a database. SQLCipher gives it when the key is wrong.</summary>
    private const int SQLITE_NOTADB = 26;

    /// <summary>SQLite result code that means the database file is damaged.</summary>
    private const int SQLITE_CORRUPT = 11;

    /// <summary>
    /// Path of the encrypted database file.
    /// </summary>
    private readonly string _databasePath;

    /// <summary>
    /// True when access to the trust store folder is limited.
    /// </summary>
    private readonly bool _restrictFolderAccess;

    /// <summary>
    /// Other accounts that get access to the trust store folder.
    /// </summary>
    private readonly IReadOnlyList<string> _additionalAccounts;

    /// <summary>
    /// Gives the key that opens the database.
    /// </summary>
    private readonly TrustStoreKeyProvider _keyProvider;

    /// <summary>
    /// Lock that makes sure the database is set up only once.
    /// </summary>
    private readonly object _initializeLock = new();

    /// <summary>
    /// Connection string of the database. Null until the database is set up.
    /// </summary>
    private string? _connectionString;

    #endregion

    #region Constructor

    /// <summary>
    /// Sets up the SQLite native library once, so SQLCipher is used for every connection.
    /// </summary>
    static TrustStoreDatabase()
    {
        SQLitePCL.Batteries_V2.Init();
    }

    /// <summary>
    /// Creates the trust store for the given file paths and key protector. Nothing is opened yet. Throws when the options or the key protector are null.
    /// </summary>
    /// <param name="options">Trust store settings with the file paths.</param>
    /// <param name="keyProtector">Protects and unprotects the database key.</param>
    public TrustStoreDatabase(TrustStoreOptions options, IKeyProtector keyProtector)
    {
        if (options is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_OPTIONS_IS_NULL);
            throw new ArgumentNullException(nameof(options));
        }

        if (keyProtector is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_PROTECTOR_IS_NULL);
            throw new ArgumentNullException(nameof(keyProtector));
        }

        _databasePath = options.DatabasePath;
        _restrictFolderAccess = options.RestrictFolderAccess;
        _additionalAccounts = (options.AdditionalAccounts ?? new List<string>()).ToList();
        _keyProvider = new TrustStoreKeyProvider(options.KeyFilePath, keyProtector);
    }

    #endregion

    #region Public Properties

    /// <summary>Full path of the encrypted database file.</summary>
    public string DatabasePath => _databasePath;

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the key, opens the file with it and creates the table and indexes when they are missing.
    /// Throws TrustStoreException with a message for the user when the file cannot be opened, like when it was copied from another computer.
    /// Calling it again does nothing.
    /// </summary>
    public void EnsureInitialized()
    {
        lock (_initializeLock)
        {
            if (_connectionString is not null)
            {
                return;
            }

            string directory = Path.GetDirectoryName(Path.GetFullPath(_databasePath))!;
            Directory.CreateDirectory(directory);
            if (_restrictFolderAccess)
            {
                TrustStoreFolderSecurity.Restrict(directory, _additionalAccounts);
            }

            bool isNewDatabase = !File.Exists(_databasePath);
            if (!isNewDatabase && !_keyProvider.KeyFileExists)
            {
                CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_FILE_MISSING, _databasePath, _keyProvider.KeyFilePath);
                throw new TrustStoreException(DatabaseConstants.TRUST_STORE_KEY_MISSING_MESSAGE);
            }

            string connectionString = BuildConnectionString(_keyProvider.GetOrCreateKey());
            CreateSchema(connectionString);
            _connectionString = connectionString;

            if (isNewDatabase)
            {
                CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_CREATED, _databasePath);
            }
        }
    }

    /// <summary>
    /// Opens a connection to the trust store. The caller disposes it.
    /// </summary>
    /// <returns>The open connection.</returns>
    public SqliteConnection OpenConnection()
    {
        EnsureInitialized();

        var connection = new SqliteConnection(_connectionString);
        connection.Open();
        return connection;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds the connection string. The password is the key as hex text, which SQLCipher uses to open the file.
    /// </summary>
    /// <param name="key">The database key.</param>
    /// <returns>The connection string.</returns>
    private string BuildConnectionString(byte[] key)
    {
        string password = Convert.ToHexString(key);
        CryptographicOperations.ZeroMemory(key);

        return new SqliteConnectionStringBuilder
        {
            DataSource = _databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Password = password
        }.ToString();
    }

    /// <summary>
    /// Checks that the key opens the file and creates the table and indexes. A wrong key or a file from another computer is reported as TrustStoreException.
    /// </summary>
    /// <param name="connectionString">The connection string to use.</param>
    private void CreateSchema(string connectionString)
    {
        try
        {
            using var connection = new SqliteConnection(connectionString);
            connection.Open();

            Execute(connection, VERIFY_KEY_SQL);
            Execute(connection, CREATE_TABLE_SQL);
            Execute(connection, CREATE_THUMBPRINT_INDEX_SQL);
            Execute(connection, CREATE_LIST_INDEX_SQL);
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode is SQLITE_NOTADB or SQLITE_CORRUPT)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_OPEN_FAILED, _databasePath, ex.Message);
            throw new TrustStoreException(DatabaseConstants.TRUST_STORE_DECRYPT_FAILED_MESSAGE, ex);
        }
    }

    /// <summary>
    /// Runs one SQL statement without parameters.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="sql">The SQL to run.</param>
    private static void Execute(SqliteConnection connection, string sql)
    {
        using SqliteCommand command = connection.CreateCommand();
        command.CommandText = sql;
        command.ExecuteNonQuery();
    }

    #endregion
}
