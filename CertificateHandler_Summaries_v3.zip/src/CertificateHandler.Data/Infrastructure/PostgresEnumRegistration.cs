// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Links the C sharp enums to the PostgreSQL enum types for Npgsql.
/// </summary>
public static class PostgresEnumRegistration
{
    #region Public Methods

    /// <summary>
    /// Links the enum types to their PostgreSQL enum types.
    /// </summary>
    /// <param name="builder">The data source builder to set up.</param>
    /// <exception cref="ArgumentNullException">Thrown when the builder is null.</exception>
    public static void Configure(NpgsqlDataSourceBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        builder.MapEnum<DeviceType>("device_type");
        builder.MapEnum<DeviceOperationalStatus>("device_operational_status");
        builder.MapEnum<CertificateRole>("certificate_role");
        builder.MapEnum<TrustListKind>("trust_list_kind");
        builder.MapEnum<PendingRequestType>("pending_request_type");
        builder.MapEnum<PendingRequestStatus>("pending_request_status");
        builder.MapEnum<BlacklistReasonClass>("blacklist_reason_class");
        builder.MapEnum<RenewalRequestStatus>("renewal_request_status");
        builder.MapEnum<BulkOperationStatus>("bulk_operation_status");
        builder.MapEnum<TrustEventDeliveryStatus>("trust_event_delivery_status");
        builder.MapEnum<ProvisioningOutcome>("provisioning_outcome");
        builder.MapEnum<PeerNotificationStatus>("peer_notification_status");
        builder.MapEnum<DeliveryResult>("delivery_result");
    }

    #endregion
}
