﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Options;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Creates the app database and applies the stored schema on the first run.
/// </summary>
public static class DatabaseBootstrapper
{
    #region Member Variables

    /// <summary>
    /// The schema SQL stored in the app. It is loaded the first time it is used.
    /// </summary>
    private static readonly Lazy<string> EmbeddedSchemaSql = new(
        LoadEmbeddedSchemaSql,
        LazyThreadSafetyMode.ExecutionAndPublication);

    /// <summary>
    /// Migrations that run after the schema, with their ids and resource names, in order.
    /// </summary>
    private static readonly (string MigrationId, string ResourceName)[] IncrementalMigrations =
    [
        (DatabaseConstants.DashboardIndexesMigrationId, DatabaseConstants.EmbeddedDashboardIndexesMigrationResourceName),
        (DatabaseConstants.SecurityHardeningMigrationId, DatabaseConstants.EmbeddedSecurityHardeningMigrationResourceName)
    ];

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates the database and applies the schema and the missing migrations when needed.
    /// When the setup is skipped, only the missing migrations are applied.
    /// </summary>
    /// <param name="options">The database settings.</param>
    /// <exception cref="ArgumentNullException">Thrown when the settings are null.</exception>
    public static void EnsureInitialized(DatabaseOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        options.Validate();

        if (options.SkipBootstrap)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_SKIPPED);
            TryApplyPendingMigrations(options);
            return;
        }

        try
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_STARTED, DatabaseOptions.Database);
            EnsureDatabaseExists(options);

            if (IsSchemaApplied(options))
            {
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.DB_SCHEMA_PRESENT, DatabaseOptions.Database);
            }
            else
            {
                ApplyEmbeddedSchema(options);
                CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.DB_SCHEMA_APPLIED, DatabaseOptions.Database);
            }

            TryApplyPendingMigrations(options);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.DB_BOOTSTRAP_FAILED, DatabaseOptions.Database, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Creates the database if it does not exist.
    /// </summary>
    /// <param name="options">The database settings.</param>
    private static void EnsureDatabaseExists(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenConnection(options, DatabaseConstants.AdminDatabaseName);
        NpgsqlConnection connection = scope.Connection;

        using var existsCommand = connection.CreateCommand();
        existsCommand.CommandText = "SELECT 1 FROM pg_database WHERE datname = @name";
        existsCommand.Parameters.AddWithValue("name", DatabaseOptions.Database);

        if (existsCommand.ExecuteScalar() is not null)
        {
            return;
        }

        using var createCommand = connection.CreateCommand();
        createCommand.CommandText = BuildCreateDatabaseStatement(DatabaseOptions.Database);
        createCommand.ExecuteNonQuery();
        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DataLogConstants.DB_CREATED, DatabaseOptions.Database);
    }

    /// <summary>
    /// Checks if the schema stored in the app is already applied.
    /// </summary>
    /// <param name="options">The database settings.</param>
    /// <returns>True if the schema is applied, otherwise false.</returns>
    private static bool IsSchemaApplied(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenApplicationConnection(options);
        NpgsqlConnection connection = scope.Connection;

        if (!MigrationTableExists(connection))
        {
            return false;
        }

        return MigrationRecordExists(connection, DatabaseConstants.AppliedMigrationId);
    }

    /// <summary>
    /// Runs the schema SQL stored in the app on the database.
    /// </summary>
    /// <param name="options">The database settings.</param>
    private static void ApplyEmbeddedSchema(DatabaseOptions options)
    {
        using BootstrapConnectionScope scope = OpenApplicationConnection(options);
        NpgsqlConnection connection = scope.Connection;

        using var command = connection.CreateCommand();
        command.CommandText = EmbeddedSchemaSql.Value;
        command.CommandTimeout = DatabaseConstants.SchemaCommandTimeoutSeconds;
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Applies the migrations that are not applied yet.
    /// Database errors are ignored when the setup is skipped.
    /// </summary>
    /// <param name="options">The database settings.</param>
    private static void TryApplyPendingMigrations(DatabaseOptions options)
    {
        try
        {
            using BootstrapConnectionScope scope = OpenApplicationConnection(options);
            NpgsqlConnection connection = scope.Connection;

            if (!MigrationTableExists(connection))
            {
                return;
            }

            foreach ((string migrationId, string resourceName) in IncrementalMigrations)
            {
                if (MigrationRecordExists(connection, migrationId))
                {
                    continue;
                }

                ApplyEmbeddedMigration(connection, resourceName);
            }
        }
        catch (NpgsqlException)
        {
            if (!options.SkipBootstrap)
            {
                throw;
            }
        }
    }

    /// <summary>
    /// Opens a connection to the app database.
    /// </summary>
    /// <param name="options">The database settings.</param>
    /// <returns>Holder of the open connection.</returns>
    private static BootstrapConnectionScope OpenApplicationConnection(DatabaseOptions options) =>
        OpenConnection(options, DatabaseOptions.Database);

    /// <summary>
    /// Opens a connection to the given database, using the client certificate when it is set.
    /// </summary>
    /// <param name="options">The database settings.</param>
    /// <param name="databaseName">Name of the database to connect to.</param>
    /// <returns>Holder of the open connection.</returns>
    private static BootstrapConnectionScope OpenConnection(DatabaseOptions options, string databaseName)
    {
        var connectionStringBuilder = new NpgsqlConnectionStringBuilder(options.BuildConnectionString())
        {
            Database = databaseName
        };

        if (!options.UsesClientCertificate)
        {
            var connection = new NpgsqlConnection(connectionStringBuilder.ConnectionString);
            DatabaseServerConnection.Open(connection);
            return new BootstrapConnectionScope(connection, null, null);
        }

        var dataSourceBuilder = new NpgsqlDataSourceBuilder(connectionStringBuilder.ConnectionString);
        X509Certificate2? clientCertificate = PostgresTlsConfiguration.Apply(dataSourceBuilder, options);
        NpgsqlDataSource dataSource = dataSourceBuilder.Build();
        NpgsqlConnection tlsConnection = dataSource.OpenConnection();
        return new BootstrapConnectionScope(tlsConnection, dataSource, clientCertificate);
    }

    /// <summary>
    /// Holds an open setup connection and the things it uses.
    /// </summary>
    private sealed class BootstrapConnectionScope : IDisposable
    {
        /// <summary>
        /// The open database connection.
        /// </summary>
        private readonly NpgsqlConnection _connection;

        /// <summary>
        /// Data source of the connection. Null when no client certificate is used.
        /// </summary>
        private readonly NpgsqlDataSource? _dataSource;

        /// <summary>
        /// Client certificate of the connection. Null when no client certificate is used.
        /// </summary>
        private readonly X509Certificate2? _clientCertificate;

        /// <summary>
        /// Creates the connection holder.
        /// </summary>
        /// <param name="connection">The open database connection.</param>
        /// <param name="dataSource">Data source of the connection, or null.</param>
        /// <param name="clientCertificate">Client certificate of the connection, or null.</param>
        public BootstrapConnectionScope(
            NpgsqlConnection connection,
            NpgsqlDataSource? dataSource,
            X509Certificate2? clientCertificate)
        {
            _connection = connection;
            _dataSource = dataSource;
            _clientCertificate = clientCertificate;
        }

        /// <summary>
        /// Gets the open database connection.
        /// </summary>
        public NpgsqlConnection Connection => _connection;

        /// <summary>
        /// Closes the connection and frees the data source and the client certificate.
        /// </summary>
        public void Dispose()
        {
            _connection.Dispose();
            _dataSource?.Dispose();
            _clientCertificate?.Dispose();
        }
    }

    /// <summary>
    /// Runs a migration SQL file stored in the app on the database.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="resourceName">Resource name of the migration SQL.</param>
    private static void ApplyEmbeddedMigration(NpgsqlConnection connection, string resourceName)
    {
        string sql = LoadEmbeddedResource(resourceName);

        using var command = connection.CreateCommand();
        command.CommandText = sql;
        command.CommandTimeout = DatabaseConstants.SchemaCommandTimeoutSeconds;
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Loads the schema SQL stored in the app.
    /// </summary>
    /// <returns>The schema SQL.</returns>
    private static string LoadEmbeddedSchemaSql() =>
        LoadEmbeddedResource(DatabaseConstants.EmbeddedSchemaResourceName);

    /// <summary>
    /// Loads a text file stored in the app.
    /// </summary>
    /// <param name="resourceName">Name of the stored file.</param>
    /// <returns>The text of the file.</returns>
    /// <exception cref="InvalidOperationException">Thrown when the file is not found.</exception>
    private static string LoadEmbeddedResource(string resourceName)
    {
        var assembly = typeof(DatabaseBootstrapper).Assembly;
        using var stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException($"Embedded resource not found: {resourceName}");

        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    /// <summary>
    /// Builds the SQL that creates the database.
    /// </summary>
    /// <param name="databaseName">Name of the database.</param>
    /// <returns>The CREATE DATABASE SQL.</returns>
    private static string BuildCreateDatabaseStatement(string databaseName)
    {
        var escapedName = databaseName.Replace("\"", "\"\"", StringComparison.Ordinal);
        return $"""CREATE DATABASE "{escapedName}" ENCODING 'UTF8' TEMPLATE template0""";
    }

    /// <summary>
    /// Checks if the schema migration table exists.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <returns>True if the table exists, otherwise false.</returns>
    private static bool MigrationTableExists(NpgsqlConnection connection)
    {
        using var schemaCommand = connection.CreateCommand();
        schemaCommand.CommandText =
            """
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = @schemaName
              AND table_name = @tableName
            """;
        schemaCommand.Parameters.AddWithValue("schemaName", DatabaseConstants.SchemaName);
        schemaCommand.Parameters.AddWithValue("tableName", DatabaseConstants.SchemaMigrationTable);
        return schemaCommand.ExecuteScalar() is not null;
    }

    /// <summary>
    /// Checks if the migration is already applied.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="migrationId">Id of the migration.</param>
    /// <returns>True if the migration is applied, otherwise false.</returns>
    private static bool MigrationRecordExists(NpgsqlConnection connection, string migrationId)
    {
        using var migrationCommand = connection.CreateCommand();
        migrationCommand.CommandText =
            $"""
            SELECT 1
            FROM {DatabaseConstants.SchemaName}.{DatabaseConstants.SchemaMigrationTable}
            WHERE migration_id = @migrationId
            """;
        migrationCommand.Parameters.AddWithValue("migrationId", migrationId);
        return migrationCommand.ExecuteScalar() is not null;
    }

    #endregion
}
