// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Thrown when the encrypted local trust store cannot be opened or its key cannot be used.
/// The message is written for the user and can be shown as it is.
/// </summary>
public sealed class TrustStoreException : Exception
{
    #region Constructor

    /// <summary>
    /// Creates the exception with a message for the user.
    /// </summary>
    /// <param name="message">Message for the user.</param>
    public TrustStoreException(string message) : base(message)
    {
    }

    /// <summary>
    /// Creates the exception with a message for the user and the error that caused it.
    /// </summary>
    /// <param name="message">Message for the user.</param>
    /// <param name="innerException">The error that caused it.</param>
    public TrustStoreException(string message, Exception innerException) : base(message, innerException)
    {
    }

    #endregion
}
