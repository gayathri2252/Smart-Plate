// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Reflection;
using NpgsqlTypes;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Turns enums into PostgreSQL labels and back, using their PgName attributes.
/// </summary>
public static class PostgresEnumNames
{
    #region Public Methods

    /// <summary>
    /// Gives the PostgreSQL label of the value. Throws if it has none.
    /// </summary>
    /// <typeparam name="TEnum">The enum type.</typeparam>
    /// <param name="value">The enum value.</param>
    /// <returns>The PostgreSQL label.</returns>
    public static string ToPgName<TEnum>(TEnum value)
        where TEnum : struct, Enum
    {
        if (!Labels<TEnum>.ByValue.TryGetValue(value, out string? label))
        {
            throw new InvalidOperationException($"Unrecognized {typeof(TEnum).Name} value: {value}");
        }

        return label;
    }

    /// <summary>
    /// Gives the enum value for the PostgreSQL label. Throws if it is not known.
    /// </summary>
    /// <typeparam name="TEnum">The enum type.</typeparam>
    /// <param name="label">The PostgreSQL label.</param>
    /// <returns>The enum value.</returns>
    public static TEnum FromPgName<TEnum>(string label)
        where TEnum : struct, Enum
    {
        if (label is null || !Labels<TEnum>.ByLabel.TryGetValue(label, out TEnum value))
        {
            throw new InvalidOperationException($"Unrecognized {typeof(TEnum).Name} label: {label}");
        }

        return value;
    }

    #endregion

    #region Member Variables

    // Built once per enum type, from its PgName attributes.
    /// <summary>
    /// Keeps the PostgreSQL labels of one enum type, built once from its PgName attributes.
    /// </summary>
    private static class Labels<TEnum>
        where TEnum : struct, Enum
    {
        #region Member Variables

        /// <summary>
        /// PostgreSQL names, looked up by the enum value.
        /// </summary>
        public static readonly Dictionary<TEnum, string> ByValue;

        /// <summary>
        /// Enum values, looked up by the PostgreSQL name.
        /// </summary>
        public static readonly Dictionary<string, TEnum> ByLabel;

        #endregion

        #region Constructor

        /// <summary>
        /// Reads the PostgreSQL label of each enum member from its PgName attribute
        /// and fills the lookup tables.
        /// </summary>
        static Labels()
        {
            var byValue = new Dictionary<TEnum, string>();
            var byLabel = new Dictionary<string, TEnum>(StringComparer.Ordinal);

            foreach (FieldInfo field in typeof(TEnum).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                PgNameAttribute? attribute = field.GetCustomAttribute<PgNameAttribute>();
                if (attribute is null)
                {
                    continue;
                }

                var value = (TEnum)field.GetValue(null)!;
                byValue[value] = attribute.PgName;
                byLabel[attribute.PgName] = value;
            }

            ByValue = byValue;
            ByLabel = byLabel;
        }

        #endregion
    }

    #endregion
}
