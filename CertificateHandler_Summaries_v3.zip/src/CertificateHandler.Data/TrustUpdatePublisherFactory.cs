// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
namespace CertificateHandler.Data;

/// <summary>
/// Picks the real or the test trust event publisher.
/// </summary>
public static class TrustUpdatePublisherFactory
{
    #region Public Methods

    /// <summary>
    /// Creates the trust update publisher with its own data access.
    /// The test publisher is used when it is turned on.
    /// </summary>
    /// <param name="options">Database settings, or null to use the default settings.</param>
    /// <returns>The trust update publisher.</returns>
    public static ITrustUpdatePublisher Create(DatabaseOptions? options = null)
    {
        if (string.Equals(Environment.GetEnvironmentVariable("CH_USE_SIMULATED_TRUST_PUBLISHER"), "1", StringComparison.Ordinal))
        {
            return new SimulatedTrustUpdatePublisher();
        }

        CertificateHandlerDataAccess access = CertificateHandlerDataAccess.Create(options ?? new DatabaseOptions());
        return new DatabaseTrustEventPublisher(access.CreateDbContext());
    }

    /// <summary>
    /// Creates the trust update publisher with the given data access.
    /// The test publisher is used when it is turned on.
    /// </summary>
    /// <param name="dataAccess">Data access used to save the trust events.</param>
    /// <returns>The trust update publisher.</returns>
    /// <exception cref="ArgumentNullException">Thrown when the data access is null.</exception>
    public static ITrustUpdatePublisher Create(CertificateHandlerDataAccess dataAccess)
    {
        ArgumentNullException.ThrowIfNull(dataAccess);
        if (string.Equals(Environment.GetEnvironmentVariable("CH_USE_SIMULATED_TRUST_PUBLISHER"), "1", StringComparison.Ordinal))
        {
            return new SimulatedTrustUpdatePublisher();
        }

        return new DatabaseTrustEventPublisher(dataAccess.CreateDbContext());
    }

    #endregion
}
