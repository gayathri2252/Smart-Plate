﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Globalization;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using DataConstants = CertificateHandler.Data.Constants.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Gives the SBC and MIB certificate details with their expiry status, only to administrators. This service only reads. It never renews, replaces or deletes a certificate.
/// </summary>
public sealed class CertificateInformationService : ICertificateInformationService
{
    #region Member Variables

    /// <summary>
    /// Certificate roles shown on the certificate information page.
    /// </summary>
    private static readonly CertificateRole[] SHOWN_ROLES = { CertificateRole.LocalSbc, CertificateRole.LocalMib };

    /// <summary>
    /// Reads the active local certificates.
    /// </summary>
    private readonly ICertificateExpiryReader _reader;

    /// <summary>
    /// Checks if the user is an administrator.
    /// </summary>
    private readonly IAdministratorAuthorizer _authorizer;

    /// <summary>
    /// Works out the expiry status of the certificates.
    /// </summary>
    private readonly ICertificateExpiryStatusCalculator _calculator;

    /// <summary>
    /// Gives the current time.
    /// </summary>
    private readonly TimeProvider _timeProvider;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service with the system clock.
    /// </summary>
    /// <param name="reader">Reads the certificates from the store.</param>
    /// <param name="authorizer">Checks if the user is an administrator.</param>
    /// <param name="calculator">Works out the expiry status.</param>
    public CertificateInformationService(ICertificateExpiryReader reader, IAdministratorAuthorizer authorizer, ICertificateExpiryStatusCalculator calculator)
        : this(reader, authorizer, calculator, TimeProvider.System)
    {
    }

    /// <summary>
    /// Creates the service with the given parts.
    /// </summary>
    /// <param name="reader">Reads the certificates from the store.</param>
    /// <param name="authorizer">Checks if the user is an administrator.</param>
    /// <param name="calculator">Works out the expiry status.</param>
    /// <param name="timeProvider">Clock used to get the current time.</param>
    public CertificateInformationService(ICertificateExpiryReader reader, IAdministratorAuthorizer authorizer, ICertificateExpiryStatusCalculator calculator, TimeProvider timeProvider)
    {
        if (reader is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.SERVICE_READER_IS_NULL);
            throw new ArgumentNullException(nameof(reader));
        }

        if (authorizer is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.SERVICE_AUTHORIZER_IS_NULL);
            throw new ArgumentNullException(nameof(authorizer));
        }

        if (calculator is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.SERVICE_CALCULATOR_IS_NULL);
            throw new ArgumentNullException(nameof(calculator));
        }

        if (timeProvider is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.SERVICE_CLOCK_IS_NULL);
            throw new ArgumentNullException(nameof(timeProvider));
        }

        _reader = reader;
        _authorizer = authorizer;
        _calculator = calculator;
        _timeProvider = timeProvider;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Gives the certificate details and expiry status for the given administrator.
    /// </summary>
    /// <param name="callerUserName">User who asks for the certificate details.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The certificate details for the user.</returns>
    public async Task<CertificateInformationResult> GetCertificateInformationAsync(string? callerUserName,CancellationToken cancellationToken = default)
    {
        if (!_authorizer.IsAdministrator(callerUserName))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(),DataConstants.CALLER_NOT_AUTHORIZED,callerUserName ?? string.Empty);
            return new CertificateInformationResult { IsAuthorized = false };
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(),DataConstants.RETRIEVAL_STARTED,callerUserName!);
        IReadOnlyList<StoredCertificateInfo> stored;
        try
        {
            stored = await _reader.ReadActiveLocalCertificatesAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.RETRIEVAL_FAILED, ex.Message);
            throw;
        }

        DateTimeOffset now = _timeProvider.GetUtcNow();
        List<CertificateDetails> details = new();

        foreach (CertificateRole role in SHOWN_ROLES)
        {
            StoredCertificateInfo? certificate = stored.FirstOrDefault(c => c.Role == role);
            if (certificate is null)
            {
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataConstants.CERTIFICATE_NOT_FOUND, RoleName(role));
                details.Add(new CertificateDetails { Role = role, Status = CertificateExpiryStatus.NotAvailable });
                continue;
            }

            CertificateExpiryStatus status = _calculator.Calculate(certificate.NotAfter, now);
            string validUntil = certificate.NotAfter.UtcDateTime.ToString(DataConstants.DATE_FORMAT, CultureInfo.InvariantCulture);
            CertificateHandlerLogger.Information( MessageIdGenerator.Next(), DataConstants.CERTIFICATE_DETAILS, RoleName(role),certificate.Subject, validUntil,status.ToString());
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(),DataConstants.CERTIFICATE_ISSUER,RoleName(role),certificate.Issuer);

            if (status == CertificateExpiryStatus.Expired)
            {
                CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.CERTIFICATE_EXPIRED_ERROR, RoleName(role), validUntil);
            }
            else if (status != CertificateExpiryStatus.Valid)
            {
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataConstants.CERTIFICATE_STATUS_WARNING, RoleName(role), status.ToString(), validUntil);
            }

            details.Add(new CertificateDetails
            {
                Role = role,
                Subject = certificate.Subject,
                Issuer = certificate.Issuer,
                Thumbprint = certificate.Thumbprint,
                NotAfter = certificate.NotAfter,
                Status = status,
                PublicKeyAlgorithm = certificate.PublicKeyAlgorithm,
                PublicKeyPem = certificate.PublicKeyPem
            });
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(),DataConstants.RETRIEVAL_SUCCEEDED,stored.Count.ToString(CultureInfo.InvariantCulture));
        return new CertificateInformationResult { IsAuthorized = true, Certificates = details };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Gives the display name of the certificate role.
    /// </summary>
    /// <param name="role">The certificate role.</param>
    /// <returns>SBC or MIB.</returns>
    private static string RoleName(CertificateRole role) => role == CertificateRole.LocalSbc
         ? DataConstants.SBC_ROLE_NAME
         : DataConstants.MIB_ROLE_NAME;

    #endregion
}
