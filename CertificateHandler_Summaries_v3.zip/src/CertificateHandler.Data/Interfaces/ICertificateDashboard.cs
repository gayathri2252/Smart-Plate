// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access for the certificate dashboard.
/// </summary>
public interface ICertificateDashboard
{
    /// <summary>
    /// Gives the dashboard counts and the asked page of pending requests, newest first. Page numbers start at 1. A null filter shows every pending request.
    /// </summary>
    /// <param name="pageNumber">Number of the page to read.</param>
    /// <param name="pageSize">Number of requests on a page.</param>
    /// <param name="filter">Request type and search text to filter by, or null.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The counts and the page of requests.</returns>
    Task<DashboardPage> GetDashboardPageAsync(
        int pageNumber,
        int pageSize,
        DashboardRequestFilter? filter = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gives the active whitelist and blacklist entries, newest first. Entries that are not active are not given.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The whitelist and blacklist entries.</returns>
    Task<DashboardTrustLists> GetTrustListsAsync(CancellationToken cancellationToken = default);
}
