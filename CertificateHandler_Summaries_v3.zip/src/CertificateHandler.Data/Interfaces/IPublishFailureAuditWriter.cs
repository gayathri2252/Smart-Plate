﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes the audit row of a failed send in its own transaction.
/// </summary>
public interface IPublishFailureAuditWriter
{
    #region Public Methods

    /// <summary>
    /// Adds one audit row with the result FAILURE for the failed send.
    /// </summary>
    /// <param name="update">The trust update that failed.</param>
    /// <param name="error">The error that happened.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task WriteAsync(TrustUpdate update, Exception error, CancellationToken cancellationToken = default);

    #endregion
}
