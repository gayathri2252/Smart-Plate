// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Sends trust list notifications to peers. The real MAXUM communication will replace this.
/// </summary>
public interface IPeerNotificationChannel
{
    /// <summary>
    /// Sends the notification to the requesting device.
    /// </summary>
    /// <param name="notificationId">Id of the notification.</param>
    /// <param name="requestId">Id of the certificate request.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the notification was sent, otherwise false.</returns>
    Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default);
}
