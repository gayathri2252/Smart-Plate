// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Entities;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access for pending certificate requests.
/// </summary>
public interface ICertificatePendingRequest
{
    #region Public Methods

    /// <summary>
    /// Gets all requests that are pending now.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The pending requests.</returns>
    Task<List<PendingRequest>> GetPendingRequestsAsync(
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the pending requests that were created longer ago than the given timeout.
    /// </summary>
    /// <param name="timeoutHours">The timeout in hours.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The pending requests that are too old.</returns>
    Task<List<PendingRequest>> GetExpiredCertificateRequestsAsync(
        int timeoutHours,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Marks a request as expired, only if it is still pending. Returns false if it was already decided.
    /// </summary>
    /// <param name="requestId">Id of the request.</param>
    /// <param name="expiredAtUtc">Time when the request expired, in UTC.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the request was marked as expired, otherwise false.</returns>
    Task<bool> MarkAsExpiredAsync(
        Guid requestId,
        DateTimeOffset expiredAtUtc,
        CancellationToken cancellationToken = default);

    #endregion
}
