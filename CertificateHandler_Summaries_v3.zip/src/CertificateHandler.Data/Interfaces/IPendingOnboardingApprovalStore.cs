// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Approves or rejects pending peer onboarding requests and updates the whitelist, audit, events and notifications.
/// </summary>
public interface IPendingOnboardingApprovalStore
{
    #region Public Methods

    /// <summary>
    /// Checks the pending request and adds an active whitelist row when it is approved.
    /// </summary>
    /// <param name="decision">The decision of the administrator.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    /// <summary>
    /// Rejects the pending request with a reason that must be given and queues a notification for the peer.
    /// </summary>
    /// <param name="decision">The decision of the administrator.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    #endregion
}
