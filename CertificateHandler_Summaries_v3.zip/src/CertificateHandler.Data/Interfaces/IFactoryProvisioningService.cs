// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Saves the factory provisioning attempts.
/// </summary>
public interface IFactoryProvisioningService
{
    /// <summary>
    /// Saves the start of a factory provisioning attempt.
    /// </summary>
    /// <param name="deviceId">Id of the device.</param>
    /// <param name="targetRole">Role of the certificate to provision.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Id of the new attempt.</returns>
    Task<Guid> StartAttemptAsync(Guid deviceId, string targetRole, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves the result of a factory provisioning attempt.
    /// </summary>
    /// <param name="attemptId">Id of the attempt.</param>
    /// <param name="success">True if the provisioning worked.</param>
    /// <param name="certificateId">Id of the new certificate, or null if it failed.</param>
    /// <param name="error">Error message, or null if it worked.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task CompleteAttemptAsync(Guid attemptId, bool success, Guid? certificateId, string? error, CancellationToken cancellationToken = default);
}
