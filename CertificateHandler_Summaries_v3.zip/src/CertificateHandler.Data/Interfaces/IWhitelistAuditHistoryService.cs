// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Reads the whitelist audit history in the order it happened.
/// </summary>
public interface IWhitelistAuditHistoryService
{
    /// <summary>
    /// Reads the whitelist audit history.
    /// </summary>
    /// <param name="maxRows">Most rows to read.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The whitelist audit rows.</returns>
    Task<IReadOnlyList<WhitelistAuditEntry>> GetWhitelistHistoryAsync(
        int maxRows = 500,
        CancellationToken cancellationToken = default);
}
