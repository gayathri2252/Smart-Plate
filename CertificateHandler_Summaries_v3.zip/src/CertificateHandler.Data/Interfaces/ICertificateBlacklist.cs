// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Database access for the certificate blacklist.
/// </summary>
public interface ICertificateBlackList
{
    #region Public Methods

    /// <summary>
    /// Adds the thumbprint to the blacklist. It adds an active blacklist row or makes an older one active again, turns off any active whitelist row and writes one audit row, all in one transaction.
    /// </summary>
    /// <param name="request">The thumbprint, the reason and the user.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the blacklist change.</returns>
    Task<BlackListResponse> BlackListAsync(
        BlackListRequest request,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns true when the thumbprint has an active blacklist row.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the certificate is on the blacklist, otherwise false.</returns>
    Task<bool> IsBlackListedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default);

    #endregion
}
