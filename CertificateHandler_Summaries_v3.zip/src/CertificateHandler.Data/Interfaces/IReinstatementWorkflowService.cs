// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Steps of the reinstatement that needs two approvals.
/// </summary>
public interface IReinstatementWorkflowService
{
    /// <summary>
    /// Creates a pending reinstatement request for the certificate.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="requesterIdentity">Administrator who asks for the reinstatement.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Id of the new reinstatement request.</returns>
    Task<Guid> RequestReinstatementAsync(string thumbprintSha256, string requesterIdentity, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves an approval or a rejection of the reinstatement request.
    /// </summary>
    /// <param name="requestId">Id of the request.</param>
    /// <param name="approverIdentity">User who makes the decision.</param>
    /// <param name="approved">True to approve, false to reject.</param>
    /// <param name="comments">Comments of the user, or null if none.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task RecordApprovalAsync(Guid requestId, string approverIdentity, bool approved, string? comments, CancellationToken cancellationToken = default);

    /// <summary>
    /// Finishes the reinstatement after two approvals.
    /// </summary>
    /// <param name="requestId">Id of the request.</param>
    /// <param name="actorIdentity">Administrator who finishes the reinstatement.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task CompleteReinstatementAsync(Guid requestId, string actorIdentity, CancellationToken cancellationToken = default);
}
