// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Adds many certificates to the blacklist at once.
/// </summary>
public interface IBulkBlacklistService
{
    /// <summary>
    /// Adds the selected certificates to the blacklist and saves the bulk operation.
    /// </summary>
    /// <param name="request">The thumbprints, the reason and the user who started it.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The bulk operation id and the result of each certificate.</returns>
    Task<BulkBlacklistResponse> ExecuteAsync(BulkBlacklistRequest request, CancellationToken cancellationToken = default);
}
