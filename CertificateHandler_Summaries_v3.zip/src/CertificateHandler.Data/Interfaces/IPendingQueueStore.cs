﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Stores the open requests of unknown peers and keeps their number within a limit.
/// </summary>
public interface IPendingQueueStore
{
    #region Public Methods

    /// <summary>
    /// Gives the number of open requests made for peers that connected.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Number of open peer requests.</returns>
    Task<int> CountOpenPeerRequestsAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Adds an open request for the peer unless its certificate already has one or the queue is full.
    /// The check and the insert run as one step, so two peers that connect at the same time cannot both take the last place.
    /// </summary>
    /// <param name="request">The peer onboarding request.</param>
    /// <param name="maxOpenRequests">Most open requests allowed.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A result that says if the request was added, already exists or was refused because the queue is full.</returns>
    Task<PendingQueueAddResult> TryAddPeerRequestAsync(
        PeerOnboardingRequest request,
        int maxOpenRequests,
        CancellationToken cancellationToken = default);

    #endregion
}
