﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Sends a saved trust change to the rest of the system.
/// </summary>
public interface ITrustUpdatePublisher
{
    #region Public Methods

    /// <summary>
    /// Sends the trust update. Throws when sending fails.
    /// </summary>
    /// <param name="update">The trust update to send.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default);

    #endregion
}
