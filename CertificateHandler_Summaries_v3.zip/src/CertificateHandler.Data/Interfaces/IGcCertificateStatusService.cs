// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Gives the SBC and MIB certificate expiry details for MCC.
/// </summary>
public interface IGcCertificateStatusService
{
    /// <summary>
    /// Gets the status of the SBC and MIB certificates of the GC for an administrator.
    /// </summary>
    /// <param name="administratorUserName">User name of the administrator.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The status of the SBC and MIB certificates.</returns>
    Task<GcCertificateStatusSnapshot> GetSnapshotForAdministratorAsync(
        string? administratorUserName,
        CancellationToken cancellationToken = default);
}
