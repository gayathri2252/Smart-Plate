// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Result of the commissioning check.
/// </summary>
public sealed class CommissioningHaltResult
{
    /// <summary>
    /// True when commissioning must stop.
    /// </summary>
    public bool ShouldHalt { get; init; }

    /// <summary>
    /// Message that says why commissioning stops.
    /// </summary>
    public string Message { get; init; } = string.Empty;

    /// <summary>
    /// Creates a result that lets commissioning go on.
    /// </summary>
    /// <returns>A result that lets commissioning go on.</returns>
    public static CommissioningHaltResult Continue() => new() { ShouldHalt = false };

    /// <summary>
    /// Creates a result that stops commissioning.
    /// </summary>
    /// <param name="message">Message that says why commissioning stops.</param>
    /// <returns>A result that stops commissioning.</returns>
    public static CommissioningHaltResult Halt(string message) =>
        new() { ShouldHalt = true, Message = message };
}

/// <summary>
/// Checks if commissioning can go on.
/// </summary>
public interface ICommissioningGateService
{
    /// <summary>
    /// Checks if commissioning can go on.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A result that says if commissioning goes on or stops.</returns>
    Task<CommissioningHaltResult> EvaluateAsync(CancellationToken cancellationToken = default);
}
