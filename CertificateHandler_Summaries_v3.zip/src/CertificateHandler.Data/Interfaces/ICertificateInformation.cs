﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Decides if a user can see certificate information.
/// </summary>
public interface IAdministratorAuthorizer
{
    /// <summary>
    /// Returns true only when the given user name belongs to an administrator. A null or empty name is never allowed.
    /// </summary>
    /// <param name="userName">The user name to check.</param>
    /// <returns>True if the user is an administrator, otherwise false.</returns>
    bool IsAdministrator(string? userName);
}

/// <summary>
/// Reads the saved details of the active local certificates. It only reads.
/// </summary>
public interface ICertificateExpiryReader
{
    /// <summary>
    /// Gives the active local SBC and MIB certificates. A role without an active certificate is not in the result.
    /// When a role has more than one active certificate, the one that expires last is given.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The active local certificates.</returns>
    Task<IReadOnlyList<StoredCertificateInfo>> ReadActiveLocalCertificatesAsync(
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Calculates the expiry status of a certificate.
/// </summary>
public interface ICertificateExpiryStatusCalculator
{
    /// <summary>
    /// Gives Expired when now is after the end date, NearingExpiration when the end date is inside the warning window, and Valid in all other cases.
    /// </summary>
    /// <param name="notAfter">End date of the certificate.</param>
    /// <param name="now">The current time.</param>
    /// <returns>The expiry status.</returns>
    CertificateExpiryStatus Calculate(DateTimeOffset notAfter, DateTimeOffset now);
}

/// <summary>
/// Gives the SBC and MIB certificate information to an administrator.
/// </summary>
public interface ICertificateInformationService
{
    /// <summary>
    /// Gives the SBC and MIB certificate details for the given user. A user who is not an administrator gets IsAuthorized false and no certificate details.
    /// </summary>
    /// <param name="callerUserName">User who asks for the details.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The certificate information result.</returns>
    Task<CertificateInformationResult> GetCertificateInformationAsync(
        string? callerUserName,
        CancellationToken cancellationToken = default);
}
