// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Sends trust events to the subscribers in the device.
/// </summary>
public interface IInDeviceTrustSubscriberChannel
{
    /// <summary>
    /// Sends the trust event to a subscriber in the device.
    /// </summary>
    /// <param name="eventId">Id of the trust event.</param>
    /// <param name="subscriberName">Name of the subscriber.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the event was sent, otherwise false.</returns>
    Task<bool> TryDeliverAsync(Guid eventId, string subscriberName, CancellationToken cancellationToken = default);
}
