﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Runs the publish step after a trust row was saved and handles its failure.
/// </summary>
public interface ITrustUpdatePublishService
{
    #region Public Methods

    /// <summary>
    /// Sends the update. When sending fails, it writes the log, the audit row and the administrator message and returns the result.
    /// It does not throw and never changes the saved trust row.
    /// </summary>
    /// <param name="update">Trust update that is already saved.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the send.</returns>
    Task<PublishResult> PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default);

    #endregion
}
