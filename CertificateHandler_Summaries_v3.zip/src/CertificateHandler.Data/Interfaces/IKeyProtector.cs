// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Protects and unprotects the database key, so the key file cannot be used on another computer. The real version uses Windows DPAPI.
/// </summary>
public interface IKeyProtector
{
    #region Public Methods

    /// <summary>
    /// Protects the data. The protected bytes can only be read by the same protector on the same computer.
    /// </summary>
    /// <param name="data">The data to protect.</param>
    /// <returns>The protected bytes.</returns>
    byte[] Protect(byte[] data);

    /// <summary>
    /// Unprotects the bytes given by Protect. Throws CryptographicException when they cannot be read here.
    /// </summary>
    /// <param name="protectedData">The protected bytes.</param>
    /// <returns>The original data.</returns>
    byte[] Unprotect(byte[] protectedData);

    #endregion
}
