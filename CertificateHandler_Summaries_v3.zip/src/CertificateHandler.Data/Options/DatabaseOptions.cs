﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.RegularExpressions;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Security;

namespace CertificateHandler.Data.Options;

/// <summary>
/// Connection and security settings for the Certificate Handler PostgreSQL database.
/// </summary>
public sealed partial class DatabaseOptions
{
    #region Member Variables

    /// <summary>
    /// Name of the settings section for the database.
    /// </summary>
    public const string SectionName = "CertificateHandler:Database";

    #endregion

    #region Public Properties

    /// <summary>
    /// Host name of the database server.
    /// </summary>
    public string Host { get; set; } = "localhost";

    /// <summary>
    /// Port of the database server.
    /// </summary>
    public int Port { get; set; } = 5432;

    /// <summary>
    /// Name of the product database. It is fixed and cannot be changed.
    /// </summary>
    public static string Database => DatabaseConstants.DatabaseName;

    /// <summary>
    /// Database user of the application. The application creates it and sets its password.
    /// </summary>
    public string Username { get; set; } = DatabaseConstants.DEFAULT_APPLICATION_USERNAME;

    /// <summary>
    /// PostgreSQL administrator account, used only to create or repair the database. Its password comes from an environment variable.
    /// </summary>
    public string AdminUsername { get; set; } = DatabaseConstants.DEFAULT_ADMIN_USERNAME;

    /// <summary>
    /// Folder of the sealed password of the database user. Leave empty to use the default folder
    /// under the common application data folder.
    /// </summary>
    public string SecretDirectoryPath { get; set; } = string.Empty;

    /// <summary>
    /// Plain password used as a fallback. Not advised on the device. Use the password environment variable or the DPAPI protected password instead.
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// Optional DPAPI protected password in Base64. The environment variable is preferred over this property.
    /// </summary>
    public string ProtectedPassword { get; set; } = string.Empty;

    /// <summary>
    /// True when TLS is used for the database connection.
    /// </summary>
    public bool SslMode { get; set; }

    /// <summary>
    /// When true, only the local host is allowed. This is the default for IoT devices.
    /// </summary>
    public bool RequireLocalHost { get; set; } = true;

    /// <summary>
    /// When true, startup skips creating the database and applying the schema, for tests or offline use.
    /// </summary>
    public bool SkipBootstrap { get; set; }

    /// <summary>
    /// Display name or subject CN of the client certificate used for mutual TLS. Leave empty to connect without a client certificate.
    /// </summary>
    public string ClientCertificateName { get; set; } = string.Empty;

    /// <summary>
    /// True when a client certificate is configured, so the connection uses mutual TLS.
    /// </summary>
    public bool UsesClientCertificate => !string.IsNullOrWhiteSpace(ClientCertificateName);

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks the port, user name, host, SSL mode and client certificate setting. Throws InvalidOperationException when a value is not allowed.
    /// </summary>
    public void Validate()
    {
        if (Port is < 1 or > 65535)
        {
            throw new InvalidOperationException("Database port is out of range.");
        }

        if (!UsernamePattern().IsMatch(Username))
        {
            throw new InvalidOperationException("Database username contains invalid characters.");
        }

        if (!UsernamePattern().IsMatch(AdminUsername ?? string.Empty))
        {
            throw new InvalidOperationException("Database administrator username contains invalid characters.");
        }

        if (RequireLocalHost && !IsLocalHost(Host))
        {
            throw new InvalidOperationException(
                "Database host must be localhost unless RequireLocalHost is disabled.");
        }

        if (!SslMode && !IsLocalHost(Host))
        {
            throw new InvalidOperationException("Non-local database connections require SslMode.");
        }
        if (UsesClientCertificate && !SslMode)
        {
            throw new InvalidOperationException("A client certificate requires SslMode to be enabled.");
        }
    }

    /// <summary>
    /// Gives the folder of the protected password, or the default folder when none is set.
    /// </summary>
    /// <returns>The folder path.</returns>
    public string ResolveSecretDirectory()
    {
        if (!string.IsNullOrWhiteSpace(SecretDirectoryPath))
        {
            return SecretDirectoryPath;
        }

        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "Valmet",
            "CertificateHandler",
            "Database");
    }

    /// <summary>
    /// Builds a connection string for one use, without pooling, for the given database, user and password. Used to set up the database with the administrator account.
    /// </summary>
    /// <param name="database">Name of the database.</param>
    /// <param name="username">Database user name.</param>
    /// <param name="password">Database password.</param>
    /// <returns>The connection string.</returns>
    public string BuildSetupConnectionString(string database, string username, string password)
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder(CreateConnectionString(database, username, password))
        {
            Pooling = false
        };
        return builder.ConnectionString;
    }

    /// <summary>
    /// Builds the app connection string from these settings.
    /// </summary>
    /// <returns>The connection string.</returns>
    public string BuildConnectionString()
    {
        return CreateConnectionString(Database, Username, ResolvePasswordFromEnvironmentOrConfig());
    }

    /// <summary>
    /// Builds the administrator connection string used to set up the database.
    /// </summary>
    /// <returns>The connection string.</returns>
    public string BuildAdminConnectionString()
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder(BuildConnectionString())
        {
            Database = DatabaseConstants.AdminDatabaseName
        };
        return builder.ConnectionString;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds a connection string for the given database, user and password with these settings.
    /// </summary>
    /// <param name="database">Name of the database.</param>
    /// <param name="username">Database user name.</param>
    /// <param name="password">Database password.</param>
    /// <returns>The connection string.</returns>
    private string CreateConnectionString(string database, string username, string password)
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder
        {
            Host = Host,
            Port = Port,
            Database = database,
            Username = username,
            Password = password,
            IncludeErrorDetail = false,
            MaxPoolSize = DatabaseConstants.MaxPoolSize,
            Timeout = DatabaseConstants.ConnectionTimeoutSeconds,
            CommandTimeout = DatabaseConstants.CommandTimeoutSeconds,
            Options = $"-c search_path={DatabaseConstants.SchemaName},public"
        };

        builder.SslMode = SslMode ? Npgsql.SslMode.Require : Npgsql.SslMode.Disable;

        return builder.ConnectionString;
    }

    /// <summary>
    /// Gives the password from the password environment variable. Uses the configured Password when the variable is not set.
    /// </summary>
    /// <returns>The database password.</returns>
    private string ResolvePasswordFromEnvironmentOrConfig()
    {
        string? plain = Environment.GetEnvironmentVariable(DatabaseConstants.PasswordEnvironmentVariable);
        if (!string.IsNullOrEmpty(plain))
        {
            return plain;
        }

        string? protectedEnv = Environment.GetEnvironmentVariable(DatabasePasswordProtector.ProtectedPasswordEnvironmentVariable);
        if (DatabasePasswordProtector.TryUnprotectFromBase64(protectedEnv, out string fromEnv))
        {
            return fromEnv;
        }

        if (DatabasePasswordProtector.TryUnprotectFromBase64(ProtectedPassword, out string fromConfig))
        {
            return fromConfig;
        }

        return Password;
    }

    /// <summary>
    /// Returns true when the host is the local computer.
    /// </summary>
    /// <param name="host">The host name.</param>
    /// <returns>True if the host is local, otherwise false.</returns>
    private static bool IsLocalHost(string host)
    {
        if (string.IsNullOrWhiteSpace(host))
        {
            return false;
        }

        return host.Equals("localhost", StringComparison.OrdinalIgnoreCase)
            || host == "127.0.0.1"
            || host == "::1";
    }

    /// <summary>
    /// Pattern that a valid database user name must match.
    /// </summary>
    /// <returns>The pattern for the user name.</returns>
    [GeneratedRegex("^[a-zA-Z_][a-zA-Z0-9_.$-]{0,62}$", RegexOptions.CultureInvariant)]
    private static partial Regex UsernamePattern();

    #endregion
}