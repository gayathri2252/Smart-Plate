﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// How an attempt to put an unknown peer in the pending queue ended.
/// </summary>
public enum PendingQueueAddOutcome
{
    /// <summary>A new request was added. The peer waits for an administrator decision.</summary>
    Added,

    /// <summary>The certificate already has an open request, so nothing was added.</summary>
    AlreadyPending,

    /// <summary>The queue already holds the most open requests allowed, so nothing was added.</summary>
    QueueFull
}

/// <summary>
/// Result of an attempt to put an unknown peer in the pending queue.
/// </summary>
public sealed class PendingQueueAddResult
{
    #region Public Properties

    /// <summary>How the attempt ended.</summary>
    public PendingQueueAddOutcome Outcome { get; init; }

    /// <summary>Id of the new request, or null when nothing was added.</summary>
    public Guid? RequestId { get; init; }

    /// <summary>Number of open peer requests found before the attempt.</summary>
    public int OpenRequestCount { get; init; }

    #endregion
}
