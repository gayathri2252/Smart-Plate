﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;

namespace CertificateHandler.Data.Models;

/// <summary>
/// The certificate and device details of an unknown peer, used to put it in the pending queue.
/// </summary>
public sealed class PeerOnboardingRequest
{
    #region Public Properties

    /// <summary>SHA256 thumbprint of the peer certificate, as 64 hex characters.</summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>Subject of the peer certificate.</summary>
    public string SubjectDn { get; set; } = string.Empty;

    /// <summary>Issuer of the peer certificate.</summary>
    public string IssuerDn { get; set; } = string.Empty;

    /// <summary>Serial number of the peer certificate, or null when it is not known.</summary>
    public string? SerialNumber { get; set; }

    /// <summary>Date from which the certificate is valid, in UTC.</summary>
    public DateTimeOffset NotBefore { get; set; }

    /// <summary>Date until which the certificate is valid, in UTC.</summary>
    public DateTimeOffset NotAfter { get; set; }

    /// <summary>Id of the peer device, like its name. It is saved as the device code.</summary>
    public string DeviceCode { get; set; } = string.Empty;

    /// <summary>IP address of the peer MAXUM, or null when it is not known.</summary>
    public string? MaxumIp { get; set; }

    /// <summary>Who made the request. It is the system for a peer that connects.</summary>
    public string RequestedBy { get; set; } = DatabaseConstants.SystemActor;

    /// <summary>Id of the refused connection, so the request can be matched to the connection log.</summary>
    public Guid? ConnectionCorrelationId { get; set; }

    /// <summary>Time when the request expires if nobody decides on it, in UTC.</summary>
    public DateTimeOffset ExpiresAt { get; set; }

    /// <summary>The certificate sent by the peer in DER format, used to check it again later.</summary>
    public byte[]? PresentedCertificateDer { get; set; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates the request from the certificate a peer sent in its certificate request.
    /// </summary>
    /// <param name="certificate">Peer certificate. Must not be null.</param>
    /// <param name="deviceCode">Id of the peer device. Must not be empty.</param>
    /// <param name="maxumIp">IP address of the peer, or null when it is not known.</param>
    /// <returns>The request, without an expiry time.</returns>
    public static PeerOnboardingRequest FromCertificate(X509Certificate2 certificate, string deviceCode, string? maxumIp)
    {
        ArgumentNullException.ThrowIfNull(certificate);
        ArgumentException.ThrowIfNullOrWhiteSpace(deviceCode);

        return new PeerOnboardingRequest
        {
            ThumbprintSha256 = certificate.GetCertHashString(HashAlgorithmName.SHA256),
            SubjectDn = certificate.Subject,
            IssuerDn = certificate.Issuer,
            SerialNumber = certificate.SerialNumber,
            NotBefore = new DateTimeOffset(certificate.NotBefore.ToUniversalTime(), TimeSpan.Zero),
            NotAfter = new DateTimeOffset(certificate.NotAfter.ToUniversalTime(), TimeSpan.Zero),
            DeviceCode = deviceCode.Trim(),
            MaxumIp = string.IsNullOrWhiteSpace(maxumIp) ? null : maxumIp.Trim(),
            PresentedCertificateDer = certificate.RawData
        };
    }

    #endregion
}
