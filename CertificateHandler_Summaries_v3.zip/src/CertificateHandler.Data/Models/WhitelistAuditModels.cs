// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// One whitelist audit row for the history views.
/// </summary>
public sealed class WhitelistAuditEntry
{
    /// <summary>
    /// Id of the audit row.
    /// </summary>
    public long AuditId { get; init; }

    /// <summary>
    /// Time of the event.
    /// </summary>
    public DateTimeOffset EventTimestamp { get; init; }

    /// <summary>
    /// Type of the event.
    /// </summary>
    public string EventType { get; init; } = string.Empty;

    /// <summary>
    /// User who did the action.
    /// </summary>
    public string ActorIdentity { get; init; } = string.Empty;

    /// <summary>
    /// Id of the request.
    /// </summary>
    public Guid? RequestId { get; init; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string? ThumbprintSha256 { get; init; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid? DeviceId { get; init; }

    /// <summary>
    /// Status before the action.
    /// </summary>
    public string? PreviousStatus { get; init; }

    /// <summary>
    /// Status after the action.
    /// </summary>
    public string? NewStatus { get; init; }

    /// <summary>
    /// Status of the action.
    /// </summary>
    public string? ActionStatus { get; init; }

    /// <summary>
    /// Reason for the action.
    /// </summary>
    public string? Reason { get; init; }
}
