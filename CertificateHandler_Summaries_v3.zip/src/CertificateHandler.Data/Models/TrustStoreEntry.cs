// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// One row of the encrypted local trust store, a certificate on the whitelist, the blacklist or the pending list. Times are saved and given in UTC.
/// </summary>
public sealed class TrustStoreEntry
{
    #region Public Properties

    /// <summary>SHA256 thumbprint as 64 hex characters. It is the unique lookup key.</summary>
    public string Thumbprint { get; set; } = string.Empty;

    /// <summary>The list the certificate is on.</summary>
    public TrustListType ListType { get; set; }

    /// <summary>Subject name of the certificate.</summary>
    public string SubjectDistinguishedName { get; set; } = string.Empty;

    /// <summary>Serial number of the certificate.</summary>
    public string SerialNumber { get; set; } = string.Empty;

    /// <summary>Date from which the certificate is valid.</summary>
    public DateTimeOffset NotBefore { get; set; }

    /// <summary>Date until which the certificate is valid.</summary>
    public DateTimeOffset NotAfter { get; set; }

    /// <summary>User or part of the app that added the row.</summary>
    public string AddedBy { get; set; } = string.Empty;

    /// <summary>Time the row was added, in UTC.</summary>
    public DateTimeOffset AddedAt { get; set; }

    /// <summary>Optional comment of the user who added the row.</summary>
    public string? Comment { get; set; }

    /// <summary>True when the row is in use. A row that is not active is kept but not given as active.</summary>
    public bool IsActive { get; set; } = true;

    #endregion
}
