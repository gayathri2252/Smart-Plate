// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// Input to add one thumbprint to the blacklist after a security failure.
/// </summary>
public sealed class BlackListRequest
{
    #region Public Properties

    /// <summary>
    /// SHA256 thumbprint of the failed certificate, 64 hex characters in any case.
    /// </summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>
    /// Why the thumbprint is added to the blacklist.
    /// </summary>
    public BlacklistReasonClass ReasonClass { get; set; }

    /// <summary>
    /// Details from the trust engine, saved as the reason in the audit row.
    /// </summary>
    public string Reason { get; set; } = string.Empty;

    /// <summary>
    /// Time when the trust engine finished, in UTC.
    /// </summary>
    public DateTimeOffset EvaluatedAt { get; set; } = DateTimeOffset.UtcNow;

    /// <summary>
    /// Part of the app that found the failure. It is saved in the audit row.
    /// </summary>
    public string SourceComponent { get; set; } = DatabaseConstants.DEFAULT_SOURCE_COMPONENT;

    #endregion
}