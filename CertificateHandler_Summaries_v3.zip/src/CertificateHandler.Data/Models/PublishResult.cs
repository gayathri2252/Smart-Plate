﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// Result of the send step. The send step never throws, so the caller reads this instead.
/// </summary>
public sealed class PublishResult
{
    #region Public Properties

    /// <summary>True when the trust update was sent.</summary>
    public bool Published { get; init; }

    /// <summary>True when the audit row of the failure was written. False when nothing failed.</summary>
    public bool AuditWritten { get; init; }

    /// <summary>True when the administrator was told. False when nothing failed.</summary>
    public bool AdministratorNotified { get; init; }

    /// <summary>The error of the failed send, or null when it worked.</summary>
    public Exception? Error { get; init; }

    #endregion
}
