// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// A request to add many certificates to the blacklist.
/// </summary>
public sealed class BulkBlacklistRequest
{
    /// <summary>
    /// Administrator who starts the operation.
    /// </summary>
    public string ActorIdentity { get; init; } = string.Empty;

    /// <summary>
    /// Reason for adding the certificates to the blacklist.
    /// </summary>
    public string Reason { get; init; } = string.Empty;

    /// <summary>
    /// SHA256 thumbprints of the certificates to add.
    /// </summary>
    public IReadOnlyList<string> ThumbprintsSha256 { get; init; } = Array.Empty<string>();
}

/// <summary>
/// Result for one certificate in a bulk blacklist operation.
/// </summary>
public sealed class BulkBlacklistItemResult
{
    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string ThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>
    /// True if the certificate was added to the blacklist.
    /// </summary>
    public bool Succeeded { get; init; }

    /// <summary>
    /// Error message when the certificate could not be added.
    /// </summary>
    public string? Error { get; init; }
}

/// <summary>
/// Response of a bulk blacklist operation.
/// </summary>
public sealed class BulkBlacklistResponse
{
    /// <summary>
    /// Id of the bulk operation.
    /// </summary>
    public Guid BulkOperationId { get; init; }

    /// <summary>
    /// Results of the certificates in the operation.
    /// </summary>
    public IReadOnlyList<BulkBlacklistItemResult> Items { get; init; } = Array.Empty<BulkBlacklistItemResult>();
}
