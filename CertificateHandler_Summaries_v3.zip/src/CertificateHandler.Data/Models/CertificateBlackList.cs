// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// What happened when a thumbprint was added to the blacklist.
/// </summary>
public enum CertificateBlackList
{
    /// <summary>
    /// A new active blacklist row was inserted.
    /// </summary>
    Added = 1,

    /// <summary>
    /// An older blacklist row that was turned off was made active again.
    /// </summary>
    Reactivated = 2,

    /// <summary>
    /// The thumbprint was already on the blacklist, so nothing changed in the list.
    /// </summary>
    AlreadyBlackListed = 3,

    /// <summary>
    /// No certificate with this thumbprint exists, so no row could be written.
    /// </summary>
    CertificateNotFound = 4
}
