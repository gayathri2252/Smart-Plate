﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// Saved details of one active local certificate, as read from the database.
/// </summary>
public sealed record StoredCertificateInfo
{
    #region Public Properties

    /// <summary>Role of the certificate, local SBC or local MIB.</summary>
    public CertificateRole Role { get; init; }

    /// <summary>Subject name of the certificate.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>Issuer name of the certificate.</summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>SHA256 thumbprint of the certificate.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>Date until which the certificate is valid.</summary>
    public DateTimeOffset NotAfter { get; init; }

    /// <summary>Type of the public key, when it is saved.</summary>
    public string PublicKeyAlgorithm { get; init; } = string.Empty;

    /// <summary>The public key in PEM format, when it is saved.</summary>
    public string PublicKeyPem { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Certificate details shown on the read only certificate view, with the calculated status.
/// </summary>
public sealed record CertificateDetails
{
    #region Public Properties

    /// <summary>Role of the certificate, local SBC or local MIB.</summary>
    public CertificateRole Role { get; init; }

    /// <summary>Subject name of the certificate. Empty when no certificate was found.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>Issuer name of the certificate. Empty when no certificate was found.</summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>SHA256 thumbprint of the certificate. Empty when no certificate was found.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>Date until which the certificate is valid. Null when no certificate was found.</summary>
    public DateTimeOffset? NotAfter { get; init; }

    /// <summary>Expiry status worked out from the end date and the current time.</summary>
    public CertificateExpiryStatus Status { get; init; }

    /// <summary>Type of the public key. Empty when no certificate was found.</summary>
    public string PublicKeyAlgorithm { get; init; } = string.Empty;

    /// <summary>The public key in PEM format. Empty when no certificate was found.</summary>
    public string PublicKeyPem { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Result of a certificate information request. A user who is not allowed gets no certificate details.
/// </summary>
public sealed record CertificateInformationResult
{
    #region Public Properties

    /// <summary>True when the user is an allowed administrator.</summary>
    public bool IsAuthorized { get; init; }

    /// <summary>The SBC and MIB certificate details. Empty when the user is not allowed.</summary>
    public IReadOnlyList<CertificateDetails> Certificates { get; init; } = Array.Empty<CertificateDetails>();

    #endregion
}
