﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// A trust change that is already saved and now has to be sent.
/// </summary>
public sealed class TrustUpdate
{
    #region Public Properties

    /// <summary>SHA256 thumbprint of the certificate whose trust row was saved.</summary>
    public string ThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>Certificate row the trust row belongs to, or null when it is not known.</summary>
    public Guid? CertificateId { get; init; }

    /// <summary>What the save step did, like Added or Reactivated.</summary>
    public string Change { get; init; } = string.Empty;

    /// <summary>Why the trust row was changed.</summary>
    public string Reason { get; init; } = string.Empty;

    /// <summary>Time when the trust row was saved, in UTC.</summary>
    public DateTimeOffset SavedAt { get; init; } = DateTimeOffset.UtcNow;

    #endregion
}
