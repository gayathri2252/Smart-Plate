// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using DataConstants = CertificateHandler.Data.Constants.Constants;

namespace CertificateHandler.Data.Models;

/// <summary>
/// The numbers shown on the dashboard cards, counted over all rows and not only the visible page. The 90 day count also has the certificates in the 30 day count.
/// </summary>
public sealed class DashboardCounts
{
    #region Public Properties

    /// <summary>Active whitelist entries.</summary>
    public long Whitelisted { get; init; }

    /// <summary>Active blacklist entries.</summary>
    public long Blacklisted { get; init; }

    /// <summary>Requests that are waiting for a decision.</summary>
    public long Pending { get; init; }

    /// <summary>Active local certificates, SBC, MIB and GCP application, whose end date has passed.</summary>
    public long Expired { get; init; }

    /// <summary>Number of managed certificates, each active trust list or local certificate thumbprint counted once.</summary>
    public long Total { get; init; }

    /// <summary>Active local certificates that are still valid and expire within 30 days from now.</summary>
    public long ExpiringWithin30Days { get; init; }

    /// <summary>Active local certificates that are still valid and expire within 90 days from now.</summary>
    public long ExpiringWithin90Days { get; init; }

    /// <summary>Failed validations in the validation log inside the set time window.</summary>
    public long ValidationFailures { get; init; }

    /// <summary>Length in hours of the window used for the validation failure count.</summary>
    public int ValidationFailureWindowHours { get; init; } = DataConstants.DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS;

    #endregion
}

/// <summary>
/// One pending request shown in the request queue overview, read from the saved columns only.
/// </summary>
public sealed class DashboardRequestRow
{
    #region Public Properties

    /// <summary>Id of the request.</summary>
    public Guid RequestId { get; init; }

    /// <summary>Device name, or the device code when the device has no name.</summary>
    public string DeviceIdentifier { get; init; } = string.Empty;

    /// <summary>Display name of the request type, like Peer onboarding.</summary>
    public string RequestType { get; init; } = string.Empty;

    /// <summary>Who made the request.</summary>
    public string RequestedBy { get; init; } = string.Empty;

    /// <summary>Time when the request was made, in UTC.</summary>
    public DateTimeOffset RequestDate { get; init; }

    /// <summary>MAXUM IP address of the device. Empty when the device has none.</summary>
    public string MaxumIp { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Column the request queue overview is sorted by.
/// </summary>
public enum DashboardSortColumn
{
    /// <summary>When the request was made.</summary>
    RequestDate,

    /// <summary>Device name, or the device code when the device has no name.</summary>
    DeviceName,

    /// <summary>MAXUM IP address of the device.</summary>
    IpAddress,

    /// <summary>Type of the request.</summary>
    RequestType,

    /// <summary>Who made the request.</summary>
    RequestedBy
}

/// <summary>
/// Filters and orders the request queue overview. An empty filter shows every pending request, newest first.
/// </summary>
public sealed class DashboardRequestFilter
{
    #region Public Properties

    /// <summary>Text matched against the device name, the device code and the MAXUM IP address.</summary>
    public string SearchText { get; init; } = string.Empty;

    /// <summary>Request type to show, or null to show every type.</summary>
    public PendingRequestType? RequestType { get; init; }

    /// <summary>Column the rows are sorted by. The default is the request date.</summary>
    public DashboardSortColumn SortColumn { get; init; } = DashboardSortColumn.RequestDate;

    /// <summary>True to sort from the highest value down. The default is newest first.</summary>
    public bool SortDescending { get; init; } = true;

    #endregion
}

/// <summary>
/// The counts and one page of requests given by one dashboard load.
/// </summary>
public sealed class DashboardPage
{
    #region Public Properties

    /// <summary>Counts over all rows, not only this page.</summary>
    public DashboardCounts Counts { get; init; } = new();

    /// <summary>The requests of this page, newest first.</summary>
    public IReadOnlyList<DashboardRequestRow> Rows { get; init; } = Array.Empty<DashboardRequestRow>();

    /// <summary>Number of this page, starting at 1.</summary>
    public int PageNumber { get; init; } = DataConstants.FIRST_PAGE_NUMBER;

    /// <summary>Most rows on a page.</summary>
    public int PageSize { get; init; } = DataConstants.DEFAULT_PAGE_SIZE;

    /// <summary>Number of pending requests that match the filter, over all pages.</summary>
    public long MatchingRequests { get; init; }

    /// <summary>
    /// Number of pages needed for the matching requests. It is at least 1, so an empty overview still shows page 1 of 1.
    /// </summary>
    public int TotalPages
    {
        get
        {
            int pageSize = Math.Max(PageSize, DataConstants.MIN_PAGE_SIZE);
            int pages = (int)Math.Ceiling((double)MatchingRequests / pageSize);
            return Math.Max(pages, DataConstants.FIRST_PAGE_NUMBER);
        }
    }

    #endregion
}

/// <summary>
/// One active whitelist or blacklist entry shown on the dashboard, read from the saved columns only.
/// </summary>
public sealed class DashboardTrustListRow
{
    #region Public Properties

    /// <summary>Id of the trust list entry.</summary>
    public long EntryId { get; init; }

    /// <summary>Device name, or the device code when the device has no name. Empty when no device is linked.</summary>
    public string DeviceIdentifier { get; init; } = string.Empty;

    /// <summary>Subject of the certificate.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>SHA256 thumbprint of the certificate.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>Comment of the entry, or the blacklist reason type when there is no comment. Can be empty.</summary>
    public string Reason { get; init; } = string.Empty;

    /// <summary>Who added the entry.</summary>
    public string AddedBy { get; init; } = string.Empty;

    /// <summary>Time when the entry was added, in UTC.</summary>
    public DateTimeOffset AddedAt { get; init; }

    /// <summary>MAXUM IP address of the device. Empty when the device has none.</summary>
    public string MaxumIp { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// The active whitelist and blacklist entries given by one dashboard load, each newest first.
/// </summary>
public sealed class DashboardTrustLists
{
    #region Public Properties

    /// <summary>Active whitelist entries, newest first.</summary>
    public IReadOnlyList<DashboardTrustListRow> Whitelisted { get; init; } = Array.Empty<DashboardTrustListRow>();

    /// <summary>Active blacklist entries, newest first.</summary>
    public IReadOnlyList<DashboardTrustListRow> Blacklisted { get; init; } = Array.Empty<DashboardTrustListRow>();

    #endregion
}
