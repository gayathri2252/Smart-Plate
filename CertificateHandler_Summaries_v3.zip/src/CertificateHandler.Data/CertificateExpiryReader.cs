// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using DataConstants = CertificateHandler.Data.Constants.Constants;
using Npgsql;
using CertificateHandler.Data.Infrastructure;

namespace CertificateHandler.Data;

/// <summary>
/// Reads the active local SBC and MIB certificates from the certificate table. It only reads with one SELECT and never changes the certificate store or the database.
/// </summary>
public sealed class CertificateExpiryReader : ICertificateExpiryReader
{
    #region Member Variables

    /// <summary>
    /// One row for each role, the active certificate that expires last. It reads saved columns only, so no certificate chain is built.
    /// </summary>
    private const string ACTIVE_CERTIFICATES_SQL =
        $"""
        SELECT DISTINCT ON (certificate_role)
               certificate_role::text, subject_dn, thumbprint_sha256, not_after, issuer_dn,
               COALESCE(public_key_algorithm, ''), COALESCE(public_key_pem, '')
        FROM {DatabaseConstants.SchemaName}.ch_certificate
        WHERE is_active
          AND certificate_role::text IN ('{DataConstants.LOCAL_SBC_ROLE}','{DataConstants.LOCAL_MIB_ROLE}')
        ORDER BY certificate_role, not_after DESC
        """;



    /// <summary>Data source that opens one connection for each read.</summary>
    private readonly NpgsqlDataSource _dataSource;

    #endregion

    #region Constructor

    /// <summary>Creates the reader with the given data source, which must not be null.</summary>
    /// <param name="dataSource">Data source used to connect to the database.</param>
    public CertificateExpiryReader(NpgsqlDataSource dataSource)
    {
        if (dataSource is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataConstants.READER_DATA_SOURCE_IS_NULL);
            throw new ArgumentNullException(nameof(dataSource));
        }

        _dataSource = dataSource;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the active local SBC and MIB certificates from the database.
    /// Rows with a role that is not expected are skipped and logged.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The active local certificates.</returns>
    public async Task<IReadOnlyList<StoredCertificateInfo>> ReadActiveLocalCertificatesAsync(
        CancellationToken cancellationToken = default)
    {
        List<StoredCertificateInfo> certificates = new();

        await using NpgsqlConnection connection = await DatabaseServerConnection.OpenAsync(_dataSource, cancellationToken);
        await using NpgsqlCommand command = new(ACTIVE_CERTIFICATES_SQL, connection);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            string role = reader.GetString(DataConstants.ROLE_COLUMN);
            CertificateRole? mapped = MapRole(role);
            if (mapped is null)
            {
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataConstants.UNEXPECTED_ROLE, role);
                continue;
            }

            certificates.Add(new StoredCertificateInfo
            {
                Role = mapped.Value,
                Subject = reader.GetString(DataConstants.SUBJECT_COLUMN),
                Issuer = reader.GetString(DataConstants.ISSUER_COLUMN),
                Thumbprint = reader.GetString(DataConstants.THUMBPRINT_COLUMN),
                NotAfter = await reader.GetFieldValueAsync<DateTimeOffset>(DataConstants.NOT_AFTER_COLUMN, cancellationToken),
                PublicKeyAlgorithm = reader.GetString(5),
                PublicKeyPem = reader.GetString(6)
            });
        }

        return certificates;
    }

    #endregion

    #region Private Methods

    /// <summary>Turns the saved role text into the role enum. Gives null for any other role.</summary>
    /// <param name="role">The saved role text.</param>
    /// <returns>The certificate role, or null.</returns>
    private static CertificateRole? MapRole(string role) => role switch
    {
        DataConstants.LOCAL_SBC_ROLE => CertificateRole.LocalSbc,
        DataConstants.LOCAL_MIB_ROLE => CertificateRole.LocalMib,
        _ => null
    };

    #endregion
}
