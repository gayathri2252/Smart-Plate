﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using CertificateHandler.Data.Infrastructure;

namespace CertificateHandler.Data;

/// <summary>
/// Writes the audit row of a failed publish. It uses its own short transaction, so it can never roll back or change the trust row that was saved before.
/// </summary>
public sealed class PublishFailureAuditWriter : IPublishFailureAuditWriter
{
    #region Private Fields

    /// <summary>
    /// SQL that adds the audit row for a failed publish.
    /// </summary>
    private const string INSERT_AUDIT_SQL = $"INSERT INTO {DatabaseConstants.SchemaName}.{TrustPublishConstants.AUDIT_LOG_TABLE} " +
        $"({TrustPublishConstants.AUDIT_INSERT_COLUMNS}) " +
        $"VALUES (@{DatabaseConstants.EVENT_TYPE_PARAMETER}, @{DatabaseConstants.NOW_PARAMETER}, @{DatabaseConstants.ACTOR_PARAMETER}, " +
        $"@{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.THUMBPRINT_PARAMETER}, " +
        $"@{DatabaseConstants.ACTION_STATUS_PARAMETER}, @{DatabaseConstants.REASON_PARAMETER}, " +
        $"CAST(@{DatabaseConstants.DETAILS_PARAMETER} AS jsonb), '{TrustPublishConstants.RESULT_FAILURE}', @{DatabaseConstants.SOURCE_PARAMETER})";

    /// <summary>
    /// Database context used to write the audit rows.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the writer with the given database context. The context must not be null.
    /// </summary>
    /// <param name="dbContext">Database context used to write the audit rows.</param>
    public PublishFailureAuditWriter(CertificateHandlerDbContext dbContext)
    {
        if (dbContext is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.DB_CONTEXT_IS_NULL);
            throw new ArgumentNullException(nameof(dbContext));
        }
        _dbContext = dbContext;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Writes an audit row for a trust update that could not be sent.
    /// </summary>
    /// <param name="update">The trust update that failed.</param>
    /// <param name="error">The error that happened.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <exception cref="ArgumentNullException">Thrown when the update or the error is null.</exception>
    public async Task WriteAsync(TrustUpdate update, Exception error, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(update);
        ArgumentNullException.ThrowIfNull(error);

        string errorText = Truncate(error.Message);
        string details = JsonSerializer.Serialize(new Dictionary<string, object?>
        {
            [TrustPublishConstants.DETAILS_CHANGE] = update.Change,
            [TrustPublishConstants.DETAILS_SAVED_AT] = update.SavedAt,
            [TrustPublishConstants.DETAILS_ERROR_TYPE] = error.GetType().Name,
            [TrustPublishConstants.DETAILS_ERROR] = errorText
        });

        var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();
        bool isConnectionClosed = connection.State is not ConnectionState.Open;
        if (isConnectionClosed)
        {
            await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
        }

        try
        {
            await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);
            await using var command = new NpgsqlCommand(INSERT_AUDIT_SQL, connection, transaction);
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.EVENT_TYPE_PARAMETER, TrustPublishConstants.AUDIT_EVENT_TYPE));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.NOW_PARAMETER, DateTimeOffset.UtcNow));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.ACTOR_PARAMETER, DatabaseConstants.SystemActor));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.CERTIFICATE_ID_PARAMETER, (object?)update.CertificateId ?? DBNull.Value));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, update.ThumbprintSha256));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.ACTION_STATUS_PARAMETER, TrustPublishConstants.ACTION_PUBLISH_FAILED));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.REASON_PARAMETER, errorText));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.DETAILS_PARAMETER, details));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.SOURCE_PARAMETER, TrustPublishConstants.SOURCE_COMPONENT));
            await command.ExecuteNonQueryAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        finally
        {
            if (isConnectionClosed)
            {
                await connection.CloseAsync();
            }
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Makes the error text short enough for the audit row.
    /// </summary>
    /// <param name="text">The error text.</param>
    /// <returns>The text, cut to the longest allowed length.</returns>
    private static string Truncate(string text)
    {
        string value = string.IsNullOrWhiteSpace(text) ? TrustPublishConstants.UNKNOWN_ERROR_TEXT : text.Trim();
        return value.Length <= TrustPublishConstants.MAX_ERROR_LENGTH
            ? value
            : value[..TrustPublishConstants.MAX_ERROR_LENGTH];
    }

    #endregion
}
