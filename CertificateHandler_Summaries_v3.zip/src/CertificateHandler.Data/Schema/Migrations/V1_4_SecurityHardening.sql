-- =============================================================================
-- Certificate Handler migration v1.4_security_hardening
--
-- presented_cert_der: persisted peer certificate for approval-time re-validation (RS_03, RS_21).
-- signed_certificate_pem: keeps CSR in csr_pem during renewal import (RS_06).
-- =============================================================================

ALTER TABLE certificate_handler.ch_certificate
  ADD COLUMN IF NOT EXISTS presented_cert_der BYTEA;

ALTER TABLE certificate_handler.ch_csr_renewal_request
  ADD COLUMN IF NOT EXISTS signed_certificate_pem TEXT;

INSERT INTO certificate_handler.ch_schema_migration (migration_id, applied_by)
VALUES ('v1.4_security_hardening', 'certificate_handler_ddl')
ON CONFLICT (migration_id) DO NOTHING;
