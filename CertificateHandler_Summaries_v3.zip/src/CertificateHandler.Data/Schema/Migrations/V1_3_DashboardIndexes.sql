-- =============================================================================
-- MAXUM Certificate Handler migration v1.3_dashboard_indexes (SBC_CH_RS_02)
--
-- Indexes used by the dashboard counts and the dashboard page:
--   ix_ch_certificate_thumbprint      thumbprint lookups. Already part of the v1.2
--                                     baseline; created here only when it is missing.
--   ix_ch_certificate_dashboard_page  active certificates ordered by not_after and then
--                                     certificate_id: serves the expiry counts and the
--                                     ordered, paged dashboard rows.
--
-- Safe to run more than once. The application applies it at start-up when the
-- database bootstrap is enabled; otherwise an administrator runs this file once.
-- =============================================================================

CREATE INDEX IF NOT EXISTS ix_ch_certificate_thumbprint
  ON certificate_handler.ch_certificate (thumbprint_sha256);

CREATE INDEX IF NOT EXISTS ix_ch_certificate_dashboard_page
  ON certificate_handler.ch_certificate (not_after, certificate_id)
  WHERE is_active;

INSERT INTO certificate_handler.ch_schema_migration (migration_id, applied_by)
VALUES ('v1.3_dashboard_indexes', 'certificate_handler_ddl')
ON CONFLICT (migration_id) DO NOTHING;
