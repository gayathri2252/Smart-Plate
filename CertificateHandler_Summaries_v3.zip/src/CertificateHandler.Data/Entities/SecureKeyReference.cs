// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Reference to a TPM or CNG key label. No private key is saved in the database.
/// </summary>
public class SecureKeyReference
{
    #region Public Properties

    /// <summary>
    /// Id of the key.
    /// </summary>
    public Guid KeyId { get; set; }

    /// <summary>
    /// Id of the device that owns the key.
    /// </summary>
    public Guid DeviceId { get; set; }

    /// <summary>
    /// Label of the key in the secure key store.
    /// </summary>
    public string KeyLabel { get; set; } = string.Empty;

    /// <summary>
    /// How the private key is protected.
    /// </summary>
    public string ProtectionMode { get; set; } = "TPM_NON_EXPORTABLE";

    /// <summary>
    /// True if the private key can be exported.
    /// </summary>
    public bool IsExportable { get; set; }

    /// <summary>
    /// Time when the row was created.
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// Time when the key was last used. Null if it was never used.
    /// </summary>
    public DateTimeOffset? LastUsedAt { get; set; }

    /// <summary>
    /// Device that owns the key.
    /// </summary>
    public Device Device { get; set; } = null!;

    /// <summary>
    /// Renewal requests made with this key.
    /// </summary>
    public ICollection<CsrRenewalRequest> RenewalRequests { get; set; } = new List<CsrRenewalRequest>();

    #endregion
}
