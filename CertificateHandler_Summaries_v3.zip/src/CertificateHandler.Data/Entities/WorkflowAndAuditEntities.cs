// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// A change of the certificate status.
/// </summary>
public class CertificateStatusHistory
{
    #region Public Properties

    /// <summary>
    /// Id of the history row.
    /// </summary>
    public long HistoryId { get; set; }

    /// <summary>
    /// Id of the certificate.
    /// </summary>
    public Guid CertificateId { get; set; }

    /// <summary>
    /// Id of the device. Null when the device is not known.
    /// </summary>
    public Guid? DeviceId { get; set; }

    /// <summary>
    /// Status before the change.
    /// </summary>
    public string PreviousStatus { get; set; } = string.Empty;

    /// <summary>
    /// Status after the change.
    /// </summary>
    public string NewStatus { get; set; } = string.Empty;

    /// <summary>
    /// Time of the change.
    /// </summary>
    public DateTimeOffset ChangedAt { get; set; }

    /// <summary>
    /// User or system that made the change.
    /// </summary>
    public string ChangedBy { get; set; } = string.Empty;

    /// <summary>
    /// Reason for the change.
    /// </summary>
    public string? Reason { get; set; }

    /// <summary>
    /// Id of the request that caused the change.
    /// </summary>
    public Guid? RelatedRequestId { get; set; }

    /// <summary>
    /// Certificate whose status changed.
    /// </summary>
    public Certificate Certificate { get; set; } = null!;

    /// <summary>
    /// Request that caused the change.
    /// </summary>
    public PendingRequest? RelatedRequest { get; set; }

    #endregion
}

/// <summary>
/// One approval or rejection of a reinstatement request.
/// </summary>
public class ReinstatementApproval
{
    #region Public Properties

    /// <summary>
    /// Id of the approval.
    /// </summary>
    public long ApprovalId { get; set; }

    /// <summary>
    /// Id of the reinstatement request.
    /// </summary>
    public Guid RequestId { get; set; }

    /// <summary>
    /// Order of the approval, 1 for the first and 2 for the second.
    /// </summary>
    public short ApprovalSequence { get; set; }

    /// <summary>
    /// User who made the decision.
    /// </summary>
    public string ApproverIdentity { get; set; } = string.Empty;

    /// <summary>
    /// The decision.
    /// </summary>
    public string Decision { get; set; } = string.Empty;

    /// <summary>
    /// Time of the decision.
    /// </summary>
    public DateTimeOffset DecidedAt { get; set; }

    /// <summary>
    /// Comments of the user.
    /// </summary>
    public string? Comments { get; set; }

    /// <summary>
    /// Reinstatement request of the approval.
    /// </summary>
    public PendingRequest Request { get; set; } = null!;

    #endregion
}

/// <summary>
/// A certificate signing or renewal request.
/// </summary>
public class CsrRenewalRequest
{
    #region Public Properties

    /// <summary>
    /// Id of the renewal request.
    /// </summary>
    public Guid RenewalRequestId { get; set; }

    /// <summary>
    /// Id of the certificate to renew.
    /// </summary>
    public Guid CertificateId { get; set; }

    /// <summary>
    /// Id of the key used for the request.
    /// </summary>
    public Guid KeyId { get; set; }

    /// <summary>
    /// The certificate signing request in PEM format.
    /// </summary>
    public string? CsrPem { get; set; }

    /// <summary>
    /// Status of the renewal request.
    /// </summary>
    public RenewalRequestStatus Status { get; set; } = RenewalRequestStatus.Created;

    /// <summary>
    /// Time when the request was created.
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// Time when the request was exported. Null if not exported.
    /// </summary>
    public DateTimeOffset? ExportedAt { get; set; }

    /// <summary>
    /// User who exported the request.
    /// </summary>
    public string? ExportedBy { get; set; }

    /// <summary>
    /// Time when the signed certificate was imported.
    /// </summary>
    public DateTimeOffset? ImportedAt { get; set; }

    /// <summary>
    /// Time when the renewed certificate was activated.
    /// </summary>
    public DateTimeOffset? ActivatedAt { get; set; }

    /// <summary>
    /// Why the renewal failed.
    /// </summary>
    public string? FailureReason { get; set; }

    /// <summary>
    /// Id of the certificate that was replaced.
    /// </summary>
    public Guid? PreviousCertificateId { get; set; }

    /// <summary>
    /// Certificate to renew.
    /// </summary>
    public Certificate Certificate { get; set; } = null!;

    /// <summary>
    /// Key used for the request.
    /// </summary>
    public SecureKeyReference Key { get; set; } = null!;

    #endregion
}

/// <summary>
/// A factory provisioning attempt for a device.
/// </summary>
public class FactoryProvisioningAttempt
{
    #region Public Properties

    /// <summary>
    /// Id of the attempt.
    /// </summary>
    public Guid AttemptId { get; set; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid DeviceId { get; set; }

    /// <summary>
    /// Role of the certificate to provision.
    /// </summary>
    public CertificateRole TargetRole { get; set; }

    /// <summary>
    /// Result of the attempt.
    /// </summary>
    public ProvisioningOutcome Outcome { get; set; } = ProvisioningOutcome.InProgress;

    /// <summary>
    /// Number of retries done.
    /// </summary>
    public int RetryCount { get; set; }

    /// <summary>
    /// Most retries allowed.
    /// </summary>
    public int MaxRetries { get; set; } = 3;

    /// <summary>
    /// Time when the attempt started.
    /// </summary>
    public DateTimeOffset StartedAt { get; set; }

    /// <summary>
    /// Time when the attempt ended. Null while it is running.
    /// </summary>
    public DateTimeOffset? CompletedAt { get; set; }

    /// <summary>
    /// Error message when the attempt failed.
    /// </summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// Id of the certificate that was made.
    /// </summary>
    public Guid? ResultingCertificateId { get; set; }

    /// <summary>
    /// Device of the attempt.
    /// </summary>
    public Device Device { get; set; } = null!;

    #endregion
}

/// <summary>
/// An audit row for a Certificate Handler action.
/// </summary>
public class AuditLog
{
    #region Public Properties

    /// <summary>
    /// Id of the audit row.
    /// </summary>
    public long AuditId { get; set; }

    /// <summary>
    /// Id of the event.
    /// </summary>
    public Guid EventId { get; set; }

    /// <summary>
    /// Type of the event.
    /// </summary>
    public string EventType { get; set; } = string.Empty;

    /// <summary>
    /// Time of the event.
    /// </summary>
    public DateTimeOffset EventTimestamp { get; set; }

    /// <summary>
    /// User or system that did the action.
    /// </summary>
    public string ActorIdentity { get; set; } = string.Empty;

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid? DeviceId { get; set; }

    /// <summary>
    /// Id of the request.
    /// </summary>
    public Guid? RequestId { get; set; }

    /// <summary>
    /// Id of the certificate.
    /// </summary>
    public Guid? CertificateId { get; set; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string? ThumbprintSha256 { get; set; }

    /// <summary>
    /// Status before the action.
    /// </summary>
    public string? PreviousStatus { get; set; }

    /// <summary>
    /// Status after the action.
    /// </summary>
    public string? NewStatus { get; set; }

    /// <summary>
    /// Status of the action.
    /// </summary>
    public string? ActionStatus { get; set; }

    /// <summary>
    /// Reason for the action.
    /// </summary>
    public string? Reason { get; set; }

    /// <summary>
    /// More details in JSON format.
    /// </summary>
    public string? DetailsJson { get; set; }

    /// <summary>
    /// Result of the action.
    /// </summary>
    public string Result { get; set; } = "SUCCESS";

    /// <summary>
    /// Part of the app that wrote the row.
    /// </summary>
    public string? SourceComponent { get; set; }

    #endregion
}

/// <summary>
/// A bulk blacklist operation.
/// </summary>
public class BulkOperation
{
    #region Public Properties

    /// <summary>
    /// Id of the bulk operation.
    /// </summary>
    public Guid BulkOperationId { get; set; }

    /// <summary>
    /// Administrator who started the operation.
    /// </summary>
    public string InitiatedBy { get; set; } = string.Empty;

    /// <summary>
    /// Reason for the operation.
    /// </summary>
    public string Reason { get; set; } = string.Empty;

    /// <summary>
    /// Most items allowed in the operation.
    /// </summary>
    public int MaxBatchSize { get; set; }

    /// <summary>
    /// Time allowed for the operation, in seconds.
    /// </summary>
    public int ProcessingTimeoutSeconds { get; set; }

    /// <summary>
    /// Status of the operation.
    /// </summary>
    public BulkOperationStatus Status { get; set; } = BulkOperationStatus.Running;

    /// <summary>
    /// Time when the operation started.
    /// </summary>
    public DateTimeOffset StartedAt { get; set; }

    /// <summary>
    /// Time when the operation ended.
    /// </summary>
    public DateTimeOffset? CompletedAt { get; set; }

    /// <summary>
    /// Items of the operation.
    /// </summary>
    public ICollection<BulkOperationItem> Items { get; set; } = new List<BulkOperationItem>();

    #endregion
}

/// <summary>
/// One item of a bulk blacklist operation.
/// </summary>
public class BulkOperationItem
{
    #region Public Properties

    /// <summary>
    /// Id of the item.
    /// </summary>
    public long ItemId { get; set; }

    /// <summary>
    /// Id of the bulk operation.
    /// </summary>
    public Guid BulkOperationId { get; set; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid? DeviceId { get; set; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string? ThumbprintSha256 { get; set; }

    /// <summary>
    /// Status of the item.
    /// </summary>
    public string ItemStatus { get; set; } = string.Empty;

    /// <summary>
    /// Error message when the item failed.
    /// </summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// Time when the item was done.
    /// </summary>
    public DateTimeOffset? ProcessedAt { get; set; }

    /// <summary>
    /// Bulk operation of the item.
    /// </summary>
    public BulkOperation BulkOperation { get; set; } = null!;

    #endregion
}

/// <summary>
/// A change of the trust status of a device.
/// </summary>
public class TrustEvent
{
    #region Public Properties

    /// <summary>
    /// Id of the event.
    /// </summary>
    public Guid EventId { get; set; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid? DeviceId { get; set; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>
    /// New trust status of the device.
    /// </summary>
    public string NewTrustStatus { get; set; } = string.Empty;

    /// <summary>
    /// Id of the request that caused the change.
    /// </summary>
    public Guid? RelatedRequestId { get; set; }

    /// <summary>
    /// User who made the change.
    /// </summary>
    public string? ActorIdentity { get; set; }

    /// <summary>
    /// Time of the change.
    /// </summary>
    public DateTimeOffset OccurredAt { get; set; }

    /// <summary>
    /// Details of the event in JSON format.
    /// </summary>
    public string PayloadJson { get; set; } = "{}";

    /// <summary>
    /// Deliveries of the event to the subscribers.
    /// </summary>
    public ICollection<TrustEventDelivery> Deliveries { get; set; } = new List<TrustEventDelivery>();

    #endregion
}

/// <summary>
/// Delivery of a trust event to one subscriber.
/// </summary>
public class TrustEventDelivery
{
    #region Public Properties

    /// <summary>
    /// Id of the delivery.
    /// </summary>
    public long DeliveryId { get; set; }

    /// <summary>
    /// Id of the trust event.
    /// </summary>
    public Guid EventId { get; set; }

    /// <summary>
    /// Name of the subscriber.
    /// </summary>
    public string SubscriberName { get; set; } = string.Empty;

    /// <summary>
    /// Status of the delivery.
    /// </summary>
    public TrustEventDeliveryStatus Status { get; set; } = TrustEventDeliveryStatus.Pending;

    /// <summary>
    /// Number of times the delivery was tried.
    /// </summary>
    public int AttemptCount { get; set; }

    /// <summary>
    /// Time of the last try.
    /// </summary>
    public DateTimeOffset? LastAttemptAt { get; set; }

    /// <summary>
    /// Error of the last try.
    /// </summary>
    public string? LastError { get; set; }

    /// <summary>
    /// Time when the event was delivered.
    /// </summary>
    public DateTimeOffset? DeliveredAt { get; set; }

    /// <summary>
    /// Trust event of the delivery.
    /// </summary>
    public TrustEvent Event { get; set; } = null!;

    #endregion
}

/// <summary>
/// A notification sent to the requesting device about the status of its request.
/// </summary>
public class PeerNotification
{
    #region Public Properties

    /// <summary>
    /// Id of the notification.
    /// </summary>
    public long NotificationId { get; set; }

    /// <summary>
    /// Id of the request.
    /// </summary>
    public Guid RequestId { get; set; }

    /// <summary>
    /// Id of the device that gets the notification.
    /// </summary>
    public Guid? TargetDeviceId { get; set; }

    /// <summary>
    /// Status sent in the notification.
    /// </summary>
    public PeerNotificationStatus NotificationStatus { get; set; }

    /// <summary>
    /// Time when the notification was sent.
    /// </summary>
    public DateTimeOffset SentAt { get; set; }

    /// <summary>
    /// Result of the send.
    /// </summary>
    public DeliveryResult DeliveryResult { get; set; }

    /// <summary>
    /// Number of retries.
    /// </summary>
    public int RetryCount { get; set; }

    /// <summary>
    /// Error of the last try.
    /// </summary>
    public string? LastError { get; set; }

    /// <summary>
    /// Request of the notification.
    /// </summary>
    public PendingRequest Request { get; set; } = null!;

    #endregion
}

/// <summary>
/// Result of one certificate validation step.
/// </summary>
public class ValidationResult
{
    #region Public Properties

    /// <summary>
    /// Id of the result.
    /// </summary>
    public long ValidationId { get; set; }

    /// <summary>
    /// Time when the step was checked.
    /// </summary>
    public DateTimeOffset EvaluatedAt { get; set; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string? ThumbprintSha256 { get; set; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public Guid? DeviceId { get; set; }

    /// <summary>
    /// Name of the validation step.
    /// </summary>
    public string ValidationStep { get; set; } = string.Empty;

    /// <summary>
    /// True when the step passed.
    /// </summary>
    public bool Passed { get; set; }

    /// <summary>
    /// Why the step failed.
    /// </summary>
    public string? FailureReason { get; set; }

    /// <summary>
    /// True when the system time was trusted.
    /// </summary>
    public bool TimeVerified { get; set; } = true;

    /// <summary>
    /// True when the certificate was added to the blacklist by the system.
    /// </summary>
    public bool AutoBlacklisted { get; set; }

    #endregion
}

/// <summary>
/// A system setting.
/// </summary>
public class SystemConfig
{
    #region Public Properties

    /// <summary>
    /// Key of the setting.
    /// </summary>
    public string ConfigKey { get; set; } = string.Empty;

    /// <summary>
    /// Value of the setting.
    /// </summary>
    public string ConfigValue { get; set; } = string.Empty;

    /// <summary>
    /// Description of the setting.
    /// </summary>
    public string? Description { get; set; }

    /// <summary>
    /// Time when the value was last changed.
    /// </summary>
    public DateTimeOffset UpdatedAt { get; set; }

    /// <summary>
    /// User who last changed the value.
    /// </summary>
    public string UpdatedBy { get; set; } = "system";

    #endregion
}

/// <summary>
/// A schema migration that was applied.
/// </summary>
public class SchemaMigration
{
    #region Public Properties

    /// <summary>
    /// Id of the migration.
    /// </summary>
    public string MigrationId { get; set; } = string.Empty;

    /// <summary>
    /// Time when the migration was applied.
    /// </summary>
    public DateTimeOffset AppliedAt { get; set; }

    /// <summary>
    /// User that applied the migration.
    /// </summary>
    public string AppliedBy { get; set; } = string.Empty;

    #endregion
}

/// <summary>
/// Counts shown on the dashboard.
/// </summary>
public class DashboardCounts
{
    #region Public Properties

    /// <summary>
    /// Number of whitelisted certificates.
    /// </summary>
    public long WhitelistedCount { get; set; }

    /// <summary>
    /// Number of blacklisted certificates.
    /// </summary>
    public long BlacklistedCount { get; set; }

    /// <summary>
    /// Number of pending requests.
    /// </summary>
    public long PendingCount { get; set; }

    /// <summary>
    /// Number of expired local certificates.
    /// </summary>
    public long ExpiredLocalCertCount { get; set; }

    /// <summary>
    /// Number of certificates that expire within 90 days.
    /// </summary>
    public long Expiring90Days { get; set; }

    /// <summary>
    /// Number of certificates that expire within 30 days.
    /// </summary>
    public long Expiring30Days { get; set; }

    /// <summary>
    /// Number of validation failures in the set time window.
    /// </summary>
    public long ValidationFailuresWindow { get; set; }

    /// <summary>
    /// Total number of managed certificates.
    /// </summary>
    public long TotalManagedCertificates { get; set; }

    #endregion
}

/// <summary>
/// A row of the pending queue overview.
/// </summary>
public class PendingQueueOverview
{
    #region Public Properties

    /// <summary>
    /// Id of the request.
    /// </summary>
    public Guid RequestId { get; set; }

    /// <summary>
    /// Id of the device.
    /// </summary>
    public string DeviceIdentifier { get; set; } = string.Empty;

    /// <summary>
    /// Type of the request.
    /// </summary>
    public PendingRequestType RequestType { get; set; }

    /// <summary>
    /// Who asked for it.
    /// </summary>
    public string? RequesterIdentity { get; set; }

    /// <summary>
    /// User or system that created the request.
    /// </summary>
    public string RequestedBy { get; set; } = string.Empty;

    /// <summary>
    /// Date of the request.
    /// </summary>
    public DateTimeOffset RequestDate { get; set; }

    /// <summary>
    /// Current status of the request.
    /// </summary>
    public PendingRequestStatus CurrentStatus { get; set; }

    /// <summary>
    /// MAXUM IP address of the device.
    /// </summary>
    public string? MaxumIp { get; set; }

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>
    /// Subject name of the certificate.
    /// </summary>
    public string SubjectDn { get; set; } = string.Empty;

    /// <summary>
    /// Time when the request expires.
    /// </summary>
    public DateTimeOffset ExpiresAt { get; set; }

    #endregion
}
