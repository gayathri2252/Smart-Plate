﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Test publisher used until the real one exists.
/// It works, unless the file simulate publish failure flag exists in the working folder. Then it throws, so QA can force a failure after a save that worked.
/// To use the real publisher, change one registration.
/// </summary>
public sealed class SimulatedTrustUpdatePublisher : ITrustUpdatePublisher
{
    #region Public Methods

    /// <summary>
    /// Sends the trust update. When the test flag file exists, it fails on purpose to test error handling, audit rows and administrator messages.
    /// </summary>
    /// <param name="update">
    /// Trust update to send.
    /// </param>
    /// <param name="cancellationToken">
    /// Token to cancel the work.
    /// </param>
    /// <returns>
    /// A task that ends when the send is done.
    /// </returns>
    public Task PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default)
    {
        string flagPath = Path.Combine(AppContext.BaseDirectory, TrustPublishConstants.SIMULATE_FAILURE_FLAG_FILE);
        if (File.Exists(flagPath) || File.Exists(TrustPublishConstants.SIMULATE_FAILURE_FLAG_FILE))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataLogConstants.TRUST_UPDATE_SIMULATED_FAILURE, update?.ThumbprintSha256 ?? string.Empty);
            throw new InvalidOperationException(TrustPublishConstants.SIMULATED_FAILURE_MESSAGE);
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.TRUST_UPDATE_SIMULATED, update?.Change ?? string.Empty, update?.ThumbprintSha256 ?? string.Empty);
        return Task.CompletedTask;
    }

    #endregion
}
