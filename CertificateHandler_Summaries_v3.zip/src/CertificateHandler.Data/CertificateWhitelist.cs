﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Reads the certificate whitelist. Plain SQL with an enum cast is used, like for the blacklist, because PostgreSQL does not allow plain text for an enum column.
/// </summary>
public sealed class CertificateWhitelist : ICertificateWhitelist
{
    #region Member Variables

    /// <summary>
    /// Name of the database schema.
    /// </summary>
    private const string Schema = DatabaseConstants.SchemaName;

    /// <summary>
    /// SQL that checks if the certificate has an active whitelist entry.
    /// </summary>
    private const string IsWhitelistedSql =
        $"SELECT EXISTS (SELECT 1 FROM {Schema}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @thumbprint AND is_active AND list_kind = CAST(@kind AS {Schema}.trust_list_kind))";

    /// <summary>
    /// Database context used to read and change the trust list entries.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the whitelist lookup with the given database context. The context must not be null.
    /// </summary>
    /// <param name="dbContext">Database context used to read the whitelist.</param>
    public CertificateWhitelist(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns true when the thumbprint has an active whitelist row. The connection is opened for the check and closed again if it was closed before.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the certificate is on the whitelist, otherwise false.</returns>
    public async Task<bool> IsWhitelistedAsync(
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(thumbprintSha256);

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using var command = new NpgsqlCommand(IsWhitelistedSql, connection);
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
                command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Whitelist)));

                object? result = await command.ExecuteScalarAsync(cancellationToken);
                bool isWhitelisted = result is true;
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.WHITELIST_CHECKED, thumbprint, isWhitelisted.ToString());
                return isWhitelisted;
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.WHITELIST_LOOKUP_FAILED, thumbprintSha256 ?? string.Empty, ex.Message);
            throw;
        }
    }

    #endregion
}
