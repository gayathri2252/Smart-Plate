﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Net;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using NpgsqlTypes;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Manages pending peer onboarding requests. It keeps the queue size limit, stops double requests and saves the device and certificate details in one transaction.
/// </summary>
public sealed class PendingQueueStore : IPendingQueueStore
{
    #region Member Variables

    /// <summary>
    /// Name of the database schema.
    /// </summary>
    private const string SCHEMA = DatabaseConstants.SchemaName;

    /// <summary>
    /// SQL part that turns the status value into the pending request status type.
    /// </summary>
    private const string PENDING_STATUS_CAST = $"CAST(@{DatabaseConstants.PENDING_STATUS_PARAMETER} AS {SCHEMA}.{DatabaseConstants.PendingRequestStatusEnumName})";

    /// <summary>
    /// SQL part that turns the request type value into the pending request type.
    /// </summary>
    private const string PEER_TYPE_CAST = $"CAST(@{DatabaseConstants.REQUEST_TYPE_PARAMETER} AS {SCHEMA}.{DatabaseConstants.PendingRequestTypeEnumName})";

    /// <summary>
    /// Holds a lock until the transaction ends. So when two peers connect at the same time, they are counted and added one after the other, also when more than one process uses the database.
    /// </summary>
    private const string LOCK_QUEUE_SQL = $"SELECT pg_advisory_xact_lock(@{DatabaseConstants.LOCK_KEY_PARAMETER})";

    /// <summary>
    /// SQL that checks if the certificate already has an open pending request.
    /// </summary>
    private const string HAS_OPEN_REQUEST_SQL = $"SELECT EXISTS (SELECT 1 FROM {SCHEMA}.{DatabaseConstants.PendingRequestTable} pr " +
        $"JOIN {SCHEMA}.ch_certificate c ON c.certificate_id = pr.certificate_id " +
        $"WHERE c.thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND pr.status = {PENDING_STATUS_CAST})";

    /// <summary>
    /// SQL that counts the open peer onboarding requests.
    /// </summary>
    private const string COUNT_OPEN_PEER_REQUESTS_SQL = $"SELECT COUNT(*) FROM {SCHEMA}.{DatabaseConstants.PendingRequestTable} " +
        $"WHERE status = {PENDING_STATUS_CAST} AND request_type = {PEER_TYPE_CAST}";

    /// <summary>
    /// SQL that adds the device, or updates its MAXUM IP address if it already exists.
    /// </summary>
    private const string UPSERT_DEVICE_SQL = $"INSERT INTO {SCHEMA}.ch_device AS d (device_code, device_type, maxum_ip) " +
        $"VALUES (@{DatabaseConstants.DEVICE_CODE_PARAMETER}, CAST(@{DatabaseConstants.DEVICE_TYPE_PARAMETER} AS {SCHEMA}.device_type), " +
        $"CAST(@{DatabaseConstants.MAXUM_IP_PARAMETER} AS inet)) " +
        "ON CONFLICT (device_code) DO UPDATE SET maxum_ip = COALESCE(EXCLUDED.maxum_ip, d.maxum_ip) " +
        "RETURNING device_id";

    /// <summary>
    /// SQL that finds the active peer certificate by its thumbprint.
    /// </summary>
    private const string FIND_PEER_CERTIFICATE_SQL = $"SELECT certificate_id FROM {SCHEMA}.ch_certificate " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} " +
        $"AND certificate_role = CAST(@{DatabaseConstants.ROLE_PARAMETER} AS {SCHEMA}.certificate_role) AND is_active LIMIT 1";

    /// <summary>
    /// SQL that adds a peer certificate.
    /// </summary>
    private const string INSERT_PEER_CERTIFICATE_SQL = $"INSERT INTO {SCHEMA}.ch_certificate " +
        "(device_id, certificate_role, thumbprint_sha256, subject_dn, issuer_dn, serial_number, not_before, not_after, presented_cert_der) " +
        $"VALUES (@{DatabaseConstants.DEVICE_ID_PARAMETER}, CAST(@{DatabaseConstants.ROLE_PARAMETER} AS {SCHEMA}.certificate_role), " +
        $"@{DatabaseConstants.THUMBPRINT_PARAMETER}, @{DatabaseConstants.SUBJECT_DN_PARAMETER}, @{DatabaseConstants.ISSUER_DN_PARAMETER}, " +
        $"@{DatabaseConstants.SERIAL_NUMBER_PARAMETER}, @{DatabaseConstants.NOT_BEFORE_PARAMETER}, @{DatabaseConstants.NOT_AFTER_PARAMETER}, " +
        $"@{DatabaseConstants.PRESENTED_CERT_PARAMETER}) " +
        "RETURNING certificate_id";

    /// <summary>
    /// SQL that saves the certificate data sent by the peer.
    /// </summary>
    private const string UPDATE_PEER_PRESENTED_CERT_SQL =
        $"UPDATE {SCHEMA}.ch_certificate SET presented_cert_der = @{DatabaseConstants.PRESENTED_CERT_PARAMETER} " +
        $"WHERE certificate_id = @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}";

    /// <summary>
    /// SQL that adds a pending request.
    /// </summary>
    private const string INSERT_PENDING_REQUEST_SQL = $"INSERT INTO {SCHEMA}.{DatabaseConstants.PendingRequestTable} " +
        "(request_type, certificate_id, device_id, requested_by, expires_at, connection_correlation_id) " +
        $"VALUES ({PEER_TYPE_CAST}, @{DatabaseConstants.CERTIFICATE_ID_PARAMETER}, @{DatabaseConstants.DEVICE_ID_PARAMETER}, " +
        $"@{DatabaseConstants.ACTOR_PARAMETER}, @{DatabaseConstants.EXPIRES_AT_PARAMETER}, " +
        $"CAST(@{DatabaseConstants.CORRELATION_ID_PARAMETER} AS uuid)) " +
        "RETURNING request_id";

    /// <summary>
    /// Database context used to run the queries.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the store with the given database context. The context must not be null.
    /// </summary>
    /// <param name="dbContext">Database context used to run the queries.</param>
    public PendingQueueStore(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets the number of open peer onboarding requests that are pending now.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The number of open peer requests.</returns>
    public async Task<int> CountOpenPeerRequestsAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                return await CountOpenPeerRequestsAsync(connection, null, cancellationToken);
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.PEER_REQUEST_COUNT_FAILED, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Tries to add a peer onboarding request to the pending queue. It checks for a double request and for the most open requests allowed.
    /// </summary>
    /// <param name="request">The peer onboarding request.</param>
    /// <param name="maxOpenRequests">Most open requests allowed.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>
    /// A result that says if the request was added, already exists or was refused because the queue is full.
    /// </returns>
    public async Task<PendingQueueAddResult> TryAddPeerRequestAsync(PeerOnboardingRequest request, int maxOpenRequests, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        try
        {
            ArgumentOutOfRangeException.ThrowIfLessThan(maxOpenRequests, 1);
            ArgumentException.ThrowIfNullOrWhiteSpace(request.DeviceCode);

            string thumbprint = ThumbprintNormalizer.NormalizeRequired(request.ThumbprintSha256);

            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

                await ScalarAsync(connection, transaction, LOCK_QUEUE_SQL, cancellationToken,
                    (DatabaseConstants.LOCK_KEY_PARAMETER, DatabaseConstants.PENDING_QUEUE_LOCK_KEY));
                object? hasOpenRequest = await ScalarAsync(connection, transaction, HAS_OPEN_REQUEST_SQL, cancellationToken,
                    (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
                    (DatabaseConstants.PENDING_STATUS_PARAMETER, PostgresEnumNames.ToPgName(PendingRequestStatus.Pending)));

                int openCount = await CountOpenPeerRequestsAsync(connection, transaction, cancellationToken);

                if (hasOpenRequest is true)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    return new PendingQueueAddResult { Outcome = PendingQueueAddOutcome.AlreadyPending, OpenRequestCount = openCount };
                }

                if (openCount >= maxOpenRequests)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    return new PendingQueueAddResult { Outcome = PendingQueueAddOutcome.QueueFull, OpenRequestCount = openCount };
                }

                var deviceId = (Guid)(await ScalarAsync(connection, transaction, UPSERT_DEVICE_SQL, cancellationToken,
                    (DatabaseConstants.DEVICE_CODE_PARAMETER, request.DeviceCode.Trim()),
                    (DatabaseConstants.DEVICE_TYPE_PARAMETER, PostgresEnumNames.ToPgName(DeviceType.MaxumPeer)),
                    (DatabaseConstants.MAXUM_IP_PARAMETER, ToValidIpOrNull(request.MaxumIp))))!;

                Guid certificateId = await FindOrAddPeerCertificateAsync(connection, transaction, request, thumbprint, deviceId, cancellationToken);

                var requestId = (Guid)(await ScalarAsync(connection, transaction, INSERT_PENDING_REQUEST_SQL, cancellationToken,
                    (DatabaseConstants.REQUEST_TYPE_PARAMETER, PostgresEnumNames.ToPgName(PendingRequestType.PeerOnboarding)),
                    (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificateId),
                    (DatabaseConstants.DEVICE_ID_PARAMETER, deviceId),
                    (DatabaseConstants.ACTOR_PARAMETER, request.RequestedBy),
                    (DatabaseConstants.EXPIRES_AT_PARAMETER, request.ExpiresAt.ToUniversalTime()),
                    (DatabaseConstants.CORRELATION_ID_PARAMETER, request.ConnectionCorrelationId)))!;

                await transaction.CommitAsync(cancellationToken);

                return new PendingQueueAddResult
                {
                    Outcome = PendingQueueAddOutcome.Added,
                    RequestId = requestId,
                    OpenRequestCount = openCount
                };
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.PEER_REQUEST_ADD_FAILED, request.DeviceCode, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Counts the open requests that peers made by connecting. Requests made by an administrator, like a reinstatement, do not use up the places kept for peers.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Number of open peer requests.</returns>
    private static async Task<int> CountOpenPeerRequestsAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction? transaction,
        CancellationToken cancellationToken)
    {
        object? count = await ScalarAsync(connection, transaction, COUNT_OPEN_PEER_REQUESTS_SQL, cancellationToken,
            (DatabaseConstants.PENDING_STATUS_PARAMETER, PostgresEnumNames.ToPgName(PendingRequestStatus.Pending)),
            (DatabaseConstants.REQUEST_TYPE_PARAMETER, PostgresEnumNames.ToPgName(PendingRequestType.PeerOnboarding)));

        return Convert.ToInt32(count);
    }

    /// <summary>
    /// Gives the active peer certificate with the thumbprint, and saves it first when it is new.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="request">The peer onboarding request.</param>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="deviceId">Id of the device.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Id of the certificate.</returns>
    private static async Task<Guid> FindOrAddPeerCertificateAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PeerOnboardingRequest request,
        string thumbprint,
        Guid deviceId,
        CancellationToken cancellationToken)
    {
        string role = PostgresEnumNames.ToPgName(CertificateRole.Peer);

        object? existing = await ScalarAsync(connection, transaction, FIND_PEER_CERTIFICATE_SQL, cancellationToken,
            (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
            (DatabaseConstants.ROLE_PARAMETER, role));

        byte[]? presentedDer = request.PresentedCertificateDer;

        if (existing is Guid certificateId)
        {
            if (presentedDer is { Length: > 0 })
            {
                await ScalarAsync(connection, transaction, UPDATE_PEER_PRESENTED_CERT_SQL, cancellationToken,
                    (DatabaseConstants.PRESENTED_CERT_PARAMETER, presentedDer),
                    (DatabaseConstants.CERTIFICATE_ID_PARAMETER, certificateId));
            }

            return certificateId;
        }

        return (Guid)(await ScalarAsync(connection, transaction, INSERT_PEER_CERTIFICATE_SQL, cancellationToken,
            (DatabaseConstants.DEVICE_ID_PARAMETER, deviceId),
            (DatabaseConstants.ROLE_PARAMETER, role),
            (DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint),
            (DatabaseConstants.SUBJECT_DN_PARAMETER, request.SubjectDn),
            (DatabaseConstants.ISSUER_DN_PARAMETER, request.IssuerDn),
            (DatabaseConstants.SERIAL_NUMBER_PARAMETER, request.SerialNumber),
            (DatabaseConstants.NOT_BEFORE_PARAMETER, request.NotBefore.ToUniversalTime()),
            (DatabaseConstants.NOT_AFTER_PARAMETER, request.NotAfter.ToUniversalTime()),
            (DatabaseConstants.PRESENTED_CERT_PARAMETER, (object?)presentedDer ?? DBNull.Value)))!;
    }

    /// <summary>
    /// Gives the address when it is a valid IP address, otherwise null, so a wrong value from the peer cannot make the insert fail.
    /// </summary>
    /// <param name="maxumIp">The MAXUM IP address sent by the peer.</param>
    /// <returns>The IP address, or null.</returns>
    private static string? ToValidIpOrNull(string? maxumIp)
    {
        return IPAddress.TryParse(maxumIp?.Trim(), out IPAddress? address) ? address.ToString() : null;
    }

    /// <summary>
    /// Runs one SQL statement and gives the first column of the first row. A null value is sent as a text NULL, so PostgreSQL can still cast it.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="transaction">The current transaction.</param>
    /// <param name="sql">The SQL to run.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <param name="parameters">Names and values of the parameters.</param>
    /// <returns>The first value, or null.</returns>
    private static async Task<object?> ScalarAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction? transaction,
        string sql,
        CancellationToken cancellationToken,
        params (string Name, object? Value)[] parameters)
    {
        await using var command = new NpgsqlCommand(sql, connection, transaction);
        foreach ((string name, object? value) in parameters)
        {
            command.Parameters.Add(value is null
                ? new NpgsqlParameter(name, NpgsqlDbType.Text) { Value = DBNull.Value }
                : new NpgsqlParameter(name, value));
        }

        return await command.ExecuteScalarAsync(cancellationToken);
    }

    #endregion
}