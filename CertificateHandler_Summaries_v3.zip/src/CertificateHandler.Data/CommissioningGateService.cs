// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Stops commissioning when factory provisioning failed or used up all its retries.
/// </summary>
public sealed class CommissioningGateService : ICommissioningGateService
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the commissioning check service.
    /// </summary>
    /// <param name="dataSource">Data source used to connect to the database.</param>
    /// <exception cref="ArgumentNullException">Thrown when the data source is null.</exception>
    public CommissioningGateService(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if commissioning can go on.
    /// Commissioning stops when a device is marked as provisioning failed, or when factory provisioning failed after all retries.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A result that says if commissioning goes on or stops, with the reason.</returns>
    public async Task<CommissioningHaltResult> EvaluateAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);

        await using var failedDevices = new NpgsqlCommand(
            $"SELECT COUNT(*) FROM {DatabaseConstants.SchemaName}.ch_device WHERE operational_status = 'PROVISIONING_FAILED'",
            connection);
        int failedDeviceCount = Convert.ToInt32(await failedDevices.ExecuteScalarAsync(cancellationToken));
        if (failedDeviceCount > 0)
        {
            return CommissioningHaltResult.Halt(
                $"{failedDeviceCount} device(s) are flagged as provisioning failed. Resolve factory provisioning before commissioning.");
        }

        await using var exhausted = new NpgsqlCommand(
            $"SELECT COUNT(*) FROM {DatabaseConstants.SchemaName}.ch_factory_provisioning_attempt " +
            "WHERE outcome = 'FAILED' AND retry_count >= max_retries AND completed_at IS NOT NULL",
            connection);
        int exhaustedCount = Convert.ToInt32(await exhausted.ExecuteScalarAsync(cancellationToken));
        if (exhaustedCount > 0)
        {
            return CommissioningHaltResult.Halt(
                "Factory provisioning failed beyond the retry limit. Manual intervention is required before commissioning.");
        }

        return CommissioningHaltResult.Continue();
    }

    #endregion
}
