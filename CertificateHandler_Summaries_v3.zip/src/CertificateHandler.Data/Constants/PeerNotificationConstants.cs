// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Settings for the peer notification queue and its retries.
/// </summary>
public static class PeerNotificationConstants
{
    /// <summary>
    /// Marker saved while the notification waits to be sent.
    /// </summary>
    public const string PendingDeliveryMarker = "PENDING_DELIVERY";

    /// <summary>
    /// Error saved when the most retries are used up.
    /// </summary>
    public const string MaxRetriesExceeded = "MAX_RETRIES_EXCEEDED";

    /// <summary>
    /// Audit event type when a notification is sent.
    /// </summary>
    public const string AuditEventDelivered = "PEER_NOTIFICATION_DELIVERED";

    /// <summary>
    /// Audit event type when sending a notification fails.
    /// </summary>
    public const string AuditEventFailed = "PEER_NOTIFICATION_FAILED";

    /// <summary>
    /// Name of the part of the app written in the audit rows.
    /// </summary>
    public const string SourceComponent = "PeerNotificationDeliveryService";

    /// <summary>
    /// Default most retries for sending a notification.
    /// </summary>
    public const int DefaultMaxRetries = 3;

    /// <summary>
    /// Gets the most retries from the environment.
    /// </summary>
    /// <returns>The value that is set, or the default when it is missing or not valid.</returns>
    public static int ResolveMaxRetries()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_PEER_NOTIFY_MAX_RETRIES");
        return int.TryParse(raw, out int value) && value > 0 ? value : DefaultMaxRetries;
    }
}
