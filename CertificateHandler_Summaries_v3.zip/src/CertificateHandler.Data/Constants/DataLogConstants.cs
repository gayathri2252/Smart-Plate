﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Texts written to the Log Monitor by the data layer, so every database action and every database server problem can be followed in the logs.
/// The logger fills in the values in the given order.
/// </summary>
public static class DataLogConstants
{
    #region Database Server

    /// <summary>Error message when the database server cannot be reached. The values are the server and the error.</summary>
    public const string DB_SERVER_UNREACHABLE = "The database server %s could not be reached: %s";

    /// <summary>Information message when the database is checked at startup. The value is the database name.</summary>
    public const string DB_BOOTSTRAP_STARTED = "Checking the database %s on the database server.";

    /// <summary>Information message when the startup checks are turned off.</summary>
    public const string DB_BOOTSTRAP_SKIPPED = "The database check at start-up is switched off, so the database was not checked.";

    /// <summary>Success message when the database did not exist and was created. The value is the database name.</summary>
    public const string DB_CREATED = "The database %s did not exist and was created.";

    /// <summary>Information message when the schema is already there. The value is the database name.</summary>
    public const string DB_SCHEMA_PRESENT = "The database %s is ready; the schema is already applied.";

    /// <summary>Success message when the schema was applied. The value is the database name.</summary>
    public const string DB_SCHEMA_APPLIED = "The schema was applied to the database %s.";

    /// <summary>Error message when the database could not be prepared. The values are the database name and the error.</summary>
    public const string DB_BOOTSTRAP_FAILED = "The database %s could not be prepared at start-up: %s";

    #endregion

    #region Blacklist and Whitelist

    /// <summary>Success message when a certificate was added to the blacklist. The values are the thumbprint, the result and the reason.</summary>
    public const string BLACK_LIST_SAVED = "Certificate %s was blacklisted (%s). Reason: %s";

    /// <summary>Information message when the certificate was already on the blacklist. The value is the thumbprint.</summary>
    public const string BLACK_LIST_ALREADY_ACTIVE = "Certificate %s is already on the blacklist; nothing was changed.";

    /// <summary>Warning message when the certificate to add to the blacklist is not saved. The value is the thumbprint.</summary>
    public const string BLACK_LIST_CERTIFICATE_NOT_FOUND = "Certificate %s could not be blacklisted because it is not stored in the database.";

    /// <summary>Error message when adding to the blacklist failed. The values are the thumbprint and the error.</summary>
    public const string BLACK_LIST_SAVE_FAILED = "Certificate %s could not be blacklisted: %s";

    /// <summary>Information message when the blacklist was checked. The values are the thumbprint and the result, true or false.</summary>
    public const string BLACK_LIST_CHECKED = "Blacklist checked for certificate %s: blacklisted = %s.";

    /// <summary>Error message when the blacklist could not be checked. The values are the thumbprint and the error.</summary>
    public const string BLACK_LIST_LOOKUP_FAILED = "The blacklist could not be checked for certificate %s: %s";

    /// <summary>Information message when the whitelist was checked. The values are the thumbprint and the result, true or false.</summary>
    public const string WHITELIST_CHECKED = "Whitelist checked for certificate %s: whitelisted = %s.";

    /// <summary>Error message when the whitelist could not be checked. The values are the thumbprint and the error.</summary>
    public const string WHITELIST_LOOKUP_FAILED = "The whitelist could not be checked for certificate %s: %s";

    #endregion

    #region Pending Requests

    /// <summary>Information message when pending requests were read. The value is the number read.</summary>
    public const string PENDING_REQUESTS_READ = "%s pending request(s) were read from the database.";

    /// <summary>Error message when pending requests could not be read. The value is the error.</summary>
    public const string PENDING_REQUESTS_READ_FAILED = "The pending requests could not be read from the database: %s";

    /// <summary>Information message when requests older than the timeout were found. The values are the number and the timeout in hours.</summary>
    public const string EXPIRED_REQUESTS_FOUND = "%s pending request(s) are older than %s hours and will be marked as Expired.";

    /// <summary>Error message when the requests to expire could not be read. The value is the error.</summary>
    public const string EXPIRED_REQUESTS_READ_FAILED = "The pending requests to expire could not be read from the database: %s";

    /// <summary>Success message when a request was marked as expired. The value is the request id.</summary>
    public const string REQUEST_MARKED_EXPIRED = "Pending request %s was marked as Expired after the timeout.";

    /// <summary>Information message when the request was decided before it could expire. The value is the request id.</summary>
    public const string REQUEST_ALREADY_DECIDED = "Pending request %s was not expired because it was already approved or rejected.";

    /// <summary>Error message when a request could not be marked as expired. The values are the request id and the error.</summary>
    public const string REQUEST_EXPIRE_FAILED = "Pending request %s could not be marked as Expired: %s";

    /// <summary>Error message when the open peer requests could not be counted. The value is the error.</summary>
    public const string PEER_REQUEST_COUNT_FAILED = "The open peer requests could not be counted: %s";

    /// <summary>Error message when an unknown peer could not be added to the queue. The values are the device and the error.</summary>
    public const string PEER_REQUEST_ADD_FAILED = "The unknown peer %s could not be added to the pending queue: %s";

    #endregion

    #region Trust Updates

    /// <summary>Information message when a test trust update was sent. The values are the change and the thumbprint.</summary>
    public const string TRUST_UPDATE_SIMULATED = "Trust update %s for certificate %s was published (simulated publisher).";

    /// <summary>Warning message when the test publisher was told to fail. The value is the thumbprint.</summary>
    public const string TRUST_UPDATE_SIMULATED_FAILURE = "The simulated publisher failed the trust update for certificate %s on purpose (failure flag file found).";

    #endregion

    #region Administrator

    /// <summary>Information message when an administrator check was made. The values are the user name and the result.</summary>
    public const string ADMINISTRATOR_CHECKED = "Administrator check for user %s: administrator = %s.";

    /// <summary>Warning message when the administrator check was asked for an empty user name.</summary>
    public const string ADMINISTRATOR_CHECK_NO_USER = "Administrator check made without a user name; access is denied.";

    #endregion
}
