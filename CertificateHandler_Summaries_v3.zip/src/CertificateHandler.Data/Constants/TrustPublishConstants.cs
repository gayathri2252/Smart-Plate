﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Constants for sending saved trust changes.
/// </summary>
public static class TrustPublishConstants
{
    #region Member Variables

    /// <summary>Event type of the audit row written when sending fails.</summary>
    public const string AUDIT_EVENT_TYPE = "TRUST_PUBLISH_FAILED";

    /// <summary>Result saved in the audit row of a failed send.</summary>
    public const string RESULT_FAILURE = "FAILURE";

    /// <summary>Action status saved in the audit row of a failed send.</summary>
    public const string ACTION_PUBLISH_FAILED = "PUBLISH_FAILED";

    /// <summary>Name of the part of the app written in the audit row.</summary>
    public const string SOURCE_COMPONENT = "TrustPublisher";

    /// <summary>Name of the flag file that makes the test publisher throw, for QA only.</summary>
    public const string SIMULATE_FAILURE_FLAG_FILE = "simulate-publish-failure.flag";

    /// <summary>Longest error text kept in the audit row.</summary>
    public const int MAX_ERROR_LENGTH = 500;

    /// <summary>Name of the audit table.</summary>
    public const string AUDIT_LOG_TABLE = "ch_audit_log";

    /// <summary>Columns filled by the audit row of a failed send, in the order of the values.</summary>
    public const string AUDIT_INSERT_COLUMNS = "event_type, event_timestamp, actor_identity, certificate_id, thumbprint_sha256, " + "action_status, reason, details_json, result, source_component";

    /// <summary>Text saved when the error has no message.</summary>
    public const string UNKNOWN_ERROR_TEXT = "Unknown error";

    /// <summary>Key of the change in the details JSON.</summary>
    public const string DETAILS_CHANGE = "change";

    /// <summary>Key of the save time in the details JSON.</summary>
    public const string DETAILS_SAVED_AT = "savedAt";

    /// <summary>Key of the error type in the details JSON.</summary>
    public const string DETAILS_ERROR_TYPE = "errorType";

    /// <summary>Key of the error text in the details JSON.</summary>
    public const string DETAILS_ERROR = "error";

    /// <summary>Error text thrown by the test publisher when the flag file exists.</summary>
    public const string SIMULATED_FAILURE_MESSAGE = $"Simulated publish failure ({SIMULATE_FAILURE_FLAG_FILE} exists).";

    /// <summary>Number of thumbprint characters shown in the administrator notice.</summary>
    public const int SHORT_THUMBPRINT_LENGTH = 8;

    /// <summary>Placeholder in the message texts that is replaced by the value.</summary>
    public const string MESSAGE_PLACEHOLDER = "%s";

    /// <summary>Logged when the service is created without a publisher.</summary>
    public const string PUBLISHER_IS_NULL = "The publish service cannot be created because no publisher was given.";

    /// <summary>Logged when the service is created without an audit writer.</summary>
    public const string AUDIT_WRITER_IS_NULL = "The publish service cannot be created because no audit writer was given.";

    /// <summary>Logged when the service is created without an administrator notifier.</summary>
    public const string NOTIFIER_IS_NULL = "The publish service cannot be created because no administrator notifier was given.";

    /// <summary>Logged when the wrapper is created without the inner blacklist.</summary>
    public const string INNER_BLACKLIST_IS_NULL = "The publishing blacklist cannot be created because no inner blacklist was given.";

    /// <summary>Logged when the wrapper is created without a publish service.</summary>
    public const string PUBLISH_SERVICE_IS_NULL = "The publishing blacklist cannot be created because no publish service was given.";

    /// <summary>Logged when the audit writer is created without a database context.</summary>
    public const string DB_CONTEXT_IS_NULL = "The publish failure audit writer cannot be created because no database context was given.";

    /// <summary>Logged when a send starts. The value is the thumbprint.</summary>
    public const string PUBLISH_STARTED = "Publishing the saved trust update for thumbprint %s.";

    /// <summary>Logged when a send worked. The value is the thumbprint.</summary>
    public const string PUBLISH_SUCCEEDED = "The trust update for thumbprint %s was published.";

    /// <summary>Logged when a send failed. The values are the thumbprint and the error text.</summary>
    public const string PUBLISH_FAILED = "Publishing the trust update for thumbprint %s failed. The saved trust row is kept. Error: %s";

    /// <summary>Logged when the failure audit row is written. The value is the thumbprint.</summary>
    public const string AUDIT_WRITTEN = "The publish failure for thumbprint %s was written to the audit log.";

    /// <summary>Logged when the failure audit row cannot be written. The values are the thumbprint and the error text.</summary>
    public const string AUDIT_FAILED = "The publish failure for thumbprint %s could not be written to the audit log: %s";

    /// <summary>Logged when the administrator was told. The value is the thumbprint.</summary>
    public const string NOTIFICATION_SENT = "The administrator was notified about the publish failure for thumbprint %s.";

    /// <summary>Logged when the message to the administrator failed. The values are the thumbprint and the error text.</summary>
    public const string NOTIFICATION_FAILED = "The administrator could not be notified about the publish failure for thumbprint %s: %s";

    /// <summary>Logged when the send was cancelled. The value is the thumbprint.</summary>
    public const string PUBLISH_CANCELLED = "Publishing the trust update for thumbprint %s was cancelled.";

    /// <summary>Text shown to the administrator. The value is the short thumbprint.</summary>
    public const string ADMIN_NOTICE = "The trust change for thumbprint %s was saved, but it could not be published. Check the audit log.";

    #endregion
}
