﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Page sizes, expiry windows, the validation failure window and request type names used by the
/// certificate dashboard.
/// </summary>
public static class Constants
{
    #region Member Variables

    /// <summary>Number of the first page.</summary>
    public const int FIRST_PAGE_NUMBER = 1;

    /// <summary>Smallest allowed number of rows on a page.</summary>
    public const int MIN_PAGE_SIZE = 1;

    /// <summary>Number of rows on a page when no page size is given.</summary>
    public const int DEFAULT_PAGE_SIZE = 10;

    /// <summary>Largest allowed number of rows on a page, so a load stays small.</summary>
    public const int MAX_PAGE_SIZE = 200;

    /// <summary>Days ahead counted as expiring soon.</summary>
    public const int EXPIRING_SOON_DAYS = 30;

    /// <summary>Days ahead counted as expiring later. This also covers the first window.</summary>
    public const int EXPIRING_LATER_DAYS = 90;

    /// <summary>Hours of validation failures counted when the window setting is missing or not valid.</summary>
    public const int DEFAULT_VALIDATION_FAILURE_WINDOW_HOURS = 24;

    /// <summary>Smallest allowed validation failure window in hours.</summary>
    public const int MIN_VALIDATION_FAILURE_WINDOW_HOURS = 1;

    /// <summary>Largest allowed validation failure window in hours, which is one year. A larger value is not used.</summary>
    public const int MAX_VALIDATION_FAILURE_WINDOW_HOURS = 8760;

    /// <summary>Longest search text used to filter the request overview. Longer text is cut.</summary>
    public const int MAX_SEARCH_LENGTH = 100;

    /// <summary>Database name of the peer onboarding request type.</summary>
    public const string PEER_ONBOARDING_DB_NAME = "PEER_ONBOARDING";

    /// <summary>Database name of the reinstatement request type.</summary>
    public const string REINSTATEMENT_DB_NAME = "REINSTATEMENT";

    /// <summary>Database name of the whitelist to blacklist request type.</summary>
    public const string WHITELIST_TO_BLACKLIST_DB_NAME = "WHITELIST_TO_BLACKLIST";

    /// <summary>Request type text shown for a peer onboarding request.</summary>
    public const string PEER_ONBOARDING_TEXT = "Peer onboarding";

    /// <summary>Request type text shown for a reinstatement request.</summary>
    public const string REINSTATEMENT_TEXT = "Reinstatement";

    /// <summary>Request type text shown for a whitelist to blacklist request.</summary>
    public const string WHITELIST_TO_BLACKLIST_TEXT = "Whitelist to blacklist";

    /// <summary>Database role name of the local SBC certificate.</summary>
    public const string LOCAL_SBC_ROLE = "LOCAL_SBC";

    /// <summary>Database role name of the local MIB certificate.</summary>
    public const string LOCAL_MIB_ROLE = "LOCAL_MIB";

    /// <summary>SQL parameter name for certificate roles.</summary>
    public const string CERTIFICATE_ROLES_PARAMETER = "certificateRoles";

    /// <summary>Reader column number of the certificate role.</summary>
    public const int ROLE_COLUMN = 0;

    /// <summary>Reader column number of the subject.</summary>
    public const int SUBJECT_COLUMN = 1;

    /// <summary>Reader column number of the thumbprint.</summary>
    public const int THUMBPRINT_COLUMN = 2;

    /// <summary>Reader column number of the expiry date.</summary>
    public const int NOT_AFTER_COLUMN = 3;

    /// <summary>Reader column number of the issuer.</summary>
    public const int ISSUER_COLUMN = 4;

    /// <summary>
    /// Display name of the SBC certificate role.
    /// </summary>
    public const string SBC_ROLE_NAME = "SBC";

    /// <summary>
    /// Display name of the MIB certificate role.
    /// </summary>
    public const string MIB_ROLE_NAME = "MIB";

    /// <summary>
    /// Date format in UTC used when certificate expiry dates are logged.
    /// </summary>
    public const string DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";


    /// <summary>Logged when the reader is created without a data source.</summary>
    public const string READER_DATA_SOURCE_IS_NULL = "The certificate reader cannot be created because no database connection was given.";

    /// <summary>Logged when the service is created without a reader.</summary>
    public const string SERVICE_READER_IS_NULL = "The certificate information service cannot be created because no certificate reader was given.";

    /// <summary>Logged when the service is created without an authorizer.</summary>
    public const string SERVICE_AUTHORIZER_IS_NULL = "The certificate information service cannot be created because no administrator check was given.";

    /// <summary>Logged when the service is created without a status calculator.</summary>
    public const string SERVICE_CALCULATOR_IS_NULL = "The certificate information service cannot be created because no status calculator was given.";

    /// <summary>Logged when the service is created without a clock.</summary>
    public const string SERVICE_CLOCK_IS_NULL = "The certificate information service cannot be created because no clock was given.";

    /// <summary>Logged when a caller who is not an administrator asks for certificate information.</summary>
    public const string CALLER_NOT_AUTHORIZED = "User %s is not an administrator. No certificate information was returned.";

    /// <summary>Logged when certificate retrieval starts.</summary>
    public const string RETRIEVAL_STARTED = "Reading the SBC and MIB certificate information for administrator %s.";

    /// <summary>Logged when the certificates were read. The value is the number of certificates found.</summary>
    public const string RETRIEVAL_SUCCEEDED = "Read %s active SBC and MIB certificates.";

    /// <summary>Logged when a role has no active certificate.</summary>
    public const string CERTIFICATE_NOT_FOUND = "No active %s certificate was found.";

    /// <summary>Logged when a certificate has expired or will expire soon. The values are the role, the status and the date.</summary>
    public const string CERTIFICATE_STATUS_WARNING = "The %s certificate status is %s. It is valid until %s.";

    /// <summary>Logged when the certificates cannot be read from the database. The value is the error.</summary>
    public const string RETRIEVAL_FAILED = "Reading the SBC and MIB certificate information failed: %s";

    /// <summary>Logged when a stored certificate row has a role that is not SBC or MIB.</summary>
    public const string UNEXPECTED_ROLE = "A certificate row with the unexpected role %s was skipped.";

    /// <summary>Logged for every certificate that is read. The values are the role, subject, end date and status.</summary>
    public const string CERTIFICATE_DETAILS = "Certificate %s: subject %s, valid until %s, status %s.";

    /// <summary>Logged for every certificate that is read. The value is the issuer.</summary>
    public const string CERTIFICATE_ISSUER = "Certificate %s issuer %s.";

    /// <summary>Logged as an error when a certificate has expired. The values are the certificate role and its end date.</summary>
    public const string CERTIFICATE_EXPIRED_ERROR = "The %s certificate has expired. It was valid until %s.";

    #endregion
}
