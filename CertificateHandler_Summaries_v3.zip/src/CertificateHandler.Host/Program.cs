﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Text.Json;
using CertificateHandler.Audit.Services;
using CertificateHandler.CertificateManagement.Services;
using CertificateHandler.Communication.Tls;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Options;
using CertificateHandler.Audit.Models;
using CertificateHandler.Data;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using Microsoft.Extensions.Configuration;

namespace CertificateHandler.Host;

/// <summary>
/// Entry point of the Certificate Handler application.
/// It prepares the database, checks the PostgreSQL connection and starts the pending request expiry service.
/// </summary>
internal static class Program
{
    #region Private Methods

    private static void RunGcCertificateStatusExport(string[] args)
    {
        var databaseOptions = LoadDatabaseOptions(args);
        if (!TryInitializeDatabase(databaseOptions))
        {
            Environment.ExitCode = 1;
            return;
        }

        using var dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);
        var service = new GcCertificateStatusService(
            new CertificateExpiryReader(dataAccess.DataSource),
            new CertificateExpiryStatusCalculator(),
            new AdministratorAuthorizer());

        string user = ResolveGcExportPrincipalUserName();

        try
        {
            var snapshot = service.GetSnapshotForAdministratorAsync(user).GetAwaiter().GetResult();
            string json = JsonSerializer.Serialize(snapshot, new JsonSerializerOptions { WriteIndented = true });
            Console.WriteLine(json);
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.Error.WriteLine(ex.Message);
            Environment.ExitCode = 2;
        }
    }

    /// <summary>
    /// Starts the application: loads the database options, initializes the database,
    /// verifies the connection and runs the certificate management harness.
    /// </summary>
    private static void Main(string[] args)
    {
        if (args.Contains("--gc-cert-status", StringComparer.OrdinalIgnoreCase))
        {
            RunGcCertificateStatusExport(args);
            return;
        }

        var databaseOptions = LoadDatabaseOptions(args);

        bool isDatabaseInitialized = TryInitializeDatabase(databaseOptions);

        if (!isDatabaseInitialized)
        {
            return;
        }

        // Verifies the same connection the application uses, including the
        // client certificate and server certificate checks. Every step is
        // written to the log driver.
        bool isConnectionVerified = TestConnection(databaseOptions);

        if (!isConnectionVerified)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Startup stopped: the PostgreSQL connection check failed.");
            return;
        }

        if (args.Contains("--connection-manager", StringComparer.OrdinalIgnoreCase)
            || args.Contains("--dev-peer-listener", StringComparer.OrdinalIgnoreCase))
        {
            RunConnectionManager(databaseOptions);
            return;
        }

        if (args.Contains("--wire-listener", StringComparer.OrdinalIgnoreCase))
        {
            if (ShouldRunConnectionManagerFromEnvironment())
            {
                RunConnectionManager(databaseOptions);
                return;
            }

            WirePeerConnectionPipeline(databaseOptions);
        }

        RunCertificateManagementHarness(databaseOptions);
    }

    /// <summary>
    /// Reads the database options from appsettings.json and the environment variables.
    /// The --skip-db-bootstrap argument turns the database bootstrap off.
    /// </summary>
    private static DatabaseOptions LoadDatabaseOptions(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        var databaseOptions = configuration.GetSection(DatabaseOptions.SectionName).Get<DatabaseOptions>()
            ?? new DatabaseOptions();

        if (args.Contains("--skip-db-bootstrap", StringComparer.OrdinalIgnoreCase))
        {
            databaseOptions.SkipBootstrap = true;
        }

        return databaseOptions;
    }

    /// <summary>
    /// Creates the database and schema when they are missing and opens a first connection.
    /// Returns false and logs the reason when the database cannot be used.
    /// </summary>
    private static bool TryInitializeDatabase(DatabaseOptions databaseOptions)
    {
        try
        {
            DatabaseSetup.EnsureReady(databaseOptions, CreateKeyProtector());

            // Opens the connection directly. Unlike Database.CanConnect(), which
            // hides the reason and only returns false, a failure here throws and
            // its real message (password, certificate, TLS, permission) is logged below.
            using var dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);
            using var connection = dataAccess.OpenConnectionAsync().AsTask().GetAwaiter().GetResult();

            CertificateHandlerLogger.Success(
                MessageIdGenerator.Next(),
                "Certificate Handler database is ready.");
            return true;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Database initialization failed (ensure PostgreSQL is running and CH_DB_ADMIN_PASSWORD is set for the first set-up): %s",
                ex.Message);
            return false;
        }
    }

    /// <summary>
    /// Creates the protector that seals the database password on this computer. Works on Windows only.
    /// </summary>
    private static DpapiKeyProtector CreateKeyProtector()
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new PlatformNotSupportedException("The database password can be sealed on Windows only.");
        }

        return new DpapiKeyProtector();
    }

    /// <summary>
    /// Checks that a connection to PostgreSQL can be opened with the configured TLS settings.
    /// </summary>
    private static bool TestConnection(DatabaseOptions databaseOptions)
    {
        return CertificateHandlerData.TestConnectionAsync(databaseOptions).GetAwaiter().GetResult();
    }

    private static string ResolveGcExportPrincipalUserName()
    {
        if (OperatingSystem.IsWindows())
        {
            try
            {
                using WindowsIdentity identity = WindowsIdentity.GetCurrent();
                if (!string.IsNullOrWhiteSpace(identity.Name))
                {
                    return identity.Name.Split('\\').Last();
                }
            }
            catch (SecurityException)
            {
            }
        }

        return Environment.UserName;
    }

    private static bool ShouldRunConnectionManagerFromEnvironment() =>
        string.Equals(Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_RUN"), "1", StringComparison.Ordinal)
        || string.Equals(Environment.GetEnvironmentVariable("CH_PEER_LISTENER_RUN"), "1", StringComparison.Ordinal);

    /// <summary>
    /// Runs the MAXUM Connection Manager (inbound listener + outbound connector) until a key is pressed.
    /// </summary>
    private static void RunConnectionManager(DatabaseOptions databaseOptions)
    {
        try
        {
            using var dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);
            using PeerConnectionHostResources host = PeerConnectionHostResources.Create(dataAccess);
            MaxumConnectionManagerOptions options = MaxumConnectionManagerOptions.FromEnvironment();
            using var manager = MaxumConnectionManager.Create(host, options);
            manager.StartListener();

            Console.WriteLine(
                $"Connection Manager ready (listen={options.ListenEnabled} {options.BindAddress}:{options.ListenPort}, mTLS → PeerConnectionPipeline).");
            Console.WriteLine("Outbound: use ConnectToPeerAsync from hosted service / future API.");
            Console.WriteLine("Press any key to stop.");
            Console.ReadKey(intercept: true);
            manager.StopListener();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Connection Manager failed: %s",
                ex.Message);
            Console.Error.WriteLine(ex.Message);
            Environment.ExitCode = 1;
        }
    }

    /// <summary>
    /// Builds the peer connection pipeline for the MAXUM listener team and logs readiness.
    /// </summary>
    private static void WirePeerConnectionPipeline(DatabaseOptions databaseOptions)
    {
        try
        {
            using var dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);
            using PeerConnectionHostResources host = PeerConnectionHostResources.Create(dataAccess);
            CertificateHandlerLogger.Success(
                MessageIdGenerator.Next(),
                "Peer connection pipeline is ready (validation, authorization, TLS gate).");
            Console.WriteLine("PeerConnectionPipeline wired; inject host.Pipeline.ProcessAsync at listener entry.");
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Peer connection pipeline wiring failed: %s",
                ex.Message);
        }
    }

    /// <summary>
    /// Creates the sample audits and runs the pending request expiry service.
    /// </summary>
    private static void RunCertificateManagementHarness(DatabaseOptions databaseOptions)
    {
        var pendingRequestManager = CreateSampleAudits(out TimeoutConfiguration timeoutConfiguration);

        RunPendingRequestExpiryService(databaseOptions, pendingRequestManager, timeoutConfiguration);
    }

    /// <summary>
    /// Creates the sample approval, rejection and expiry audits.
    /// </summary>
    private static PendingRequestManager CreateSampleAudits(out TimeoutConfiguration timeoutConfiguration)
    {
        WhitelistApprovalService service = new WhitelistApprovalService();

        service.ApproveRequest(new WhitelistDecision
        {
            AuditId = 1,
            RequestId = "REQ001",
            DeviceId = "DEV001",
            DeviceName = "Laptop01",
            Thumbprint = "ABC123",
            CertificateSubject = "CN=TestCertificate",
            ApproverName = "Pooja",
            Reason = "Testing Approval"
        });

        service.RejectRequest(new WhitelistDecision
        {
            AuditId = 2,
            RequestId = "REQ002",
            DeviceId = "DEV002",
            DeviceName = "Laptop02",
            Thumbprint = "XYZ456",
            CertificateSubject = "CN=TestCertificate2",
            ApproverName = "Pooja",
            Reason = "Testing Rejection"
        });

        timeoutConfiguration = new TimeoutConfiguration();
        AuditLogService auditLogService = new AuditLogService();
        PendingRequestManager pendingRequestManager = new PendingRequestManager(timeoutConfiguration, auditLogService);

        Shared.Models.PendingCertificateRequest expiredRequest = new Shared.Models.PendingCertificateRequest
        {
            RequestID = "REQ003",
            DeviceID = "DEV003",
            Status = "Pending",
            CreatedTime = DateTime.UtcNow.AddHours(-25)
        };

        pendingRequestManager.ExpirePendingRequest(expiredRequest);

        Console.WriteLine("Approval, Rejection and Expiry audits created successfully.");

        return pendingRequestManager;
    }

    /// <summary>
    /// Runs the expiry service against the database until a key is pressed.
    /// </summary>
    private static void RunPendingRequestExpiryService(
        DatabaseOptions databaseOptions,
        PendingRequestManager pendingRequestManager,
        TimeoutConfiguration timeoutConfiguration)
    {
        // The data access object and the DbContext must stay alive for as
        // long as the timer runs, so they are disposed only after
        // monitoring has been stopped.
        using var dataAccess = CertificateHandlerDataAccess.Create(databaseOptions);
        using var dbContext = dataAccess.CreateDbContext();

        var pendingRequestRepository = new CertificatePendingRequest(dbContext);
        using var expiryService = new PendingRequestExpiryService(
            pendingRequestManager,
            pendingRequestRepository,
            timeoutConfiguration);

        expiryService.StartMonitoring();

        int delivered = new PeerNotificationDeliveryService(dataAccess.DataSource)
            .DeliverPendingAsync().GetAwaiter().GetResult();
        if (delivered > 0)
        {
            Console.WriteLine($"Delivered {delivered} peer notification(s).");
        }

        Console.WriteLine("Press any key to stop.");
        Console.ReadKey(intercept: true);
        expiryService.StopMonitoring();
    }

    #endregion
}
