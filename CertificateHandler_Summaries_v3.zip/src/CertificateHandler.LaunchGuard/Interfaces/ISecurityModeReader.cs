// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.LaunchGuard.Enums;

namespace CertificateHandler.LaunchGuard.Interfaces;

/// <summary>
/// Reads the device security mode from persistent configuration (RS_31).
/// </summary>
public interface ISecurityModeReader
{
    #region Public Methods

    /// <summary>
    /// Returns the current security mode.
    /// </summary>
    SecurityMode Read();

    #endregion
}
