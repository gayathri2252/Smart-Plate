// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.LaunchGuard.Enums;

/// <summary>
/// Device security mode stored by the Commissioning Wizard (RS_31).
/// </summary>
public enum SecurityMode
{
    #region Values

    /// <summary>Mode could not be read; Certificate Handler starts with Secure TLS defaults (RS_31).</summary>
    Unknown = 0,

    /// <summary>TLS-only operation; Certificate Handler may start.</summary>
    Secure,

    /// <summary>Same TLS behavior as Secure for Certificate Handler.</summary>
    Hybrid,

    /// <summary>Certificate Handler must not start.</summary>
    Unsecure

    #endregion
}
