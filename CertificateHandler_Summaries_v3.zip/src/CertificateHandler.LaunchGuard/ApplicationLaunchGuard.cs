// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.LaunchGuard.Enums;
using CertificateHandler.LaunchGuard.Interfaces;

namespace CertificateHandler.LaunchGuard;

/// <summary>
/// Applies RS_31 launch rules for the Certificate Handler.
/// </summary>
public sealed class ApplicationLaunchGuard
{
    #region Member Variables

    private readonly ISecurityModeReader _securityModeReader;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the guard. The reader must not be null.
    /// </summary>
    public ApplicationLaunchGuard(ISecurityModeReader securityModeReader)
    {
        _securityModeReader = securityModeReader ?? throw new ArgumentNullException(nameof(securityModeReader));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns whether the application may continue starting.
    /// </summary>
    public LaunchGuardResult Evaluate()
    {
        SecurityMode mode = _securityModeReader.Read();
        return mode switch
        {
            SecurityMode.Secure or SecurityMode.Hybrid => LaunchGuardResult.Allow(mode),
            SecurityMode.Unsecure => LaunchGuardResult.Block(
                mode,
                "Certificate Handler is not available when the device is in Unsecure mode."),
            // RS_31 AC4: missing/invalid registry → treat as Secure and continue (warning logged at UI startup).
            SecurityMode.Unknown => LaunchGuardResult.Allow(SecurityMode.Secure),
            _ => LaunchGuardResult.Allow(SecurityMode.Secure)
        };
    }

    #endregion
}

/// <summary>
/// Result of the launch guard check.
/// </summary>
public sealed class LaunchGuardResult
{
    #region Public Properties

  public bool MayStart { get; init; }

  public SecurityMode Mode { get; init; }

  public string Message { get; init; } = string.Empty;

    #endregion

    #region Public Methods

    public static LaunchGuardResult Allow(SecurityMode mode) =>
        new() { MayStart = true, Mode = mode };

    public static LaunchGuardResult Block(SecurityMode mode, string message) =>
        new() { MayStart = false, Mode = mode, Message = message };

    #endregion
}
