// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Timers;
using CertificateHandler.Data.Entities;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Watches pending certificate requests and expires them after the set timeout.
/// </summary>
public class PendingRequestExpiryService : IDisposable
{
    #region Member Variables

    /// <summary>
    /// Default time between two expiry checks, in milliseconds.
    /// </summary>
    private const double DEFAULT_EXPIRY_CHECK_INTERVAL_MILLISECONDS = 60000;

    /// <summary>
    /// Timer that starts the expiry checks.
    /// </summary>
    private readonly System.Timers.Timer _expiryTimer;

    /// <summary>
    /// Expires the pending requests and writes the audit records.
    /// </summary>
    private readonly PendingRequestManager _pendingRequestManager;

    /// <summary>
    /// Store that holds the pending requests.
    /// </summary>
    private readonly ICertificatePendingRequest _pendingRequestRepository;

    /// <summary>
    /// Timeout settings for the pending requests.
    /// </summary>
    private readonly TimeoutConfiguration _timeoutConfiguration;

    /// <summary>
    /// True when the service is disposed.
    /// </summary>
    private bool _disposed;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. The timer checks for expired requests every minute unless another interval is given.
    /// </summary>
    /// <param name="pendingRequestManager">Manager that expires the requests.</param>
    /// <param name="pendingRequestRepository">Database access for the pending requests.</param>
    /// <param name="timeoutConfiguration">The timeout settings.</param>
    /// <param name="expiryCheckIntervalMilliseconds">Time between checks, in milliseconds.</param>
    public PendingRequestExpiryService(
        PendingRequestManager pendingRequestManager,
        ICertificatePendingRequest pendingRequestRepository,
        TimeoutConfiguration timeoutConfiguration,
        double expiryCheckIntervalMilliseconds = DEFAULT_EXPIRY_CHECK_INTERVAL_MILLISECONDS)
    {
        ArgumentNullException.ThrowIfNull(pendingRequestManager);
        ArgumentNullException.ThrowIfNull(pendingRequestRepository);
        ArgumentNullException.ThrowIfNull(timeoutConfiguration);

        _pendingRequestManager = pendingRequestManager;
        _pendingRequestRepository = pendingRequestRepository;
        _timeoutConfiguration = timeoutConfiguration;
        _expiryTimer = new System.Timers.Timer(expiryCheckIntervalMilliseconds);
        _expiryTimer.Elapsed += OnExpiryTimerElapsed;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts watching pending requests for expiry.
    /// </summary>
    public void StartMonitoring()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        _expiryTimer.Start();
    }

    /// <summary>
    /// Stops watching pending requests.
    /// </summary>
    public void StopMonitoring()
    {
        if (_disposed)
        {
            return;
        }

        _expiryTimer.Stop();
    }

    /// <summary>
    /// Loads the saved pending requests that are older than the timeout and expires each one. An error on one request is logged and does not stop the others.
    /// </summary>
    public async Task ExpirePendingRequestsAsync()
    {
        List<PendingRequest>? pendingRequests =
            await _pendingRequestRepository.GetExpiredCertificateRequestsAsync(
                _timeoutConfiguration.PendingRequestExpiryTimeout);

        if (pendingRequests is null || pendingRequests.Count == 0)
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                RequestStatusConstants.NO_PENDING_REQUESTS_FOUND,
                _timeoutConfiguration.PendingRequestExpiryTimeout.ToString());
            return;
        }

        foreach (PendingRequest storedRequest in pendingRequests)
        {
            if (storedRequest is null)
            {
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    RequestStatusConstants.REQUEST_DATA_MISSING);
                continue;
            }

            try
            {
                await ExpirePendingRequestAsync(storedRequest);
            }
            catch (Exception ex)
            {
                CertificateHandlerLogger.Error(
                    MessageIdGenerator.Next(),
                    RequestStatusConstants.REQUEST_EXPIRY_FAILED,
                    storedRequest.RequestId.ToString(),
                    ex.Message);
            }
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Runs when the timer fires. It catches all errors because an async void method cannot pass them on.
    /// </summary>
    /// <param name="sender">The timer.</param>
    /// <param name="e">Timer event data.</param>
    private async void OnExpiryTimerElapsed(object? sender, ElapsedEventArgs e)
    {
        // Dispose removes this handler, but a tick that has already started can still arrive.
        // Return here so a disposed service does not query the database.
        if (_disposed)
        {
            return;
        }

        try
        {
            await ExpirePendingRequestsAsync();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                RequestStatusConstants.EXPIRY_CHECK_FAILED,
                ex.Message);
        }
    }

    /// <summary>
    /// Expires one saved request. It marks the request as expired in memory, writes the audit record and then marks the database row as expired.
    /// Logs a warning when the request was already decided.
    /// </summary>
    /// <param name="storedRequest">The saved request to expire.</param>
    private async Task ExpirePendingRequestAsync(PendingRequest storedRequest)
    {
        PendingCertificateRequest requestToExpire = MapToPendingCertificateRequest(storedRequest);

        // Sets Status and ExpiryTime on the in-memory object, logs,
        // and writes the audit record.
        _pendingRequestManager.ExpirePendingRequest(requestToExpire);

        bool isUpdated = await _pendingRequestRepository.MarkAsExpiredAsync(
            storedRequest.RequestId,
            requestToExpire.ExpiryTime.GetValueOrDefault(DateTime.UtcNow));

        // MarkAsExpiredAsync only updates a row that is still Pending. It returns false when the
        // request was approved or rejected after it was loaded, so the expiry is not applied.
        if (!isUpdated)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                RequestStatusConstants.REQUEST_ALREADY_DECIDED,
                storedRequest.RequestId.ToString());
        }
    }

    /// <summary>
    /// Turns the database row into the request object that PendingRequestManager uses. Throws ArgumentNullException when the saved request is null.
    /// </summary>
    /// <param name="storedRequest">The saved request.</param>
    /// <returns>The pending certificate request.</returns>
    private static PendingCertificateRequest MapToPendingCertificateRequest(PendingRequest storedRequest)
    {
        ArgumentNullException.ThrowIfNull(storedRequest);

        return new PendingCertificateRequest
        {
            RequestID = storedRequest.RequestId.ToString(),
            DeviceID = storedRequest.DeviceId.ToString(),
            CertificateName = storedRequest.Certificate?.SubjectDn ?? string.Empty,
            Status = RequestStatusConstants.PENDING,
            CreatedTime = storedRequest.CreatedAt.UtcDateTime
        };
    }

    #endregion

    #region Dispose Methods

    /// <summary>
    /// Stops the timer and frees it. Call it when the service is no longer needed.
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Frees the timer when it exists. The Elapsed handler is removed first so no new check can start while the service is disposed.
    /// </summary>
    /// <param name="disposing">True when called from Dispose.</param>
    protected virtual void Dispose(bool disposing)
    {
        if (_disposed)
        {
            return;
        }

        if (disposing && _expiryTimer is not null)
        {
            _expiryTimer.Elapsed -= OnExpiryTimerElapsed;
            _expiryTimer.Stop();
            _expiryTimer.Dispose();
        }

        _disposed = true;
    }

    #endregion
}
