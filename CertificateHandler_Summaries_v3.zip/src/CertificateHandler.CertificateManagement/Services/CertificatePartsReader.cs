// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Formats.Asn1;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// The three parts of an X.509 certificate that the signature check needs.
/// </summary>
public sealed class CertificateParts
{
    /// <summary>
    /// The bytes that were signed, the full TBSCertificate with its tag and length.
    /// </summary>
    public required byte[] ToBeSigned { get; init; }

    /// <summary>
    /// OID of the signature algorithm, like 1.2.840.113549.1.1.11.
    /// </summary>
    public required string SignatureAlgorithmOid { get; init; }

    /// <summary>
    /// The signature value, the content of the BIT STRING.
    /// </summary>
    public required byte[] Signature { get; init; }

    /// <summary>
    /// The public key info of the certificate, in DER format.
    /// </summary>
    public required byte[] SubjectPublicKeyInfo { get; init; }
}

/// <summary>
/// Thrown when the certificate bytes are not a valid X.509 certificate.
/// </summary>
public sealed class CertificateFormatException : Exception
{
    /// <summary>
    /// Creates the exception with a message and the original error.
    /// </summary>
    /// <param name="message">The error message.</param>
    /// <param name="inner">The first error, or null.</param>
    public CertificateFormatException(string message, Exception? inner = null)
        : base(message, inner)
    {
    }
}

/// <summary>
/// Splits a DER certificate into the signed bytes, the signature algorithm and the signature value.
/// </summary>
public static class CertificatePartsReader
{
    #region Public Methods

    /// <summary>
    /// Reads the parts of the certificate. Throws CertificateFormatException when the bytes are damaged.
    /// </summary>
    /// <param name="rawCertificate">The certificate in DER format.</param>
    /// <returns>The parts of the certificate.</returns>
    public static CertificateParts Read(byte[]? rawCertificate)
    {
        if (rawCertificate is null || rawCertificate.Length == 0)
        {
            throw new CertificateFormatException("Certificate is empty.");
        }

        try
        {
            var outer = new AsnReader(rawCertificate, AsnEncodingRules.DER);
            AsnReader certificate = outer.ReadSequence();
            outer.ThrowIfNotEmpty();

            ReadOnlyMemory<byte> tbsEncoded = certificate.ReadEncodedValue();
            string outerOid = ReadAlgorithmOid(certificate.ReadSequence());
            byte[] signature = certificate.ReadBitString(out int unusedBits);
            certificate.ThrowIfNotEmpty();

            if (unusedBits != 0 || signature.Length == 0)
            {
                throw new CertificateFormatException("Signature value is not a whole number of bytes.");
            }

            AsnReader tbs = new AsnReader(tbsEncoded, AsnEncodingRules.DER).ReadSequence();
            SkipOptionalVersion(tbs);
            tbs.ReadEncodedValue();                                  // serialNumber
            string innerOid = ReadAlgorithmOid(tbs.ReadSequence());  // signature (must equal the outer one)
            tbs.ReadEncodedValue();                                  // issuer
            tbs.ReadEncodedValue();                                  // validity
            tbs.ReadEncodedValue();                                  // subject
            byte[] spki = tbs.ReadEncodedValue().ToArray();          // subjectPublicKeyInfo

            if (!string.Equals(outerOid, innerOid, StringComparison.Ordinal))
            {
                throw new CertificateFormatException("Signature algorithm differs inside and outside the signed part.");
            }

            return new CertificateParts
            {
                ToBeSigned = tbsEncoded.ToArray(),
                SignatureAlgorithmOid = outerOid,
                Signature = signature,
                SubjectPublicKeyInfo = spki
            };
        }
        catch (AsnContentException ex)
        {
            throw new CertificateFormatException("Certificate bytes are damaged: " + ex.Message, ex);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the algorithm id.
    /// </summary>
    /// <param name="algorithmIdentifier">Reader placed on the algorithm part.</param>
    /// <returns>The algorithm id.</returns>
    private static string ReadAlgorithmOid(AsnReader algorithmIdentifier) =>
        algorithmIdentifier.ReadObjectIdentifier();

    /// <summary>
    /// Skips the version field of the certificate when it is there.
    /// </summary>
    /// <param name="tbs">Reader placed on the signed part of the certificate.</param>
    private static void SkipOptionalVersion(AsnReader tbs)
    {
        var versionTag = new Asn1Tag(TagClass.ContextSpecific, 0);
        if (tbs.HasData && tbs.PeekTag().HasSameClassAndValue(versionTag))
        {
            tbs.ReadEncodedValue();
        }
    }

    #endregion
}
