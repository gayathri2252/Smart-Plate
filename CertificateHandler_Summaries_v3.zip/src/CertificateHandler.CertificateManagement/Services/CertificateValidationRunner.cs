﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Runs the validation steps in order. The signature step always runs first. When it rejects the certificate, the runner stops and no other step runs.
/// </summary>
public sealed class CertificateValidationRunner
{
    #region Member Variables

    /// <summary>
    /// The signature check. It always runs first.
    /// </summary>
    private readonly ICertificateValidationStep _signatureStep;

    /// <summary>
    /// The checks that run after the signature check, in order.
    /// </summary>
    private readonly IReadOnlyList<ICertificateValidationStep> _laterSteps;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the runner.
    /// </summary>
    /// <param name="signatureStep">The signature step. It runs before all other steps.</param>
    /// <param name="laterSteps">The chain, lifetime, revocation and trust list steps, in order. Can be empty.</param>
    public CertificateValidationRunner(
        ICertificateValidationStep signatureStep,
        IEnumerable<ICertificateValidationStep>? laterSteps = null)
    {
        _signatureStep = signatureStep ?? throw new ArgumentNullException(nameof(signatureStep));
        _laterSteps = (laterSteps ?? Enumerable.Empty<ICertificateValidationStep>()).ToList();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks one certificate and returns the trust result.
    /// </summary>
    /// <param name="context">Data of the certificate to check.</param>
    /// <returns>The trust result.</returns>
    public TrustValidationResult Run(CertificateValidationContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        string thumbprint = ComputeThumbprintSha256(context.RawCertificate);

        ValidationStepResult signature = _signatureStep.Validate(context);
        if (!signature.IsPass)
        {
            LogFailure(thumbprint, _signatureStep, signature);
            return Build(thumbprint, signature);
        }

        foreach (ICertificateValidationStep step in _laterSteps)
        {
            ValidationStepResult result = step.Validate(context);
            if (!result.IsPass)
            {
                LogFailure(thumbprint, step, result);
                return Build(thumbprint, result);
            }
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), CertificateManagementLogConstants.CERTIFICATE_VALIDATION_PASSED, thumbprint);

        return new TrustValidationResult
        {
            ThumbprintSha256 = thumbprint,
            Outcome = TrustValidationOutcome.Passed,
            EvaluatedAt = DateTimeOffset.UtcNow
        };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Writes a warning to the Log Monitor with the step that rejected the certificate and the reason.
    /// </summary>
    /// <param name="thumbprint">Thumbprint of the certificate.</param>
    /// <param name="step">The step that rejected the certificate.</param>
    /// <param name="rejected">The result of the step.</param>
    private static void LogFailure(string thumbprint, ICertificateValidationStep step, ValidationStepResult rejected)
    {
        CertificateHandlerLogger.Warning(
            MessageIdGenerator.Next(),
            CertificateManagementLogConstants.CERTIFICATE_VALIDATION_FAILED,
            thumbprint,
            step.GetType().Name,
            rejected.Outcome.ToString(),
            rejected.Reason ?? string.Empty);
    }

    /// <summary>
    /// Creates the validation result for a failed step.
    /// </summary>
    /// <param name="thumbprint">SHA256 thumbprint of the certificate.</param>
    /// <param name="rejected">Result of the step that failed.</param>
    /// <returns>The validation result with the outcome and reason of the failed step.</returns>
    private static TrustValidationResult Build(string thumbprint, ValidationStepResult rejected) =>
        new()
        {
            ThumbprintSha256 = thumbprint,
            Outcome = rejected.Outcome,
            FailureReason = rejected.Reason,
            EvaluatedAt = DateTimeOffset.UtcNow
        };

    /// <summary>
    /// Works out the SHA256 thumbprint of the certificate data.
    /// </summary>
    /// <param name="raw">The certificate data.</param>
    /// <returns>The thumbprint as hex text, or an empty string when there is no data.</returns>
    private static string ComputeThumbprintSha256(byte[] raw) =>
        raw is { Length: > 0 }
            ? Convert.ToHexString(SHA256.HashData(raw))
            : string.Empty;

    #endregion
}
