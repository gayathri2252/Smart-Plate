// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace DashboardCH.Services;

/// <summary>
/// Matches store certificates to the thumbprint of the selector. Both older SHA1 and SHA256 thumbprints are supported.
/// </summary>
internal static class CertificateStoreThumbprint
{
    /// <summary>
    /// Checks if the certificate has the given thumbprint.
    /// The SHA1 thumbprint is compared first. The SHA256 thumbprint is compared when the given thumbprint has 64 characters.
    /// </summary>
    /// <param name="certificate">The certificate to check.</param>
    /// <param name="normalizedThumbprint">The cleaned thumbprint to compare with.</param>
    /// <returns>True if the thumbprint matches, otherwise false.</returns>
    internal static bool Matches(X509Certificate2 certificate, string normalizedThumbprint)
    {
        if (string.IsNullOrEmpty(normalizedThumbprint))
        {
            return false;
        }

        string sha1 = Normalize(certificate.Thumbprint);
        if (string.Equals(sha1, normalizedThumbprint, StringComparison.Ordinal))
        {
            return true;
        }

        if (normalizedThumbprint.Length == 64)
        {
            string sha256 = Normalize(certificate.GetCertHashString(HashAlgorithmName.SHA256));
            return string.Equals(sha256, normalizedThumbprint, StringComparison.Ordinal);
        }

        return false;
    }

    /// <summary>
    /// Removes spaces and colons from the thumbprint and makes it upper case.
    /// </summary>
    /// <param name="thumbprint">The thumbprint to clean.</param>
    /// <returns>The cleaned thumbprint, or an empty string when it is null.</returns>
    private static string Normalize(string? thumbprint)
    {
        if (thumbprint is null)
        {
            return string.Empty;
        }

        return thumbprint
            .Replace(" ", string.Empty)
            .Replace(":", string.Empty)
            .ToUpperInvariant();
    }
}
