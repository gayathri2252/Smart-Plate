﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Services;
using CertificateHandler.Shared.Constants;
using DashboardCH.Interfaces;
using DashboardCH.Models;
using DashboardCH.Models.Enums;
using CertificateHandler.Logger;
using CertificateHandler.CertificateManagement.Constants;

namespace DashboardCH.Services;

/// <summary>
/// TPM adapter that is not finished yet. It returns TPMUnavailable for every operation until TPM support is added.
/// </summary>
public sealed class TpmCertificateStoreAdapter
    : ICertificateStoreAdapter
{
    #region Member Variables

    /// <summary>
    /// Windows store reader used when the TPM is simulated. Null when the TPM is not simulated.
    /// </summary>
    private readonly WindowsCertificateStoreAdapter? _simulatedWindowsBacking;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TPM certificate store reader.
    /// Uses the Windows store when the test TPM is turned on.
    /// </summary>
    public TpmCertificateStoreAdapter()
    {
        if (SimulatedTpmStoreBridge.IsEnabled)
        {
            _simulatedWindowsBacking = new WindowsCertificateStoreAdapter();
        }
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the storage type of this reader.
    /// </summary>
    public CertificateStorageMedium BackendType =>
        CertificateStorageMedium.TPM;

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets the local certificate from the TPM.
    /// Returns TPMUnavailable when the TPM is not simulated.
    /// </summary>
    /// <param name="selector">Tells which certificate to find.</param>
    /// <returns>The result of the lookup.</returns>
    public CertificateResult GetLocalCertificate(
        CertificateSelector selector)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetLocalCertificate(selector);
        }

        // TPM certificate retrieval is not available yet, so TPMUnavailable is returned.
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, CertificateManagementLogConstants.OPERATION_GET_CERTIFICATE);

        return new CertificateResult
        {
            Status = CertLookupStatus.TPMUnavailable,
            ErrorDetail = RequestStatusConstants.TPM_RETRIEVAL_NOT_IMPLEMENTED
        };
    }

    /// <summary>
    /// Lists the certificates in the TPM.
    /// </summary>
    /// <param name="scope">Store location to list.</param>
    /// <returns>The certificates, or an empty list when the TPM is not available.</returns>
    public List<CertificateMetadata> ListCertificates(
        WindowsStoreLocation scope)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.ListCertificates(scope);
        }

        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, RequestStatusConstants.TPM_LIST_NOT_APPLICABLE);
        return new List<CertificateMetadata>();
    }

    /// <summary>
    /// Gets the certificate chain for the given thumbprint.
    /// </summary>
    /// <param name="thumbprint">Thumbprint of the certificate.</param>
    /// <returns>The certificate chain, or a TPMUnavailable result when the TPM is not available.</returns>
    public CertificateChainInfo GetCertificateChain(
        string thumbprint)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetCertificateChain(thumbprint);
        }

        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, CertificateManagementLogConstants.OPERATION_GET_CHAIN);
        return new CertificateChainInfo
        {
            Status = CertLookupStatus.TPMUnavailable,
            ErrorDetail = RequestStatusConstants.TPM_CHAIN_RETRIEVAL_NOT_IMPLEMENTED
        };
    }

    /// <summary>
    /// Gets the certificate chain for the given certificate.
    /// </summary>
    /// <param name="leafCertificate">The leaf certificate of the chain.</param>
    /// <returns>The certificate chain, or a TPMUnavailable result when the TPM is not available.</returns>
    public CertificateChainInfo GetCertificateChainFromCertificate(System.Security.Cryptography.X509Certificates.X509Certificate2 leafCertificate)
    {
        if (_simulatedWindowsBacking is not null)
        {
            return _simulatedWindowsBacking.GetCertificateChainFromCertificate(leafCertificate);
        }

        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), CertificateManagementLogConstants.TPM_NOT_AVAILABLE, CertificateManagementLogConstants.OPERATION_GET_CHAIN);
        return new CertificateChainInfo
        {
            Status = CertLookupStatus.TPMUnavailable,
            ErrorDetail = RequestStatusConstants.TPM_CHAIN_RETRIEVAL_NOT_IMPLEMENTED
        };
    }

    #endregion
}
