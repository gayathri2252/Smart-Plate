﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Reads, approves and rejects the pending requests.
/// </summary>
public class PendingRequestQueueService:IPendingRequestQueueService
{
    #region Member Variables

    /// <summary>
    /// Store that holds the pending requests.
    /// </summary>
    private readonly IPendingRequestRepository _pendingRequestsRepository;

    /// <summary>
    /// Saves the approvals of onboarding requests.
    /// </summary>
    private readonly IPendingOnboardingApprovalStore _onboardingApprovalStore;

    /// <summary>
    /// Saves the approvals of reinstatement requests. Can be null.
    /// </summary>
    private readonly IReinstatementPendingApprovalStore? _reinstatementApprovalStore;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the pending request queue service.
    /// </summary>
    /// <param name="pendingRequestRepository">
    /// Repository used to read and update pending requests.
    /// </param>
    /// <param name="onboardingApprovalStore">
    /// Store that approves or rejects onboarding requests, updates the whitelist and sends notifications.
    /// </param>
    /// <param name="reinstatementApprovalStore">
    /// Store that approves or rejects reinstatement requests.
    /// </param>
    public PendingRequestQueueService(
        IPendingRequestRepository pendingRequestRepository,
        IPendingOnboardingApprovalStore onboardingApprovalStore,
        IReinstatementPendingApprovalStore? reinstatementApprovalStore = null)
    {
        _pendingRequestsRepository = pendingRequestRepository ?? throw new ArgumentNullException(nameof(pendingRequestRepository));
        _onboardingApprovalStore = onboardingApprovalStore ?? throw new ArgumentNullException(nameof(onboardingApprovalStore));
        _reinstatementApprovalStore = reinstatementApprovalStore;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets all pending requests from the repository.
    /// </summary>
    /// <returns>
    /// The pending request items.
    /// </returns>
    public IEnumerable<PendingRequestItem> GetPendingRequests()
    {
        return _pendingRequestsRepository.GetPendingRequests();
    }

    /// <summary>
    /// Gets the certificate requests that have the given status.
    /// </summary>
    /// <param name="status">
    /// Status to read, APPROVED, REJECTED or EXPIRED.
    /// </param>
    /// <returns>
    /// The requests with that status.
    /// </returns>
    public IEnumerable<PendingRequestItem> GetRequestsByStatus(string status)
    {
        return _pendingRequestsRepository.GetRequestsByStatus(status);
    }

    /// <summary>
    /// Counts the certificate requests in each status.
    /// </summary>
    /// <returns>
    /// The number of pending, approved, rejected and expired requests.
    /// </returns>
    public RequestStatusCounts GetRequestStatusCounts()
    {
        return _pendingRequestsRepository.GetRequestStatusCounts();
    }

    /// <summary>
    /// Approves the pending request.
    /// </summary>
    /// <param name="decision">
    /// The decision, with the request id and the administrator.
    /// </param>
    public void ApproveRequest(PendingRequestDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);
        if (IsReinstatement(decision.RequestId))
        {
            if (_reinstatementApprovalStore is null)
            {
                throw new InvalidOperationException("Reinstatement approval store is not configured.");
            }

            _reinstatementApprovalStore.ApproveAsync(decision).GetAwaiter().GetResult();
            return;
        }

        _onboardingApprovalStore.ApproveAsync(decision).GetAwaiter().GetResult();
    }

    /// <summary>
    /// Rejects the pending request.
    /// </summary>
    /// <param name="decision">
    /// The decision, with the request id, the administrator and the reason.
    /// </param>
    public void RejectRequest(PendingRequestDecision decision)
    {
        ArgumentNullException.ThrowIfNull(decision);
        if (IsReinstatement(decision.RequestId))
        {
            if (_reinstatementApprovalStore is null)
            {
                throw new InvalidOperationException("Reinstatement approval store is not configured.");
            }

            _reinstatementApprovalStore.RejectAsync(decision).GetAwaiter().GetResult();
            return;
        }

        _onboardingApprovalStore.RejectAsync(decision).GetAwaiter().GetResult();
    }

    /// <summary>
    /// Checks if the request is a reinstatement request.
    /// </summary>
    /// <param name="requestId">
    /// Id of the request.
    /// </param>
    /// <returns>
    /// True if it is a reinstatement request, otherwise false.
    /// </returns>
    private bool IsReinstatement(string requestId) =>
        _pendingRequestsRepository.GetRequestType(requestId)
            .Contains("REINSTATEMENT", StringComparison.OrdinalIgnoreCase);

    #endregion

}
