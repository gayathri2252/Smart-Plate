// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Test helper that uses the Windows store as the TPM store when no hardware TPM is available.
/// </summary>
public static class SimulatedTpmStoreBridge
{
    /// <summary>
    /// True when the test TPM store is turned on.
    /// </summary>
    public static bool IsEnabled =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SIMULATE_TPM");
}
