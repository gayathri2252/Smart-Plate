﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Writes the audit row of an approval or rejection into the audit log table. The device, certificate and thumbprint are read from the request, so the caller only gives the request id.
/// </summary>
public sealed class PendingRequestAuditWriter : IPendingRequestAuditWriter
{
    #region Member Variables

    /// <summary>
    /// SQL that adds an audit row.
    /// </summary>
    private const string INSERT_AUDIT_SQL =
        @"INSERT INTO certificate_handler.ch_audit_log
            (event_type, event_timestamp, actor_identity, device_id, request_id, certificate_id,
             thumbprint_sha256, previous_status, new_status, action_status, reason, result, source_component)
          SELECT CAST(@eventType AS varchar), now(), CAST(@actor AS varchar), pr.device_id, pr.request_id, pr.certificate_id,
                 c.thumbprint_sha256, CAST(@previousStatus AS varchar), CAST(@newStatus AS varchar), CAST(@newStatus AS varchar),
                 CAST(@reason AS text), CAST(@result AS varchar), CAST(@source AS varchar)
          FROM certificate_handler.ch_pending_request pr
          JOIN certificate_handler.ch_certificate c ON c.certificate_id = pr.certificate_id
          WHERE pr.request_id = CAST(@requestId AS uuid);";

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the writer with the given database data source.
    /// </summary>
    /// <param name="dataSource">
    /// Data source used to write audit records.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the data source is null.
    /// </exception>
    public PendingRequestAuditWriter(NpgsqlDataSource dataSource)
    {
        if (dataSource is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), PendingRequestAuditConstants.DATA_SOURCE_IS_NULL);
            throw new ArgumentNullException(nameof(dataSource));
        }
        _dataSource = dataSource;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Writes an audit record for a pending request approval or rejection. The device, certificate and thumbprint are read from the request with the given id.
    /// </summary>
    /// <param name="requestId">
    /// Id of the pending request.
    /// </param>
    /// <param name="eventType">
    /// Audit event type to save.
    /// </param>
    /// <param name="newStatus">
    /// Status of the request after the action.
    /// </param>
    /// <param name="actor">
    /// User who approved or rejected the request.
    /// </param>
    /// <param name="result">
    /// Result of the action.
    /// </param>
    /// <param name="reason">
    /// Reason for the decision, or null.
    /// </param>
    /// <returns>
    /// Number of audit records written.
    /// </returns>
    public int WriteDecision(string requestId, string eventType, string newStatus, string actor, string result, string? reason)
    {
        using NpgsqlConnection connection = _dataSource.OpenConnection();
        using NpgsqlCommand command = new(INSERT_AUDIT_SQL, connection);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_EVENT_TYPE, eventType);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_ACTOR, actor);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_PREVIOUS_STATUS, PendingRequestAuditConstants.STATUS_PENDING);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_NEW_STATUS, newStatus);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_REASON, (object?)reason ?? DBNull.Value);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_RESULT, result);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_SOURCE, PendingRequestAuditConstants.SOURCE_COMPONENT);
        command.Parameters.AddWithValue(PendingRequestAuditConstants.PARAM_REQUEST_ID, requestId);
        return command.ExecuteNonQuery();
    }

    #endregion
}
