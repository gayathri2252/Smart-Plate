﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;
using CertificateHandler.Audit.Services;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Audit.Models;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Manages pending certificate requests and expires them after the set timeout.
/// </summary>
public class PendingRequestManager
{
    #region Member Variables

    /// <summary>
    /// Timeout settings for the pending requests.
    /// </summary>
    private readonly TimeoutConfiguration _timeoutConfiguration;

    /// <summary>
    /// Writes the audit records.
    /// </summary>
    private readonly AuditLogService _auditLogService;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the pending request manager.
    /// </summary>
    /// <param name="timeoutConfiguration">
    /// Timeout used to decide when a pending request expires.
    /// </param>
    /// <param name="auditLogService">
    /// Service used to write audit records for pending requests.
    /// </param>
    public PendingRequestManager(TimeoutConfiguration timeoutConfiguration, AuditLogService auditLogService)
    {
        _timeoutConfiguration = timeoutConfiguration;
        _auditLogService = auditLogService;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if a pending request is older than the set timeout.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to validate.
    /// </param>
    /// <returns>
    /// True if the request has expired, otherwise false.
    /// </returns>
    public bool HasRequestExpired(PendingCertificateRequest request)
    {
        TimeSpan elapsedTime = DateTime.UtcNow - request.CreatedTime;
        return elapsedTime.TotalHours >= _timeoutConfiguration.PendingRequestExpiryTimeout;
    }

    /// <summary>
    /// Marks a pending request as expired when the timeout is reached.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to process.
    /// </param>
    public void ProcessPendingRequest(PendingCertificateRequest request)
    {
        if (HasRequestExpired(request))
        {
            ExpirePendingRequest(request);
        }

    }

    /// <summary>
    /// Sets the request status to Expired and saves the expiry time.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to expire.
    /// </param>
    public void ExpirePendingRequest(PendingCertificateRequest request)
    {
        request.Status = RequestStatusConstants.EXPIRED;
        request.ExpiryTime = DateTime.UtcNow;
        CertificateHandlerLogger.Warning(
            MessageIdGenerator.Next(),
            RequestStatusConstants.PENDING_REQUEST_EXPIRED_MESSAGE,
            string.IsNullOrWhiteSpace(request.CertificateName) ? RequestStatusConstants.UNKNOWN_CERTIFICATE_NAME : request.CertificateName);

        _auditLogService.CreateAuditLog(new AuditLog
        {
            AuditId = 0,
            RequestId = request.RequestID,
            DeviceId = request.DeviceID,
            DeviceName = request.DeviceID,
            CertificateThumbprint = string.Empty,
            ApproverName = RequestStatusConstants.SYSTEM,
            Reason = RequestStatusConstants.PENDING_REQUEST_EXPIRED,
            ActionType = RequestStatusConstants.AUTO_EXPIRY,
            CertificateSubject = string.Empty,
            ActionStatus = RequestStatusConstants.EXPIRED,
            Comments = RequestStatusConstants.REQUEST_AUTOMATICALLY_EXPIRED
        });
    }

    /// <summary>
    /// Checks if an administrator can still approve or reject the request.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to check.
    /// </param>
    /// <returns>
    /// True if the request can still be decided, otherwise false.
    /// </returns>
    public static bool IsRequestProcessable(PendingCertificateRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        return request.Status != RequestStatusConstants.EXPIRED;
    }

    #endregion

}
