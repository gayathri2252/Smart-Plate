﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Logger;
using CertificateHandler.Shared.Models;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Approves and rejects pending certificate requests after it checks that the request has not expired.
/// </summary>
public static class PendingRequestApprovalService
{
    #region Public Methods

    /// <summary>
    /// Approves a pending certificate request after it checks that the request has not expired.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to approve.
    /// </param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when the request has expired and can no longer be approved.
    /// </exception>
    public static void ApproveRequest(PendingCertificateRequest request)
    {
        if (!PendingRequestManager.IsRequestProcessable(request))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.APPROVAL_BLOCKED_FOR_EXPIRED_REQUEST_MESSAGE, request.RequestID);
            throw new InvalidOperationException(RequestStatusConstants.REQUEST_EXPIRED_CANNOT_BE_APPROVED);
        }
        request.Status = RequestStatusConstants.APPROVED;
    }

    /// <summary>
    /// Rejects a pending certificate request after it checks that the request has not expired.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to reject.
    /// </param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when the request has expired and can no longer be rejected.
    /// </exception>
    public static void RejectRequest(PendingCertificateRequest request)
    {
        if (!PendingRequestManager.IsRequestProcessable(request))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), RequestStatusConstants.REJECTION_BLOCKED_FOR_EXPIRED_REQUEST_MESSAGE, request.RequestID);
            throw new InvalidOperationException(
               RequestStatusConstants.REQUEST_EXPIRED_CANNOT_BE_REJECTED);
        }

        request.Status = RequestStatusConstants.REJECTED;
    }

    #endregion
}
