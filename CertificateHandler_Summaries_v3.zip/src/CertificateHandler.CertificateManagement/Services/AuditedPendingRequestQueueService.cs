﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Wraps the queue service so each approval and rejection is written to the Log Monitor and to the audit table.
/// The pending request queue service makes the decision. An audit error never undoes a saved decision.
/// A failed decision is logged, saved in the audit as FAILURE and thrown again.
/// </summary>
public sealed class AuditedPendingRequestQueueService : IPendingRequestQueueService
{
    #region Member Variables

    /// <summary>
    /// Service that does the approve and reject work.
    /// </summary>
    private readonly IPendingRequestQueueService _pendingRequestQueueService;

    /// <summary>
    /// Writes the audit rows for the decisions.
    /// </summary>
    private readonly IPendingRequestAuditWriter _auditWriter;

    /// <summary>
    /// Gives the name of the logged in administrator.
    /// </summary>
    private readonly Func<string?> _actorProvider;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the wrapper.
    /// </summary>
    /// <param name="pendingRequestQueueService">Service that does the decision. Must not be null.</param>
    /// <param name="pendingrequestauditWriter">Writes the audit row. Must not be null.</param>
    /// <param name="actorProvider">Gives the name of the administrator who is logged in. It can give null.</param>
    public AuditedPendingRequestQueueService(
        IPendingRequestQueueService pendingRequestQueueService,
        IPendingRequestAuditWriter pendingrequestauditWriter,
        Func<string?>? actorProvider = null)
    {
        if (pendingRequestQueueService is null)
        {
            WriteError(PendingRequestAuditConstants.INNER_SERVICE_IS_NULL);
            throw new ArgumentNullException(nameof(pendingRequestQueueService));
        }
        if (pendingrequestauditWriter is null)
        {
            WriteError(PendingRequestAuditConstants.AUDIT_WRITER_IS_NULL);
            throw new ArgumentNullException(nameof(pendingrequestauditWriter));
        }
        _pendingRequestQueueService = pendingRequestQueueService;
        _auditWriter = pendingrequestauditWriter;
        _actorProvider = actorProvider ?? (() => null);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets the pending requests.
    /// </summary>
    /// <returns>The pending requests.</returns>
    public IEnumerable<PendingRequestItem> GetPendingRequests() => _pendingRequestQueueService.GetPendingRequests();

    /// <summary>
    /// Gets the certificate requests that have the given status. Reading does not write an audit row.
    /// </summary>
    /// <param name="status">Status to read, APPROVED, REJECTED or EXPIRED.</param>
    /// <returns>The requests with that status.</returns>
    public IEnumerable<PendingRequestItem> GetRequestsByStatus(string status) => _pendingRequestQueueService.GetRequestsByStatus(status);

    /// <summary>
    /// Counts the certificate requests in each status. Reading does not write an audit row.
    /// </summary>
    /// <returns>The number of requests in each status.</returns>
    public RequestStatusCounts GetRequestStatusCounts() => _pendingRequestQueueService.GetRequestStatusCounts();

    /// <summary>
    /// Approves the pending certificate request and writes the action to the log and to the audit history.
    /// </summary>
    /// <param name="decision">The decision, with the request id, the administrator and an optional reason.</param>
    /// <exception cref="ArgumentException">
    /// Thrown when the request id is null, empty or only spaces.
    /// </exception>
    /// <exception cref="Exception">
    /// Any error from the approval is thrown again.
    /// </exception>
    public void ApproveRequest(PendingRequestDecision decision)
    {
        Decide(
            decision,
            _pendingRequestQueueService.ApproveRequest,
            PendingRequestAuditConstants.EVENT_APPROVED,
            PendingRequestAuditConstants.STATUS_APPROVED,
            PendingRequestAuditConstants.APPROVE_STARTED,
            PendingRequestAuditConstants.APPROVE_SUCCEEDED,
            PendingRequestAuditConstants.APPROVE_FAILED);
    }

    /// <summary>
    /// Rejects the pending certificate request and writes the action to the log and to the audit history.
    /// </summary>
    /// <param name="decision">The decision, with the request id, the administrator and the reason.</param>
    /// <exception cref="ArgumentException">
    /// Thrown when the request id is null, empty or only spaces.
    /// </exception>
    /// <exception cref="Exception">
    /// Any error from the rejection is thrown again.
    /// </exception>
    public void RejectRequest(PendingRequestDecision decision)
    {
        Decide(
            decision,
            _pendingRequestQueueService.RejectRequest,
            PendingRequestAuditConstants.EVENT_REJECTED,
            PendingRequestAuditConstants.STATUS_REJECTED,
            PendingRequestAuditConstants.REJECT_STARTED,
            PendingRequestAuditConstants.REJECT_SUCCEEDED,
            PendingRequestAuditConstants.REJECT_FAILED);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Writes an information message to the log. A logging error is ignored, so it never blocks or undoes a decision.
    /// </summary>
    /// <param name="message">The message text.</param>
    /// <param name="args">Values for the message.</param>
    private static void WriteInformation(string message, params object[] args)
    {
        try { CertificateHandlerLogger.Information(MessageIdGenerator.Next(), message, args); } catch (Exception ex) { System.Console.WriteLine(ex.Message); }
    }

    /// <summary>
    /// Writes a success message to the log.
    /// If the logger fails, the error is written to the console and the work goes on.
    /// </summary>
    /// <param name="message">The message to write.</param>
    /// <param name="args">Values to put into the message.</param>
    private static void WriteSuccess(string message, params object[] args)
    {
        try { CertificateHandlerLogger.Success(MessageIdGenerator.Next(), message, args); } catch (Exception ex) { System.Console.WriteLine(ex.Message); }
    }

    /// <summary>
    /// Writes a warning message to the log.
    /// If the logger fails, the error is written to the console and the work goes on.
    /// </summary>
    /// <param name="message">The message to write.</param>
    /// <param name="args">Values to put into the message.</param>
    private static void WriteWarning(string message, params object[] args)
    {
        try { CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message, args); } catch (Exception ex) { System.Console.WriteLine(ex.Message); }
    }

    /// <summary>
    /// Writes an error message to the log.
    /// If the logger fails, the error is written to the console and the work goes on.
    /// </summary>
    /// <param name="message">The message to write.</param>
    /// <param name="args">Values to put into the message.</param>
    private static void WriteError(string message, params object[] args)
    {
        try { CertificateHandlerLogger.Error(MessageIdGenerator.Next(), message, args); } catch (Exception ex) { System.Console.WriteLine(ex.Message); }
    }

    /// <summary>
    /// Runs one decision and writes its log lines and audit row.
    /// </summary>
    /// <param name="decision">The decision on the request.</param>
    /// <param name="decisionAction">Action that saves the decision.</param>
    /// <param name="eventType">Audit event type of the decision.</param>
    /// <param name="newStatus">Status of the request after the decision.</param>
    /// <param name="startedMessage">Message logged when the decision starts.</param>
    /// <param name="succeededMessage">Message logged when the decision works.</param>
    /// <param name="failedMessage">Message logged when the decision fails.</param>
    private void Decide(
        PendingRequestDecision decision,
        Action<PendingRequestDecision> decisionAction,
        string eventType,
        string newStatus,
        string startedMessage,
        string succeededMessage,
        string failedMessage)
    {
        ArgumentNullException.ThrowIfNull(decision);

        string actor = string.IsNullOrWhiteSpace(decision.ActorIdentity)
            ? GetActor()
            : decision.ActorIdentity.Trim();

        if (string.IsNullOrWhiteSpace(decision.RequestId))
        {
            WriteWarning(PendingRequestAuditConstants.REQUEST_ID_MISSING, actor);
            throw new ArgumentException(PendingRequestAuditConstants.REQUEST_ID_REQUIRED, nameof(decision));
        }

        WriteInformation(startedMessage, actor, decision.RequestId);

        try
        {
            PendingRequestDecision enriched = new()
            {
                RequestId = decision.RequestId,
                ActorIdentity = actor,
                Reason = decision.Reason
            };
            decisionAction(enriched);
        }
        catch (Exception ex)
        {
            WriteError(failedMessage, decision.RequestId, ex.Message);
            WriteAudit(decision.RequestId, eventType, PendingRequestAuditConstants.STATUS_PENDING, actor, PendingRequestAuditConstants.RESULT_FAILURE, ex.Message);
            throw;
        }

        WriteSuccess(succeededMessage, decision.RequestId, actor);
        WriteAudit(decision.RequestId, eventType, newStatus, actor, PendingRequestAuditConstants.RESULT_SUCCESS, decision.Reason);
    }

    /// <summary>
    /// Writes the audit row. An error here is only logged, because the decision is already saved.
    /// </summary>
    /// <param name="requestId">Id of the request.</param>
    /// <param name="eventType">Audit event type.</param>
    /// <param name="newStatus">Status of the request after the decision.</param>
    /// <param name="actor">Administrator who made the decision.</param>
    /// <param name="result">Result of the decision.</param>
    /// <param name="reason">Error text, or null when the decision worked.</param>
    private void WriteAudit(string requestId, string eventType, string newStatus, string actor, string result, string? reason)
    {
        try
        {
            string? shortReason = reason is { Length: > PendingRequestAuditConstants.MAX_REASON_LENGTH }
                ? reason[..PendingRequestAuditConstants.MAX_REASON_LENGTH]
                : reason;

            int rows = _auditWriter.WriteDecision(requestId, eventType, newStatus, actor, result, shortReason);

            if (rows > 0)
            {
                WriteInformation(PendingRequestAuditConstants.AUDIT_WRITTEN, eventType, requestId);
            }
            else
            {
                WriteWarning(PendingRequestAuditConstants.AUDIT_REQUEST_NOT_FOUND, requestId);
            }
        }
        catch (Exception ex)
        {
            WriteError(PendingRequestAuditConstants.AUDIT_FAILED, requestId, ex.Message);
        }
    }

    /// <summary>
    /// Gets the administrator who is logged in, or Unknown when there is none. When the lookup fails, the error is logged as a warning and Unknown is used.
    /// </summary>
    /// <returns>Name of the administrator, or Unknown.</returns>
    private string GetActor()
    {
        try
        {
            string? actor = _actorProvider();
            return string.IsNullOrWhiteSpace(actor) ? PendingRequestAuditConstants.UNKNOWN_ACTOR : actor.Trim();
        }
        catch (Exception ex)
        {
            WriteWarning(PendingRequestAuditConstants.ACTOR_LOOKUP_FAILED, ex.Message);
            return PendingRequestAuditConstants.UNKNOWN_ACTOR;
        }
    }

    #endregion
}
