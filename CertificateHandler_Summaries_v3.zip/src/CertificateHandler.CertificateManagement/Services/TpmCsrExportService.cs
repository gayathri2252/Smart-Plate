// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Always fails until TPM CSR export is added for MAXUM hardware.
/// </summary>
public sealed class TpmCsrExportService : ITpmCsrExportService
{
    /// <summary>
    /// Exports the certificate signing request from the TPM.
    /// This is not built yet, so it always throws.
    /// </summary>
    /// <param name="keyId">Id of the key used for the request.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The certificate signing request in PEM format.</returns>
    /// <exception cref="InvalidOperationException">Always thrown because TPM export is not built yet.</exception>
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        _ = keyId;
        cancellationToken.ThrowIfCancellationRequested();
        throw new InvalidOperationException(RequestStatusConstants.TPM_RETRIEVAL_NOT_IMPLEMENTED);
    }
}
