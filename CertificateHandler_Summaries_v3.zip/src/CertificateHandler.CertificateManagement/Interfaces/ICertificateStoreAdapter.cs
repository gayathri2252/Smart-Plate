// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using DashboardCH.Models;
using DashboardCH.Models.Enums;

namespace DashboardCH.Interfaces;

/// <summary>
/// Methods that each certificate store adapter has, like the Windows certificate store or the TPM.
/// </summary>
public interface ICertificateStoreAdapter
{
    /// <summary>
    /// The storage type of this adapter.
    /// </summary>
    CertificateStorageMedium BackendType { get; }

    /// <summary>
    /// Finds one certificate by thumbprint.
    /// </summary>
    /// <param name="selector">Thumbprint, device and store to search.</param>
    /// <returns>The lookup result.</returns>
    CertificateResult GetLocalCertificate(CertificateSelector selector);

    /// <summary>
    /// Lists all certificates in the given store scope.
    /// </summary>
    /// <param name="scope">Store location to list.</param>
    /// <returns>The certificates in the store.</returns>
    List<CertificateMetadata> ListCertificates(WindowsStoreLocation scope);

    /// <summary>
    /// Builds the certificate chain for the given thumbprint.
    /// </summary>
    /// <param name="thumbprint">Thumbprint of the certificate.</param>
    /// <returns>The chain details.</returns>
    CertificateChainInfo GetCertificateChain(string thumbprint);

    /// <summary>
    /// Builds a chain for a certificate sent by a peer, not one from the local store.
    /// </summary>
    /// <param name="leafCertificate">Certificate sent by the peer.</param>
    /// <returns>The chain details.</returns>
    CertificateChainInfo GetCertificateChainFromCertificate(X509Certificate2 leafCertificate);
}
