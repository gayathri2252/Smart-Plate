﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Reads and updates pending requests in the database.
/// </summary>
public interface IPendingRequestRepository
{
    /// <summary>
    /// Gets all pending requests.
    /// </summary>
    /// <returns>The pending request items.</returns>
    IEnumerable<PendingRequestItem> GetPendingRequests();

    /// <summary>
    /// Gets the certificate requests that have the given status, APPROVED, REJECTED or EXPIRED.
    /// </summary>
    /// <param name="status">Status of the requests to read.</param>
    /// <returns>The requests with that status, newest first.</returns>
    IEnumerable<PendingRequestItem> GetRequestsByStatus(string status);

    /// <summary>
    /// Counts the certificate requests in each status, pending, approved, rejected and expired.
    /// </summary>
    /// <returns>The number of requests in each status.</returns>
    RequestStatusCounts GetRequestStatusCounts();

    /// <summary>
    /// Gets the type of the pending request, used to pick the right approve or reject flow.
    /// </summary>
    /// <param name="requestId">Id of the request.</param>
    /// <returns>The request type.</returns>
    string GetRequestType(string requestId);

    /// <summary>
    /// Approves the pending request in the database.
    /// </summary>
    /// <param name="requestId">
    /// Id of the request to approve.
    /// </param>
    void ApproveRequest(string requestId);

    /// <summary>
    /// Rejects the pending request in the database.
    /// </summary>
    /// <param name="requestId">
    /// Id of the request to reject.
    /// </param>
    void RejectRequest(string requestId);
}