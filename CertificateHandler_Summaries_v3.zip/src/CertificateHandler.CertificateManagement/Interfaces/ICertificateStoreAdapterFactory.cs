// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Interfaces;

/// <summary>
/// Creates the certificate store adapter for the configured storage type.
/// </summary>
public interface ICertificateStoreAdapterFactory
{
    /// <summary>
    /// Gives the adapter for the given storage type. Throws NotSupportedException for a value that is not known.
    /// </summary>
    /// <param name="backend">The storage type.</param>
    /// <returns>The store adapter.</returns>
    ICertificateStoreAdapter Create(CertificateStorageMedium backend);
}
