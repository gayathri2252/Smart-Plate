﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Reads pending certificate requests and approves or rejects them.
/// </summary>
public interface IPendingRequestQueueService
{
    /// <summary>
    /// Gets all pending requests that wait for approval or rejection.
    /// </summary>
    /// <returns>The pending request items.</returns>
    IEnumerable<PendingRequestItem> GetPendingRequests();

    /// <summary>
    /// Gets the certificate requests that have the given status, APPROVED, REJECTED or EXPIRED.
    /// </summary>
    /// <param name="status">Status of the requests to read.</param>
    /// <returns>The requests with that status, newest first.</returns>
    IEnumerable<PendingRequestItem> GetRequestsByStatus(string status);

    /// <summary>
    /// Counts the certificate requests in each status, pending, approved, rejected and expired.
    /// </summary>
    /// <returns>The number of requests in each status.</returns>
    RequestStatusCounts GetRequestStatusCounts();

    /// <summary>
    /// Approves the pending request.
    /// </summary>
    /// <param name="decision">The decision, with the request id and the administrator.</param>
    void ApproveRequest(PendingRequestDecision decision);

    /// <summary>
    /// Rejects the pending request.
    /// </summary>
    /// <param name="decision">The decision, with the request id, the administrator and the reason.</param>
    void RejectRequest(PendingRequestDecision decision);
}