﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Constants;

/// <summary>
/// Texts written to the Log Monitor by certificate management, for the Request Queue and the local certificate store. The logger fills in the values in the given order.
/// </summary>
public static class CertificateManagementLogConstants
{
    #region Request Queue

    /// <summary>Information message when the Request Queue is loaded. The value is the number of pending requests.</summary>
    public const string QUEUE_LOADED = "Request Queue loaded from the database: %s pending request(s).";

    /// <summary>Error message when the Request Queue cannot be loaded. The value is the error.</summary>
    public const string QUEUE_LOAD_FAILED = "The Request Queue could not be loaded from the database: %s";

    /// <summary>Success message when the request is set to Approved in the database. The value is the request id.</summary>
    public const string REQUEST_APPROVED_SAVED = "Pending request %s was saved as Approved in the database.";

    /// <summary>Success message when the request is set to Rejected in the database. The value is the request id.</summary>
    public const string REQUEST_REJECTED_SAVED = "Pending request %s was saved as Rejected in the database.";

    /// <summary>Warning message when no request with that id is found to update. The values are the request id and the decision.</summary>
    public const string REQUEST_NOT_FOUND_FOR_DECISION = "Pending request %s was not found in the database, so it could not be set to %s.";

    /// <summary>Error message when the decision cannot be saved. The values are the decision, the request id and the error.</summary>
    public const string REQUEST_DECISION_SAVE_FAILED = "The decision %s for pending request %s could not be saved in the database: %s";

    /// <summary>Decision name for the approve action.</summary>
    public const string DECISION_APPROVED = "Approved";

    /// <summary>Decision name for the reject action.</summary>
    public const string DECISION_REJECTED = "Rejected";

    #endregion

    #region Local Certificate Store

    /// <summary>Information message when a local certificate is found. The values are the thumbprint and the store type.</summary>
    public const string LOCAL_CERTIFICATE_FOUND = "Local certificate %s was found in the %s.";

    /// <summary>Warning message when the lookup does not find exactly one local certificate. The values are the thumbprint, the status and the detail.</summary>
    public const string LOCAL_CERTIFICATE_NOT_FOUND = "Local certificate %s could not be read (%s): %s";

    /// <summary>Error message when the store adapter gives no result.</summary>
    public const string LOCAL_CERTIFICATE_NO_RESULT = "The certificate store returned no result for the certificate lookup.";

    /// <summary>Error message when the certificate store cannot be opened or read. The values are the operation and the error.</summary>
    public const string CERTIFICATE_STORE_FAILED = "The Windows certificate store could not be read during %s: %s";

    /// <summary>Warning message when one certificate in the store cannot be read. The values are the thumbprint and the error.</summary>
    public const string CERTIFICATE_MAPPING_FAILED = "Certificate %s in the Windows certificate store could not be read: %s";

    /// <summary>Information message when the store is listed. The values are the number of certificates and the store location.</summary>
    public const string CERTIFICATE_STORE_LISTED = "%s certificate(s) were listed from the Windows certificate store (%s).";

    /// <summary>Information message when a certificate chain is built. The values are the thumbprint and if the chain is complete.</summary>
    public const string CERTIFICATE_CHAIN_BUILT = "Certificate chain built for %s: complete = %s.";

    /// <summary>Warning message when the TPM store is not available yet. The value is the operation.</summary>
    public const string TPM_NOT_AVAILABLE = "The TPM certificate store is not available yet (%s).";

    /// <summary>Error message when a certificate store that is not supported is set. The value is the store type.</summary>
    public const string UNSUPPORTED_BACKEND = "The configured certificate store %s is not supported.";

    /// <summary>Operation name for reading one certificate.</summary>
    public const string OPERATION_GET_CERTIFICATE = "reading a certificate";

    /// <summary>Operation name for listing certificates.</summary>
    public const string OPERATION_LIST_CERTIFICATES = "listing the certificates";

    /// <summary>Operation name for building a chain.</summary>
    public const string OPERATION_GET_CHAIN = "building a certificate chain";

    #endregion

    #region Certificate Validation

    /// <summary>Success message when the certificate passes all validation steps. The value is the thumbprint.</summary>
    public const string CERTIFICATE_VALIDATION_PASSED = "Certificate %s passed validation.";

    /// <summary>Warning message when the certificate fails a validation step. The values are the thumbprint, the step, the outcome and the reason.</summary>
    public const string CERTIFICATE_VALIDATION_FAILED = "Certificate %s failed validation at step %s: %s (%s).";

    #endregion
}
