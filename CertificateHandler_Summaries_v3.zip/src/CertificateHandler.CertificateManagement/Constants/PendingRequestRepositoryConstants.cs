﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Constants;

/// <summary>
/// Log messages of the pending request repository, which reads and decides pending requests on the database server.
/// </summary>
public static class PendingRequestRepositoryConstants
{
    #region Member Variables

    /// <summary>Logged after the pending requests are read. The value is the number read.</summary>
    public const string PENDING_REQUESTS_READ = "%s pending request(s) were read from the database server for the Request Queue.";

    /// <summary>Logged when the pending requests cannot be read. The value is the error.</summary>
    public const string PENDING_REQUESTS_READ_FAILED = "The pending requests could not be read from the database server. Error: %s";

    /// <summary>Logged after a request is approved in the database. The values are the request id and the rows changed.</summary>
    public const string REQUEST_APPROVED = "Pending request %s was approved in the database (%s row(s) changed).";

    /// <summary>Logged when a request cannot be approved. The values are the request id and the error.</summary>
    public const string REQUEST_APPROVE_FAILED = "Pending request %s could not be approved on the database server. Error: %s";

    /// <summary>Logged after a request is rejected in the database. The values are the request id and the rows changed.</summary>
    public const string REQUEST_REJECTED = "Pending request %s was rejected in the database (%s row(s) changed).";

    /// <summary>Logged when a request cannot be rejected. The values are the request id and the error.</summary>
    public const string REQUEST_REJECT_FAILED = "Pending request %s could not be rejected on the database server. Error: %s";

    /// <summary>Logged when an approve or reject changed no row, like when the request id is not known. The value is the request id.</summary>
    public const string REQUEST_NOT_FOUND = "Pending request %s was not found in the database, so nothing was changed.";

    /// <summary>Logged after the request counts are read. The values are the pending, approved, rejected and expired counts.</summary>
    public const string STATUS_COUNTS_READ = "Request counts read from the database server: %s pending, %s approved, %s rejected, %s expired.";

    /// <summary>Logged when the request counts cannot be read. The value is the error.</summary>
    public const string STATUS_COUNTS_READ_FAILED = "The request counts could not be read from the database server. Error: %s";

    /// <summary>Logged after the requests of one status are read. The values are the number read and the status.</summary>
    public const string REQUESTS_BY_STATUS_READ = "%s %s request(s) were read from the database server for the Request Queue.";

    /// <summary>Logged when the requests of one status cannot be read. The values are the status and the error.</summary>
    public const string REQUESTS_BY_STATUS_READ_FAILED = "The %s requests could not be read from the database server. Error: %s";

    /// <summary>Error text when a status other than APPROVED, REJECTED or EXPIRED is asked for.</summary>
    public const string UNSUPPORTED_REQUEST_STATUS = "Only APPROVED, REJECTED or EXPIRED requests can be read by status.";

    #endregion
}
