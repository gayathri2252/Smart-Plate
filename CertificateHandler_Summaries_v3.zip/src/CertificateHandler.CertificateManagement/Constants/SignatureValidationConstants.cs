﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Constants;

/// <summary>
/// Constants for the signature check, the first step of certificate validation.
/// </summary>
public static class SignatureValidationConstants
{
    #region Member Variables

    /// <summary>Logged when the signature check rejects a certificate. The value is the reason.</summary>
    public const string SIGNATURE_CHECK_REJECTED = "Certificate rejected by signature check: %s";

    /// <summary>Logged when the signature check passes. The value is the signature algorithm.</summary>
    public const string SIGNATURE_CHECK_PASSED = "Certificate signature check passed. Algorithm=%s";

    #endregion
}
