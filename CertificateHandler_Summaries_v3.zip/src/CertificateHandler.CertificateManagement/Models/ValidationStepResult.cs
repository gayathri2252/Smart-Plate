// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// What one validation step decided.
/// </summary>
public enum ValidationStepStatus
{
    /// <summary>
    /// The check passed and the next check can start.
    /// </summary>
    Pass = 0,

    /// <summary>
    /// The check failed and the checks must stop.
    /// </summary>
    Rejected = 1
}

/// <summary>
/// Result of one certificate validation step, Pass, or Rejected with a reason.
/// </summary>
public sealed class ValidationStepResult
{
    #region Constructor

    /// <summary>
    /// Creates the result of a validation step.
    /// </summary>
    /// <param name="status">Status of the step.</param>
    /// <param name="reason">Message that explains the result.</param>
    /// <param name="outcome">Validation outcome for this result.</param>
    private ValidationStepResult(ValidationStepStatus status, string reason, TrustValidationOutcome outcome)
    {
        Status = status;
        Reason = reason;
        Outcome = outcome;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Pass or Rejected.
    /// </summary>
    public ValidationStepStatus Status { get; }

    /// <summary>
    /// Why the step rejected the certificate. Empty when the step passed.
    /// </summary>
    public string Reason { get; }

    /// <summary>
    /// Outcome reported to the trust engine when the step rejected. Passed when the step passed.
    /// </summary>
    public TrustValidationOutcome Outcome { get; }

    /// <summary>
    /// True when the step passed.
    /// </summary>
    public bool IsPass => Status == ValidationStepStatus.Pass;

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates a Pass result.
    /// </summary>
    /// <returns>A Pass result.</returns>
    public static ValidationStepResult Pass() =>
        new(ValidationStepStatus.Pass, string.Empty, TrustValidationOutcome.Passed);

    /// <summary>
    /// Creates a Rejected result with a reason and the outcome the trust engine should report.
    /// </summary>
    /// <param name="reason">Why the certificate was rejected.</param>
    /// <param name="outcome">Outcome the trust engine should report.</param>
    /// <returns>A Rejected result.</returns>
    public static ValidationStepResult Rejected(string reason, TrustValidationOutcome outcome) =>
        new(ValidationStepStatus.Rejected, reason, outcome);

    #endregion
}
