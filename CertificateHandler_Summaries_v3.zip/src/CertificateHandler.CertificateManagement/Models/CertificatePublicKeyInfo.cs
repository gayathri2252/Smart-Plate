// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models;

/// <summary>
/// Public key details read from a certificate. It never holds a private key.
/// </summary>
public sealed class CertificatePublicKeyInfo
{
    #region Public Properties

    /// <summary>
    /// Key type, like RSA or ECDSA.
    /// </summary>
    public string Algorithm { get; set; } = string.Empty;

    /// <summary>
    /// Key size in bits, like 2048 for a common RSA key. This is the key strength, not the length of KeyData in bytes.
    /// </summary>
    public int KeyBits { get; set; }

    /// <summary>
    /// The public key bytes, like the RSA modulus or the EC public key. It never holds a private key.
    /// </summary>
    public byte[] KeyData { get; set; } = Array.Empty<byte>();

    #endregion
}
