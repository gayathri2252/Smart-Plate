// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Where the private key of a certificate is stored.
/// </summary>
public enum CertificateStorageMedium
{
    /// <summary>
    /// Windows certificate store.
    /// </summary>
    WindowsCertificateStore = 1,

    /// <summary>
    /// Trusted Platform Module.
    /// </summary>
    TPM = 2
}
