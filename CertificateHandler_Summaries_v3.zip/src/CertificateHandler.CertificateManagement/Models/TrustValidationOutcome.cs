// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// How the check of one certificate by the trust engine ended.
/// </summary>
public enum TrustValidationOutcome
{
    /// <summary>
    /// All checks passed.
    /// </summary>
    Passed = 0,

    /// <summary>
    /// The signature is not valid. The thumbprint is added to the blacklist.
    /// </summary>
    BadSignature = 1,

    /// <summary>
    /// The certificate is revoked. The thumbprint is added to the blacklist.
    /// </summary>
    Revoked = 2,

    /// <summary>
    /// The chain to a trusted root is broken. The thumbprint is added to the blacklist.
    /// </summary>
    BrokenChain = 3,

    /// <summary>
    /// A security incident was raised for the certificate. The thumbprint is added to the blacklist.
    /// </summary>
    SecurityIncident = 4,

    /// <summary>
    /// The certificate has expired. The thumbprint is not added to the blacklist.
    /// </summary>
    Expired = 5,

    /// <summary>
    /// The certificate is not valid yet. The thumbprint is not added to the blacklist.
    /// </summary>
    NotYetValid = 6,

    /// <summary>
    /// The time could not be checked, so the validity is not known. The thumbprint is not added to the blacklist.
    /// </summary>
    TimeUnverified = 7
}
