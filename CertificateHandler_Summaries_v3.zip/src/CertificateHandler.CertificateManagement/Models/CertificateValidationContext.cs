// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Models;

/// <summary>
/// Data that every validation step gets, the certificate in DER format and the optional public key of the issuer.
/// </summary>
public sealed class CertificateValidationContext
{
    #region Constructor

    /// <summary>
    /// Creates a context for one certificate.
    /// </summary>
    /// <param name="rawCertificate">The certificate as it was received, in DER format.</param>
    /// <param name="issuerPublicKeyInfo">
    /// Public key of the issuer in DER format. Leave null for a self signed certificate, then the public key of the certificate is used.
    /// </param>
    public CertificateValidationContext(byte[] rawCertificate, byte[]? issuerPublicKeyInfo = null)
    {
        RawCertificate = rawCertificate;
        IssuerPublicKeyInfo = issuerPublicKeyInfo;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// The certificate as it was received, in DER format.
    /// </summary>
    public byte[] RawCertificate { get; }

    /// <summary>
    /// Public key of the issuer in DER format, or null to use the public key of the certificate.
    /// </summary>
    public byte[]? IssuerPublicKeyInfo { get; }

    #endregion
}
