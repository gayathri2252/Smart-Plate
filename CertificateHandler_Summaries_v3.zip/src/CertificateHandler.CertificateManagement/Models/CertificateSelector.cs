// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Input used to find one certificate, the thumbprint, the device and the Windows store location and name to search.
/// </summary>
public sealed class CertificateSelector
{
    #region Public Properties

    /// <summary>
    /// Thumbprint of the certificate to find.
    /// </summary>
    public string Thumbprint { get; set; } = string.Empty;

    /// <summary>
    /// Device that owns the certificate.
    /// </summary>
    public DeviceScope DeviceScope { get; set; }

    /// <summary>
    /// Windows certificate store location to search in.
    /// </summary>
    public WindowsStoreLocation StoreScope { get; set; }

    // Added: previously WindowsCertificateStoreConfiguration.StoreName
    // existed as a model but was never consulted — the adapter always
    // searched "My" regardless. This makes store name selectable per call.
    /// <summary>
    /// Name of the Windows certificate store to search in.
    /// </summary>
    public WindowsStoreName StoreName { get; set; } = WindowsStoreName.My;

    #endregion
}
