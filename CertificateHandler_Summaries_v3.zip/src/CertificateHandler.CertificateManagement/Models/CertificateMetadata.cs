// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Details read from one X.509 certificate by the certificate store adapters. It never holds a private key.
/// </summary>
public sealed class CertificateMetadata
{
    #region Public Properties

    /// <summary>
    /// Thumbprint of the certificate.
    /// </summary>
    public string Thumbprint { get; set; } = string.Empty;

    // Added: previously CreateMetadata() accepted a DeviceScope parameter
    // but had nowhere to store it, so it was silently discarded. Now it's
    // actually recorded on the metadata.
    /// <summary>
    /// Device that owns the certificate.
    /// </summary>
    public DeviceScope Owner { get; set; }

    /// <summary>
    /// Subject name of the certificate.
    /// </summary>
    public string Subject { get; set; } = string.Empty;

    /// <summary>
    /// Issuer name of the certificate.
    /// </summary>
    public string Issuer { get; set; } = string.Empty;

    /// <summary>
    /// Serial number given by the certificate authority.
    /// </summary>
    public string SerialNumber { get; set; } = string.Empty;

    /// <summary>
    /// Date from which the certificate is valid, in UTC.
    /// </summary>
    public DateTime ValidFromUtc { get; set; }

    /// <summary>
    /// Date until which the certificate is valid, in UTC.
    /// </summary>
    public DateTime ValidToUtc { get; set; }

    /// <summary>
    /// Details of the public key.
    /// </summary>
    public CertificatePublicKeyInfo PublicKey { get; set; } = new();

    /// <summary>
    /// True if the certificate has a private key.
    /// </summary>
    public bool HasPrivateKey { get; set; }

    /// <summary>
    /// True if the private key is kept in the TPM.
    /// </summary>
    public bool IsTpmBound { get; set; }

    #endregion

}
