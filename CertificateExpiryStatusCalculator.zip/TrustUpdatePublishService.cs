﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Publishes a trust update that was already committed. If the publish throws, the failure is logged,
/// written to the audit log and shown to the administrator. Each of those steps is isolated, so one
/// failing step cannot stop the others, and the saved trust row is never touched.
/// </summary>
public sealed class TrustUpdatePublishService : ITrustUpdatePublishService
{
    #region Private Fields

    /// <summary>
    /// Publishes the trust updates.
    /// </summary>
    private readonly ITrustUpdatePublisher _publisher;

    /// <summary>
    /// Writes the audit record when publishing fails.
    /// </summary>
    private readonly IPublishFailureAuditWriter _auditWriter;

    /// <summary>
    /// Notifies the administrator when publishing fails.
    /// </summary>
    private readonly IAdministratorNotifier _notifier;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service. None of the arguments may be null.
    /// </summary>
    public TrustUpdatePublishService(ITrustUpdatePublisher publisher, IPublishFailureAuditWriter auditWriter, IAdministratorNotifier notifier)
    {
        _publisher = Require(publisher, TrustPublishConstants.PUBLISHER_IS_NULL, nameof(publisher));
        _auditWriter = Require(auditWriter, TrustPublishConstants.AUDIT_WRITER_IS_NULL, nameof(auditWriter));
        _notifier = Require(notifier, TrustPublishConstants.NOTIFIER_IS_NULL, nameof(notifier));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Publishes the specified trust update. If publishing fails, the failure is
    /// logged, written to the audit log, and reported to the administrator.
    /// </summary>
    /// <param name="update">
    /// Trust update that has already been committed.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the publish operation.
    /// </param>
    /// <returns>
    /// The result of the publish operation, including audit and notification status.
    /// </returns>
    public async Task<PublishResult> PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(update);

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_STARTED, update.ThumbprintSha256);

        try
        {
            await _publisher.PublishAsync(update, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_CANCELLED, update.ThumbprintSha256);
            throw;
        }
        catch (Exception ex)
        {
            return await HandleFailureAsync(update, ex);
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_SUCCEEDED, update.ThumbprintSha256);
        return new PublishResult { Published = true };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Handles a publish failure by logging the error, writing an audit record,
    /// and notifying the administrator.
    /// </summary>
    /// <param name="update">
    /// Trust update that failed to publish.
    /// </param>
    /// <param name="error">
    /// Exception raised during publishing.
    /// </param>
    /// <returns>
    /// Result containing the outcome of the failure-handling actions.
    /// </returns>
    private async Task<PublishResult> HandleFailureAsync(TrustUpdate update, Exception error)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_FAILED, update.ThumbprintSha256, error.Message);

        bool auditWritten = false;
        try
        {
            await _auditWriter.WriteAsync(update, error, CancellationToken.None);
            auditWritten = true;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.AUDIT_WRITTEN, update.ThumbprintSha256);
        }
        catch (Exception auditError)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.AUDIT_FAILED, update.ThumbprintSha256, auditError.Message);
        }

        bool notified = false;
        try
        {
            _notifier.NotifyPublishFailed(BuildNotice(update.ThumbprintSha256));
            notified = true;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), TrustPublishConstants.NOTIFICATION_SENT, update.ThumbprintSha256);
        }
        catch (Exception notifyError)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.NOTIFICATION_FAILED, update.ThumbprintSha256, notifyError.Message);
        }

        return new PublishResult
        {
            Published = false,
            AuditWritten = auditWritten,
            AdministratorNotified = notified,
            Error = error
        };
    }

    /// <summary>
    /// Creates the administrator notification message using a shortened thumbprint.
    /// </summary>
    /// <param name="thumbprint">
    /// Certificate thumbprint associated with the failed publish operation.
    /// </param>
    /// <returns>
    /// Administrator-facing notification text.
    /// </returns>
    private static string BuildNotice(string thumbprint)
    {
        string shortThumbprint = thumbprint.Length > TrustPublishConstants.SHORT_THUMBPRINT_LENGTH
            ? thumbprint[..TrustPublishConstants.SHORT_THUMBPRINT_LENGTH]
            : thumbprint;
        return TrustPublishConstants.ADMIN_NOTICE.Replace(TrustPublishConstants.MESSAGE_PLACEHOLDER, shortThumbprint);
    }

    /// <summary>
    /// Validates that the specified dependency is not null and logs an error before
    /// throwing an exception when validation fails.
    /// </summary>
    /// <typeparam name="T">
    /// Dependency type.
    /// </typeparam>
    /// <param name="value">
    /// Dependency instance to validate.
    /// </param>
    /// <param name="message">
    /// Log message written when the dependency is null.
    /// </param>
    /// <param name="name">
    /// Name of the dependency parameter.
    /// </param>
    /// <returns>
    /// The validated dependency instance.
    /// </returns>
    /// <exception cref="ArgumentNullException">
    /// Thrown when the dependency is null.
    /// </exception>
    private static T Require<T>(T value, string message, string name) where T : class
    {
        if (value is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), message);
            throw new ArgumentNullException(name);
        }
        return value;
    }

    #endregion
}
