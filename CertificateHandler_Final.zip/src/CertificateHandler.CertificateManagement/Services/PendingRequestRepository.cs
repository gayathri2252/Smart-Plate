﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using Npgsql;

namespace CertificateHandler.CertificateManagement.Services;
/// <summary>
/// Service layer responsible for managing
/// pending request operations and coordinating
/// communication between the UI and repository.
/// </summary>
public class PendingRequestRepository : IPendingRequestRepository
{
    #region Member Variables
    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>Database value of an approved request.</summary>
    private const string APPROVED_STATUS = "APPROVED";

    /// <summary>Database value of a rejected request.</summary>
    private const string REJECTED_STATUS = "REJECTED";

    /// <summary>Database value of an expired request.</summary>
    private const string EXPIRED_STATUS = "EXPIRED";

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the
    /// PendingRequestQueueService class.
    /// </summary>
    /// <param name="dataSource">
    /// Repository used for retrieving and updating
    /// pending request information.
    /// </param>
    /// <exception cref="ArgumentNullException"></exception>
    public PendingRequestRepository(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Retrieves all pending requests from
    /// the repository.
    /// </summary>
    /// <returns>
    /// Collection of pending request items.
    /// </returns>
    public IEnumerable<PendingRequestItem>
        GetPendingRequests()
    {
        try
        {
            List<PendingRequestItem> requests = new();
            using NpgsqlConnection connection = DatabaseServerConnection.Open(_dataSource);
            // The certificate validity dates are not part of the overview view, so they are read from the
            // certificate of each request.
            const string QUERY =
                @"SELECT v.*, c.not_before, c.not_after,
                         COALESCE(NULLIF(d.device_name, ''), d.device_code) AS device_display_name
                  FROM certificate_handler.vw_pending_queue_overview v
                  JOIN certificate_handler.ch_pending_request pr ON pr.request_id = v.request_id
                  JOIN certificate_handler.ch_certificate c ON c.certificate_id = pr.certificate_id
                  JOIN certificate_handler.ch_device d ON d.device_id = pr.device_id
                  WHERE v.current_status = 'PENDING'
                  AND c.not_after > now()
                  ORDER BY v.request_date DESC;";
            using NpgsqlCommand command = new(QUERY, connection);
            using NpgsqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                requests.Add(ReadRequest(reader));
            }

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(), PendingRequestRepositoryConstants.PENDING_REQUESTS_READ, requests.Count.ToString());
            return requests;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), PendingRequestRepositoryConstants.PENDING_REQUESTS_READ_FAILED, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Retrieves the certificate requests that have the given status. EXPIRED also returns pending
    /// requests whose certificate is no longer valid, because the Request Queue no longer shows them as pending;
    /// their status is shown as Expired. The status is returned as Approved, Rejected or Expired, the same style as Pending.
    /// </summary>
    /// <param name="status">
    /// APPROVED, REJECTED or EXPIRED.
    /// </param>
    /// <returns>
    /// Collection of request items with that status, newest first.
    /// </returns>
    /// <exception cref="ArgumentException">The status is not APPROVED, REJECTED or EXPIRED.</exception>
    public IEnumerable<PendingRequestItem> GetRequestsByStatus(string status)
    {
        string normalizedStatus = (status ?? string.Empty).Trim().ToUpperInvariant();
        if (normalizedStatus is not (APPROVED_STATUS or REJECTED_STATUS or EXPIRED_STATUS))
        {
            throw new ArgumentException(PendingRequestRepositoryConstants.UNSUPPORTED_REQUEST_STATUS, nameof(status));
        }

        try
        {
            List<PendingRequestItem> requests = new();
            using NpgsqlConnection connection = DatabaseServerConnection.Open(_dataSource);
            const string QUERY =
                @"SELECT v.*, c.not_before, c.not_after,
                         COALESCE(NULLIF(d.device_name, ''), d.device_code) AS device_display_name,
                         CASE WHEN v.current_status = 'PENDING' AND c.not_after <= now()
                              THEN 'Expired'
                              ELSE initcap(v.current_status::text)
                         END AS display_status
                  FROM certificate_handler.vw_pending_queue_overview v
                  JOIN certificate_handler.ch_pending_request pr ON pr.request_id = v.request_id
                  JOIN certificate_handler.ch_certificate c ON c.certificate_id = pr.certificate_id
                  JOIN certificate_handler.ch_device d ON d.device_id = pr.device_id
                  WHERE (@status = 'EXPIRED'
                         AND (v.current_status = 'EXPIRED'
                              OR (v.current_status = 'PENDING' AND c.not_after <= now())))
                     OR (@status <> 'EXPIRED' AND v.current_status::text = @status)
                  ORDER BY v.request_date DESC;";
            using NpgsqlCommand command = new(QUERY, connection);
            command.Parameters.AddWithValue("@status", normalizedStatus);
            using NpgsqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                PendingRequestItem item = ReadRequest(reader);
                item.CurrentStatus = reader["display_status"].ToString() ?? string.Empty;
                requests.Add(item);
            }

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                PendingRequestRepositoryConstants.REQUESTS_BY_STATUS_READ,
                requests.Count.ToString(),
                normalizedStatus);
            return requests;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                PendingRequestRepositoryConstants.REQUESTS_BY_STATUS_READ_FAILED,
                normalizedStatus,
                ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Counts the certificate requests in each status. Pending counts only requests whose certificate
    /// is still valid, the same requests the Request Queue shows; a pending request whose certificate
    /// is no longer valid is counted as expired.
    /// </summary>
    /// <returns>
    /// The number of pending, approved, rejected and expired requests.
    /// </returns>
    public RequestStatusCounts GetRequestStatusCounts()
    {
        try
        {
            using NpgsqlConnection connection = DatabaseServerConnection.Open(_dataSource);
            const string QUERY =
                @"SELECT
                    COUNT(*) FILTER (WHERE pr.status = 'PENDING' AND c.not_after > now()) AS pending_count,
                    COUNT(*) FILTER (WHERE pr.status = 'APPROVED') AS approved_count,
                    COUNT(*) FILTER (WHERE pr.status = 'REJECTED') AS rejected_count,
                    COUNT(*) FILTER (WHERE pr.status = 'EXPIRED'
                                     OR (pr.status = 'PENDING' AND c.not_after <= now())) AS expired_count
                  FROM certificate_handler.ch_pending_request pr
                  JOIN certificate_handler.ch_certificate c ON c.certificate_id = pr.certificate_id;";
            using NpgsqlCommand command = new(QUERY, connection);
            using NpgsqlDataReader reader = command.ExecuteReader();

            RequestStatusCounts counts = new();
            if (reader.Read())
            {
                counts.Pending = Convert.ToInt32(reader["pending_count"]);
                counts.Approved = Convert.ToInt32(reader["approved_count"]);
                counts.Rejected = Convert.ToInt32(reader["rejected_count"]);
                counts.Expired = Convert.ToInt32(reader["expired_count"]);
            }

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                PendingRequestRepositoryConstants.STATUS_COUNTS_READ,
                counts.Pending.ToString(),
                counts.Approved.ToString(),
                counts.Rejected.ToString(),
                counts.Expired.ToString());
            return counts;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), PendingRequestRepositoryConstants.STATUS_COUNTS_READ_FAILED, ex.Message);
            throw;
        }
    }

    /// <inheritdoc />
    public string GetRequestType(string requestId)
    {
        if (!Guid.TryParse(requestId, out Guid id))
        {
            return string.Empty;
        }

        using NpgsqlConnection connection = _dataSource.OpenConnection();
        using var command = new NpgsqlCommand(
            "SELECT request_type::text FROM certificate_handler.ch_pending_request WHERE request_id = @id",
            connection);
        command.Parameters.AddWithValue("id", id);
        object? result = command.ExecuteScalar();
        return result?.ToString() ?? string.Empty;
    }

    /// <summary>
    /// Approves the specified pending request
    /// </summary>
    /// <param name="requestId">
    /// Identifier of the request to approve.
    /// </param>
    public void ApproveRequest(string requestId)
    {
        throw new NotSupportedException("Use PendingRequestQueueService with PendingOnboardingApprovalStore.");
    }

    /// <summary>
    /// Rejects the specified pending request.
    /// </summary>
    /// <param name="requestId">
    /// Identifier of the request to reject.
    /// </param>
    public void RejectRequest(string requestId)
    {
        throw new NotSupportedException("Use PendingRequestQueueService with PendingOnboardingApprovalStore.");
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds a request item from the current row of the overview query.
    /// </summary>
    /// <param name="reader">Reader positioned on a row.</param>
    /// <returns>The request item of that row.</returns>
    private static PendingRequestItem ReadRequest(NpgsqlDataReader reader)
    {
        return new PendingRequestItem
        {
            RequestId = reader["request_id"].ToString() ?? string.Empty,
            DeviceIdentifier = reader["device_display_name"].ToString() ?? string.Empty,
            RequestType = reader["request_type"].ToString() ?? string.Empty,
            RequesterIdentity = reader["requester_identity"].ToString() ?? string.Empty,
            RequestedBy = reader["requested_by"].ToString() ?? string.Empty,
            RequestDate = Convert.ToDateTime(reader["request_date"]),
            CurrentStatus = reader["current_status"].ToString() ?? string.Empty,
            MaxumIpAddress = reader["maxum_ip"].ToString() ?? string.Empty,
            CertificateThumbprint = reader["thumbprint_sha256"].ToString() ?? string.Empty,
            CertificateSubject = reader["subject_dn"].ToString() ?? string.Empty,
            CertificateValidFrom = reader["not_before"] is DateTime validFrom ? validFrom : null,
            CertificateValidTo = reader["not_after"] is DateTime validTo ? validTo : null
        };
    }

    #endregion

}