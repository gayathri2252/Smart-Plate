// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Windows TPM key storage provider (Microsoft Platform Crypto Provider).
/// </summary>
internal static class TpmPlatformCrypto
{
    /// <summary>Name of the Windows TPM key storage provider.</summary>
    public const string ProviderName = "Microsoft Platform Crypto Provider";

    /// <summary>
    /// Checks if the TPM key storage provider can be opened on this machine.
    /// </summary>
    public static bool IsAvailable()
    {
        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        int status = NCryptOpenStorageProvider(out IntPtr provider, ProviderName, 0);
        if (status != 0)
        {
            return false;
        }

        NCryptFreeObject(provider);
        return true;
    }

    /// <summary>
    /// Checks if the private key of the certificate is kept in the TPM.
    /// </summary>
    public static bool IsTpmBacked(X509Certificate2 certificate)
    {
        try
        {
            if (!certificate.HasPrivateKey)
            {
                return false;
            }

            using RSA? rsa = certificate.GetRSAPrivateKey();
            if (rsa is RSACng rsaCng && rsaCng.Key.Provider is not null)
            {
                return string.Equals(rsaCng.Key.Provider.Provider, ProviderName, StringComparison.Ordinal);
            }

            using ECDsa? ecdsa = certificate.GetECDsaPrivateKey();
            if (ecdsa is ECDsaCng ecdsaCng && ecdsaCng.Key.Provider is not null)
            {
                return string.Equals(ecdsaCng.Key.Provider.Provider, ProviderName, StringComparison.Ordinal);
            }
        }
        catch (CryptographicException)
        {
            return false;
        }

        return false;
    }

    /// <summary>
    /// Creates a new key in the TPM and returns the certificate signing request in PEM format.
    /// Throws when not running on Windows.
    /// </summary>
    public static string CreateCsrPem(Guid keyId)
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new InvalidOperationException(Shared.Constants.RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE);
        }

        return CreateWindowsCsr(keyId);
    }

    /// <summary>
    /// Creates a 2048 bit RSA key in the TPM and builds the certificate signing request with it.
    /// </summary>
    [SupportedOSPlatform("windows")]
    private static string CreateWindowsCsr(Guid keyId)
    {
        if (!IsAvailable())
        {
            throw new InvalidOperationException(Shared.Constants.RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE);
        }

        var parameters = new CngKeyCreationParameters
        {
            Provider = new CngProvider(ProviderName),
            KeyCreationOptions = CngKeyCreationOptions.MachineKey | CngKeyCreationOptions.OverwriteExistingKey,
            KeyUsage = CngKeyUsages.Signing
        };
        parameters.Parameters.Add(new CngProperty("Length", BitConverter.GetBytes(2048), CngPropertyOptions.None));

        using CngKey key = CngKey.Create(CngAlgorithm.Rsa, "CH-RENEW-" + keyId.ToString("N"), parameters);
        using var rsa = new RSACng(key);
        var request = new CertificateRequest("CN=MAXUM-" + keyId.ToString("N"), rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        byte[] csr = request.CreateSigningRequest();
        return new string(PemEncoding.Write("CERTIFICATE REQUEST", csr));
    }

    /// <summary>
    /// Opens the key storage provider with the given name.
    /// </summary>
    [DllImport("ncrypt.dll", CharSet = CharSet.Unicode)]
    private static extern int NCryptOpenStorageProvider(out IntPtr phProvider, string pszProviderName, int dwFlags);

    /// <summary>
    /// Frees a key storage object.
    /// </summary>
    [DllImport("ncrypt.dll")]
    private static extern int NCryptFreeObject(IntPtr hObject);
}
