﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;
using CertificateHandler.Audit.Services;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Audit.Models;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Manages pending certificate requests and handles
/// request expiration based on the configured timeout.
/// </summary>
public class PendingRequestManager
{
    #region Member Variables

    /// <summary>Timeout settings for the pending requests.</summary>
    private readonly TimeoutConfiguration _timeoutConfiguration;
    /// <summary>Writes the audit records.</summary>
    private readonly AuditLogService _auditLogService;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the PendingRequestManager class.
    /// </summary>
    /// <param name="timeoutConfiguration">
    /// Provides the configured timeout duration used to determine
    /// when a pending request should expire.
    /// </param>
    /// <param name="auditLogService">
    /// Provides audit logging functionality for recording
    /// pending request-related events.
    /// </param>
    public PendingRequestManager(TimeoutConfiguration timeoutConfiguration, AuditLogService auditLogService)
    {
        _timeoutConfiguration = timeoutConfiguration;
        _auditLogService = auditLogService;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Determines whether a pending request has exceeded the
    /// configured timeout duration.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to validate.
    /// </param>
    /// <returns>
    /// True if the request has expired; otherwise, false.
    /// </returns>
    public bool HasRequestExpired(PendingCertificateRequest request)
    {
        TimeSpan elapsedTime = DateTime.UtcNow - request.CreatedTime;
        return elapsedTime.TotalHours >= _timeoutConfiguration.PendingRequestExpiryTimeout;
    }

    /// <summary>
    /// Processes a pending request and marks it as expired
    /// when the configured timeout duration is reached.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to process.
    /// </param>
    public void ProcessPendingRequest(PendingCertificateRequest request)
    {
        if (HasRequestExpired(request))
        {
            ExpirePendingRequest(request);
        }

    }

    /// <summary>
    /// Updates the request status to Expired and records
    /// the expiration timestamp.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to expire.
    /// </param>
    public void ExpirePendingRequest(PendingCertificateRequest request)
    {
        request.Status = RequestStatusConstants.EXPIRED;
        request.ExpiryTime = DateTime.UtcNow;
        CertificateHandlerLogger.Warning(
            MessageIdGenerator.Next(),
            RequestStatusConstants.PENDING_REQUEST_EXPIRED_MESSAGE,
            string.IsNullOrWhiteSpace(request.CertificateName) ? RequestStatusConstants.UNKNOWN_CERTIFICATE_NAME : request.CertificateName);

        _auditLogService.CreateAuditLog(new AuditLog
        {
            AuditId = 0,
            RequestId = request.RequestID,
            DeviceId = request.DeviceID,
            DeviceName = request.DeviceID,
            CertificateThumbprint = string.Empty,
            ApproverName = RequestStatusConstants.SYSTEM,
            Reason = RequestStatusConstants.PENDING_REQUEST_EXPIRED,
            ActionType = RequestStatusConstants.AUTO_EXPIRY,
            CertificateSubject = string.Empty,
            ActionStatus = RequestStatusConstants.EXPIRED,
            Comments = RequestStatusConstants.REQUEST_AUTOMATICALLY_EXPIRED
        });
    }

    /// <summary>
    /// Determines whether the request can still be approved
    /// or rejected by an administrator.
    /// </summary>
    /// <param name="request">
    /// The pending certificate request to evaluate
    /// </param>
    /// <returns>
    /// True if the request is processable; otherwise, false.
    /// </returns>
    public static bool IsRequestProcessable(PendingCertificateRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        return request.Status != RequestStatusConstants.EXPIRED;
    }

    #endregion

}
