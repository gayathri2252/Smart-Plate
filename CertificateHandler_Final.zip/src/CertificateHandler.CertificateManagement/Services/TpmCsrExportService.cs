// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Exports a CSR whose key is created in the Windows TPM key storage provider (RS_26).
/// </summary>
public sealed class TpmCsrExportService : ITpmCsrExportService
{
    /// <summary>
    /// Creates a new key in the TPM and returns the certificate signing request in PEM format.
    /// </summary>
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            return Task.FromResult(TpmPlatformCrypto.CreateCsrPem(keyId));
        }
        catch (Exception ex) when (ex is not InvalidOperationException and not OperationCanceledException)
        {
            throw new InvalidOperationException(RequestStatusConstants.TPM_PROVIDER_UNAVAILABLE, ex);
        }
    }
}
