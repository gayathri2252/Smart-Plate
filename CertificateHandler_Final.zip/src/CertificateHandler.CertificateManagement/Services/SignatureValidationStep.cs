// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Formats.Asn1;
using System.Security.Cryptography;
using CertificateHandler.CertificateManagement.Constants;
using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// First validation step. Checks the certificate signature over the TBS bytes
/// (RSA PKCS#1 v1.5 or ECDSA, with SHA-256/384/512) before anything else is looked at.
/// </summary>
public sealed class SignatureValidationStep : ICertificateValidationStep
{
    #region Member Variables

    /// <summary>
    /// Key types that the signature check supports.
    /// </summary>
    private enum KeyFamily
    {
        /// <summary>RSA key.</summary>
        Rsa,
        /// <summary>ECDSA key.</summary>
        Ecdsa
    }

    /// <summary>Signature algorithms that are supported. The key is the algorithm id and the value has the key type, hash and name.</summary>
    private static readonly Dictionary<string, (KeyFamily Family, HashAlgorithmName Hash, string Name)> SupportedAlgorithms = new()
    {
        ["1.2.840.113549.1.1.11"] = (KeyFamily.Rsa, HashAlgorithmName.SHA256, "sha256WithRSAEncryption"),
        ["1.2.840.113549.1.1.12"] = (KeyFamily.Rsa, HashAlgorithmName.SHA384, "sha384WithRSAEncryption"),
        ["1.2.840.113549.1.1.13"] = (KeyFamily.Rsa, HashAlgorithmName.SHA512, "sha512WithRSAEncryption"),
        ["1.2.840.10045.4.3.2"] = (KeyFamily.Ecdsa, HashAlgorithmName.SHA256, "ecdsa-with-SHA256"),
        ["1.2.840.10045.4.3.3"] = (KeyFamily.Ecdsa, HashAlgorithmName.SHA384, "ecdsa-with-SHA384"),
        ["1.2.840.10045.4.3.4"] = (KeyFamily.Ecdsa, HashAlgorithmName.SHA512, "ecdsa-with-SHA512")
    };

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public ValidationStepResult Validate(CertificateValidationContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        CertificateParts parts;
        try
        {
            parts = CertificatePartsReader.Read(context.RawCertificate);
        }
        catch (CertificateFormatException ex)
        {
            return Reject("Certificate is damaged: " + ex.Message);
        }

        if (!SupportedAlgorithms.TryGetValue(parts.SignatureAlgorithmOid, out var algorithm))
        {
            return Reject("Signature algorithm is not supported: " + parts.SignatureAlgorithmOid);
        }

        byte[] publicKey = context.IssuerPublicKeyInfo ?? parts.SubjectPublicKeyInfo;

        bool valid;
        try
        {
            valid = algorithm.Family == KeyFamily.Rsa
                ? VerifyRsa(publicKey, parts, algorithm.Hash)
                : VerifyEcdsa(publicKey, parts, algorithm.Hash);
        }
        catch (Exception ex) when (ex is CryptographicException or AsnContentException or ArgumentException)
        {
            return Reject("Signature could not be checked (" + algorithm.Name + "): " + ex.Message);
        }

        if (!valid)
        {
            return Reject("Signature does not match the certificate (" + algorithm.Name + ").");
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(),
            SignatureValidationConstants.SIGNATURE_CHECK_PASSED, algorithm.Name);
        return ValidationStepResult.Pass();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Logs the problem and returns a failed result for a bad signature.
    /// </summary>
    private static ValidationStepResult Reject(string reason)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(),
            SignatureValidationConstants.SIGNATURE_CHECK_REJECTED, reason);
        return ValidationStepResult.Rejected(reason, TrustValidationOutcome.BadSignature);
    }

    /// <summary>
    /// Checks an RSA signature of the certificate.
    /// </summary>
    private static bool VerifyRsa(byte[] spki, CertificateParts parts, HashAlgorithmName hash)
    {
        using var rsa = RSA.Create();
        rsa.ImportSubjectPublicKeyInfo(spki, out _);
        return rsa.VerifyData(parts.ToBeSigned, parts.Signature, hash, RSASignaturePadding.Pkcs1);
    }

    /// <summary>
    /// Checks an ECDSA signature of the certificate.
    /// </summary>
    private static bool VerifyEcdsa(byte[] spki, CertificateParts parts, HashAlgorithmName hash)
    {
        using var ecdsa = ECDsa.Create();
        ecdsa.ImportSubjectPublicKeyInfo(spki, out _);
        return ecdsa.VerifyData(parts.ToBeSigned, parts.Signature, hash, DSASignatureFormat.Rfc3279DerSequence);
    }

    #endregion
}
