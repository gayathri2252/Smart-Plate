// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Outcome of a certificate lookup operation. Describes how the lookup
/// itself went, not the certificate's own validity or trust status.
/// </summary>
public enum CertLookupStatus
{
    /// <summary>The certificate was found.</summary>
    Found = 1,
    /// <summary>No certificate matches the search.</summary>
    CertificateNotFound = 2,
    /// <summary>More than one certificate matches the search.</summary>
    MultipleMatches = 3,
    /// <summary>Access to the certificate store was denied.</summary>
    AccessDenied = 4,
    /// <summary>The certificate is not valid.</summary>
    InvalidCertificate = 5,
    /// <summary>The certificate store is not available.</summary>
    StoreUnavailable = 6,
    /// <summary>The TPM is not available.</summary>
    TPMUnavailable = 7,
    /// <summary>Some other error happened.</summary>
    UnknownError = 99
}
