// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Identifies which MAXUM device a certificate belongs to. Descriptive
/// label only — does not change how or where a lookup happens.
/// </summary>
public enum DeviceScope
{
    /// <summary>Single board computer.</summary>
    SBC = 1,
    /// <summary>MIB device.</summary>
    MIB = 2
}
