// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Which Windows certificate store scope to search: the machine itself,
/// or the current logged-in user.
/// </summary>
public enum WindowsStoreLocation
{
    /// <summary>Store of the local machine.</summary>
    LocalMachine = 1,
    /// <summary>Store of the current user.</summary>
    CurrentUser = 2
}
