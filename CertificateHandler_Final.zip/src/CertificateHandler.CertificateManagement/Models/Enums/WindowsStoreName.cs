// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Models.Enums;

/// <summary>
/// Logical certificate category within a Windows store location: personal
/// identity, trusted root CA, or intermediate CA.
/// </summary>
public enum WindowsStoreName
{
    /// <summary>Personal store that holds the device certificates.</summary>
    My = 1,
    /// <summary>Trusted root certificate authorities store.</summary>
    Root = 2,
    /// <summary>Intermediate certificate authorities store.</summary>
    CertificateAuthority = 3
}
