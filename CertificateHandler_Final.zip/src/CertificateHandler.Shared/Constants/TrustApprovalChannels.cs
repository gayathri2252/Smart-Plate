// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Shared.Constants;

/// <summary>
/// How a whitelist row was created. MCC actions are allowed only after an HMI_LOCAL workstation whitelist.
/// </summary>
public static class TrustApprovalChannels
{
    public const string HmiLocal = "HMI_LOCAL";

    public const string Mcc = "MCC";

    public const string MaxumAuto = "MAXUM_AUTO";
}
