// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.Concurrent;

namespace CertificateHandler.Shared.Trust;

/// <summary>
/// In-device gate for protected MAXUM services (RS_27). A thumbprint stays closed until a
/// whitelist or MAXUM auto-approve opens it, and closes again on blacklist or a pending decision.
/// </summary>
public sealed class ProtectedServiceGate
{
    private readonly ConcurrentDictionary<string, byte> _allowed = new(StringComparer.OrdinalIgnoreCase);

    public static ProtectedServiceGate Shared { get; } = new();

    public void Allow(string thumbprintSha256)
    {
        if (!string.IsNullOrWhiteSpace(thumbprintSha256))
        {
            _allowed[thumbprintSha256.Trim()] = 0;
        }
    }

    public void Deny(string thumbprintSha256)
    {
        if (!string.IsNullOrWhiteSpace(thumbprintSha256))
        {
            _allowed.TryRemove(thumbprintSha256.Trim(), out _);
        }
    }

    public bool IsAllowed(string thumbprintSha256)
    {
        return !string.IsNullOrWhiteSpace(thumbprintSha256)
            && _allowed.ContainsKey(thumbprintSha256.Trim());
    }

    public void Reset() => _allowed.Clear();
}
