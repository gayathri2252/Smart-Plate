﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using System.Text;
using System.Text.Json;
using CertificateHandler.Communication.Constants;
using CertificateHandler.Communication.Interface;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Refreshes the session by posting the refresh token to the configured HTTP endpoint.
/// 400, 401 and 403 answers throw SessionRejectedException; connection problems and timeouts throw network exceptions.
/// </summary>
public sealed class HttpTokenRefreshClient : ITokenRefreshClient
{
    #region Member Variables

    /// <summary>HTTP client used to send the refresh request.</summary>
    private readonly HttpClient _httpClient;
    /// <summary>Settings for the session refresh.</summary>
    private readonly SessionRefreshOptions _options;
    /// <summary>Gives the current time.</summary>
    private readonly TimeProvider _timeProvider;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the client with the HTTP client, the refresh settings and an optional clock.
    /// </summary>
    public HttpTokenRefreshClient(HttpClient httpClient, SessionRefreshOptions options, TimeProvider? timeProvider = null)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _timeProvider = timeProvider ?? TimeProvider.System;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Requests a new access token using the current refresh token and returns
    /// an updated session token.
    /// </summary>
    /// <param name="current">The current session token.</param>
    /// <param name="cancellationToken">Token used to cancel the operation.</param>
    /// <returns>A refreshed session token.</returns>
    /// <exception cref="SessionRejectedException">
    /// Thrown when the refresh request is rejected by the server.
    /// </exception>
    /// <exception cref="TimeoutException">
    /// Thrown when the refresh request exceeds the configured timeout.
    /// </exception>
    /// <exception cref="FormatException">
    /// Thrown when the response body is missing or contains invalid token data.
    /// </exception>
    public async Task<SessionToken> RefreshAsync(SessionToken current, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(current);

        if (string.IsNullOrWhiteSpace(_options.RefreshEndpoint))
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_ENDPOINT_MISSING);
            throw new InvalidOperationException(SessionRefreshConstants.REFRESH_ENDPOINT_MISSING_MESSAGE);
        }

        using var timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutSource.CancelAfter(TimeSpan.FromSeconds(_options.RequestTimeoutSeconds));

        using var request = CreateRequest(current);

        string endpoint = _options.RefreshEndpoint;
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_REQUEST_SENT, endpoint);

        try
        {
            using HttpResponseMessage response = await _httpClient
                .SendAsync(request, timeoutSource.Token)
                .ConfigureAwait(false);

            LogServerAnswer(endpoint, response.StatusCode);
            ThrowIfUnsuccessful(response.StatusCode);

            string body = await response.Content.ReadAsStringAsync(timeoutSource.Token).ConfigureAwait(false);
            ThrowIfBodyMissing(response.StatusCode, body);

            try
            {
                return ParseToken(body, current);
            }
            catch (JsonException ex)
            {
                throw new FormatException(SessionRefreshConstants.REFRESH_RESPONSE_INVALID_MESSAGE, ex);
            }
        }
        catch (OperationCanceledException ex) when (!cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_TIMEOUT, endpoint, _options.RequestTimeoutSeconds.ToString());
            throw new TimeoutException(ex.Message, ex);
        }
        catch (HttpRequestException ex) when (ex.StatusCode is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_UNREACHABLE, endpoint, ex.Message);
            throw;
        }
        catch (FormatException ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_INVALID_RESPONSE, endpoint, ex.Message);
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Writes the server answer to the Log Monitor: Information for success, Warning for a refused
    /// refresh (400, 401, 403) and Error for any other error code.
    /// </summary>
    private static void LogServerAnswer(string endpoint, HttpStatusCode statusCode)
    {
        int code = (int)statusCode;
        string codeText = code.ToString();

        if (code is >= 200 and < 300)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_ANSWERED, endpoint, codeText);
        }
        else if (statusCode is HttpStatusCode.BadRequest or HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_REFUSED, endpoint, codeText);
        }
        else
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SERVER_ERROR, endpoint, codeText);
        }
    }

    /// <summary>
    /// Builds the POST request that carries the refresh token as JSON.
    /// </summary>
    private HttpRequestMessage CreateRequest(SessionToken current)
    {
        string json = JsonSerializer.Serialize(new Dictionary<string, string>
        {
            [SessionRefreshConstants.REFRESH_TOKEN_FIELD] = current.RefreshToken
        });

        return new HttpRequestMessage(HttpMethod.Post, _options.RefreshEndpoint)
        {
            Content = new StringContent(json, Encoding.UTF8, SessionRefreshConstants.JSON_MEDIA_TYPE)
        };
    }

    /// <summary>
    /// Throws SessionRejectedException for refused refreshes and HttpRequestException for other error codes.
    /// </summary>
    private static void ThrowIfUnsuccessful(HttpStatusCode statusCode)
    {
        int code = (int)statusCode;

        if (code is >= 200 and < 300)
        {
            return;
        }

        if (statusCode is HttpStatusCode.BadRequest or HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
        {
            throw new SessionRejectedException(
                string.Format(SessionRefreshConstants.REFRESH_REJECTED_MESSAGE, code));
        }

        throw new HttpRequestException(
            string.Format(SessionRefreshConstants.REFRESH_SERVER_ERROR_MESSAGE, code),
            null,
            statusCode);
    }

    /// <summary>
    /// Throws FormatException when a successful answer has no body (for example 204 No Content),
    /// because the new tokens can only be read from the body. It is not retried like a network failure.
    /// </summary>
    private static void ThrowIfBodyMissing(HttpStatusCode statusCode, string body)
    {
        if (statusCode is HttpStatusCode.NoContent or HttpStatusCode.ResetContent || string.IsNullOrWhiteSpace(body))
        {
            throw new FormatException(string.Format(SessionRefreshConstants.REFRESH_RESPONSE_EMPTY_MESSAGE, (int)statusCode));
        }
    }

    /// <summary>
    /// Reads the new tokens from the response body. The user stays the same as in the current session.
    /// A missing refresh token in the response keeps the current one.
    /// </summary>
    private SessionToken ParseToken(string body, SessionToken current)
    {
        using JsonDocument document = JsonDocument.Parse(body);
        JsonElement root = document.RootElement;

        if (!root.TryGetProperty(SessionRefreshConstants.ACCESS_TOKEN_FIELD, out JsonElement accessElement) ||
            string.IsNullOrWhiteSpace(accessElement.GetString()) ||
            !root.TryGetProperty(SessionRefreshConstants.EXPIRES_IN_FIELD, out JsonElement expiresElement) ||
            !expiresElement.TryGetInt32(out int expiresInSeconds))
        {
            throw new FormatException(SessionRefreshConstants.REFRESH_RESPONSE_INVALID_MESSAGE);
        }

        string refreshToken = root.TryGetProperty(SessionRefreshConstants.REFRESH_TOKEN_FIELD, out JsonElement refreshElement) && !string.IsNullOrWhiteSpace(refreshElement.GetString())
            ? refreshElement.GetString()!
            : current.RefreshToken;

        return new SessionToken(
            current.UserName,
            accessElement.GetString()!,
            refreshToken,
            _timeProvider.GetUtcNow().AddSeconds(expiresInSeconds));
    }

    #endregion
}
