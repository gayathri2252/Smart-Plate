﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Communication.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Stores the current user session in memory.
/// </summary>
public interface ISessionStore
{
    /// <summary>
    /// Gets the current session token, or null when no user is signed in.
    /// </summary>
    SessionToken? Current { get; }

    /// <summary>
    /// Gets a value indicating whether a user is signed in.
    /// </summary>
    bool HasSession { get; }

    /// <summary>
    /// Starts a new session after the user signs in.
    /// </summary>
    void Start(SessionToken token);

    /// <summary>
    /// Replaces the tokens of the current session after a successful refresh.
    /// The user of the new token must match the user of the current session.
    /// </summary>
    void Replace(SessionToken token);

    /// <summary>
    /// Replaces the tokens only when the current session is still the one the refresh started with.
    /// Returns false, and keeps the current session, when the user signed out or in again meanwhile.
    /// </summary>
    bool TryReplace(SessionToken expectedCurrent, SessionToken refreshed);

    /// <summary>
    /// Ends the session only when it is still the given one. Returns false when it already changed.
    /// </summary>
    bool TryEnd(SessionToken expectedCurrent);

    /// <summary>
    /// Ends the current session.
    /// </summary>
    void End();
}

/// <summary>
/// Thread-safe in-memory store for the current user session.
/// A refresh failure never clears the session; only End removes it.
/// </summary>
public sealed class SessionStore : ISessionStore
{
    #region Member Variables

    /// <summary>
    /// Lock used when reading or changing the current token.
    /// </summary>
    private readonly object _syncLock = new();
    /// <summary>
    /// The current session token. Null when there is no session.
    /// </summary>
    private SessionToken? _current;

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the current session token. Null when there is no session.
    /// </summary>
    public SessionToken? Current
    {
        get
        {
            lock (_syncLock)
            {
                return _current;
            }
        }
    }

    /// <summary>
    /// True when there is a session.
    /// </summary>
    public bool HasSession => Current is not null;

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts a new user session using the specified session token.
    /// </summary>
    /// <param name="token">The session token for the authenticated user.</param>
    public void Start(SessionToken token)
    {
        ArgumentNullException.ThrowIfNull(token);

        lock (_syncLock)
        {
            _current = token;
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SESSION_STARTED, token.UserName);
    }

    /// <summary>
    /// Replaces the current session token with a refreshed token while ensuring
    /// that both tokens belong to the same user.
    /// </summary>
    /// <param name="token">The refreshed session token.</param>
    public void Replace(SessionToken token)
    {
        ArgumentNullException.ThrowIfNull(token);

        lock (_syncLock)
        {
            if (_current is not null &&
                !string.Equals(_current.UserName, token.UserName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(string.Format(
                    SessionRefreshConstants.SESSION_USER_MISMATCH_MESSAGE,
                    token.UserName,
                    _current.UserName));
            }

            _current = token;
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SESSION_TOKENS_REPLACED, token.UserName);
    }

    /// <summary>
    /// Replaces the current session token only if the expected session is still active.
    /// </summary>
    /// <param name="expectedCurrent">The session expected to be active.</param>
    /// <param name="refreshed">The refreshed session token.</param>
    /// <returns>
    /// True if the session was successfully replaced; otherwise, false.
    /// </returns>
    public bool TryReplace(SessionToken expectedCurrent, SessionToken refreshed)
    {
        ArgumentNullException.ThrowIfNull(expectedCurrent);
        ArgumentNullException.ThrowIfNull(refreshed);

        lock (_syncLock)
        {
            if (!ReferenceEquals(_current, expectedCurrent))
            {
                return false;
            }

            if (!string.Equals(expectedCurrent.UserName, refreshed.UserName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(string.Format(
                    SessionRefreshConstants.SESSION_USER_MISMATCH_MESSAGE,
                    refreshed.UserName,
                    expectedCurrent.UserName));
            }

            _current = refreshed;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SESSION_TOKENS_REPLACED, refreshed.UserName);
            return true;
        }
    }

    /// <summary>
    /// Ends the current session only if it matches the expected session.
    /// </summary>
    /// <param name="expectedCurrent">The session expected to be active.</param>
    /// <returns>
    /// True if the session was ended; otherwise, false.
    /// </returns>
    public bool TryEnd(SessionToken expectedCurrent)
    {
        ArgumentNullException.ThrowIfNull(expectedCurrent);

        lock (_syncLock)
        {
            if (!ReferenceEquals(_current, expectedCurrent))
            {
                return false;
            }

            _current = null;
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SESSION_ENDED, expectedCurrent.UserName);
            return true;
        }
    }

    /// <summary>
    /// Ends the current user session and removes the stored session token.
    /// </summary>
    public void End()
    {
        SessionToken? ended;

        lock (_syncLock)
        {
            ended = _current;
            _current = null;
        }

        if (ended is not null)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_SESSION_ENDED, ended.UserName);
        }
    }

    #endregion
}
