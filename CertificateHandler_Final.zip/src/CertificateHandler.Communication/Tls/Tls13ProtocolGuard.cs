// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Mutual TLS limited to TLS 1.3. TLS 1.2 and every older protocol are refused,
/// including when the negotiated cipher is not a TLS 1.3 cipher.
/// </summary>
public static class Tls13ProtocolGuard
{
    /// <summary>
    /// Creates the server TLS settings that need a client certificate and allow only TLS 1.3.
    /// </summary>
    public static SslServerAuthenticationOptions CreateServerOptions(
        X509Certificate2 serverCertificate,
        bool checkCertificateRevocation)
    {
        ArgumentNullException.ThrowIfNull(serverCertificate);

        return new SslServerAuthenticationOptions
        {
            ServerCertificate = serverCertificate,
            ClientCertificateRequired = true,
            EnabledSslProtocols = SslProtocols.Tls13,
            EncryptionPolicy = EncryptionPolicy.RequireEncryption,
            AllowRenegotiation = false,
            CertificateRevocationCheckMode = RevocationMode(checkCertificateRevocation)
        };
    }

    /// <summary>
    /// Creates the client TLS settings that allow only TLS 1.3.
    /// </summary>
    public static SslClientAuthenticationOptions CreateClientOptions(
        string targetHost,
        X509Certificate2Collection clientCertificates,
        bool checkCertificateRevocation)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(targetHost);
        ArgumentNullException.ThrowIfNull(clientCertificates);

        return new SslClientAuthenticationOptions
        {
            TargetHost = targetHost,
            ClientCertificates = clientCertificates,
            EnabledSslProtocols = SslProtocols.Tls13,
            EncryptionPolicy = EncryptionPolicy.RequireEncryption,
            AllowRenegotiation = false,
            CertificateRevocationCheckMode = RevocationMode(checkCertificateRevocation)
        };
    }

    /// <summary>
    /// Does the server TLS handshake and checks that TLS 1.3 was used.
    /// </summary>
    public static async Task AuthenticateServerAsync(
        SslStream sslStream,
        X509Certificate2 serverCertificate,
        bool checkCertificateRevocation,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);

        await sslStream.AuthenticateAsServerAsync(
            CreateServerOptions(serverCertificate, checkCertificateRevocation),
            cancellationToken).ConfigureAwait(false);

        EnsureNegotiated(sslStream);
    }

    /// <summary>
    /// Does the client TLS handshake and checks that TLS 1.3 was used.
    /// </summary>
    public static async Task AuthenticateClientAsync(
        SslStream sslStream,
        string targetHost,
        X509Certificate2Collection clientCertificates,
        bool checkCertificateRevocation,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(sslStream);

        await sslStream.AuthenticateAsClientAsync(
            CreateClientOptions(targetHost, clientCertificates, checkCertificateRevocation),
            cancellationToken).ConfigureAwait(false);

        EnsureNegotiated(sslStream);
    }

    /// <summary>
    /// Checks that the TLS stream uses TLS 1.3 and is authenticated.
    /// </summary>
    public static void EnsureNegotiated(SslStream sslStream)
    {
        ArgumentNullException.ThrowIfNull(sslStream);
        Ensure(sslStream.SslProtocol, sslStream.NegotiatedCipherSuite, sslStream.IsAuthenticated);
    }

    /// <summary>
    /// Throws when the connection is not authenticated or does not use TLS 1.3 with a TLS 1.3 cipher.
    /// </summary>
    public static void Ensure(SslProtocols protocol, TlsCipherSuite cipher, bool authenticated)
    {
        if (authenticated && protocol == SslProtocols.Tls13 && IsTls13Cipher(cipher))
        {
            return;
        }

        throw new AuthenticationException(
            $"TLS 1.3 is required. Negotiated protocol {protocol}, cipher {cipher}, authenticated {authenticated}.");
    }

    /// <summary>
    /// Checks if the cipher is a TLS 1.3 cipher.
    /// </summary>
    private static bool IsTls13Cipher(TlsCipherSuite cipher) =>
        cipher is TlsCipherSuite.TLS_AES_128_GCM_SHA256
            or TlsCipherSuite.TLS_AES_256_GCM_SHA384
            or TlsCipherSuite.TLS_CHACHA20_POLY1305_SHA256;

    /// <summary>
    /// Gets the revocation check mode, online when the check is turned on, otherwise no check.
    /// </summary>
    private static X509RevocationMode RevocationMode(bool checkCertificateRevocation) =>
        checkCertificateRevocation ? X509RevocationMode.Online : X509RevocationMode.NoCheck;
}
