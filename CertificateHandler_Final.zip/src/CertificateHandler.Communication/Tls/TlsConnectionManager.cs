// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.DeviceTrust.Tls;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Applies admission, handshake suspension, and blacklist blocking at connection time (RS_11).
/// </summary>
public sealed class TlsConnectionManager
{
    #region Member Variables

    /// <summary>Checks if the connection is let in.</summary>
    private readonly ConnectionAdmissionService _admission;

    /// <summary>Holds and releases TLS handshakes.</summary>
    private readonly ITlsHandshakeCoordinator _handshakes;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TLS connection manager.
    /// </summary>
    public TlsConnectionManager(ConnectionAdmissionService admission, ITlsHandshakeCoordinator handshakes)
    {
        _admission = admission ?? throw new ArgumentNullException(nameof(admission));
        _handshakes = handshakes ?? throw new ArgumentNullException(nameof(handshakes));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if the TLS session can start.
    /// It cannot start when the connection is not let in or the handshake is on hold.
    /// </summary>
    public async Task<bool> MayStartTlsAsync(string thumbprintSha256, string? correlationId, CancellationToken cancellationToken = default)
    {
        if (!await _admission.IsConnectionAllowedAsync(thumbprintSha256, cancellationToken))
        {
            return false;
        }

        if (!string.IsNullOrWhiteSpace(correlationId) && _handshakes.IsSuspended(correlationId))
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Holds the TLS handshake while the certificate request waits for approval.
    /// </summary>
    public bool SuspendPendingHandshake(string correlationId, string thumbprintSha256) =>
        _handshakes.TrySuspend(correlationId, thumbprintSha256);

    #endregion
}
