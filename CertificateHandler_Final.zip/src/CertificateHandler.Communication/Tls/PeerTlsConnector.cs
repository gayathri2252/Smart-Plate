// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Outbound MAXUM connector: mutual TLS 1.3 to a peer, then trust gate before the session is usable.
/// </summary>
public sealed class PeerTlsConnector
{
    #region Member Variables

    /// <summary>Checks and approves the peer certificate.</summary>
    private readonly IPeerConnectionPipeline _pipeline;

    /// <summary>Settings for the outgoing connections.</summary>
    private readonly MaxumConnectionManagerOptions _options;

    /// <summary>Certificate this device shows to the peer.</summary>
    private readonly X509Certificate2 _clientCertificate;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TLS connector.
    /// </summary>
    public PeerTlsConnector(
        IPeerConnectionPipeline pipeline,
        MaxumConnectionManagerOptions options,
        X509Certificate2 clientCertificate)
    {
        _pipeline = pipeline ?? throw new ArgumentNullException(nameof(pipeline));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _clientCertificate = clientCertificate ?? throw new ArgumentNullException(nameof(clientCertificate));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Connects to the peer, does the TLS 1.3 handshake and checks the peer certificate.
    /// </summary>
    public async Task<PeerTlsConnection?> ConnectAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(host);

        int targetPort = port ?? _options.DefaultPeerPort;
        string correlationId = Guid.NewGuid().ToString();
        var tcpClient = new TcpClient();

        try
        {
            using var connectCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            connectCts.CancelAfter(_options.ConnectTimeout);
            await tcpClient.ConnectAsync(host, targetPort, connectCts.Token).ConfigureAwait(false);

            var networkStream = tcpClient.GetStream();
            var sslStream = new SslStream(networkStream, leaveInnerStreamOpen: false);
            var clientCerts = new X509Certificate2Collection { _clientCertificate };

            try
            {
                await Tls13ProtocolGuard.AuthenticateClientAsync(
                    sslStream,
                    host,
                    clientCerts,
                    _options.CheckCertificateRevocation,
                    cancellationToken).ConfigureAwait(false);

                PeerTlsGateOutcome gate = await PeerTlsSessionProcessor.ProcessOutboundPeerAsync(
                    sslStream,
                    _pipeline,
                    host,
                    correlationId,
                    cancellationToken).ConfigureAwait(false);

                if (!gate.Allowed)
                {
                    await sslStream.DisposeAsync().ConfigureAwait(false);
                    tcpClient.Dispose();
                    CertificateHandlerLogger.Warning(
                        MessageIdGenerator.Next(),
                        "Outbound connect to %s denied by trust gate.",
                        host);
                    return null;
                }

                return new PeerTlsConnection(tcpClient, sslStream, gate, host);
            }
            catch
            {
                await sslStream.DisposeAsync().ConfigureAwait(false);
                throw;
            }
        }
        catch (OperationCanceledException)
        {
            tcpClient.Dispose();
            throw;
        }
        catch (Exception ex)
        {
            tcpClient.Dispose();
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Outbound connect to %s failed: %s",
                $"{host}:{targetPort}",
                ex.Message);
            throw;
        }
    }

    #endregion
}
