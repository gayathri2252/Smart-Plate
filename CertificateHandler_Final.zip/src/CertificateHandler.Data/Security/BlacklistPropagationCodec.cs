// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Signed unicast payload for a blacklist that must be applied by peer MAXUM devices (RS_33).
/// </summary>
public sealed class BlacklistPropagationMessage
{
    /// <summary>SHA256 thumbprint of the blacklisted certificate.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>Reason for the blacklist.</summary>
    public string Reason { get; init; } = string.Empty;

    /// <summary>Name of the device that sent the message.</summary>
    public string Origin { get; init; } = string.Empty;

    /// <summary>Time when the message was sent, in Unix milliseconds.</summary>
    public long SentAtUnixMs { get; init; }

    /// <summary>Signature of the message.</summary>
    public string Signature { get; init; } = string.Empty;
}

/// <summary>
/// Creates and checks the signed blacklist messages sent between MAXUM devices.
/// </summary>
public static class BlacklistPropagationCodec
{
    /// <summary>Default UDP port for the blacklist messages.</summary>
    public const int DefaultPort = 47433;

    /// <summary>Default subnet prefix length.</summary>
    public const int DefaultPrefixLength = 24;

    /// <summary>Most characters allowed in the reason.</summary>
    public const int MaxReasonLength = 500;

    /// <summary>Most characters allowed in the sender name.</summary>
    public const int MaxOriginLength = 128;

    /// <summary>Most age allowed for a message.</summary>
    public static readonly TimeSpan MaximumAge = TimeSpan.FromMinutes(5);

    /// <summary>
    /// Creates the signed blacklist message as JSON bytes.
    /// </summary>
    public static byte[] CreateSignedPayload(string thumbprint, string reason, string origin, DateTimeOffset sentAt, string key)
    {
        string normalized = NormalizeThumbprint(thumbprint);
        string boundedReason = Bound(reason, MaxReasonLength);
        string boundedOrigin = Bound(origin, MaxOriginLength);
        long sentAtUnixMs = sentAt.ToUnixTimeMilliseconds();
        var message = new BlacklistPropagationMessage
        {
            Thumbprint = normalized,
            Reason = boundedReason,
            Origin = boundedOrigin,
            SentAtUnixMs = sentAtUnixMs,
            Signature = Sign(normalized, boundedReason, boundedOrigin, sentAtUnixMs, key)
        };
        return JsonSerializer.SerializeToUtf8Bytes(message);
    }

    /// <summary>
    /// Checks the key, the content, the signature, the time and the subnet of a received message.
    /// Returns false with the error when any check fails.
    /// </summary>
    public static bool TryValidate(
        ReadOnlySpan<byte> payload,
        IPAddress remoteAddress,
        DateTimeOffset now,
        string? key,
        IReadOnlyCollection<IPAddress> localAddresses,
        int prefixLength,
        out BlacklistPropagationMessage? message,
        out string error)
    {
        message = null;
        if (string.IsNullOrWhiteSpace(key) || key.Length < 16)
        {
            error = "Blacklist sync key is missing.";
            return false;
        }

        BlacklistPropagationMessage? parsed;
        try
        {
            parsed = JsonSerializer.Deserialize<BlacklistPropagationMessage>(payload);
        }
        catch (JsonException)
        {
            error = "Blacklist message is not valid JSON.";
            return false;
        }

        if (parsed is null || !IsHexThumbprint(parsed.Thumbprint))
        {
            error = "Blacklist message thumbprint is missing.";
            return false;
        }

        if (parsed.Reason.Length > MaxReasonLength || parsed.Origin.Length > MaxOriginLength)
        {
            error = "Blacklist message fields are too long.";
            return false;
        }

        string expected = Sign(parsed.Thumbprint, parsed.Reason, parsed.Origin, parsed.SentAtUnixMs, key);
        if (!FixedEquals(expected, parsed.Signature))
        {
            error = "Blacklist message signature is not valid.";
            return false;
        }

        DateTimeOffset sentAt = DateTimeOffset.FromUnixTimeMilliseconds(parsed.SentAtUnixMs);
        if (sentAt > now.Add(MaximumAge) || now - sentAt > MaximumAge)
        {
            error = "Blacklist message is outside the allowed time window.";
            return false;
        }

        if (!SharesSubnet(remoteAddress, localAddresses, prefixLength))
        {
            error = "Blacklist message did not come from the same IP subnet.";
            return false;
        }

        message = parsed;
        error = string.Empty;
        return true;
    }

    /// <summary>
    /// Reads the subnet prefix length from the environment, or uses the default.
    /// </summary>
    public static int ReadPrefixLength()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_BLACKLIST_SUBNET_PREFIX");
        return int.TryParse(raw, out int prefix) && prefix is >= 1 and <= 32
            ? prefix
            : DefaultPrefixLength;
    }

    /// <summary>
    /// Reads the UDP port from the environment, or uses the default.
    /// </summary>
    public static int ReadPort()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_BLACKLIST_UNICAST_PORT");
        return int.TryParse(raw, out int port) && port is > 0 and <= 65535
            ? port
            : DefaultPort;
    }

    /// <summary>
    /// Reads the shared signing key from the environment.
    /// </summary>
    public static string? ReadKey() => Environment.GetEnvironmentVariable("CH_BLACKLIST_SYNC_KEY");

    /// <summary>
    /// Checks if the sender is on the same subnet as one of the local addresses.
    /// </summary>
    private static bool SharesSubnet(IPAddress remote, IReadOnlyCollection<IPAddress> localAddresses, int prefixLength)
    {
        foreach (IPAddress local in localAddresses)
        {
            if (Ipv4Subnet.SameSubnet(local, remote, prefixLength))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Signs the message fields with HMAC SHA256 and the shared key.
    /// </summary>
    private static string Sign(string thumbprint, string reason, string origin, long sentAtUnixMs, string key)
    {
        string canonical = thumbprint + "\n" + reason + "\n" + origin + "\n" + sentAtUnixMs.ToString(System.Globalization.CultureInfo.InvariantCulture);
        byte[] hash = HMACSHA256.HashData(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(canonical));
        return Convert.ToHexString(hash);
    }

    /// <summary>
    /// Compares two signatures in a fixed time.
    /// </summary>
    private static bool FixedEquals(string expected, string actual)
    {
        byte[] left = Encoding.UTF8.GetBytes(expected);
        byte[] right = Encoding.UTF8.GetBytes(actual ?? string.Empty);
        return left.Length == right.Length && CryptographicOperations.FixedTimeEquals(left, right);
    }

    /// <summary>
    /// Removes spaces from the thumbprint and makes it upper case.
    /// Throws when it is not 64 hex characters.
    /// </summary>
    private static string NormalizeThumbprint(string thumbprint)
    {
        string normalized = (thumbprint ?? string.Empty).Replace(" ", string.Empty, StringComparison.Ordinal).ToUpperInvariant();
        if (!IsHexThumbprint(normalized))
        {
            throw new ArgumentException("Thumbprint must be 64 hexadecimal characters.", nameof(thumbprint));
        }

        return normalized;
    }

    /// <summary>
    /// Checks that the thumbprint is 64 hex characters.
    /// </summary>
    private static bool IsHexThumbprint(string? thumbprint)
    {
        if (thumbprint is null || thumbprint.Length != 64)
        {
            return false;
        }

        foreach (char character in thumbprint)
        {
            bool hex = character is >= '0' and <= '9' or >= 'A' and <= 'F' or >= 'a' and <= 'f';
            if (!hex)
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Trims the text and cuts it to the given length.
    /// </summary>
    private static string Bound(string? value, int max)
    {
        string trimmed = value?.Trim() ?? string.Empty;
        return trimmed.Length <= max ? trimmed : trimmed[..max];
    }
}
