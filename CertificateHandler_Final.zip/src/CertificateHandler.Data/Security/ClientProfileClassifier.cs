// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Classifies a connecting client before the trust decision (RS_32, RS_34).
/// An explicit <see cref="PeerOnboardingRequest.ClientProfile"/> wins. Otherwise the certificate
/// subject is used. Anything that is not a MAXUM peer stays on the pending queue.
/// </summary>
public static class ClientProfileClassifier
{
    /// <summary>
    /// Gets the device type of the client from its profile or from the certificate subject.
    /// </summary>
    public static DeviceType Classify(PeerOnboardingRequest peer)
    {
        ArgumentNullException.ThrowIfNull(peer);
        if (peer.ClientProfile is DeviceType explicitProfile)
        {
            return explicitProfile;
        }

        string subject = peer.SubjectDn ?? string.Empty;
        if (HasOrganizationalUnit(subject, "MAXUM") || HasCommonNamePrefix(subject, "MAXUM-"))
        {
            return DeviceType.MaxumPeer;
        }

        if (HasOrganizationalUnit(subject, "GCP")
            || HasOrganizationalUnit(subject, "MCC")
            || HasOrganizationalUnit(subject, "WORKSTATION"))
        {
            return DeviceType.GcpWorkstation;
        }

        return DeviceType.Other;
    }

    /// <summary>
    /// Checks if the subject has the given organizational unit.
    /// </summary>
    private static bool HasOrganizationalUnit(string subject, string unit)
    {
        foreach (string part in subject.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (part.StartsWith("OU=", StringComparison.OrdinalIgnoreCase)
                && string.Equals(part[3..].Trim(), unit, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Checks if the common name in the subject starts with the given text.
    /// </summary>
    private static bool HasCommonNamePrefix(string subject, string prefix)
    {
        foreach (string part in subject.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (part.StartsWith("CN=", StringComparison.OrdinalIgnoreCase)
                && part[3..].Trim().StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }
}
