// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using System.Net.Sockets;

namespace CertificateHandler.Data.Security;

/// <summary>
/// IPv4 subnet comparison used to choose MAXUM peers for blacklist unicast (RS_33).
/// </summary>
public static class Ipv4Subnet
{
    /// <summary>
    /// Checks if two IPv4 addresses are on the same subnet.
    /// </summary>
    public static bool SameSubnet(IPAddress left, IPAddress right, int prefixLength)
    {
        if (left.AddressFamily != AddressFamily.InterNetwork || right.AddressFamily != AddressFamily.InterNetwork)
        {
            return false;
        }

        if (prefixLength is < 0 or > 32)
        {
            throw new ArgumentOutOfRangeException(nameof(prefixLength));
        }

        uint mask = prefixLength == 0 ? 0u : uint.MaxValue << (32 - prefixLength);
        return (ToUInt32(left) & mask) == (ToUInt32(right) & mask);
    }

    /// <summary>
    /// Lists the IPv4 addresses of the network cards that are up, without loopback.
    /// </summary>
    public static IReadOnlyList<IPAddress> LocalUnicastAddresses()
    {
        var addresses = new List<IPAddress>();
        foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up)
            {
                continue;
            }

            foreach (System.Net.NetworkInformation.UnicastIPAddressInformation unicast in nic.GetIPProperties().UnicastAddresses)
            {
                if (unicast.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(unicast.Address))
                {
                    addresses.Add(unicast.Address);
                }
            }
        }

        return addresses;
    }

    /// <summary>
    /// Turns the IPv4 address into a number.
    /// </summary>
    private static uint ToUInt32(IPAddress address)
    {
        byte[] bytes = address.GetAddressBytes();
        return ((uint)bytes[0] << 24) | ((uint)bytes[1] << 16) | ((uint)bytes[2] << 8) | bytes[3];
    }
}
