// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Creates the random 256-bit database key on the first run and keeps only the sealed bytes in a key file.
/// The key is unsealed again on every start, so it works only on the computer that sealed it.
/// </summary>
public sealed class TrustStoreKeyProvider
{
    #region Member Variables

    /// <summary>Size of the trust store key, in bytes.</summary>
    private const int KEY_SIZE_BYTES = 32;
    /// <summary>End of the name of the temporary file used while the key file is written.</summary>
    private const string TEMPORARY_FILE_SUFFIX = ".tmp";

    /// <summary>Path of the file that holds the protected key.</summary>
    private readonly string _keyFilePath;
    /// <summary>Protects and unprotects the key.</summary>
    private readonly IKeyProtector _keyProtector;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the provider for the key file path and the protector that seals the key.
    /// Throws when the path is empty or the protector is null.
    /// </summary>
    public TrustStoreKeyProvider(string keyFilePath, IKeyProtector keyProtector)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(keyFilePath);

        if (keyProtector is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_PROTECTOR_IS_NULL);
            throw new ArgumentNullException(nameof(keyProtector));
        }

        _keyFilePath = keyFilePath;
        _keyProtector = keyProtector;
    }

    #endregion

    #region Public Properties

    /// <summary>Full path of the sealed key file.</summary>
    public string KeyFilePath => _keyFilePath;

    /// <summary>True when the sealed key file exists.</summary>
    public bool KeyFileExists => File.Exists(_keyFilePath);

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns the unsealed key. Creates and seals a new random key when no key file exists yet.
    /// Throws TrustStoreException with a message for the user when the key cannot be created or unsealed.
    /// </summary>
    public byte[] GetOrCreateKey()
    {
        return KeyFileExists ? UnsealKey() : CreateKey();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the key file and unseals the key. A key file from another computer cannot be unsealed.
    /// </summary>
    private byte[] UnsealKey()
    {
        byte[] key;
        try
        {
            byte[] sealedKey = File.ReadAllBytes(_keyFilePath);
            key = _keyProtector.Unprotect(sealedKey);
        }
        catch (Exception ex) when (ex is CryptographicException or IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_UNSEAL_FAILED, _keyFilePath, ex.Message);
            throw new TrustStoreException(DatabaseConstants.TRUST_STORE_KEY_UNSEAL_MESSAGE, ex);
        }

        if (key.Length != KEY_SIZE_BYTES)
        {
            CryptographicOperations.ZeroMemory(key);
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_INVALID, _keyFilePath);
            throw new TrustStoreException(DatabaseConstants.TRUST_STORE_KEY_INVALID_MESSAGE);
        }

        return key;
    }

    /// <summary>
    /// Generates a random key, seals it and writes only the sealed bytes to the key file.
    /// The file is written under a temporary name first, so a failed write never leaves a half key file.
    /// </summary>
    private byte[] CreateKey()
    {
        byte[] key = RandomNumberGenerator.GetBytes(KEY_SIZE_BYTES);
        string temporaryPath = _keyFilePath + TEMPORARY_FILE_SUFFIX;

        try
        {
            byte[] sealedKey = _keyProtector.Protect(key);
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(_keyFilePath))!);
            File.WriteAllBytes(temporaryPath, sealedKey);
            File.Move(temporaryPath, _keyFilePath, overwrite: false);

            // The key is never changed again, so nobody gets write access to the sealed key file.
            TrustStoreFolderSecurity.MakeReadOnly(_keyFilePath);
        }
        catch (Exception ex) when (ex is CryptographicException or IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            CryptographicOperations.ZeroMemory(key);
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_CREATE_FAILED, _keyFilePath, ex.Message);
            throw new TrustStoreException(DatabaseConstants.TRUST_STORE_KEY_CREATE_MESSAGE, ex);
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.TRUST_STORE_KEY_CREATED, _keyFilePath);
        return key;
    }

    #endregion
}
