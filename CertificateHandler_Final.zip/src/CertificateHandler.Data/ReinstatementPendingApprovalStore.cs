// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Shared.Models;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Records reinstatement approvals from the pending queue; completes after two distinct approvers (RS_14–17).
/// </summary>
public sealed class ReinstatementPendingApprovalStore : IReinstatementPendingApprovalStore
{
    #region Member Variables

    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>Saves the approvals and finishes the reinstatement.</summary>
    private readonly IReinstatementWorkflowService _workflow;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the reinstatement approval store.
    /// </summary>
    public ReinstatementPendingApprovalStore(NpgsqlDataSource dataSource, IReinstatementWorkflowService workflow)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _workflow = workflow ?? throw new ArgumentNullException(nameof(workflow));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Saves an approval of the reinstatement request.
    /// When this is the second approval, the reinstatement is finished.
    /// </summary>
    public async Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(decision);
        Guid requestId = ParseRequestId(decision.RequestId);
        string actor = decision.ActorIdentity?.Trim() ?? throw new InvalidOperationException("Actor identity is required.");

        PendingReinstatementRow row = await LoadAsync(requestId, cancellationToken);
        if (string.Equals(row.RequestedBy, actor, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("The requester cannot approve their own reinstatement request.");
        }

        if (row.Approvers.Any(a => string.Equals(a, actor, StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidOperationException("This approver has already recorded a decision.");
        }

        await _workflow.RecordApprovalAsync(requestId, actor, approved: true, decision.Reason, cancellationToken);

        int approvedCount = row.Approvers.Count + 1;
        if (approvedCount >= 2)
        {
            await _workflow.CompleteReinstatementAsync(requestId, actor, cancellationToken);
        }
    }

    /// <summary>
    /// Saves the rejection and marks the reinstatement request as REJECTED.
    /// </summary>
    public async Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(decision);
        Guid requestId = ParseRequestId(decision.RequestId);
        string actor = decision.ActorIdentity?.Trim() ?? throw new InvalidOperationException("Actor identity is required.");

        await _workflow.RecordApprovalAsync(requestId, actor, approved: false, decision.Reason, cancellationToken);

        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var update = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_pending_request " +
            "SET status = CAST('REJECTED' AS certificate_handler.pending_request_status), decided_at = now(), decided_by = @actor, decision_reason = @reason " +
            "WHERE request_id = @requestId",
            connection);
        update.Parameters.AddWithValue("actor", actor);
        update.Parameters.AddWithValue("reason", (object?)decision.Reason ?? DBNull.Value);
        update.Parameters.AddWithValue("requestId", requestId);
        await update.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Turns the request id text into a GUID.
    /// </summary>
    private static Guid ParseRequestId(string requestId)
    {
        if (!Guid.TryParse(requestId, out Guid id))
        {
            throw new ArgumentException("Invalid request id.", nameof(requestId));
        }

        return id;
    }

    /// <summary>
    /// Loads the pending reinstatement request and the users who approved it.
    /// </summary>
    private async Task<PendingReinstatementRow> LoadAsync(Guid requestId, CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT requested_by FROM {DatabaseConstants.SchemaName}.ch_pending_request " +
            "WHERE request_id = @id AND request_type = 'REINSTATEMENT' AND status = 'PENDING'",
            connection);
        command.Parameters.AddWithValue("id", requestId);
        object? requestedBy = await command.ExecuteScalarAsync(cancellationToken);
        if (requestedBy is null or DBNull)
        {
            throw new InvalidOperationException("Reinstatement request not found or not pending.");
        }

        await using var approvals = new NpgsqlCommand(
            $"SELECT approver_identity FROM {DatabaseConstants.SchemaName}.ch_reinstatement_approval " +
            "WHERE request_id = @id AND decision = 'APPROVED'",
            connection);
        approvals.Parameters.AddWithValue("id", requestId);
        var approvers = new List<string>();
        await using var reader = await approvals.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            approvers.Add(reader.GetString(0));
        }

        return new PendingReinstatementRow(requestedBy.ToString()!, approvers);
    }

    /// <summary>
    /// A pending reinstatement request with the administrators who approved it.
    /// </summary>
    private sealed record PendingReinstatementRow(string RequestedBy, IReadOnlyList<string> Approvers);

    #endregion
}
