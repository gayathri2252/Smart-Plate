// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Auto-whitelists a validated MAXUM peer and writes the audit and trust-event rows (RS_32).
/// </summary>
public sealed class MaxumPeerAutoApprovalStore : IMaxumPeerAutoApprover
{
    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Creates the auto approval store.
    /// </summary>
    public MaxumPeerAutoApprovalStore(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    /// <summary>
    /// Adds the MAXUM peer to the whitelist and writes the audit and trust event rows.
    /// Returns false when the certificate is blacklisted, the device is not a MAXUM peer or the write fails.
    /// </summary>
    public async Task<bool> TryAutoApproveAsync(PeerOnboardingRequest peer, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(peer);

        try
        {
            string thumbprint = ThumbprintNormalizer.NormalizeRequired(peer.ThumbprintSha256);
            await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
            await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

            string? activeKind = await ReadActiveListKindAsync(connection, transaction, thumbprint, cancellationToken);
            if (string.Equals(activeKind, "BLACKLIST", StringComparison.Ordinal)
                || await IsPropagatedBlackListAsync(connection, transaction, thumbprint, cancellationToken))
            {
                await transaction.RollbackAsync(cancellationToken);
                return false;
            }

            if (string.Equals(activeKind, "WHITELIST", StringComparison.Ordinal))
            {
                await transaction.CommitAsync(cancellationToken);
                return true;
            }

            DeviceUpsert device = await UpsertDeviceAsync(connection, transaction, peer, cancellationToken);
            if (!device.IsMaxumPeer)
            {
                await transaction.RollbackAsync(cancellationToken);
                return false;
            }

            Guid deviceId = device.DeviceId;
            Guid certificateId = await FindOrAddCertificateAsync(connection, transaction, peer, thumbprint, deviceId, cancellationToken);
            DateTimeOffset now = DateTimeOffset.UtcNow;
            await InsertWhitelistAsync(connection, transaction, peer, thumbprint, certificateId, deviceId, now, cancellationToken);
            await InsertAuditAsync(connection, transaction, peer, thumbprint, certificateId, deviceId, now, cancellationToken);
            await InsertTrustEventAsync(connection, transaction, thumbprint, deviceId, now, cancellationToken);
            await transaction.CommitAsync(cancellationToken);

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                "MAXUM peer {0} was auto-whitelisted after validation (RS_32).",
                peer.DeviceCode);
            return true;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "MAXUM peer auto-approve failed for {0}: {1}",
                peer.DeviceCode,
                ex.Message);
            return false;
        }
    }

    /// <summary>
    /// Reads the list that holds the certificate, WHITELIST or BLACKLIST. Null when it is on no list.
    /// </summary>
    private static async Task<string?> ReadActiveListKindAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"SELECT list_kind::text FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
            "WHERE thumbprint_sha256 = @thumbprint AND is_active LIMIT 1",
            connection,
            transaction);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        object? kind = await command.ExecuteScalarAsync(cancellationToken);
        return kind as string;
    }

    /// <summary>
    /// Checks if the certificate was blacklisted by another device on the subnet.
    /// </summary>
    private static async Task<bool> IsPropagatedBlackListAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_propagated_blacklist WHERE thumbprint_sha256 = @thumbprint)",
            connection,
            transaction);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        object? exists = await command.ExecuteScalarAsync(cancellationToken);
        return exists is true;
    }

    /// <summary>
    /// The device id and if the device is a MAXUM peer.
    /// </summary>
    private readonly record struct DeviceUpsert(Guid DeviceId, bool IsMaxumPeer);

    /// <summary>
    /// Adds the device, or updates its MAXUM IP address if it already exists.
    /// </summary>
    private static async Task<DeviceUpsert> UpsertDeviceAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PeerOnboardingRequest peer,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_device AS d (device_code, device_type, maxum_ip) " +
            "VALUES (@deviceCode, CAST('MAXUM_PEER' AS certificate_handler.device_type), CAST(@maxumIp AS inet)) " +
            "ON CONFLICT (device_code) DO UPDATE SET maxum_ip = COALESCE(EXCLUDED.maxum_ip, d.maxum_ip) " +
            "RETURNING device_id, device_type::text",
            connection,
            transaction);
        command.Parameters.AddWithValue("deviceCode", peer.DeviceCode.Trim());
        command.Parameters.AddWithValue("maxumIp", (object?)ToValidIpOrNull(peer.MaxumIp) ?? DBNull.Value);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            throw new InvalidOperationException("Device upsert did not return a row.");
        }

        return new DeviceUpsert(
            reader.GetGuid(0),
            string.Equals(reader.GetString(1), "MAXUM_PEER", StringComparison.Ordinal));
    }

    /// <summary>
    /// Finds the active peer certificate, or adds it when it is not there.
    /// </summary>
    private static async Task<Guid> FindOrAddCertificateAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PeerOnboardingRequest peer,
        string thumbprint,
        Guid deviceId,
        CancellationToken cancellationToken)
    {
        await using var find = new NpgsqlCommand(
            $"SELECT certificate_id FROM {DatabaseConstants.SchemaName}.ch_certificate " +
            "WHERE thumbprint_sha256 = @thumbprint AND certificate_role = CAST('PEER' AS certificate_handler.certificate_role) AND is_active LIMIT 1",
            connection,
            transaction);
        find.Parameters.AddWithValue("thumbprint", thumbprint);
        object? existing = await find.ExecuteScalarAsync(cancellationToken);
        if (existing is Guid certificateId)
        {
            return certificateId;
        }

        await using var insert = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_certificate " +
            "(device_id, certificate_role, thumbprint_sha256, subject_dn, issuer_dn, serial_number, not_before, not_after, presented_cert_der) " +
            "VALUES (@deviceId, CAST('PEER' AS certificate_handler.certificate_role), @thumbprint, @subject, @issuer, @serial, @notBefore, @notAfter, @der) " +
            "RETURNING certificate_id",
            connection,
            transaction);
        insert.Parameters.AddWithValue("deviceId", deviceId);
        insert.Parameters.AddWithValue("thumbprint", thumbprint);
        insert.Parameters.AddWithValue("subject", peer.SubjectDn);
        insert.Parameters.AddWithValue("issuer", peer.IssuerDn);
        insert.Parameters.AddWithValue("serial", (object?)peer.SerialNumber ?? DBNull.Value);
        insert.Parameters.AddWithValue("notBefore", peer.NotBefore.ToUniversalTime());
        insert.Parameters.AddWithValue("notAfter", peer.NotAfter.ToUniversalTime());
        insert.Parameters.AddWithValue("der", (object?)peer.PresentedCertificateDer ?? DBNull.Value);
        return (Guid)(await insert.ExecuteScalarAsync(cancellationToken))!;
    }

    /// <summary>
    /// Adds the certificate to the whitelist with the MAXUM auto approval channel.
    /// </summary>
    private static async Task InsertWhitelistAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PeerOnboardingRequest peer,
        string thumbprint,
        Guid certificateId,
        Guid deviceId,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
            "(list_kind, certificate_id, thumbprint_sha256, device_id, subject_dn, serial_number, not_before, not_after, " +
            "added_by, added_at, comment, is_active, approval_channel) " +
            "VALUES (CAST('WHITELIST' AS certificate_handler.trust_list_kind), @certificateId, @thumbprint, @deviceId, " +
            "@subject, @serial, @notBefore, @notAfter, @actor, @now, @comment, TRUE, @channel)",
            connection,
            transaction);
        command.Parameters.AddWithValue("certificateId", certificateId);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        command.Parameters.AddWithValue("deviceId", deviceId);
        command.Parameters.AddWithValue("subject", peer.SubjectDn);
        command.Parameters.AddWithValue("serial", (object?)peer.SerialNumber ?? DBNull.Value);
        command.Parameters.AddWithValue("notBefore", peer.NotBefore.ToUniversalTime());
        command.Parameters.AddWithValue("notAfter", peer.NotAfter.ToUniversalTime());
        command.Parameters.AddWithValue("actor", DatabaseConstants.SystemActor);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("comment", "MAXUM peer auto-approved after validation (RS_32)");
        command.Parameters.AddWithValue("channel", TrustApprovalChannels.MaxumAuto);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Writes the audit row for the auto approval.
    /// </summary>
    private static async Task InsertAuditAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PeerOnboardingRequest peer,
        string thumbprint,
        Guid certificateId,
        Guid deviceId,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        string details = JsonSerializer.Serialize(new { peer.DeviceCode, channel = TrustApprovalChannels.MaxumAuto });
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
            "(event_type, event_timestamp, actor_identity, device_id, certificate_id, thumbprint_sha256, " +
            "previous_status, new_status, action_status, reason, details_json, result, source_component) " +
            "VALUES ('MAXUM_PEER_AUTO_WHITELISTED', @now, @actor, @deviceId, @certificateId, @thumbprint, " +
            "'NOT_LISTED', 'WHITELISTED', 'SUCCESS', @reason, CAST(@details AS jsonb), 'SUCCESS', 'MaxumPeerAutoApproval')",
            connection,
            transaction);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("actor", DatabaseConstants.SystemActor);
        command.Parameters.AddWithValue("deviceId", deviceId);
        command.Parameters.AddWithValue("certificateId", certificateId);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        command.Parameters.AddWithValue("reason", "Validated MAXUM peer auto-approved (RS_32)");
        command.Parameters.AddWithValue("details", details);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Saves the trust event for the auto approval and queues it for the default subscriber.
    /// </summary>
    private static async Task InsertTrustEventAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        Guid deviceId,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        string payload = JsonSerializer.Serialize(new { trustStatus = "WHITELISTED", channel = TrustApprovalChannels.MaxumAuto });
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event " +
            "(device_id, thumbprint_sha256, new_trust_status, actor_identity, occurred_at, payload_json) " +
            "VALUES (@deviceId, @thumbprint, 'WHITELISTED', @actor, @now, CAST(@payload AS jsonb)) " +
            "RETURNING event_id",
            connection,
            transaction);
        command.Parameters.AddWithValue("deviceId", deviceId);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        command.Parameters.AddWithValue("actor", DatabaseConstants.SystemActor);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("payload", payload);
        Guid eventId = (Guid)(await command.ExecuteScalarAsync(cancellationToken))!;

        await using var delivery = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event_delivery (event_id, subscriber_name, status) " +
            "VALUES (@eventId, 'MAXUM_IN_DEVICE', 'PENDING') ON CONFLICT (event_id, subscriber_name) DO NOTHING",
            connection,
            transaction);
        delivery.Parameters.AddWithValue("eventId", eventId);
        await delivery.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Returns the IP address when it is valid, otherwise null.
    /// </summary>
    private static string? ToValidIpOrNull(string? maxumIp)
    {
        return System.Net.IPAddress.TryParse(maxumIp?.Trim(), out System.Net.IPAddress? address) ? address.ToString() : null;
    }
}
