// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using System.Net.Sockets;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// After a local blacklist, unicasts a signed message to each other MAXUM device on the same subnet (RS_33).
/// </summary>
public sealed class SubnetBlacklistPropagator : ISubnetBlacklistPropagator
{
    /// <summary>Finds the MAXUM peers on the same subnet.</summary>
    private readonly ISubnetPeerDirectory _peers;
    /// <summary>Sends the messages to the peers.</summary>
    private readonly IBlacklistUnicastTransport _transport;
    /// <summary>Shared key used to sign the messages. Null when not set.</summary>
    private readonly string? _syncKey;
    /// <summary>Name of this device, written in the messages.</summary>
    private readonly string _origin;

    /// <summary>
    /// Creates the subnet blacklist sender.
    /// </summary>
    public SubnetBlacklistPropagator(
        ISubnetPeerDirectory peers,
        IBlacklistUnicastTransport transport,
        string? syncKey,
        string origin)
    {
        _peers = peers ?? throw new ArgumentNullException(nameof(peers));
        _transport = transport ?? throw new ArgumentNullException(nameof(transport));
        _syncKey = syncKey;
        _origin = string.IsNullOrWhiteSpace(origin) ? Environment.MachineName : origin.Trim();
    }

    /// <summary>
    /// Creates the sender with the database peer list, UDP and the key from the environment.
    /// </summary>
    public static SubnetBlacklistPropagator Create(NpgsqlDataSource dataSource) =>
        new(new DatabaseSubnetPeerDirectory(dataSource), new UdpBlacklistUnicastTransport(), BlacklistPropagationCodec.ReadKey(), Environment.MachineName);

    /// <summary>
    /// Sends the signed blacklist message to each MAXUM peer on the same subnet.
    /// Nothing is sent when the shared key is missing.
    /// </summary>
    public async Task PropagateAsync(string thumbprintSha256, string reason, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_syncKey) || _syncKey.Length < 16)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Blacklist was saved locally. Subnet unicast was skipped because CH_BLACKLIST_SYNC_KEY is missing (RS_33).");
            return;
        }

        byte[] payload = BlacklistPropagationCodec.CreateSignedPayload(
            thumbprintSha256,
            reason,
            _origin,
            DateTimeOffset.UtcNow,
            _syncKey);

        IReadOnlyList<IPAddress> peers = await _peers.ListSameSubnetPeersAsync(cancellationToken);
        int sent = 0;
        foreach (IPAddress peer in peers)
        {
            try
            {
                await _transport.SendAsync(peer, payload, cancellationToken);
                sent++;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Blacklist unicast to {0} failed: {1}",
                    peer,
                    ex.Message);
            }
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Blacklist unicast sent to {0} MAXUM peer(s) on the local subnet (RS_33).",
            sent);
    }
}

/// <summary>
/// Finds the MAXUM peers on the same subnet from the device table.
/// </summary>
public sealed class DatabaseSubnetPeerDirectory : ISubnetPeerDirectory
{
    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Creates the peer directory.
    /// </summary>
    public DatabaseSubnetPeerDirectory(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    /// <summary>
    /// Lists the active MAXUM peers on the same subnet, without this device.
    /// </summary>
    public async Task<IReadOnlyList<IPAddress>> ListSameSubnetPeersAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyList<IPAddress> local = Ipv4Subnet.LocalUnicastAddresses();
        int prefix = BlacklistPropagationCodec.ReadPrefixLength();
        var peers = new List<IPAddress>();
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT host(maxum_ip) FROM {DatabaseConstants.SchemaName}.ch_device " +
            "WHERE device_type = CAST('MAXUM_PEER' AS certificate_handler.device_type) " +
            "AND maxum_ip IS NOT NULL AND operational_status = CAST('ACTIVE' AS certificate_handler.device_operational_status)",
            connection);
        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            if (!IPAddress.TryParse(reader.GetString(0), out IPAddress? peer))
            {
                continue;
            }

            if (local.Any(address => address.Equals(peer)))
            {
                continue;
            }

            if (local.Any(address => Ipv4Subnet.SameSubnet(address, peer, prefix)))
            {
                peers.Add(peer);
            }
        }

        return peers;
    }
}

/// <summary>
/// Sends the blacklist messages over UDP.
/// </summary>
public sealed class UdpBlacklistUnicastTransport : IBlacklistUnicastTransport
{
    /// <summary>
    /// Sends the message to the peer over UDP.
    /// </summary>
    public async Task SendAsync(IPAddress peer, byte[] payload, CancellationToken cancellationToken = default)
    {
        using var client = new UdpClient();
        await client.SendAsync(payload, new IPEndPoint(peer, BlacklistPropagationCodec.ReadPort()), cancellationToken);
    }
}
