// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// MCC trust actions are refused until one workstation was whitelisted on the SBC HMI.
/// After that, a Keycloak MCC Administrator and the SBC local administrator must both succeed (RS_34).
/// </summary>
public interface IHmiWorkstationWhitelistQuery
{
    /// <summary>
    /// Checks if a workstation was whitelisted on the SBC HMI.
    /// </summary>
    Task<bool> HasHmiApprovedWorkstationAsync(CancellationToken cancellationToken = default);
}

/// <summary>
/// Checks the Keycloak MCC administrator session.
/// </summary>
public interface IKeycloakMccAdminVerifier
{
    /// <summary>
    /// Checks the access token and tells if the user is an MCC administrator.
    /// </summary>
    Task<KeycloakAdminCheck> VerifyAsync(string accessToken, CancellationToken cancellationToken = default);
}

/// <summary>
/// Checks the SBC local administrator user name and password.
/// </summary>
public interface ISbcLocalAdminCredentialVerifier
{
    /// <summary>
    /// Checks the user name and password of the local administrator.
    /// </summary>
    Task<bool> ValidateAsync(string userName, string password, CancellationToken cancellationToken = default);
}

/// <summary>
/// Result of the Keycloak administrator check.
/// </summary>
public sealed class KeycloakAdminCheck
{
    /// <summary>True when the user has the MCC administrator role.</summary>
    public bool IsAdministrator { get; init; }

    /// <summary>User name of the checked user.</summary>
    public string Subject { get; init; } = string.Empty;
}

/// <summary>
/// A request to do a trust action from MCC.
/// </summary>
public sealed class MccTrustActionRequest
{
    /// <summary>Keycloak access token of the MCC user.</summary>
    public string AccessToken { get; init; } = string.Empty;

    /// <summary>User name of the SBC local administrator.</summary>
    public string LocalAdministratorUser { get; init; } = string.Empty;

    /// <summary>Password of the SBC local administrator.</summary>
    public string LocalAdministratorPassword { get; init; } = string.Empty;
}

/// <summary>
/// Result of the MCC trust action check.
/// </summary>
public sealed class MccTrustActionResult
{
    /// <summary>True when the trust action is allowed.</summary>
    public bool IsAllowed { get; init; }

    /// <summary>Why the trust action is not allowed.</summary>
    public string DenialReason { get; init; } = string.Empty;

    /// <summary>Keycloak user name of the MCC administrator.</summary>
    public string KeycloakSubject { get; init; } = string.Empty;

    /// <summary>User name of the SBC local administrator.</summary>
    public string SbcAdministrator { get; init; } = string.Empty;

    /// <summary>Both administrators, saved as the user of the action. Empty when not allowed.</summary>
    public string ActorIdentity => IsAllowed ? $"mcc:{KeycloakSubject};sbc:{SbcAdministrator}" : string.Empty;
}

/// <summary>
/// Checks if an MCC trust action is allowed.
/// </summary>
public sealed class MccTrustActionAuthorizer
{
    /// <summary>Checks the HMI workstation whitelist.</summary>
    private readonly IHmiWorkstationWhitelistQuery _workstations;
    /// <summary>Checks the Keycloak administrator session.</summary>
    private readonly IKeycloakMccAdminVerifier _keycloak;
    /// <summary>Checks the SBC local administrator.</summary>
    private readonly ISbcLocalAdminCredentialVerifier _localAdmin;

    /// <summary>
    /// Creates the MCC trust action checker.
    /// </summary>
    public MccTrustActionAuthorizer(
        IHmiWorkstationWhitelistQuery workstations,
        IKeycloakMccAdminVerifier keycloak,
        ISbcLocalAdminCredentialVerifier localAdmin)
    {
        _workstations = workstations ?? throw new ArgumentNullException(nameof(workstations));
        _keycloak = keycloak ?? throw new ArgumentNullException(nameof(keycloak));
        _localAdmin = localAdmin ?? throw new ArgumentNullException(nameof(localAdmin));
    }

    /// <summary>
    /// Allows the trust action only when a workstation was whitelisted on the HMI.
    /// The Keycloak user must be an MCC administrator and the local administrator login must be correct.
    /// </summary>
    public async Task<MccTrustActionResult> AuthorizeAsync(MccTrustActionRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        bool workstationApproved;
        try
        {
            workstationApproved = await _workstations.HasHmiApprovedWorkstationAsync(cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            return Deny("The HMI workstation whitelist could not be verified.");
        }

        if (!workstationApproved)
        {
            return Deny("The first workstation for this SBC must be approved on the SBC HMI by a local administrator.");
        }

        KeycloakAdminCheck admin = await _keycloak.VerifyAsync(request.AccessToken, cancellationToken);
        if (!admin.IsAdministrator)
        {
            return Deny("A Keycloak MCC Administrator session is required.");
        }

        bool localOk = await _localAdmin.ValidateAsync(
            request.LocalAdministratorUser,
            request.LocalAdministratorPassword,
            cancellationToken);
        if (!localOk)
        {
            return Deny("SBC local administrator credentials were rejected.");
        }

        return new MccTrustActionResult
        {
            IsAllowed = true,
            KeycloakSubject = admin.Subject,
            SbcAdministrator = request.LocalAdministratorUser.Trim()
        };
    }

    /// <summary>
    /// Creates a result that does not allow the action.
    /// </summary>
    private static MccTrustActionResult Deny(string reason) =>
        new() { IsAllowed = false, DenialReason = reason };
}

/// <summary>
/// Reads the workstation whitelist from the database.
/// </summary>
public sealed class HmiWorkstationWhitelistQuery : IHmiWorkstationWhitelistQuery
{
    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Creates the workstation whitelist query.
    /// </summary>
    public HmiWorkstationWhitelistQuery(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    /// <summary>
    /// Checks if an active workstation was whitelisted through the SBC HMI.
    /// </summary>
    public async Task<bool> HasHmiApprovedWorkstationAsync(CancellationToken cancellationToken = default)
    {
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry t " +
            $"JOIN {DatabaseConstants.SchemaName}.ch_device d ON d.device_id = t.device_id " +
            "WHERE t.is_active AND t.list_kind = CAST('WHITELIST' AS certificate_handler.trust_list_kind) " +
            "AND t.approval_channel = @channel " +
            "AND d.device_type IN (CAST('GCP_WORKSTATION' AS certificate_handler.device_type), CAST('OTHER' AS certificate_handler.device_type)))",
            connection);
        command.Parameters.AddWithValue("channel", TrustApprovalChannels.HmiLocal);
        object? exists = await command.ExecuteScalarAsync(cancellationToken);
        return exists is true;
    }
}

/// <summary>
/// Checks the Keycloak session through the token check address.
/// </summary>
public sealed class HttpKeycloakMccAdminVerifier : IKeycloakMccAdminVerifier
{
    /// <summary>HTTP client used to call Keycloak.</summary>
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

    /// <summary>
    /// Asks Keycloak if the token is active and has the MCC administrator role.
    /// Returns a check with no administrator when the settings are missing or the call fails.
    /// </summary>
    public async Task<KeycloakAdminCheck> VerifyAsync(string accessToken, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            return new KeycloakAdminCheck();
        }

        string? url = Environment.GetEnvironmentVariable("CH_KEYCLOAK_INTROSPECTION_URL");
        string? clientId = Environment.GetEnvironmentVariable("CH_KEYCLOAK_CLIENT_ID");
        string? clientSecret = Environment.GetEnvironmentVariable("CH_KEYCLOAK_CLIENT_SECRET");
        if (string.IsNullOrWhiteSpace(url) || string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
        {
            return new KeycloakAdminCheck();
        }

        string? role = Environment.GetEnvironmentVariable("CH_MCC_ADMIN_ROLE");
        if (string.IsNullOrWhiteSpace(role))
        {
            role = "MCC_ADMINISTRATOR";
        }

        using var content = new FormUrlEncodedContent(new Dictionary<string, string> { ["token"] = accessToken.Trim() });
        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, url) { Content = content };
        string basic = Convert.ToBase64String(Encoding.UTF8.GetBytes(clientId + ":" + clientSecret));
        httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);

        try
        {
            using HttpResponseMessage response = await Http.SendAsync(httpRequest, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                return new KeycloakAdminCheck();
            }

            await using Stream body = await response.Content.ReadAsStreamAsync(cancellationToken);
            using JsonDocument document = await JsonDocument.ParseAsync(body, cancellationToken: cancellationToken);
            return ReadCheck(document.RootElement, role);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or TaskCanceledException)
        {
            return new KeycloakAdminCheck();
        }
    }

    /// <summary>
    /// Reads the user and the role from the Keycloak answer.
    /// </summary>
    private static KeycloakAdminCheck ReadCheck(JsonElement root, string role)
    {
        if (!root.TryGetProperty("active", out JsonElement active) || active.ValueKind != JsonValueKind.True)
        {
            return new KeycloakAdminCheck();
        }

        string subject = ReadString(root, "preferred_username");
        if (subject.Length == 0)
        {
            subject = ReadString(root, "sub");
        }

        return new KeycloakAdminCheck
        {
            IsAdministrator = HasRole(root, role),
            Subject = subject
        };
    }

    /// <summary>
    /// Checks if the role is in the realm, the token or the client roles.
    /// </summary>
    private static bool HasRole(JsonElement root, string role)
    {
        if (root.TryGetProperty("realm_access", out JsonElement realm)
            && realm.TryGetProperty("roles", out JsonElement realmRoles)
            && Contains(realmRoles, role))
        {
            return true;
        }

        if (root.TryGetProperty("roles", out JsonElement roles) && Contains(roles, role))
        {
            return true;
        }

        if (!root.TryGetProperty("resource_access", out JsonElement resources) || resources.ValueKind != JsonValueKind.Object)
        {
            return false;
        }

        foreach (JsonProperty client in resources.EnumerateObject())
        {
            if (client.Value.TryGetProperty("roles", out JsonElement clientRoles) && Contains(clientRoles, role))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Checks if the role is in the list.
    /// </summary>
    private static bool Contains(JsonElement roles, string role)
    {
        if (roles.ValueKind != JsonValueKind.Array)
        {
            return false;
        }

        foreach (JsonElement item in roles.EnumerateArray())
        {
            if (item.ValueKind == JsonValueKind.String
                && string.Equals(item.GetString(), role, StringComparison.Ordinal))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Reads a text value from the JSON, or an empty string when it is missing.
    /// </summary>
    private static string ReadString(JsonElement root, string name) =>
        root.TryGetProperty(name, out JsonElement value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;
}
