﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security;
using System.Security.Principal;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.Data.Constants;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Authorizes local device administrators: caller must match the current OS user and belong to the platform Windows group.
/// </summary>
public sealed class AdministratorAuthorizer : IAdministratorAuthorizer
{
    #region Public Methods

    /// <summary>
    /// Determines whether the specified user is authorized as an administrator.
    /// </summary>
    /// <param name="userName">The user name to validate.</param>
    /// <returns>
    /// <c>true</c> if the user is authorized; otherwise, <c>false</c>.
    /// </returns>
    public bool IsAdministrator(string? userName)
    {
        if (string.IsNullOrWhiteSpace(userName) || !string.Equals(userName, userName.Trim(), StringComparison.Ordinal))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DataLogConstants.ADMINISTRATOR_CHECK_NO_USER);
            return false;
        }

        bool isAdministrator = IsCurrentUserAdministrator(userName.Trim());
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.ADMINISTRATOR_CHECKED, userName.Trim(), isAdministrator.ToString());
        return isAdministrator;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Returns true when the caller is the current Windows user and belongs to the administrator group.
    /// </summary>
    /// <param name="userName">Trimmed user name of the caller.</param>
    /// <returns>True for an administrator; otherwise false.</returns>
    private static bool IsCurrentUserAdministrator(string userName)
    {
        if (!CallerMatchesCurrentUser(userName))
        {
            return false;
        }

        if (OperatingSystem.IsWindows())
        {
            string group = AdministratorGroupOptions.Load().AdministratorGroup;
            return WindowsAdministratorMembership.IsCurrentUserInGroup(group);
        }

        string? devUser = Environment.GetEnvironmentVariable("CH_GC_ADMIN_USER");
        return !string.IsNullOrWhiteSpace(devUser)
               && string.Equals(userName, devUser.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Checks if the user name is the user running the app.
    /// On Windows it also checks the full account name and the name without the domain.
    /// </summary>
    private static bool CallerMatchesCurrentUser(string userName)
    {
        if (string.Equals(Environment.UserName, userName, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            if (string.Equals(identity.Name, userName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            string? suffix = identity.Name?.Split('\\').LastOrDefault();
            return !string.IsNullOrWhiteSpace(suffix)
                   && string.Equals(suffix, userName, StringComparison.OrdinalIgnoreCase);
        }
        catch (SecurityException)
        {
            return false;
        }
    }

    #endregion
}
