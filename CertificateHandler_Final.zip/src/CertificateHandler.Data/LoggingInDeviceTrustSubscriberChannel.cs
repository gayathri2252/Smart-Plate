// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Logs trust-event delivery. The production path uses <see cref="ServiceGateTrustSubscriberChannel"/>.
/// </summary>
public sealed class LoggingInDeviceTrustSubscriberChannel : IInDeviceTrustSubscriberChannel
{
    /// <summary>
    /// Writes the trust event to the log. Returns false when the test failure setting is on.
    /// </summary>
    public Task<bool> TryDeliverAsync(
        Guid eventId,
        string subscriberName,
        string newTrustStatus,
        string thumbprintSha256,
        CancellationToken cancellationToken = default)
    {
        if (string.Equals(Environment.GetEnvironmentVariable("CH_TRUST_DELIVERY_FAIL"), "1", StringComparison.Ordinal))
        {
            return Task.FromResult(false);
        }

        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            "Trust event {0} for {1} status {2} delivered to subscriber {3}.",
            eventId,
            thumbprintSha256,
            newTrustStatus,
            subscriberName);
        return Task.FromResult(true);
    }
}
