// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using CertificateHandler.Shared.Constants;
using CertificateHandler.Shared.Models;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// End-to-end pending onboarding approval: validation, whitelist insert, audit, trust event outbox, peer notification.
/// </summary>
public sealed class PendingOnboardingApprovalStore : IPendingOnboardingApprovalStore
{
    #region Member Variables

    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>Sends the trust updates. Null when updates are not sent.</summary>
    private readonly ITrustUpdatePublishService? _publishService;

    /// <summary>Releases the TLS handshake that waits for this request. Null when not used.</summary>
    private readonly Action<Guid>? _resumePendingHandshake;

    /// <summary>SQL that loads a pending request together with its certificate.</summary>
    private const string LoadPendingSql =
        $"SELECT pr.request_id, pr.requested_by, pr.device_id, pr.certificate_id, " +
        "c.thumbprint_sha256, c.subject_dn, c.serial_number, c.not_before, c.not_after, c.presented_cert_der " +
        $"FROM {DatabaseConstants.SchemaName}.ch_pending_request pr " +
        $"JOIN {DatabaseConstants.SchemaName}.ch_certificate c ON c.certificate_id = pr.certificate_id " +
        "WHERE pr.request_id = CAST(@requestId AS uuid) AND pr.status = CAST(@pending AS certificate_handler.pending_request_status) " +
        "FOR UPDATE";

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the store on top of the shared data source.
    /// </summary>
    public PendingOnboardingApprovalStore(
        NpgsqlDataSource dataSource,
        ITrustUpdatePublishService? publishService = null,
        Action<Guid>? resumePendingHandshake = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _publishService = publishService;
        _resumePendingHandshake = resumePendingHandshake;
    }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public async Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(decision);
        ValidateDecisionIds(decision);

        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

        PendingRow row = await LoadPendingRowAsync(connection, transaction, decision.RequestId, cancellationToken);

        ValidateSelfApproval(row.RequestedBy, decision.ActorIdentity);
        ValidateCertificate(row);
        PeerCertificateCryptographicValidator.ValidateOrThrow(row.PresentedCertificateDer);
        await EnsureNoActiveTrustAsync(connection, transaction, row.ThumbprintSha256, cancellationToken);

        DateTimeOffset now = DateTimeOffset.UtcNow;
        await InsertWhitelistRowAsync(connection, transaction, row, decision.ActorIdentity, decision.ApprovalChannel, now, cancellationToken);
        await UpdatePendingAsync(
            connection,
            transaction,
            decision.RequestId,
            "APPROVED",
            decision.ActorIdentity,
            decision.Reason,
            cancellationToken);
        await WriteValidationStepsAsync(connection, transaction, row, passed: true, cancellationToken);
        await InsertAuditAsync(
            connection,
            transaction,
            row,
            decision,
            OnboardingApprovalConstants.EVENT_WHITELISTED,
            DatabaseConstants.STATUS_NOT_LISTED,
            DatabaseConstants.STATUS_WHITELISTED,
            now,
            cancellationToken);
        await InsertTrustEventAsync(
            connection,
            transaction,
            row,
            decision.ActorIdentity,
            OnboardingApprovalConstants.TRUST_STATUS_WHITELISTED,
            now,
            cancellationToken);
        await InsertPeerNotificationAsync(
            connection,
            transaction,
            row,
            "APPROVED",
            cancellationToken);

        await transaction.CommitAsync(cancellationToken);

        _resumePendingHandshake?.Invoke(row.RequestId);

        if (_publishService is not null)
        {
            await _publishService.PublishAsync(
                new TrustUpdate
                {
                    ThumbprintSha256 = row.ThumbprintSha256,
                    CertificateId = row.CertificateId,
                    Change = OnboardingApprovalConstants.TRUST_STATUS_WHITELISTED,
                    Reason = decision.Reason ?? string.Empty,
                    SavedAt = now
                },
                cancellationToken);
        }
    }

    /// <inheritdoc />
    public async Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(decision);
        ValidateDecisionIds(decision);

        string reason = decision.Reason?.Trim() ?? string.Empty;
        if (string.IsNullOrEmpty(reason))
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.REJECTION_REASON_REQUIRED);
        }

        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using NpgsqlTransaction transaction = await connection.BeginTransactionAsync(cancellationToken);

        PendingRow row = await LoadPendingRowAsync(connection, transaction, decision.RequestId, cancellationToken);
        ValidateSelfApproval(row.RequestedBy, decision.ActorIdentity);

        DateTimeOffset now = DateTimeOffset.UtcNow;
        await UpdatePendingAsync(
            connection,
            transaction,
            decision.RequestId,
            "REJECTED",
            decision.ActorIdentity,
            reason,
            cancellationToken);
        await WriteValidationStepsAsync(connection, transaction, row, passed: false, cancellationToken);
        await InsertAuditAsync(
            connection,
            transaction,
            row,
            decision,
            OnboardingApprovalConstants.EVENT_REJECTED,
            DatabaseConstants.STATUS_NOT_LISTED,
            OnboardingApprovalConstants.TRUST_STATUS_REJECTED,
            now,
            cancellationToken);
        await InsertTrustEventAsync(
            connection,
            transaction,
            row,
            decision.ActorIdentity,
            OnboardingApprovalConstants.TRUST_STATUS_REJECTED,
            now,
            cancellationToken);
        await InsertPeerNotificationAsync(
            connection,
            transaction,
            row,
            "REJECTED",
            cancellationToken);

        await transaction.CommitAsync(cancellationToken);
    }

    #endregion

    #region Internal Methods

    /// <summary>
    /// Stops an administrator from approving their own request.
    /// </summary>
    public static void ValidateSelfApproval(string requestedBy, string actorIdentity)
    {
        if (string.Equals(requestedBy?.Trim(), actorIdentity?.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.SELF_APPROVAL_DENIED);
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Checks that the decision has a request id and a user.
    /// </summary>
    private static void ValidateDecisionIds(PendingRequestDecision decision)
    {
        if (string.IsNullOrWhiteSpace(decision.RequestId))
        {
            throw new ArgumentException("Request id is required.", nameof(decision));
        }

        if (string.IsNullOrWhiteSpace(decision.ActorIdentity))
        {
            throw new ArgumentException("Actor identity is required.", nameof(decision));
        }
    }

    /// <summary>
    /// Checks that the certificate of the request has not expired and has a subject.
    /// </summary>
    private static void ValidateCertificate(PendingRow row)
    {
        if (row.NotAfter <= DateTimeOffset.UtcNow)
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.CERTIFICATE_EXPIRED);
        }

        if (string.IsNullOrWhiteSpace(row.SubjectDn))
        {
            throw new InvalidOperationException("Certificate subject is missing.");
        }
    }

    /// <summary>
    /// Loads the pending request and its certificate details.
    /// </summary>
    private static async Task<PendingRow> LoadPendingRowAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string requestId,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(LoadPendingSql, connection, transaction);
        command.Parameters.AddWithValue("requestId", Guid.Parse(requestId));
        command.Parameters.AddWithValue("pending", "PENDING");

        await using NpgsqlDataReader reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.REQUEST_NOT_PENDING);
        }

        byte[]? presentedDer = null;
        if (!reader.IsDBNull(9))
        {
            presentedDer = reader.GetFieldValue<byte[]>(9);
        }

        return new PendingRow(
            reader.GetGuid(0),
            reader.GetString(1),
            reader.IsDBNull(2) ? null : reader.GetGuid(2),
            reader.GetGuid(3),
            reader.GetString(4),
            reader.IsDBNull(5) ? null : reader.GetString(5),
            reader.IsDBNull(6) ? null : reader.GetString(6),
            reader.IsDBNull(7) ? DateTimeOffset.MinValue : reader.GetFieldValue<DateTimeOffset>(7),
            reader.IsDBNull(8) ? DateTimeOffset.MinValue : reader.GetFieldValue<DateTimeOffset>(8),
            presentedDer);
    }

    /// <summary>
    /// Checks that the certificate is not already on an active list.
    /// </summary>
    private static async Task EnsureNoActiveTrustAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"SELECT EXISTS (SELECT 1 FROM {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
            "WHERE thumbprint_sha256 = @thumbprint AND is_active)",
            connection,
            transaction);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        object? exists = await command.ExecuteScalarAsync(cancellationToken);
        if (exists is true)
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.ALREADY_LISTED);
        }
    }

    /// <summary>
    /// Adds the certificate of the request to the whitelist and removes it from the subnet blacklist.
    /// </summary>
    private static async Task InsertWhitelistRowAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PendingRow row,
        string actor,
        string? approvalChannel,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
            "(list_kind, certificate_id, thumbprint_sha256, device_id, subject_dn, serial_number, not_before, not_after, " +
            "added_by, added_at, comment, is_active, approval_channel) " +
            "VALUES (CAST('WHITELIST' AS certificate_handler.trust_list_kind), @certificateId, @thumbprint, @deviceId, " +
            "@subjectDn, @serialNumber, @notBefore, @notAfter, @actor, @now, @comment, TRUE, @channel)",
            connection,
            transaction);
        command.Parameters.AddWithValue("certificateId", row.CertificateId);
        command.Parameters.AddWithValue("thumbprint", row.ThumbprintSha256);
        command.Parameters.AddWithValue("deviceId", (object?)row.DeviceId ?? DBNull.Value);
        command.Parameters.AddWithValue("subjectDn", (object?)row.SubjectDn ?? DBNull.Value);
        command.Parameters.AddWithValue("serialNumber", (object?)row.SerialNumber ?? DBNull.Value);
        command.Parameters.AddWithValue("notBefore", row.NotBefore);
        command.Parameters.AddWithValue("notAfter", row.NotAfter);
        command.Parameters.AddWithValue("actor", actor);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("comment", "Peer onboarding approved");
        string channel = string.IsNullOrWhiteSpace(approvalChannel)
            ? TrustApprovalChannels.HmiLocal
            : approvalChannel.Trim();
        command.Parameters.AddWithValue("channel", channel);
        await command.ExecuteNonQueryAsync(cancellationToken);
        await ClearPropagatedBlackListAsync(connection, transaction, row.ThumbprintSha256, cancellationToken);
    }

    /// <summary>
    /// An administrator whitelist replaces a subnet blacklist on this device.
    /// A later signed unicast can block the thumbprint again.
    /// </summary>
    private static async Task ClearPropagatedBlackListAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"DELETE FROM {DatabaseConstants.SchemaName}.ch_propagated_blacklist WHERE thumbprint_sha256 = @thumbprint",
            connection,
            transaction);
        command.Parameters.AddWithValue("thumbprint", thumbprint);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Updates the status and decision details of the pending request.
    /// </summary>
    private static async Task UpdatePendingAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        string requestId,
        string status,
        string decidedBy,
        string? reason,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_pending_request " +
            "SET status = CAST(@status AS certificate_handler.pending_request_status), " +
            "decided_at = now(), decided_by = @decidedBy, decision_reason = @reason " +
            "WHERE request_id = CAST(@requestId AS uuid)",
            connection,
            transaction);
        command.Parameters.AddWithValue("status", status);
        command.Parameters.AddWithValue("decidedBy", decidedBy);
        command.Parameters.AddWithValue("reason", (object?)reason ?? DBNull.Value);
        command.Parameters.AddWithValue("requestId", Guid.Parse(requestId));
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Saves the result of the expiry, subject and self approval checks.
    /// </summary>
    private static async Task WriteValidationStepsAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PendingRow row,
        bool passed,
        CancellationToken cancellationToken)
    {
        string[] steps = { "EXPIRY", "SUBJECT", "SELF_APPROVAL_DENY" };
        foreach (string step in steps)
        {
            await using var command = new NpgsqlCommand(
                $"INSERT INTO {DatabaseConstants.SchemaName}.ch_validation_result " +
                "(thumbprint_sha256, device_id, validation_step, passed, failure_reason, time_verified) " +
                "VALUES (@thumbprint, @deviceId, @step, @passed, @failure, TRUE)",
                connection,
                transaction);
            command.Parameters.AddWithValue("thumbprint", row.ThumbprintSha256);
            command.Parameters.AddWithValue("deviceId", (object?)row.DeviceId ?? DBNull.Value);
            command.Parameters.AddWithValue("step", step);
            command.Parameters.AddWithValue("passed", passed);
            command.Parameters.AddWithValue("failure", passed ? DBNull.Value : "Rejected or validation failed");
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
    }

    /// <summary>
    /// Writes the audit row for the decision.
    /// </summary>
    private static async Task InsertAuditAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PendingRow row,
        PendingRequestDecision decision,
        string eventType,
        string previousStatus,
        string newStatus,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        string details = JsonSerializer.Serialize(new { decision.RequestId, decision.Reason });
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
            "(event_type, event_timestamp, actor_identity, device_id, request_id, certificate_id, thumbprint_sha256, " +
            "previous_status, new_status, action_status, reason, details_json, result, source_component) " +
            "VALUES (@eventType, @now, @actor, @deviceId, @requestId, @certificateId, @thumbprint, @previous, @newStatus, " +
            "'SUCCESS', @reason, CAST(@details AS jsonb), 'SUCCESS', @source)",
            connection,
            transaction);
        command.Parameters.AddWithValue("eventType", eventType);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("actor", decision.ActorIdentity);
        command.Parameters.AddWithValue("deviceId", (object?)row.DeviceId ?? DBNull.Value);
        command.Parameters.AddWithValue("requestId", row.RequestId);
        command.Parameters.AddWithValue("certificateId", row.CertificateId);
        command.Parameters.AddWithValue("thumbprint", row.ThumbprintSha256);
        command.Parameters.AddWithValue("previous", previousStatus);
        command.Parameters.AddWithValue("newStatus", newStatus);
        command.Parameters.AddWithValue("reason", (object?)decision.Reason ?? DBNull.Value);
        command.Parameters.AddWithValue("details", details);
        command.Parameters.AddWithValue("source", OnboardingApprovalConstants.SOURCE_COMPONENT);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Saves the trust event for the decision and queues it for the default subscriber.
    /// </summary>
    private static async Task InsertTrustEventAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PendingRow row,
        string actor,
        string trustStatus,
        DateTimeOffset now,
        CancellationToken cancellationToken)
    {
        string payload = JsonSerializer.Serialize(new { row.RequestId, trustStatus });
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event " +
            "(device_id, thumbprint_sha256, new_trust_status, related_request_id, actor_identity, occurred_at, payload_json) " +
            "VALUES (@deviceId, @thumbprint, @status, @requestId, @actor, @now, CAST(@payload AS jsonb)) " +
            "RETURNING event_id",
            connection,
            transaction);
        command.Parameters.AddWithValue("deviceId", (object?)row.DeviceId ?? DBNull.Value);
        command.Parameters.AddWithValue("thumbprint", row.ThumbprintSha256);
        command.Parameters.AddWithValue("status", trustStatus);
        command.Parameters.AddWithValue("requestId", row.RequestId);
        command.Parameters.AddWithValue("actor", actor);
        command.Parameters.AddWithValue("now", now);
        command.Parameters.AddWithValue("payload", payload);
        Guid eventId = (Guid)(await command.ExecuteScalarAsync(cancellationToken))!;
        await TrustEventDeliveryService.QueueDefaultSubscriberAsync(connection, eventId, cancellationToken);
    }

    /// <summary>
    /// Saves a notification that tells the requesting device about the decision.
    /// It is saved as not sent yet, so the delivery service sends it later.
    /// </summary>
    private static async Task InsertPeerNotificationAsync(
        NpgsqlConnection connection,
        NpgsqlTransaction transaction,
        PendingRow row,
        string notificationStatus,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_peer_notification " +
            "(request_id, target_device_id, notification_status, delivery_result, last_error) " +
            "VALUES (@requestId, @deviceId, CAST(@status AS certificate_handler.peer_notification_status), " +
            "CAST('FAILED' AS certificate_handler.delivery_result), @pending)",
            connection,
            transaction);
        command.Parameters.AddWithValue("pending", PeerNotificationConstants.PendingDeliveryMarker);
        command.Parameters.AddWithValue("requestId", row.RequestId);
        command.Parameters.AddWithValue("deviceId", (object?)row.DeviceId ?? DBNull.Value);
        command.Parameters.AddWithValue("status", notificationStatus);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// A pending request with the details of its certificate.
    /// </summary>
    private sealed record PendingRow(
        Guid RequestId,
        string RequestedBy,
        Guid? DeviceId,
        Guid CertificateId,
        string ThumbprintSha256,
        string? SubjectDn,
        string? SerialNumber,
        DateTimeOffset NotBefore,
        DateTimeOffset NotAfter,
        byte[]? PresentedCertificateDer);

    #endregion
}
