// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Constants;

/// <summary>
/// Text and event identifiers for pending onboarding approve/reject (RS_21, RS_09).
/// </summary>
internal static class OnboardingApprovalConstants
{
    #region Member Variables

    /// <summary>Audit event type when a peer is whitelisted.</summary>
    internal const string EVENT_WHITELISTED = "PEER_WHITELISTED";

    /// <summary>Audit event type when a peer onboarding request is rejected.</summary>
    internal const string EVENT_REJECTED = "PEER_ONBOARDING_REJECTED";

    /// <summary>Trust status when the peer is whitelisted.</summary>
    internal const string TRUST_STATUS_WHITELISTED = "WHITELISTED";

    /// <summary>Trust status when the peer onboarding request is rejected.</summary>
    internal const string TRUST_STATUS_REJECTED = "REJECTED";

    /// <summary>Message shown when the requester tries to approve their own request.</summary>
    internal const string SELF_APPROVAL_DENIED = "The requester cannot approve their own onboarding request.";

    /// <summary>Message shown when a rejection has no reason.</summary>
    internal const string REJECTION_REASON_REQUIRED = "A rejection reason is required.";

    /// <summary>Message shown when the request is not pending or does not exist.</summary>
    internal const string REQUEST_NOT_PENDING = "The request is not pending or does not exist.";

    /// <summary>Message shown when the certificate has expired.</summary>
    internal const string CERTIFICATE_EXPIRED = "The certificate has expired and cannot be whitelisted.";

    /// <summary>Message shown when the certificate data from the peer is missing.</summary>
    internal const string PRESENTED_CERTIFICATE_REQUIRED =
        "The presented certificate bytes are missing; the peer must reconnect before approval.";

    /// <summary>Message shown when the certificate already has an active list entry.</summary>
    internal const string ALREADY_LISTED = "The certificate thumbprint already has an active trust list row.";

    /// <summary>Name of the part of the app written in the audit rows.</summary>
    internal const string SOURCE_COMPONENT = "PendingOnboardingApproval";

    #endregion
}
