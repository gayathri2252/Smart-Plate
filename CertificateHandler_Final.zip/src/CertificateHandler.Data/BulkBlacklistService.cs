// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Adds many certificates to the blacklist in one go for incident response, and saves the result of each one.
/// </summary>
public sealed class BulkBlacklistService : IBulkBlacklistService
{
    #region Member Variables

    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>Adds each certificate to the blacklist.</summary>
    private readonly ICertificateBlackList _certificateBlackList;

    /// <summary>Most certificates allowed in one batch.</summary>
    private const int DefaultMaxBatch = 50;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the bulk blacklist service.
    /// </summary>
    public BulkBlacklistService(NpgsqlDataSource dataSource, ICertificateBlackList certificateBlackList)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _certificateBlackList = certificateBlackList ?? throw new ArgumentNullException(nameof(certificateBlackList));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Adds the selected certificates to the blacklist and saves the bulk operation.
    /// If one certificate fails, the error is kept in its result and the others still go on.
    /// </summary>
    public async Task<BulkBlacklistResponse> ExecuteAsync(BulkBlacklistRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        BlacklistReasonPolicy.ValidateOrThrow(request.Reason);

        if (request.ThumbprintsSha256.Count == 0)
        {
            throw new ArgumentException("At least one thumbprint is required.", nameof(request));
        }

        if (request.ThumbprintsSha256.Count > DefaultMaxBatch)
        {
            throw new InvalidOperationException($"Batch limit is {DefaultMaxBatch}.");
        }

        Guid bulkId = Guid.NewGuid();
        await InsertBulkHeaderAsync(bulkId, request, cancellationToken);

        var results = new List<BulkBlacklistItemResult>();
        foreach (string thumbprint in request.ThumbprintsSha256)
        {
            try
            {
                await _certificateBlackList.BlackListAsync(
                    new BlackListRequest
                    {
                        ThumbprintSha256 = thumbprint,
                        Reason = request.Reason,
                        ReasonClass = BlacklistReasonClass.ManualAction,
                        SourceComponent = "BulkBlacklist",
                        ActorIdentity = request.ActorIdentity
                    },
                    cancellationToken);
                results.Add(new BulkBlacklistItemResult { ThumbprintSha256 = thumbprint, Succeeded = true });
            }
            catch (Exception ex)
            {
                results.Add(new BulkBlacklistItemResult { ThumbprintSha256 = thumbprint, Succeeded = false, Error = ex.Message });
            }
        }

        await CompleteBulkAsync(bulkId, cancellationToken);
        return new BulkBlacklistResponse { BulkOperationId = bulkId, Items = results };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Adds the main row of the bulk operation with the status RUNNING.
    /// </summary>
    private async Task InsertBulkHeaderAsync(Guid bulkId, BulkBlacklistRequest request, CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_bulk_operation " +
            "(bulk_operation_id, initiated_by, reason, max_batch_size, processing_timeout_seconds, status) " +
            "VALUES (@id, @actor, @reason, @max, 120, 'RUNNING')",
            connection);
        command.Parameters.AddWithValue("id", bulkId);
        command.Parameters.AddWithValue("actor", request.ActorIdentity);
        command.Parameters.AddWithValue("reason", request.Reason);
        command.Parameters.AddWithValue("max", DefaultMaxBatch);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Marks the bulk operation as COMPLETED.
    /// </summary>
    private async Task CompleteBulkAsync(Guid bulkId, CancellationToken cancellationToken)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_bulk_operation SET status = CAST('COMPLETED' AS certificate_handler.bulk_operation_status), completed_at = now() WHERE bulk_operation_id = @id",
            connection);
        command.Parameters.AddWithValue("id", bulkId);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion
}
