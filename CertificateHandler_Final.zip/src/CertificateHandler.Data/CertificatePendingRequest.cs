﻿// The information contained herein is confidential and proprietary to Valmet.
// All rights reserved.

using System.Data;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Entities;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// EF Core implementation for pending certificate requests. The one
/// write method uses raw SQL instead, see its own summary for why.
/// </summary>
public sealed class CertificatePendingRequest : Interfaces.ICertificatePendingRequest
{
    #region Member Variables

    /// <summary>SQL that marks a pending request as expired.</summary>
    private const string MarkAsExpiredSql =
        $"UPDATE {DatabaseConstants.SchemaName}.{DatabaseConstants.PendingRequestTable} " +
        $"SET status = CAST(@expiredStatus AS {DatabaseConstants.SchemaName}.{DatabaseConstants.PendingRequestStatusEnumName}), " +
        "    decided_at = @decidedAt, " +
        "    decided_by = @decidedBy " +
        "WHERE request_id = @requestId " +
        $"  AND status = CAST(@pendingStatus AS {DatabaseConstants.SchemaName}.{DatabaseConstants.PendingRequestStatusEnumName})";

    /// <summary>Database context used to run the queries.</summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the pending request data access for the given database context.
    /// Throws when the context is null.
    /// </summary>
    public CertificatePendingRequest(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public async Task<List<PendingRequest>> GetPendingRequestsAsync(
        CancellationToken cancellationToken = default)
    {
        try
        {
            List<PendingRequest> requests = await _dbContext.PendingRequests
                .AsNoTracking()
                .Where(request => request.Status == PendingRequestStatus.Pending)
                .ToListAsync(cancellationToken);

            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.PENDING_REQUESTS_READ, requests.Count.ToString());
            return requests;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.PENDING_REQUESTS_READ_FAILED, ex.Message);
            throw;
        }
    }

    /// <inheritdoc />
    public async Task<List<PendingRequest>> GetExpiredCertificateRequestsAsync(
        int timeoutHours,
        CancellationToken cancellationToken = default)
    {
        try
        {
            DateTimeOffset expiryDateTime = DateTimeOffset.UtcNow.AddHours(-timeoutHours);

            // Only the certificate subject is read. Loading the whole Certificate row
            // would also read the certificate_role enum column, which EF cannot read
            // here (it has no string conversion like the pending request enums do).
            var rows = await _dbContext.PendingRequests
                .AsNoTracking()
                .Where(request =>
                    request.Status == PendingRequestStatus.Pending &&
                    request.CreatedAt <= expiryDateTime)
                .Select(request => new { Request = request, request.Certificate.SubjectDn })
                .ToListAsync(cancellationToken);

            var result = new List<PendingRequest>(rows.Count);

            foreach (var row in rows)
            {
                row.Request.Certificate = new Certificate
                {
                    CertificateId = row.Request.CertificateId,
                    SubjectDn = row.SubjectDn
                };
                result.Add(row.Request);
            }

            if (result.Count > 0)
            {
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DataLogConstants.EXPIRED_REQUESTS_FOUND, result.Count.ToString(), timeoutHours.ToString());
            }

            return result;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.EXPIRED_REQUESTS_READ_FAILED, ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Uses raw SQL with an explicit cast, since PostgreSQL does not
    /// allow assigning plain text to an enum column (SQLSTATE 42804).
    /// </summary>
    public async Task<bool> MarkAsExpiredAsync(
        Guid requestId,
        DateTimeOffset expiredAtUtc,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

            bool isConnectionClosed = connection.State is not ConnectionState.Open;
            if (isConnectionClosed)
            {
                await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
            }

            try
            {
                await using var command = new NpgsqlCommand(MarkAsExpiredSql, connection);
                command.Parameters.Add(new NpgsqlParameter("requestId", requestId));
                command.Parameters.Add(new NpgsqlParameter("decidedAt", expiredAtUtc));
                command.Parameters.Add(new NpgsqlParameter("decidedBy", DatabaseConstants.SystemActor));
                command.Parameters.Add(new NpgsqlParameter("expiredStatus", PostgresEnumNames.ToPgName(PendingRequestStatus.Expired)));
                command.Parameters.Add(new NpgsqlParameter("pendingStatus", PostgresEnumNames.ToPgName(PendingRequestStatus.Pending)));

                int rowsAffected = await command.ExecuteNonQueryAsync(cancellationToken);

                // 1 if still Pending and updated; 0 if already decided.
                bool isExpired = rowsAffected == 1;
                CertificateHandlerLogger.Information(
                    MessageIdGenerator.Next(),
                    isExpired ? DataLogConstants.REQUEST_MARKED_EXPIRED : DataLogConstants.REQUEST_ALREADY_DECIDED,
                    requestId.ToString());
                return isExpired;
            }
            finally
            {
                if (isConnectionClosed)
                {
                    await connection.CloseAsync();
                }
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DataLogConstants.REQUEST_EXPIRE_FAILED, requestId.ToString(), ex.Message);
            throw;
        }
    }

    #endregion
}