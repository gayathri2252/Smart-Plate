// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Records factory provisioning attempts (RS_01).
/// </summary>
public sealed class FactoryProvisioningService : IFactoryProvisioningService
{
    #region Member Variables

    /// <summary>Data source used to connect to the database.</summary>
    private readonly NpgsqlDataSource _dataSource;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the factory provisioning service.
    /// </summary>
    public FactoryProvisioningService(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Saves the start of a factory provisioning attempt with the status IN PROGRESS.
    /// </summary>
    public async Task<Guid> StartAttemptAsync(Guid deviceId, string targetRole, CancellationToken cancellationToken = default)
    {
        Guid attemptId = Guid.NewGuid();
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_factory_provisioning_attempt (attempt_id, device_id, target_role, outcome) " +
            "VALUES (@attemptId, @deviceId, CAST(@role AS certificate_handler.certificate_role), 'IN_PROGRESS')",
            connection);
        command.Parameters.AddWithValue("attemptId", attemptId);
        command.Parameters.AddWithValue("deviceId", deviceId);
        command.Parameters.AddWithValue("role", targetRole);
        await command.ExecuteNonQueryAsync(cancellationToken);
        return attemptId;
    }

    /// <summary>
    /// Saves the result of a factory provisioning attempt and writes an audit row.
    /// </summary>
    public async Task CompleteAttemptAsync(Guid attemptId, bool success, Guid? certificateId, string? error, CancellationToken cancellationToken = default)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_factory_provisioning_attempt " +
            "SET outcome = CAST(@outcome AS certificate_handler.provisioning_outcome), completed_at = now(), " +
            "resulting_certificate_id = @certificateId, error_message = @error WHERE attempt_id = @attemptId",
            connection);
        command.Parameters.AddWithValue("outcome", success ? "SUCCESS" : "FAILED");
        command.Parameters.AddWithValue("certificateId", (object?)certificateId ?? DBNull.Value);
        command.Parameters.AddWithValue("error", (object?)error ?? DBNull.Value);
        command.Parameters.AddWithValue("attemptId", attemptId);
        await command.ExecuteNonQueryAsync(cancellationToken);

        await using var audit = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
            "(event_type, actor_identity, device_id, action_status, reason, result, source_component) " +
            "SELECT 'FACTORY_PROVISIONING', 'system', device_id, @status, @error, @result, 'FactoryProvisioningService' " +
            $"FROM {DatabaseConstants.SchemaName}.ch_factory_provisioning_attempt WHERE attempt_id = @attemptId",
            connection);
        audit.Parameters.AddWithValue("status", success ? "COMPLETED" : "FAILED");
        audit.Parameters.AddWithValue("error", (object?)error ?? DBNull.Value);
        audit.Parameters.AddWithValue("result", success ? "SUCCESS" : "FAILED");
        audit.Parameters.AddWithValue("attemptId", attemptId);
        await audit.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion
}
