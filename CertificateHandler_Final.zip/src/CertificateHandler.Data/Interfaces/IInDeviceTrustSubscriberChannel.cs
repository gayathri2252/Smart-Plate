// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers trust events to in-device subscribers that gate protected services (RS_27).
/// </summary>
public interface IInDeviceTrustSubscriberChannel
{
    /// <summary>
    /// Sends the trust event to a subscriber in the device.
    /// </summary>
    Task<bool> TryDeliverAsync(
        Guid eventId,
        string subscriberName,
        string newTrustStatus,
        string thumbprintSha256,
        CancellationToken cancellationToken = default);
}
