// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes certificate expiry alerts that are sent to MCC through WEF.
/// </summary>
public interface IWefCertificateEventWriter
{
    /// <summary>Writes the expiry alert. Returns true when the Windows Event Log accepted it.</summary>
    bool WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter);
}
