// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes a whitelist and audit row for a validated MAXUM peer (RS_32).
/// </summary>
public interface IMaxumPeerAutoApprover
{
    /// <summary>
    /// Returns true when the peer is whitelisted. Returns false when the write did not happen
    /// and the caller should keep the peer on the pending queue.
    /// </summary>
    Task<bool> TryAutoApproveAsync(PeerOnboardingRequest peer, CancellationToken cancellationToken = default);
}
