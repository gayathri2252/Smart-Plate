// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;
using CertificateHandler.Data.Security;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Sends one unicast blacklist message to each MAXUM peer on the same IP subnet (RS_33).
/// </summary>
public interface ISubnetBlacklistPropagator
{
    /// <summary>
    /// Sends the blacklist of the certificate to the MAXUM peers on the same subnet.
    /// </summary>
    Task PropagateAsync(string thumbprintSha256, string reason, CancellationToken cancellationToken = default);
}

/// <summary>
/// Finds the MAXUM peers on the same subnet.
/// </summary>
public interface ISubnetPeerDirectory
{
    /// <summary>
    /// Lists the IP addresses of the MAXUM peers on the same subnet.
    /// </summary>
    Task<IReadOnlyList<IPAddress>> ListSameSubnetPeersAsync(CancellationToken cancellationToken = default);
}

/// <summary>
/// Sends a blacklist message to one peer.
/// </summary>
public interface IBlacklistUnicastTransport
{
    /// <summary>
    /// Sends the message to the peer.
    /// </summary>
    Task SendAsync(IPAddress peer, byte[] payload, CancellationToken cancellationToken = default);
}

/// <summary>
/// Saves the blacklist messages received from other devices.
/// </summary>
public interface IPropagatedBlacklistStore
{
    /// <summary>
    /// Saves the received blacklist message.
    /// </summary>
    Task ApplyAsync(BlacklistPropagationMessage message, CancellationToken cancellationToken = default);
}
