// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Production trust-event publisher: writes <c>ch_trust_event</c> (RS_27).
/// </summary>
public sealed class DatabaseTrustEventPublisher : ITrustUpdatePublisher
{
    #region Member Variables

    /// <summary>Database context used to save the trust events.</summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the publisher on top of the given database context.
    /// </summary>
    public DatabaseTrustEventPublisher(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <inheritdoc />
    public async Task PublishAsync(TrustUpdate update, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(update);

        string thumbprint = ThumbprintNormalizer.NormalizeRequired(update.ThumbprintSha256);
        string payload = JsonSerializer.Serialize(new
        {
            update.Change,
            update.Reason,
            update.SavedAt,
            update.CertificateId
        });

        var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();
        bool wasClosed = connection.State != System.Data.ConnectionState.Open;
        if (wasClosed)
        {
            await connection.OpenAsync(cancellationToken);
        }

        try
        {
            await using var command = new NpgsqlCommand(
                $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event " +
                "(thumbprint_sha256, new_trust_status, actor_identity, occurred_at, payload_json) " +
                "VALUES (@thumbprint, @status, @actor, now(), CAST(@payload AS jsonb)) " +
                "RETURNING event_id",
                connection);
            command.Parameters.AddWithValue("thumbprint", thumbprint);
            command.Parameters.AddWithValue("status", update.Change);
            command.Parameters.AddWithValue("actor", (object?)update.Reason ?? DBNull.Value);
            command.Parameters.AddWithValue("payload", payload);
            Guid eventId = (Guid)(await command.ExecuteScalarAsync(cancellationToken))!;
            await TrustEventDeliveryService.QueueDefaultSubscriberAsync(connection, eventId, cancellationToken);
        }
        finally
        {
            if (wasClosed)
            {
                await connection.CloseAsync();
            }
        }
    }

    #endregion
}
