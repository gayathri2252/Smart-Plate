// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// X.509 certificate metadata (private keys remain in Windows Certificate Store / TPM).
/// </summary>
public class Certificate
{
    #region Public Properties

    /// <summary>Id of the certificate.</summary>
    public Guid CertificateId { get; set; }

    /// <summary>Id of the device that owns the certificate. Null when the device is not known.</summary>
    public Guid? DeviceId { get; set; }

    /// <summary>Role of the certificate, like peer, local SBC or local MIB.</summary>
    public CertificateRole CertificateRole { get; set; }

    /// <summary>SHA256 thumbprint of the certificate.</summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>Subject name of the certificate.</summary>
    public string SubjectDn { get; set; } = string.Empty;

    /// <summary>Issuer name of the certificate.</summary>
    public string IssuerDn { get; set; } = string.Empty;

    /// <summary>Serial number given by the certificate authority.</summary>
    public string? SerialNumber { get; set; }

    /// <summary>Date from which the certificate is valid.</summary>
    public DateTimeOffset NotBefore { get; set; }

    /// <summary>Date until which the certificate is valid.</summary>
    public DateTimeOffset NotAfter { get; set; }

    /// <summary>Type of the public key.</summary>
    public string? PublicKeyAlgorithm { get; set; }

    /// <summary>The public key in PEM format.</summary>
    public string? PublicKeyPem { get; set; }

    /// <summary>The certificate in DER format.</summary>
    public byte[]? CertDer { get; set; }

    /// <summary>Windows certificate store location that holds the certificate.</summary>
    public string? WindowsStoreLocation { get; set; }

    /// <summary>Thumbprint of the certificate in the Windows certificate store.</summary>
    public string? WindowsStoreThumbprint { get; set; }

    /// <summary>True when the certificate is active.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Id of the certificate that replaced this one. Null when it is not replaced.</summary>
    public Guid? SupersededByCertificateId { get; set; }

    /// <summary>Time when the row was created.</summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>Time when the row was last changed.</summary>
    public DateTimeOffset UpdatedAt { get; set; }

    /// <summary>Device that owns the certificate.</summary>
    public Device? Device { get; set; }

    /// <summary>Certificate that replaced this one.</summary>
    public Certificate? SupersededByCertificate { get; set; }

    /// <summary>Whitelist and blacklist entries of the certificate.</summary>
    public ICollection<TrustListEntry> TrustListEntries { get; set; } = new List<TrustListEntry>();

    /// <summary>Pending requests of the certificate.</summary>
    public ICollection<PendingRequest> PendingRequests { get; set; } = new List<PendingRequest>();

    #endregion
}
