// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Active whitelist or blacklist row used for TLS trust enforcement.
/// </summary>
public class TrustListEntry
{
    #region Public Properties

    /// <summary>Id of the entry.</summary>
    public long Id { get; set; }

    /// <summary>List that holds the entry, the whitelist or the blacklist.</summary>
    public TrustListKind ListKind { get; set; }

    /// <summary>Id of the certificate.</summary>
    public Guid CertificateId { get; set; }

    /// <summary>SHA256 thumbprint of the certificate.</summary>
    public string ThumbprintSha256 { get; set; } = string.Empty;

    /// <summary>Id of the device. Null when the device is not known.</summary>
    public Guid? DeviceId { get; set; }

    /// <summary>Subject name of the certificate.</summary>
    public string? SubjectDn { get; set; }

    /// <summary>Serial number of the certificate.</summary>
    public string? SerialNumber { get; set; }

    /// <summary>Date from which the certificate is valid.</summary>
    public DateTimeOffset? NotBefore { get; set; }

    /// <summary>Date until which the certificate is valid.</summary>
    public DateTimeOffset? NotAfter { get; set; }

    /// <summary>User who added the entry.</summary>
    public string AddedBy { get; set; } = "SYSTEM";

    /// <summary>Time when the entry was added.</summary>
    public DateTimeOffset AddedAt { get; set; }

    /// <summary>Comment or reason for the entry.</summary>
    public string? Comment { get; set; }

    /// <summary>Reason type of a blacklist entry. Null for whitelist entries.</summary>
    public BlacklistReasonClass? BlacklistReasonClass { get; set; }

    /// <summary>True when the entry is active.</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>Time when the entry was turned off. Null while it is active.</summary>
    public DateTimeOffset? DeactivatedAt { get; set; }

    /// <summary>User who turned off the entry.</summary>
    public string? DeactivatedBy { get; set; }

    /// <summary>Certificate of the entry.</summary>
    public Certificate Certificate { get; set; } = null!;

    /// <summary>Device of the entry.</summary>
    public Device? Device { get; set; }

    #endregion
}
