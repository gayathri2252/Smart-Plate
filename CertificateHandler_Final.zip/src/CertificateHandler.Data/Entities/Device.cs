// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// MAXUM device identity stored for HMI and trust workflows.
/// </summary>
public class Device
{
    #region Public Properties

    /// <summary>Id of the device.</summary>
    public Guid DeviceId { get; set; }

    /// <summary>Code of the device.</summary>
    public string DeviceCode { get; set; } = string.Empty;

    /// <summary>Display name of the device.</summary>
    public string? DeviceName { get; set; }

    /// <summary>Type of the device.</summary>
    public DeviceType DeviceType { get; set; } = DeviceType.MaxumPeer;

    /// <summary>MAXUM IP address of the device.</summary>
    public string? MaxumIp { get; set; }

    /// <summary>Working status of the device.</summary>
    public DeviceOperationalStatus OperationalStatus { get; set; } = DeviceOperationalStatus.Active;

    /// <summary>Id of the main certificate of the device.</summary>
    public Guid? PrimaryCertificateId { get; set; }

    /// <summary>Time when the row was created.</summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>Time when the row was last changed.</summary>
    public DateTimeOffset UpdatedAt { get; set; }

    /// <summary>Main certificate of the device.</summary>
    public Certificate? PrimaryCertificate { get; set; }

    /// <summary>Certificates of the device.</summary>
    public ICollection<Certificate> Certificates { get; set; } = new List<Certificate>();

    /// <summary>References to the protected keys of the device.</summary>
    public ICollection<SecureKeyReference> SecureKeys { get; set; } = new List<SecureKeyReference>();

    #endregion
}
