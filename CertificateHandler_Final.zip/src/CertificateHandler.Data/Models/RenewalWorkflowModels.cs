// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Models;

/// <summary>
/// Current state of a renewal request.
/// </summary>
public sealed class RenewalWorkflowState
{
    /// <summary>Id of the renewal request.</summary>
    public Guid RenewalRequestId { get; init; }

    /// <summary>Id of the certificate to renew.</summary>
    public Guid CertificateId { get; init; }

    /// <summary>Id of the key used for the request.</summary>
    public Guid KeyId { get; init; }

    /// <summary>Status of the renewal request.</summary>
    public string Status { get; init; } = string.Empty;

    /// <summary>The certificate signing request in PEM format.</summary>
    public string? CsrPem { get; init; }

    /// <summary>The signed certificate in PEM format.</summary>
    public string? SignedCertificatePem { get; init; }
}
