// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Saves the result of each certificate validation step in the database.
/// </summary>
public sealed class ValidationResultWriter : IValidationResultWriter
{
    #region Member Variables

    /// <summary>Database context used to save the results.</summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the validation result writer.
    /// </summary>
    public ValidationResultWriter(CertificateHandlerDbContext dbContext)
    {
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Saves the result of one certificate validation step.
    /// </summary>
    public async Task WriteAsync(
        string? thumbprintSha256,
        Guid? deviceId,
        string validationStep,
        bool passed,
        string? failureReason,
        bool timeVerified,
        bool autoBlacklisted,
        CancellationToken cancellationToken = default)
    {
        var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();
        bool wasClosed = connection.State != System.Data.ConnectionState.Open;
        if (wasClosed)
        {
            await connection.OpenAsync(cancellationToken);
        }

        try
        {
            await using var command = new NpgsqlCommand(
                $"INSERT INTO {DatabaseConstants.SchemaName}.ch_validation_result " +
                "(thumbprint_sha256, device_id, validation_step, passed, failure_reason, time_verified, auto_blacklisted) " +
                "VALUES (@thumbprint, @deviceId, @step, @passed, @failure, @timeVerified, @autoBlacklisted)",
                connection);
            command.Parameters.AddWithValue("thumbprint", (object?)thumbprintSha256 ?? DBNull.Value);
            command.Parameters.AddWithValue("deviceId", (object?)deviceId ?? DBNull.Value);
            command.Parameters.AddWithValue("step", validationStep);
            command.Parameters.AddWithValue("passed", passed);
            command.Parameters.AddWithValue("failure", (object?)failureReason ?? DBNull.Value);
            command.Parameters.AddWithValue("timeVerified", timeVerified);
            command.Parameters.AddWithValue("autoBlacklisted", autoBlacklisted);
            await command.ExecuteNonQueryAsync(cancellationToken);
        }
        finally
        {
            if (wasClosed)
            {
                await connection.CloseAsync();
            }
        }
    }

    #endregion
}
