// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Writes certificate expiry events to Windows Event Log for MCC / WEF pickup (RS_25).
/// </summary>
public sealed class WefCertificateEventWriter : IWefCertificateEventWriter
{
    /// <summary>Set to 1 when the event source is ready.</summary>
    private static int _eventSourceReady;

    #region Public Methods

    /// <summary>
    /// Writes a certificate expiry alert to the log and, on Windows, to the Windows event log so WEF can pick it up.
    /// Returns true when it was written to the event log.
    /// </summary>
    public bool WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter)
    {
        string message = $"WEF certificate expiry alert: {certificateName} thumbprint {thumbprint} notAfter {notAfter:u}";
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message);

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            const string source = "CertificateHandler";
            EnsureEventSource(source);

            using var log = new System.Diagnostics.EventLog("Application") { Source = source };
            log.WriteEntry(message, System.Diagnostics.EventLogEntryType.Warning, 42501);
            return true;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "WEF Event Log write failed: {0}", ex.Message);
            return false;
        }
    }

    /// <summary>
    /// Creates the event source when it does not exist.
    /// </summary>
    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    private static void EnsureEventSource(string source)
    {
        if (System.Threading.Interlocked.CompareExchange(ref _eventSourceReady, 0, 0) == 1)
        {
            return;
        }

        if (!System.Diagnostics.EventLog.SourceExists(source))
        {
            System.Diagnostics.EventLog.CreateEventSource(source, "Application");
        }

        System.Threading.Interlocked.Exchange(ref _eventSourceReady, 1);
    }

    #endregion
}
