// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Options;

/// <summary>
/// Optional environment overrides for developer workstations (same variables as integration tests).
/// </summary>
public static class DatabaseOptionsEnvironmentOverrides
{
    /// <summary>Name of the environment variable that holds the test user name.</summary>
    public const string IntegrationUsernameVariable = "CH_PG_INTEGRATION_USERNAME";

    /// <summary>Name of the environment variable that holds the client certificate name.</summary>
    public const string ClientCertificateVariable = "CH_PG_CLIENT_CERT_NAME";

    /// <summary>Client certificate name used when only the test user name is set.</summary>
    public const string DefaultClientCertificateName = "Valmet-UserManagement-PostgreSQL-Client";

    /// <summary>
    /// Sets the user name and client certificate from the environment variables.
    /// On the same machine, plain transport is used and nothing else is changed.
    /// </summary>
    public static void Apply(DatabaseOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);

        string? integrationUser = Environment.GetEnvironmentVariable(IntegrationUsernameVariable);
        if (!string.IsNullOrWhiteSpace(integrationUser))
        {
            options.Username = integrationUser;
        }

        if (DatabaseOptions.IsSameMachine(options.Host))
        {
            options.UsePlainTransportOnSameMachine();
            return;
        }

        string? clientCert = Environment.GetEnvironmentVariable(ClientCertificateVariable);
        if (!string.IsNullOrWhiteSpace(clientCert))
        {
            options.SslMode = true;
            options.ClientCertificateName = clientCert;
            return;
        }

        if (!string.IsNullOrWhiteSpace(integrationUser))
        {
            options.SslMode = true;
            options.ClientCertificateName = DefaultClientCertificateName;
        }
    }
}
