// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.UI.Integration;

/// <summary>
/// MCC trust channel is active when the host sets CH_TRUST_CHANNEL=MCC (RS_34).
/// The HMI path leaves the variable unset and uses the local administrator only.
/// </summary>
public static class MccTrustSession
{
    public const string ChannelEnvironmentVariable = "CH_TRUST_CHANNEL";

    public static bool IsActive =>
        string.Equals(Environment.GetEnvironmentVariable(ChannelEnvironmentVariable), "MCC", StringComparison.OrdinalIgnoreCase);
}

/// <summary>
/// Holds the dual-authentication identities for the trust action that is about to be saved.
/// </summary>
public static class MccTrustProof
{
    public static string? ActorIdentity { get; private set; }

    public static void Set(string keycloakSubject, string localAdministrator)
    {
        ActorIdentity = $"mcc:{keycloakSubject.Trim()};sbc:{localAdministrator.Trim()}";
    }

    public static void Clear() => ActorIdentity = null;
}
