// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data;
using CertificateHandler.UI.Interfaces;

namespace CertificateHandler.UI.Authentication;

/// <summary>
/// Checks SBC local administrator credentials through the same Windows logon used by the HMI (RS_34).
/// </summary>
public sealed class AuthenticatorSbcLocalAdminVerifier : ISbcLocalAdminCredentialVerifier
{
    private readonly ILocalUserAuthenticator _authenticator;

    public AuthenticatorSbcLocalAdminVerifier(ILocalUserAuthenticator authenticator)
    {
        _authenticator = authenticator ?? throw new ArgumentNullException(nameof(authenticator));
    }

    public Task<bool> ValidateAsync(string userName, string password, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(_authenticator.SignIn(userName, password) == LocalSignInResult.Success);
    }
}
