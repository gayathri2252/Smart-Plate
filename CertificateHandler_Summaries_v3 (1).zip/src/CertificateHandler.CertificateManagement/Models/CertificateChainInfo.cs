// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Result of a certificate chain lookup: leaf, intermediates, root,
/// and a status/error pair. Carries chain data only, no trust decision.
/// </summary>
public sealed class CertificateChainInfo
{
    #region Public Properties

    /// <summary>
    /// Result of reading the certificate chain.
    /// </summary>
    public CertLookupStatus Status { get; set; }

    /// <summary>
    /// Error message when the chain could not be built fully. Empty when there is no error.
    /// </summary>
    public string ErrorDetail { get; set; } = string.Empty;

    /// <summary>
    /// The leaf certificate of the chain.
    /// </summary>
    public CertificateMetadata? LeafCertificate { get; set; }

    /// <summary>
    /// The middle certificates of the chain, from the leaf up to the root.
    /// </summary>
    public List<CertificateMetadata> IntermediateCertificates { get; set; } = new();

    /// <summary>
    /// The root certificate of the chain.
    /// </summary>
    public CertificateMetadata? RootCertificate { get; set; }

    #endregion
}
