// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Default store location/name for the Windows Certificate Store
/// adapter, overridable per call via CertificateSelector.
/// </summary>
public sealed class WindowsCertificateStoreConfiguration
{
    #region Public Properties

    /// <summary>
    /// Windows certificate store location that holds the certificates.
    /// </summary>
    public WindowsStoreLocation Location { get; set; } =
        WindowsStoreLocation.LocalMachine;

    /// <summary>
    /// Name of the Windows certificate store that holds the certificates.
    /// </summary>
    public WindowsStoreName StoreName { get; set; } =
        WindowsStoreName.My;

    #endregion
}
