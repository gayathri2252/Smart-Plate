// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Models.Enums;

namespace DashboardCH.Models;

/// <summary>
/// Outcome of a single-certificate retrieval, reported via Status
/// rather than by throwing. Metadata is set only when Status is Found.
/// </summary>
public sealed class CertificateResult
{
    #region Public Properties

    /// <summary>
    /// Result of the certificate lookup.
    /// </summary>
    public CertLookupStatus Status { get; set; }

    /// <summary>
    /// Details of the certificate that was found. Null when no certificate was found.
    /// </summary>
    public CertificateMetadata? Metadata { get; set; }

    /// <summary>
    /// Error message when the lookup failed. Empty when there is no error.
    /// </summary>
    public string ErrorDetail { get; set; } = string.Empty;

    #endregion
}
