// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Exports a CSR from TPM-backed key material (RS_26).
/// </summary>
public interface ITpmCsrExportService
{
    /// <summary>
    /// Exports the certificate signing request made with the TPM key.
    /// </summary>
    Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default);
}
