// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Interfaces;

/// <summary>
/// Writes renewal CSR PEM for MCC pickup (RS_26).
/// </summary>
public interface IMccRenewalExportWriter
{
    /// <summary>
    /// Writes the certificate signing request to the MCC export folder.
    /// </summary>
    void ExportCsrPem(Guid keyId, string csrPem);
}
