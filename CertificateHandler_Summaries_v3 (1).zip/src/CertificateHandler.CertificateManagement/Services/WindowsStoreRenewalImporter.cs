// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Adds the signed renewal certificate to the Windows <c>Personal</c> store (RS_06).
/// </summary>
public sealed class WindowsStoreRenewalImporter : ICertificateStoreRenewalImporter
{
    /// <summary>
    /// Adds the renewed certificate to the personal Windows certificate store.
    /// Does nothing when the store install is turned off for testing.
    /// </summary>
    public Task ImportSignedCertificateAsync(X509Certificate2 certificate, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (IsStoreInstallSkipped())
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                "Renewal store install skipped (CH_SKIP_WINDOWS_STORE_INSTALL).");
            return Task.CompletedTask;
        }

        if (!OperatingSystem.IsWindows())
        {
            throw new InvalidOperationException("Windows Certificate Store install is only supported on Windows.");
        }

        StoreLocation location = ResolveStoreLocation();
        StoreName storeName = StoreName.My;

        using var store = new X509Store(storeName, location);
        store.Open(OpenFlags.ReadWrite);
        store.Add(certificate);
        CertificateHandlerLogger.Success(
            MessageIdGenerator.Next(),
            "Renewed certificate installed to {0}\\{1}.",
            location,
            storeName);
        return Task.CompletedTask;
    }

    /// <summary>
    /// Checks if the store install is turned off for testing.
    /// </summary>
    private static bool IsStoreInstallSkipped() =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SKIP_WINDOWS_STORE_INSTALL");

    /// <summary>
    /// Gets the store location for the renewed certificate from the environment.
    /// </summary>
    private static StoreLocation ResolveStoreLocation()
    {
        string? raw = Environment.GetEnvironmentVariable("CH_RENEWAL_STORE_LOCATION");
        if (string.Equals(raw, "CurrentUser", StringComparison.OrdinalIgnoreCase))
        {
            return StoreLocation.CurrentUser;
        }

        return StoreLocation.LocalMachine;
    }
}
