﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using DashboardCH.Interfaces;
using DashboardCH.Models.Enums;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using CertificateHandler.CertificateManagement.Constants;

namespace DashboardCH.Services;

/// <summary>
/// Maps a CertificateStorageMedium value to its adapter implementation.
/// </summary>
public sealed class CertificateStoreAdapterFactory
    : ICertificateStoreAdapterFactory
{
    #region Public Methods

    /// <summary>
    /// Creates the certificate store reader for the given storage type.
    /// </summary>
    public ICertificateStoreAdapter Create(CertificateStorageMedium backend)
    {
        switch (backend)
        {
            case CertificateStorageMedium.WindowsCertificateStore:
                return new WindowsCertificateStoreAdapter();

            case CertificateStorageMedium.TPM:
                return new TpmCertificateStoreAdapter();

            default:
                CertificateHandlerLogger.Error(MessageIdGenerator.Next(), CertificateManagementLogConstants.UNSUPPORTED_BACKEND, backend.ToString());
                throw new NotSupportedException(
                    $"Unsupported certificate backend: {backend}");
        }
    }

    #endregion
}
