// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Selects hardware or simulated TPM CSR export.
/// </summary>
public static class TpmCsrExportServiceFactory
{
    /// <summary>
    /// Creates the request export service. The test service is used when it is turned on.
    /// </summary>
    public static ITpmCsrExportService Create() =>
        SimulatedTpmCsrExportService.IsEnabled
            ? new SimulatedTpmCsrExportService()
            : new TpmCsrExportService();
}
