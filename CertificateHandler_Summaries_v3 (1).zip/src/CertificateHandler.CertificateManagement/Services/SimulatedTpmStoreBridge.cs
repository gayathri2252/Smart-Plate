// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Dev bridge: treat TPM store as Windows store when hardware TPM is unavailable (RS_04).
/// </summary>
public static class SimulatedTpmStoreBridge
{
    /// <summary>
    /// True when the test TPM store is turned on.
    /// </summary>
    public static bool IsEnabled =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SIMULATE_TPM");
}
