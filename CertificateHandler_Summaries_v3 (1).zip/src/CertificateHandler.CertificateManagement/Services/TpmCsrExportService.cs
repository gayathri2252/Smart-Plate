// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Fails closed until TPM CSR export is integrated on MAXUM hardware.
/// </summary>
public sealed class TpmCsrExportService : ITpmCsrExportService
{
    /// <summary>
    /// Exports the certificate signing request from the TPM.
    /// This is not built yet, so it always throws.
    /// </summary>
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        _ = keyId;
        cancellationToken.ThrowIfCancellationRequested();
        throw new InvalidOperationException(RequestStatusConstants.TPM_RETRIEVAL_NOT_IMPLEMENTED);
    }
}
