// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace DashboardCH.Options;

/// <summary>
/// Controls CRL/OCSP behavior when building certificate chains (RS_03).
/// </summary>
public sealed class RevocationPolicyOptions
{
    #region Public Properties

    /// <summary>When false, chain building skips revocation (legacy behavior).</summary>
    public bool RevocationCheckEnabled { get; init; } = true;

    /// <summary>When true, unknown revocation status fails chain validation.</summary>
    public bool RevocationHardFail { get; init; } = true;

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads policy from environment variables <c>CH_REVOCATION_CHECK</c> and <c>CH_REVOCATION_HARD_FAIL</c>.
    /// </summary>
    public static RevocationPolicyOptions FromEnvironment()
    {
        bool checkEnabled = !string.Equals(
            Environment.GetEnvironmentVariable("CH_REVOCATION_CHECK"),
            "0",
            StringComparison.Ordinal);

        bool hardFail = !string.Equals(
            Environment.GetEnvironmentVariable("CH_REVOCATION_HARD_FAIL"),
            "0",
            StringComparison.Ordinal);

        return new RevocationPolicyOptions
        {
            RevocationCheckEnabled = checkEnabled,
            RevocationHardFail = hardFail
        };
    }

    #endregion
}
