// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.DeviceTrust.Constants;

/// <summary>
/// Constants (including message texts) for the device trust services, so wording can be changed in one place.
/// </summary>
internal static class DeviceTrustConstants
{
    #region Member Variables

    /// <summary>Logged when a certificate is put on the blacklist after a security failure; the argument is the reason class.</summary>
    public const string THUMBPRINT_BLACK_LISTED = "The certificate was added to the blacklist. Reason: %s.";

    /// <summary>Logged when a certificate with a security failure is already on the blacklist.</summary>
    public const string THUMBPRINT_ALREADY_BLACK_LISTED = "The certificate was already on the blacklist, so nothing was changed.";

    /// <summary>Logged when a certificate cannot be blacklisted because it is not stored in the database.</summary>
    public const string BLACK_LIST_CERTIFICATE_NOT_FOUND = "The certificate could not be blacklisted because it is not known to the Certificate Handler.";

    /// <summary>Logged when writing the blacklist row fails; the argument is the error.</summary>
    public const string BLACK_LIST_FAILED = "The certificate could not be blacklisted because of an error: %s";

    /// <summary>Logged when the blacklist service is called without a validation result.</summary>
    public const string VALIDATION_RESULT_IS_NULL = "No validation result was given, so the blacklist was not changed.";

    /// <summary>Logged when a validation failure, such as an expired certificate, does not put the certificate on the blacklist; the argument is the outcome.</summary>
    public const string VALIDATION_FAILURE_NOT_BLACK_LISTED = "The certificate validation ended with %s. This result does not blacklist a certificate.";

    /// <summary>Logged when a connection is denied because the certificate is blacklisted.</summary>
    public const string CONNECTION_DENIED_BLACK_LISTED = "Connection denied: the certificate is blacklisted.";

    /// <summary>Logged when a connection is denied because the thumbprint is missing or not valid.</summary>
    public const string CONNECTION_DENIED_INVALID_THUMBPRINT = "Connection denied: the certificate thumbprint is missing or not valid.";

    /// <summary>Logged when a connection is denied because the blacklist could not be read; the argument is the error.</summary>
    public const string CONNECTION_DENIED_LOOKUP_FAILED = "Connection denied: the blacklist could not be checked because of an error: %s";

    /// <summary>Logged when the trust engine finds the certificate on the blacklist.</summary>
    public const string TRUST_DECISION_BLACK_LISTED = "The certificate is blacklisted, so the connection is denied.";

    /// <summary>Logged when the trust engine finds the certificate on the whitelist.</summary>
    public const string TRUST_DECISION_WHITELISTED = "The certificate is whitelisted, so it is trusted.";

    /// <summary>Logged when the certificate is on neither list and needs an administrator decision.</summary>
    public const string TRUST_DECISION_UNKNOWN = "The certificate is on neither list, so it is unknown and needs an administrator decision.";

    /// <summary>Logged when the trust engine rejects a missing or malformed thumbprint.</summary>
    public const string TRUST_DECISION_INVALID_THUMBPRINT = "The certificate thumbprint is missing or not valid, so the certificate is rejected.";

    /// <summary>Logged when the trust engine cannot read the whitelist or blacklist; the argument is the error.</summary>
    public const string TRUST_DECISION_LOOKUP_FAILED = "The whitelist or blacklist could not be read, so the certificate is rejected. Error: %s";

    /// <summary>Logged when the configured queue limit is below 1; the arguments are the configured value and the default that is used instead.</summary>
    public const string PENDING_QUEUE_LIMIT_INVALID = "The pending queue limit %s is not valid. It must be 1 or more, so the default of %s is used.";

    /// <summary>Logged when an unknown peer is added to the pending queue; the arguments are the device, the places used and the limit.</summary>
    public const string PENDING_QUEUE_PEER_ADDED = "The unknown peer %s was added to the pending queue (%s of %s places used). It waits for an administrator decision.";

    /// <summary>Logged when an unknown peer already has an open request, so no new request is added; the argument is the device.</summary>
    public const string PENDING_QUEUE_PEER_ALREADY_WAITING = "The unknown peer %s already waits in the pending queue, so no new request was added.";

    /// <summary>Logged when an unknown peer is refused because the pending queue is full; the arguments are the limit and the device.</summary>
    public const string PENDING_QUEUE_FULL = "Pending queue limit exceeded";

    /// <summary>Logged when a certificate request is refused because its details are missing, or its thumbprint is not valid or does not match the validation result.</summary>
    public const string CERTIFICATE_REQUEST_INVALID_REQUEST = "Connection refused: the peer certificate details are missing, or its thumbprint is not valid or does not match the validated certificate.";

    /// <summary>Logged when a certificate request is refused because the certificate failed validation; the arguments are the device and the outcome.</summary>
    public const string CERTIFICATE_REQUEST_VALIDATION_FAILED = "Connection refused: the certificate of peer %s failed validation (%s).";

    /// <summary>Logged when a certificate request is refused because the peer did not prove it holds the private key; the argument is the device.</summary>
    public const string CERTIFICATE_REQUEST_AUTHENTICATION_FAILED = "Connection refused: peer %s did not prove during the connection that it holds the private key of its certificate.";

    /// <summary>Logged when a certificate request is refused because the certificate is blacklisted; the argument is the device.</summary>
    public const string CERTIFICATE_REQUEST_BLACK_LISTED = "Connection refused: the certificate of peer %s is blacklisted.";

    /// <summary>Logged when a certificate request is refused because the trust lists could not be read; the argument is the device.</summary>
    public const string CERTIFICATE_REQUEST_LOOKUP_FAILED = "Connection refused: the trust lists could not be checked for peer %s.";

    /// <summary>Logged when a certificate request is refused because of an unexpected error; the arguments are the device and the error.</summary>
    public const string CERTIFICATE_REQUEST_CHECK_FAILED = "Connection refused: the certificate request of peer %s could not be checked because of an error: %s";

    /// <summary>Logged when a certificate request is allowed because the certificate passed validation and is whitelisted; the argument is the device.</summary>
    public const string CERTIFICATE_REQUEST_ALLOWED = "The certificate of peer %s passed validation and is whitelisted, so the certificate request is allowed.";

    /// <summary>Logged when a certificate that was removed from the blacklist passed validation and authentication again and is allowed; the argument is the device.</summary>
    public const string CERTIFICATE_REQUEST_REVALIDATED_ALLOWED = "The certificate of peer %s was removed from the blacklist before. It passed validation and authentication again and is whitelisted, so the certificate request is allowed.";

    #endregion
}