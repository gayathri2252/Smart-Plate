// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.Json;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Loads whitelist-related audit rows newest-last ordering converted to chronological (RS_09).
/// </summary>
public sealed class WhitelistAuditHistoryService : IWhitelistAuditHistoryService
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// SQL that reads the whitelist audit rows.
    /// </summary>
    private const string QuerySql =
        $"""
        SELECT audit_id, event_type, event_timestamp, actor_identity, request_id, thumbprint_sha256,
               device_id, previous_status, new_status, action_status, reason, details_json
        FROM {DatabaseConstants.SchemaName}.ch_audit_log
        WHERE event_type = 'PEER_WHITELISTED' OR new_status = 'WHITELISTED'
        ORDER BY event_timestamp ASC
        LIMIT @limit
        """;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the whitelist audit history service.
    /// </summary>
    public WhitelistAuditHistoryService(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the whitelist audit history.
    /// </summary>
    public async Task<IReadOnlyList<WhitelistAuditEntry>> GetWhitelistHistoryAsync(
        int maxRows = 500,
        CancellationToken cancellationToken = default)
    {
        if (maxRows < 1)
        {
            maxRows = 500;
        }

        var entries = new List<WhitelistAuditEntry>();
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(QuerySql, connection);
        command.Parameters.AddWithValue("limit", maxRows);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            Guid? requestId = reader.IsDBNull(4) ? null : reader.GetGuid(4);
            if (requestId is null && !reader.IsDBNull(11))
            {
                requestId = TryReadRequestIdFromDetails(reader.GetString(11));
            }

            entries.Add(new WhitelistAuditEntry
            {
                AuditId = reader.GetInt64(0),
                EventType = reader.GetString(1),
                EventTimestamp = reader.GetFieldValue<DateTimeOffset>(2),
                ActorIdentity = reader.GetString(3),
                RequestId = requestId,
                ThumbprintSha256 = reader.IsDBNull(5) ? null : reader.GetString(5),
                DeviceId = reader.IsDBNull(6) ? null : reader.GetGuid(6),
                PreviousStatus = reader.IsDBNull(7) ? null : reader.GetString(7),
                NewStatus = reader.IsDBNull(8) ? null : reader.GetString(8),
                ActionStatus = reader.IsDBNull(9) ? null : reader.GetString(9),
                Reason = reader.IsDBNull(10) ? null : reader.GetString(10)
            });
        }

        return entries;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the request id from the audit details.
    /// </summary>
    private static Guid? TryReadRequestIdFromDetails(string json)
    {
        try
        {
            using JsonDocument doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("RequestId", out JsonElement element)
                && element.ValueKind == JsonValueKind.String
                && Guid.TryParse(element.GetString(), out Guid id))
            {
                return id;
            }
        }
        catch (JsonException)
        {
        }

        return null;
    }

    #endregion
}
