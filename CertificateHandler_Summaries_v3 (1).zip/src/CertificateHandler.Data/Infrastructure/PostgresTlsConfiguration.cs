﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Options;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// Adds the mutual TLS settings from <see cref="DatabaseOptions"/> to the Npgsql data source.
/// It loads the client certificate from the Windows certificate store and validates the server certificate.
/// </summary>
internal static class PostgresTlsConfiguration
{
    #region Public Methods

    /// <summary>
    /// Adds the client certificate and the server certificate validation to the data source builder.
    /// Checks that the CA certificate that issued the client certificate is present in the Root store.
    /// </summary>
    /// <returns>
    /// The client certificate, which must stay alive as long as the data source is used,
    /// so the caller owns it and must dispose it. Null when no client certificate is configured.
    /// </returns>
    public static X509Certificate2? Apply(
        NpgsqlDataSourceBuilder builder,
        DatabaseOptions options,
        StoreLocation storeLocation = StoreLocation.LocalMachine)
    {
        ArgumentNullException.ThrowIfNull(builder);
        ArgumentNullException.ThrowIfNull(options);

        if (!options.UsesClientCertificate)
        {
            return null;
        }

        X509Certificate2 clientCertificate = LoadCertificateByNameOrSubject(
            storeLocation,
            StoreName.My,
            options.ClientCertificateName);

        try
        {
            // The CA must be present in the store, otherwise server validation cannot
            // succeed. It is only checked for, so it is released straight away.
            using X509Certificate2 caCertificate = LoadIssuerCertificate(storeLocation, clientCertificate);

            builder.UseSslClientAuthenticationOptionsCallback(sslOptions => ConfigureSslOptions(sslOptions, clientCertificate));

            return clientCertificate;
        }
        catch
        {
            clientCertificate.Dispose();
            throw;
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Finds a certificate in the given store by friendly name, or else by subject common name.
    /// Throws when no certificate matches.
    /// </summary>
    private static X509Certificate2 LoadCertificateByNameOrSubject(
        StoreLocation storeLocation,
        StoreName storeName,
        string certificateName)
    {
        using var store = new X509Store(storeName, storeLocation);
        store.Open(OpenFlags.ReadOnly);

        // Reading store.Certificates creates a new certificate object for every entry,
        // so everything except the match is disposed below.
        X509Certificate2Collection certificates = store.Certificates;

        X509Certificate2? match = certificates
            .Cast<X509Certificate2>()
            .FirstOrDefault(c => string.Equals(c.FriendlyName, certificateName, StringComparison.OrdinalIgnoreCase))
            ?? certificates
            .Cast<X509Certificate2>()
            .FirstOrDefault(c => c.Subject.Contains($"CN={certificateName}", StringComparison.OrdinalIgnoreCase));

        foreach (X509Certificate2 certificate in certificates.Where(certificate => !ReferenceEquals(certificate, match)))
        {
            certificate.Dispose();
        }

        if (match is null)
        {
            throw new InvalidOperationException(
                $"Certificate with friendly name or subject CN '{certificateName}' was not found in " +
                $"{storeLocation}\\{storeName}. Verify the configured name and that the certificate has " +
                "been imported on this machine.");
        }

        return match;
    }

    /// <summary>
    /// Finds the CA certificate that issued the client certificate in the Root store.
    /// Throws when it is not there.
    /// </summary>
    private static X509Certificate2 LoadIssuerCertificate(
        StoreLocation storeLocation,
        X509Certificate2 clientCertificate)
    {
        using var store = new X509Store(StoreName.Root, storeLocation);
        store.Open(OpenFlags.ReadOnly);

        // Reading store.Certificates creates a new certificate object for every entry,
        // so everything except the match is disposed below.
        X509Certificate2Collection certificates = store.Certificates;

        X509Certificate2? match = certificates
            .Cast<X509Certificate2>()
            .FirstOrDefault(c => c.SubjectName.RawData.AsSpan().SequenceEqual(clientCertificate.IssuerName.RawData));

        foreach (X509Certificate2 certificate in certificates.Where(certificate => !ReferenceEquals(certificate, match)))
        {
            certificate.Dispose();
        }

        if (match is null)
        {
            throw new InvalidOperationException(
                $"The CA certificate '{clientCertificate.Issuer}' that issued the client certificate was not found in " +
                $"{storeLocation}\\{StoreName.Root}. Verify that the CA certificate has been imported on this machine.");
        }

        return match;
    }

    /// <summary>
    /// Accepts the PostgreSQL server certificate only when the TLS policy reports no errors.
    /// Logs the policy errors when validation fails.
    /// </summary>
    private static bool ValidateServerCertificate(
        object sender,
        X509Certificate? certificate,
        X509Chain? chain,
        SslPolicyErrors sslPolicyErrors)
    {
        if (sslPolicyErrors != SslPolicyErrors.None)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "PostgreSQL server certificate validation failed: %s",
                sslPolicyErrors.ToString());
        }

        return sslPolicyErrors == SslPolicyErrors.None;
    }

    /// <summary>
    /// Sets the client certificate and the server certificate validation on the TLS handshake options.
    /// </summary>
    private static void ConfigureSslOptions(SslClientAuthenticationOptions sslOptions, X509Certificate2 clientCertificate)
    {
        sslOptions.ClientCertificates = new X509CertificateCollection { clientCertificate };
        sslOptions.RemoteCertificateValidationCallback = ValidateServerCertificate;
    }

    #endregion
}
