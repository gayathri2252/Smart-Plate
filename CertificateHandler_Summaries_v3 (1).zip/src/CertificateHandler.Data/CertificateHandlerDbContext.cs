// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Configurations;
using CertificateHandler.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace CertificateHandler.Data;

/// <summary>
/// Entity Framework Core context for Certificate Handler PostgreSQL persistence.
/// </summary>
public class CertificateHandlerDbContext : DbContext
{
    #region Constructor

    /// <summary>
    /// Creates the database context.
    /// </summary>
    public CertificateHandlerDbContext(DbContextOptions<CertificateHandlerDbContext> options)
        : base(options)
    {
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// The MAXUM devices.
    /// </summary>
    public DbSet<Device> Devices => Set<Device>();

    /// <summary>
    /// The certificates.
    /// </summary>
    public DbSet<Certificate> Certificates => Set<Certificate>();

    /// <summary>
    /// References to the protected device keys.
    /// </summary>
    public DbSet<SecureKeyReference> SecureKeyReferences => Set<SecureKeyReference>();

    /// <summary>
    /// The whitelist and blacklist entries.
    /// </summary>
    public DbSet<TrustListEntry> TrustListEntries => Set<TrustListEntry>();

    /// <summary>
    /// History of the certificate status changes.
    /// </summary>
    public DbSet<CertificateStatusHistory> CertificateStatusHistory => Set<CertificateStatusHistory>();

    /// <summary>
    /// The pending requests.
    /// </summary>
    public DbSet<PendingRequest> PendingRequests => Set<PendingRequest>();

    /// <summary>
    /// Approvals of the reinstatement requests.
    /// </summary>
    public DbSet<ReinstatementApproval> ReinstatementApprovals => Set<ReinstatementApproval>();

    /// <summary>
    /// Certificate signing and renewal requests.
    /// </summary>
    public DbSet<CsrRenewalRequest> CsrRenewalRequests => Set<CsrRenewalRequest>();

    /// <summary>
    /// Factory provisioning attempts.
    /// </summary>
    public DbSet<FactoryProvisioningAttempt> FactoryProvisioningAttempts => Set<FactoryProvisioningAttempt>();

    /// <summary>
    /// Audit log rows.
    /// </summary>
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    /// <summary>
    /// Bulk operations.
    /// </summary>
    public DbSet<BulkOperation> BulkOperations => Set<BulkOperation>();

    /// <summary>
    /// Items of the bulk operations.
    /// </summary>
    public DbSet<BulkOperationItem> BulkOperationItems => Set<BulkOperationItem>();

    /// <summary>
    /// Trust events.
    /// </summary>
    public DbSet<TrustEvent> TrustEvents => Set<TrustEvent>();

    /// <summary>
    /// Deliveries of the trust events to the subscribers.
    /// </summary>
    public DbSet<TrustEventDelivery> TrustEventDeliveries => Set<TrustEventDelivery>();

    /// <summary>
    /// Notifications sent to the peer devices.
    /// </summary>
    public DbSet<PeerNotification> PeerNotifications => Set<PeerNotification>();

    /// <summary>
    /// Results of the certificate validation steps.
    /// </summary>
    public DbSet<ValidationResult> ValidationResults => Set<ValidationResult>();

    /// <summary>
    /// System settings.
    /// </summary>
    public DbSet<SystemConfig> SystemConfig => Set<SystemConfig>();

    /// <summary>
    /// Schema migrations that are applied.
    /// </summary>
    public DbSet<SchemaMigration> SchemaMigrations => Set<SchemaMigration>();

    /// <summary>
    /// Counts shown on the dashboard.
    /// </summary>
    public DbSet<DashboardCounts> DashboardCounts => Set<DashboardCounts>();

    /// <summary>
    /// Overview of the pending queue.
    /// </summary>
    public DbSet<PendingQueueOverview> PendingQueueOverview => Set<PendingQueueOverview>();

    #endregion

    #region Override Methods

    /// <summary>
    /// Adds the Certificate Handler table settings to the model.
    /// </summary>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyCertificateHandlerConfigurations();
    }

    #endregion
}
