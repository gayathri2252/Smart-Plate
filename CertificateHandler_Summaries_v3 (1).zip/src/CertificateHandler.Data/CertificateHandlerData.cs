// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Options;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Verifies the PostgreSQL connection end to end (including the client
/// certificate and server certificate checks), logging every step to the log driver.
/// </summary>
public static class CertificateHandlerData
{
    #region Public Methods

    /// <summary>
    /// Opens the connection the application really uses and writes each step
    /// to the log driver.
    /// </summary>
    public static async Task<bool> TestConnectionAsync(DatabaseOptions options)
    {
        try
        {
            ArgumentNullException.ThrowIfNull(options);

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                "Opening PostgreSQL connection (TLS=%s, client certificate=%s)",
                options.SslMode.ToString(),
                options.UsesClientCertificate.ToString());

            using CertificateHandlerDataAccess dataAccess = CertificateHandlerDataAccess.Create(options);
            await using var conn = await dataAccess.OpenConnectionAsync();
            CertificateHandlerLogger.Success(
                MessageIdGenerator.Next(),
                options.SslMode
                    ? "TLS communication established successfully"
                    : "Database connection established successfully (TLS disabled)");
            return true;
        }
        catch (InvalidOperationException ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Database configuration or certificate lookup failed: %s",
                ex.Message);
            return false;
        }
        catch (NpgsqlException ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "PostgreSQL connection failed: %s",
                ex.Message);
            return false;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Unexpected PostgreSQL connection failure (%s): %s | Inner: %s",
                ex.GetType().Name,
                ex.Message,
                ex.InnerException?.Message ?? string.Empty);
            return false;
        }
    }

    #endregion
}