﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Data;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Security;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Reads whether a certificate was removed from the blacklist, so a device that was blocked before is
/// checked again in full before it may communicate.
/// </summary>
public sealed class BlackListHistory : IBlackListHistory
{
    #region Member Variables

    /// <summary>
    /// Name of the database schema.
    /// </summary>
    private const string SCHEMA = DatabaseConstants.SchemaName;

    /// <summary>
    /// SQL part that turns the list kind value into the trust list kind type.
    /// </summary>
    private const string KIND_CAST = $"CAST(@{DatabaseConstants.KIND_PARAMETER} AS {SCHEMA}.{DatabaseConstants.TRUST_LIST_KIND_TYPE})";

    /// <summary>
    /// SQL that checks if the certificate was taken off the list and has no active entry now.
    /// </summary>
    private const string WAS_REMOVED_SQL = $"SELECT EXISTS (SELECT 1 FROM {SCHEMA}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND list_kind = {KIND_CAST} " +
        "AND NOT is_active AND deactivated_at IS NOT NULL) " +
        $"AND NOT EXISTS (SELECT 1 FROM {SCHEMA}.ch_trust_list_entry " +
        $"WHERE thumbprint_sha256 = @{DatabaseConstants.THUMBPRINT_PARAMETER} AND list_kind = {KIND_CAST} AND is_active)";

    /// <summary>
    /// Database context used to run the queries.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the lookup on top of the given database context. The context must not be null.
    /// </summary>
    /// <param name="dbContext">Database context whose connection is used for the lookup.</param>
    /// <exception cref="ArgumentNullException">Thrown when the context is null.</exception>
    public BlackListHistory(CertificateHandlerDbContext dbContext)
    {
        if (dbContext is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.BLACK_LIST_HISTORY_CONTEXT_IS_NULL);
            throw new ArgumentNullException(nameof(dbContext));
        }

        _dbContext = dbContext;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Determines whether the specified certificate thumbprint was previously
    /// removed from the blacklist and does not currently have an active blacklist entry.
    /// Every step is logged: the start, a server that cannot be reached, a failed query and the result.
    /// </summary>
    /// <param name="thumbprintSha256">The SHA-256 certificate thumbprint.</param>
    /// <param name="cancellationToken">Token used to cancel the operation.</param>
    public async Task<bool> WasRemovedFromBlackListAsync(string thumbprintSha256, CancellationToken cancellationToken = default)
    {
        if (!ThumbprintNormalizer.TryNormalizeRequired(thumbprintSha256, out string thumbprint))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.BLACK_LIST_HISTORY_INVALID_THUMBPRINT);
            throw new ArgumentException(DatabaseConstants.BLACK_LIST_HISTORY_INVALID_THUMBPRINT, nameof(thumbprintSha256));
        }

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), DatabaseConstants.BLACK_LIST_HISTORY_CHECK_STARTED, thumbprint);

        var connection = (NpgsqlConnection)_dbContext.Database.GetDbConnection();

        bool isConnectionClosed = connection.State is not ConnectionState.Open;
        if (isConnectionClosed)
        {
            await OpenConnectionAsync(connection, cancellationToken);
        }

        try
        {
            await using var command = new NpgsqlCommand(WAS_REMOVED_SQL, connection);
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.THUMBPRINT_PARAMETER, thumbprint));
            command.Parameters.Add(new NpgsqlParameter(DatabaseConstants.KIND_PARAMETER, PostgresEnumNames.ToPgName(TrustListKind.Blacklist)));

            object? result = await command.ExecuteScalarAsync(cancellationToken);
            bool wasRemoved = result is true;

            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                wasRemoved ? DatabaseConstants.BLACK_LIST_HISTORY_REMOVED : DatabaseConstants.BLACK_LIST_HISTORY_NOT_REMOVED,
                thumbprint);

            return wasRemoved;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.BLACK_LIST_HISTORY_QUERY_FAILED, thumbprint, ex.Message);
            throw;
        }
        finally
        {
            if (isConnectionClosed)
            {
                await connection.CloseAsync();
            }
        }
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Opens the connection to the database server. When the server cannot be reached, the reason is
    /// logged and the error is passed on.
    /// </summary>
    /// <param name="connection">Connection to open.</param>
    /// <param name="cancellationToken">Token used to cancel the operation.</param>
    private static async Task OpenConnectionAsync(NpgsqlConnection connection, CancellationToken cancellationToken)
    {
        try
        {
            await DatabaseServerConnection.OpenAsync(connection, cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.BLACK_LIST_HISTORY_SERVER_UNREACHABLE, ex.Message);
            throw;
        }
    }

    #endregion
}
