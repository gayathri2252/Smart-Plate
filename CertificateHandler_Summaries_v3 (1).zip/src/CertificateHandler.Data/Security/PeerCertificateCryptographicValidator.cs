// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Constants;
using CertificateHandler.Shared.Security;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Validates a presented peer certificate (chain, time, revocation) without local store lookup (RS_03).
/// </summary>
public static class PeerCertificateCryptographicValidator
{
    /// <summary>
    /// Checks that the certificate sent by the peer is valid.
    /// Checks the validity dates, the subject, the key size and the certificate chain.
    /// </summary>
    public static void ValidateOrThrow(byte[]? presentedCertificateDer)
    {
        if (presentedCertificateDer is null || presentedCertificateDer.Length == 0)
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.PRESENTED_CERTIFICATE_REQUIRED);
        }

        using var certificate = new X509Certificate2(presentedCertificateDer);
        DateTimeOffset now = DateTimeOffset.UtcNow;

        if (now < certificate.NotBefore.ToUniversalTime())
        {
            throw new InvalidOperationException("Certificate is not yet valid.");
        }

        if (now > certificate.NotAfter.ToUniversalTime())
        {
            throw new InvalidOperationException(OnboardingApprovalConstants.CERTIFICATE_EXPIRED);
        }

        if (string.IsNullOrWhiteSpace(certificate.Subject))
        {
            throw new InvalidOperationException("Certificate subject is missing.");
        }

        try
        {
            CertificatePublicKeyStrengthPolicy.ValidateOrThrow(certificate);
        }
        catch (ArgumentException ex)
        {
            throw new InvalidOperationException(ex.Message, ex);
        }

        bool checkRevocation = !string.Equals(
            Environment.GetEnvironmentVariable("CH_REVOCATION_CHECK"),
            "0",
            StringComparison.Ordinal);
        bool hardFailRevocation = !string.Equals(
            Environment.GetEnvironmentVariable("CH_REVOCATION_HARD_FAIL"),
            "0",
            StringComparison.Ordinal);

        using var chain = new X509Chain();
        chain.ChainPolicy.RevocationMode = checkRevocation ? X509RevocationMode.Online : X509RevocationMode.NoCheck;
        if (checkRevocation && !hardFailRevocation)
        {
            chain.ChainPolicy.VerificationFlags |= X509VerificationFlags.IgnoreCertificateAuthorityRevocationUnknown;
        }

        if (string.Equals(
                Environment.GetEnvironmentVariable("CH_PEER_ALLOW_SELF_SIGNED"),
                "1",
                StringComparison.Ordinal))
        {
            chain.ChainPolicy.VerificationFlags |= X509VerificationFlags.AllowUnknownCertificateAuthority;
        }

        if (!chain.Build(certificate))
        {
            X509ChainStatusFlags flags = chain.ChainStatus.Aggregate(
                X509ChainStatusFlags.NoError,
                (current, status) => current | status.Status);

            if ((flags & X509ChainStatusFlags.Revoked) != 0)
            {
                throw new InvalidOperationException("Certificate is revoked.");
            }

            throw new InvalidOperationException("Certificate chain validation failed.");
        }
    }
}
