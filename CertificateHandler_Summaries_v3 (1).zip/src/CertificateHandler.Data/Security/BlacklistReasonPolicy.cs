// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Security;

/// <summary>
/// Enforces mandatory blacklist reason quality (RS_12).
/// </summary>
public static class BlacklistReasonPolicy
{
    /// <summary>
    /// Least number of characters a blacklist reason must have.
    /// </summary>
    public const int MinimumLength = 8;

    /// <summary>
    /// Checks that the blacklist reason is long enough.
    /// </summary>
    public static void ValidateOrThrow(string? reason)
    {
        string trimmed = reason?.Trim() ?? string.Empty;
        if (trimmed.Length < MinimumLength)
        {
            throw new ArgumentException($"Blacklist reason must be at least {MinimumLength} characters.", nameof(reason));
        }
    }
}
