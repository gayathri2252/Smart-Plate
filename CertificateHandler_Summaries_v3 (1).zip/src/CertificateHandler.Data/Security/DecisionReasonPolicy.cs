// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Security;

/// <summary>
/// Enforces mandatory reject/ decision reasons (RS_19).
/// </summary>
public static class DecisionReasonPolicy
{
    /// <summary>
    /// Least number of characters a decision reason must have.
    /// </summary>
    public const int MinimumLength = BlacklistReasonPolicy.MinimumLength;

    /// <summary>
    /// Checks that the decision reason is long enough.
    /// </summary>
    public static void ValidateOrThrow(string? reason)
    {
        string trimmed = reason?.Trim() ?? string.Empty;
        if (trimmed.Length < MinimumLength)
        {
            throw new ArgumentException($"Decision reason must be at least {MinimumLength} characters.", nameof(reason));
        }
    }
}
