// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Text;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Creates the random password of the database user on the first run and keeps only the sealed bytes in a file.
/// The password is unsealed again on every start, so it works only on the computer that sealed it.
/// </summary>
public sealed class DatabasePasswordProvider
{
    #region Member Variables

    /// <summary>
    /// Size of a new password, in bytes.
    /// </summary>
    private const int PASSWORD_SIZE_BYTES = 32;

    /// <summary>
    /// End of the name of the temporary file used while the password file is written.
    /// </summary>
    private const string TEMPORARY_FILE_SUFFIX = ".tmp";

    /// <summary>
    /// Path of the file that holds the protected password.
    /// </summary>
    private readonly string _passwordFilePath;

    /// <summary>
    /// Protects and unprotects the password.
    /// </summary>
    private readonly IKeyProtector _keyProtector;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the provider for the password file path and the protector that seals the password.
    /// Throws when the path is empty or the protector is null.
    /// </summary>
    public DatabasePasswordProvider(string passwordFilePath, IKeyProtector keyProtector)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(passwordFilePath);
        ArgumentNullException.ThrowIfNull(keyProtector);

        _passwordFilePath = passwordFilePath;
        _keyProtector = keyProtector;
    }

    #endregion

    #region Public Properties

    /// <summary>Full path of the sealed password file.</summary>
    public string PasswordFilePath => _passwordFilePath;

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns the unsealed password. Creates and seals a new random password when no file exists yet
    /// or when the file cannot be unsealed on this computer (a new password is then set on the database user).
    /// Throws DatabaseSetupException with a message for the user when the file cannot be read or written.
    /// </summary>
    public string GetOrCreatePassword()
    {
        if (!File.Exists(_passwordFilePath))
        {
            return CreatePassword();
        }

        string? password = TryUnsealPassword();
        return password ?? CreatePassword();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Reads the file and unseals the password. Returns null when the content cannot be unsealed here
    /// or is empty, for example when the file was copied from another computer.
    /// </summary>
    private string? TryUnsealPassword()
    {
        try
        {
            byte[] sealedPassword = File.ReadAllBytes(_passwordFilePath);
            string password = Encoding.UTF8.GetString(_keyProtector.Unprotect(sealedPassword));
            if (!string.IsNullOrWhiteSpace(password))
            {
                return password;
            }

            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_UNREADABLE, _passwordFilePath, DatabaseConstants.DB_SETUP_FILE_EMPTY);
            return null;
        }
        catch (CryptographicException ex)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_UNREADABLE, _passwordFilePath, ex.Message);
            return null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_READ_FAILED, _passwordFilePath, ex.Message);
            throw new DatabaseSetupException(DatabaseConstants.DB_SETUP_PASSWORD_READ_MESSAGE, ex);
        }
    }

    /// <summary>
    /// Generates a random password, seals it and writes only the sealed bytes to the file.
    /// The file is written under a temporary name first, so a failed write never leaves a half file.
    /// </summary>
    private string CreatePassword()
    {
        string password = GeneratePassword();
        string temporaryPath = _passwordFilePath + TEMPORARY_FILE_SUFFIX;

        try
        {
            byte[] sealedPassword = _keyProtector.Protect(Encoding.UTF8.GetBytes(password));
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(_passwordFilePath))!);
            File.WriteAllBytes(temporaryPath, sealedPassword);
            File.Move(temporaryPath, _passwordFilePath, overwrite: true);
        }
        catch (Exception ex) when (ex is CryptographicException or IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_CREATE_FAILED, _passwordFilePath, ex.Message);
            throw new DatabaseSetupException(DatabaseConstants.DB_SETUP_PASSWORD_CREATE_MESSAGE, ex);
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), DatabaseConstants.DB_SETUP_PASSWORD_CREATED, _passwordFilePath);
        return password;
    }

    /// <summary>
    /// Returns 32 random bytes as text that is safe in a connection string (letters, digits, '-' and '_').
    /// </summary>
    private static string GeneratePassword()
    {
        return Convert.ToBase64String(RandomNumberGenerator.GetBytes(PASSWORD_SIZE_BYTES))
            .Replace('+', '-')
            .Replace('/', '_')
            .TrimEnd('=');
    }

    #endregion
}
