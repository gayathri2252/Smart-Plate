// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Principal;

namespace CertificateHandler.Data.Security;

/// <summary>
/// Checks local Windows group membership for the current interactive user.
/// </summary>
public static class WindowsAdministratorMembership
{
    /// <summary>
    /// Checks if the current Windows user is in the group.
    /// </summary>
    public static bool IsCurrentUserInGroup(string groupName)
    {
        if (!OperatingSystem.IsWindows() || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        try
        {
            using WindowsIdentity identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(groupName.Trim());
        }
        catch (Exception)
        {
            return false;
        }
    }
}
