// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Text;

namespace CertificateHandler.Data.Security;

/// <summary>
/// DPAPI (LocalMachine) protection for the database password — PostgreSQL equivalent to SQLCipher key sealing (design §3.3).
/// </summary>
public static class DatabasePasswordProtector
{
    /// <summary>
    /// Name of the environment variable that holds the protected database password.
    /// </summary>
    public const string ProtectedPasswordEnvironmentVariable = "CH_DB_PASSWORD_PROTECTED";

    /// <summary>
    /// Protects the password with DPAPI for the local machine.
    /// </summary>
    public static string ProtectToBase64(string plaintext)
    {
        ArgumentException.ThrowIfNullOrEmpty(plaintext);

        if (!OperatingSystem.IsWindows())
        {
            throw new PlatformNotSupportedException("DPAPI password protection is only supported on Windows.");
        }

        byte[] encrypted = ProtectedData.Protect(
            Encoding.UTF8.GetBytes(plaintext),
            optionalEntropy: null,
            DataProtectionScope.LocalMachine);

        return Convert.ToBase64String(encrypted);
    }

    /// <summary>
    /// Unprotects a password that was protected with DPAPI.
    /// Returns false when the text is empty, not running on Windows, or the password cannot be read.
    /// </summary>
    public static bool TryUnprotectFromBase64(string? protectedBase64, out string plaintext)
    {
        plaintext = string.Empty;

        if (string.IsNullOrWhiteSpace(protectedBase64))
        {
            return false;
        }

        if (!OperatingSystem.IsWindows())
        {
            return false;
        }

        try
        {
            byte[] encrypted = Convert.FromBase64String(protectedBase64.Trim());
            byte[] decrypted = ProtectedData.Unprotect(
                encrypted,
                optionalEntropy: null,
                DataProtectionScope.LocalMachine);
            plaintext = Encoding.UTF8.GetString(decrypted);
            return !string.IsNullOrEmpty(plaintext);
        }
        catch (CryptographicException)
        {
            return false;
        }
        catch (FormatException)
        {
            return false;
        }
    }
}
