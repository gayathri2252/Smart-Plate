// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Steps of the reinstatement that needs two approvals.
/// </summary>
public interface IReinstatementWorkflowService
{
    /// <summary>
    /// Creates a pending reinstatement request for the certificate.
    /// </summary>
    Task<Guid> RequestReinstatementAsync(string thumbprintSha256, string requesterIdentity, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves an approval or a rejection of the reinstatement request.
    /// </summary>
    Task RecordApprovalAsync(Guid requestId, string approverIdentity, bool approved, string? comments, CancellationToken cancellationToken = default);

    /// <summary>
    /// Finishes the reinstatement after two approvals.
    /// </summary>
    Task CompleteReinstatementAsync(Guid requestId, string actorIdentity, CancellationToken cancellationToken = default);
}
