// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Approves and rejects reinstatement requests.
/// </summary>
public interface IReinstatementPendingApprovalStore
{
    /// <summary>
    /// Saves an approval of the reinstatement request.
    /// </summary>
    Task ApproveAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves a rejection of the reinstatement request.
    /// </summary>
    Task RejectAsync(PendingRequestDecision decision, CancellationToken cancellationToken = default);
}
