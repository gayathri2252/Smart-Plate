// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Persists certificate validation step outcomes (RS_03).
/// </summary>
public interface IValidationResultWriter
{
    /// <summary>
    /// Saves the result of one certificate validation step.
    /// </summary>
    Task WriteAsync(
        string? thumbprintSha256,
        Guid? deviceId,
        string validationStep,
        bool passed,
        string? failureReason,
        bool timeVerified,
        bool autoBlacklisted,
        CancellationToken cancellationToken = default);
}
