// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Exposes SBC/MIB certificate expiry for MCC (RS_25).
/// </summary>
public interface IGcCertificateStatusService
{
    /// <summary>
    /// Gets the status of the SBC and MIB certificates of the GC for an administrator.
    /// </summary>
    Task<GcCertificateStatusSnapshot> GetSnapshotForAdministratorAsync(
        string? administratorUserName,
        CancellationToken cancellationToken = default);
}
