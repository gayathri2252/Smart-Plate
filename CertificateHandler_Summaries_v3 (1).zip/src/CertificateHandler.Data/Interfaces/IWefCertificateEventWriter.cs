// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Writes certificate expiry alerts that are sent to MCC through WEF.
/// </summary>
public interface IWefCertificateEventWriter
{
    /// <summary>
    /// Writes a certificate expiry alert.
    /// </summary>
    void WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter);
}
