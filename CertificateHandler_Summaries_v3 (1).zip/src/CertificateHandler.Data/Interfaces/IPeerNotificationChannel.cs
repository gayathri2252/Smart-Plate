// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers trust-list notifications to peers (RS_10). Production MAXUM comms replaces this transport.
/// </summary>
public interface IPeerNotificationChannel
{
    /// <summary>
    /// Sends the notification to the requesting device.
    /// </summary>
    Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default);
}
