// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Runs the daily certificate expiry check.
/// </summary>
public interface ICertificateExpiryMonitorService
{
    /// <summary>
    /// Gets the result of the daily expiry check for a certificate.
    /// </summary>
    Task<string> GetDailyCheckStatusAsync(string thumbprint, CancellationToken cancellationToken = default);
}
