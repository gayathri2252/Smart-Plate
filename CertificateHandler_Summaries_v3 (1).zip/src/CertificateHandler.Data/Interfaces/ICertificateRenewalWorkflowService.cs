// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;
using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Steps of the certificate renewal.
/// </summary>
public interface ICertificateRenewalWorkflowService
{
    /// <summary>
    /// Creates a renewal request.
    /// </summary>
    Task<Guid> CreateRenewalRequestAsync(Guid certificateId, Guid keyId, string? csrPem, CancellationToken cancellationToken = default);

    /// <summary>
    /// Starts the renewal of the local certificate with the given role.
    /// </summary>
    Task<Guid> StartLocalRenewalAsync(CertificateRole role, CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the newest renewal request for the given certificate role.
    /// </summary>
    Task<RenewalWorkflowState?> GetLatestRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves the certificate signing request of the renewal request.
    /// </summary>
    Task RecordCsrPemAsync(Guid renewalRequestId, string csrPem, bool markExported, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves the signed certificate and marks the renewal request as imported.
    /// </summary>
    Task RecordImportedAsync(Guid renewalRequestId, string signedCertificatePem, CancellationToken cancellationToken = default);

    /// <summary>
    /// Checks the imported certificate and makes it the active certificate for the role.
    /// </summary>
    Task ActivateRenewalForRoleAsync(CertificateRole role, CancellationToken cancellationToken = default);

    /// <summary>
    /// Marks the renewal request as activated.
    /// </summary>
    Task MarkActivatedAsync(Guid renewalRequestId, CancellationToken cancellationToken = default);
}
