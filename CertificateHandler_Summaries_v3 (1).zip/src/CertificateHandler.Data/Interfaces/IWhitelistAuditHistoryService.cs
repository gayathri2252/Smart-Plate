// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Models;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Reads whitelist audit history in chronological order (RS_09).
/// </summary>
public interface IWhitelistAuditHistoryService
{
    /// <summary>
    /// Reads the whitelist audit history.
    /// </summary>
    Task<IReadOnlyList<WhitelistAuditEntry>> GetWhitelistHistoryAsync(
        int maxRows = 500,
        CancellationToken cancellationToken = default);
}
