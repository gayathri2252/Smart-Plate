// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Delivers pending peer notifications with retry (RS_10).
/// </summary>
public interface IPeerNotificationDeliveryService
{
    /// <summary>
    /// Tries again to send the failed peer notifications.
    /// </summary>
    Task<int> DeliverPendingAsync(CancellationToken cancellationToken = default);
}
