// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Saves the factory provisioning attempts.
/// </summary>
public interface IFactoryProvisioningService
{
    /// <summary>
    /// Saves the start of a factory provisioning attempt.
    /// </summary>
    Task<Guid> StartAttemptAsync(Guid deviceId, string targetRole, CancellationToken cancellationToken = default);

    /// <summary>
    /// Saves the result of a factory provisioning attempt.
    /// </summary>
    Task CompleteAttemptAsync(Guid attemptId, bool success, Guid? certificateId, string? error, CancellationToken cancellationToken = default);
}
