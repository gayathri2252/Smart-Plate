// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

/// <summary>
/// Daily certificate expiry validation summary (RS_25).
/// </summary>
public sealed class CertificateExpiryMonitorService : ICertificateExpiryMonitorService
{
    #region Member Variables

    /// <summary>
    /// Reads the active local certificates.
    /// </summary>
    private readonly ICertificateExpiryReader _reader;

    /// <summary>
    /// Gives the current time.
    /// </summary>
    private readonly TimeProvider _time;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the certificate expiry check service.
    /// </summary>
    public CertificateExpiryMonitorService(ICertificateExpiryReader reader, TimeProvider? time = null)
    {
        _reader = reader ?? throw new ArgumentNullException(nameof(reader));
        _time = time ?? TimeProvider.System;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Gets the result of the daily expiry check for a certificate.
    /// The result is Attention required when the certificate expires within 30 days.
    /// </summary>
    public async Task<string> GetDailyCheckStatusAsync(string thumbprint, CancellationToken cancellationToken = default)
    {
        var certificates = await _reader.ReadActiveLocalCertificatesAsync(cancellationToken);
        bool found = certificates.Any(c =>
            string.Equals(c.Thumbprint, thumbprint, StringComparison.OrdinalIgnoreCase)
            && c.NotAfter <= _time.GetUtcNow().AddDays(30));
        return found ? "Attention required" : "Passed";
    }

    #endregion
}
