// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Entities;

/// <summary>
/// Administrator queue item for onboarding, reinstatement, or whitelist-to-blacklist approval.
/// </summary>
public class PendingRequest
{
    #region Public Properties

    /// <summary>
    /// Id of the request.
    /// </summary>
    public Guid RequestId { get; set; }

    /// <summary>
    /// Type of the request.
    /// </summary>
    public PendingRequestType RequestType { get; set; } = PendingRequestType.PeerOnboarding;

    /// <summary>
    /// Id of the certificate of the request.
    /// </summary>
    public Guid CertificateId { get; set; }

    /// <summary>
    /// Id of the device of the request.
    /// </summary>
    public Guid DeviceId { get; set; }

    /// <summary>
    /// Who asked for it, like the peer device.
    /// </summary>
    public string? RequesterIdentity { get; set; }

    /// <summary>
    /// User or system that created the request.
    /// </summary>
    public string RequestedBy { get; set; } = string.Empty;

    /// <summary>
    /// Current status of the request.
    /// </summary>
    public PendingRequestStatus Status { get; set; } = PendingRequestStatus.Pending;

    /// <summary>
    /// Time when the request was created.
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// Time when the request expires.
    /// </summary>
    public DateTimeOffset ExpiresAt { get; set; }

    /// <summary>
    /// Time when the decision was made. Null while the request is pending.
    /// </summary>
    public DateTimeOffset? DecidedAt { get; set; }

    /// <summary>
    /// Administrator who made the decision.
    /// </summary>
    public string? DecidedBy { get; set; }

    /// <summary>
    /// Reason given for the decision.
    /// </summary>
    public string? DecisionReason { get; set; }

    /// <summary>
    /// Id of the connection whose TLS handshake waits for the decision.
    /// </summary>
    public Guid? ConnectionCorrelationId { get; set; }

    /// <summary>
    /// Certificate of the request.
    /// </summary>
    public Certificate Certificate { get; set; } = null!;

    /// <summary>
    /// Device of the request.
    /// </summary>
    public Device Device { get; set; } = null!;

    /// <summary>
    /// Approvals saved for the reinstatement request.
    /// </summary>
    public ICollection<ReinstatementApproval> ReinstatementApprovals { get; set; } =
        new List<ReinstatementApproval>();

    #endregion
}
