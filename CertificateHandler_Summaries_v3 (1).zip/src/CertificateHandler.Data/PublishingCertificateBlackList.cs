﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Data.Models;
using CertificateHandler.Data.Security;
using BlackListOutcome = CertificateHandler.Data.Models.CertificateBlackList;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Wraps the blacklist so that every saved change is published afterwards. The inner call saves and
/// commits its own transaction first. The publish runs after that, as a separate step, so a publish
/// failure cannot roll the trust row back. The inner response is always returned unchanged.
/// </summary>
public sealed class PublishingCertificateBlackList : ICertificateBlackList
{
    #region Private Fields

    /// <summary>
    /// The blacklist that saves the changes.
    /// </summary>
    private readonly ICertificateBlackList _inner;

    /// <summary>
    /// Sends the trust updates after the changes are saved.
    /// </summary>
    private readonly ITrustUpdatePublishService _publishService;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the decorator. Neither argument may be null.
    /// </summary>
    public PublishingCertificateBlackList(ICertificateBlackList inner, ITrustUpdatePublishService publishService)
    {
        if (inner is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.INNER_BLACKLIST_IS_NULL);
            throw new ArgumentNullException(nameof(inner));
        }
        if (publishService is null)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), TrustPublishConstants.PUBLISH_SERVICE_IS_NULL);
            throw new ArgumentNullException(nameof(publishService));
        }
        _inner = inner;
        _publishService = publishService;
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Adds or reactivates a blacklist entry and publishes the resulting trust update
    /// after the blacklist change has been committed.
    /// </summary>
    /// <param name="request">
    /// Blacklist request containing the certificate thumbprint and reason.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the operation.
    /// </param>
    /// <returns>
    /// The blacklist operation result returned by the inner implementation.
    /// </returns>
    public async Task<BlackListResponse> BlackListAsync(BlackListRequest request, CancellationToken cancellationToken = default)
    {
        BlackListResponse response = await _inner.BlackListAsync(request, cancellationToken);
        if (response.Outcome is not (BlackListOutcome.Added or BlackListOutcome.Reactivated))
        {
            return response;
        }
        await _publishService.PublishAsync(new TrustUpdate
        {
            ThumbprintSha256 = ThumbprintNormalizer.NormalizeRequired(request.ThumbprintSha256),
            CertificateId = response.CertificateId,
            Change = response.Outcome.ToString(),
            Reason = request.Reason?.Trim() ?? string.Empty,
            SavedAt = DateTimeOffset.UtcNow
        }, cancellationToken);

        return response;
    }

    /// <summary>
    /// Determines whether the specified certificate thumbprint is currently blacklisted.
    /// </summary>
    /// <param name="thumbprintSha256">
    /// SHA-256 thumbprint of the certificate.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the operation.
    /// </param>
    /// <returns>
    /// True when the certificate is blacklisted; otherwise false.
    /// </returns>
    public Task<bool> IsBlackListedAsync(string thumbprintSha256, CancellationToken cancellationToken = default)
        => _inner.IsBlackListedAsync(thumbprintSha256, cancellationToken);

    #endregion
}
