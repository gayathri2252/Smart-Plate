﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text.RegularExpressions;
using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Security;

namespace CertificateHandler.Data.Options;

/// <summary>
/// Connection and security settings for the Certificate Handler PostgreSQL database.
/// </summary>
public sealed partial class DatabaseOptions
{
    #region Member Variables

    /// <summary>
    /// Name of the settings section for the database.
    /// </summary>
    public const string SectionName = "CertificateHandler:Database";

    #endregion

    #region Public Properties

    /// <summary>
    /// Host name of the database server.
    /// </summary>
    public string Host { get; set; } = "localhost";

    /// <summary>
    /// Port of the database server.
    /// </summary>
    public int Port { get; set; } = 5432;

    /// <summary>
    /// Name of the product database. It is fixed and cannot be changed.
    /// </summary>
    public static string Database => DatabaseConstants.DatabaseName;

    /// <summary>
    /// Database user of the application. The application creates it and sets its password.
    /// </summary>
    public string Username { get; set; } = DatabaseConstants.DEFAULT_APPLICATION_USERNAME;

    /// <summary>
    /// PostgreSQL administrator account used only to create or repair the database.
    /// Its password comes from the environment variable CH_DB_ADMIN_PASSWORD.
    /// </summary>
    public string AdminUsername { get; set; } = DatabaseConstants.DEFAULT_ADMIN_USERNAME;

    /// <summary>
    /// Folder of the sealed password of the database user. Leave empty to use the default folder
    /// under the common application data folder.
    /// </summary>
    public string SecretDirectoryPath { get; set; } = string.Empty;

    /// <summary>
    /// Plain password fallback (discouraged on device). Prefer <see cref="DatabaseConstants.PasswordEnvironmentVariable"/>
    /// or DPAPI-protected <see cref="DatabasePasswordProtector.ProtectedPasswordEnvironmentVariable"/>.
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// Optional DPAPI-protected password (base64). Prefer the environment variable over this property.
    /// </summary>
    public string ProtectedPassword { get; set; } = string.Empty;

    /// <summary>
    /// True when TLS is used for the database connection.
    /// </summary>
    public bool SslMode { get; set; }

    /// <summary>
    /// When true, only localhost / loopback hosts are permitted (default for IoT).
    /// </summary>
    public bool RequireLocalHost { get; set; } = true;

    /// <summary>
    /// When true, startup skips database creation and schema apply (tests / offline harness).
    /// </summary>
    public bool SkipBootstrap { get; set; }

    /// <summary>
    /// Friendly name or subject CN of the client certificate used for mutual TLS.
    /// Leave empty to connect without a client certificate.
    /// </summary>
    public string ClientCertificateName { get; set; } = string.Empty;

    /// <summary>
    /// True when a client certificate is configured, so the connection uses mutual TLS.
    /// </summary>
    public bool UsesClientCertificate => !string.IsNullOrWhiteSpace(ClientCertificateName);

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks the port, user name, host, SSL mode and client certificate setting.
    /// Throws InvalidOperationException when a value is not allowed.
    /// </summary>
    public void Validate()
    {
        if (Port is < 1 or > 65535)
        {
            throw new InvalidOperationException("Database port is out of range.");
        }

        if (!UsernamePattern().IsMatch(Username))
        {
            throw new InvalidOperationException("Database username contains invalid characters.");
        }

        if (!UsernamePattern().IsMatch(AdminUsername ?? string.Empty))
        {
            throw new InvalidOperationException("Database administrator username contains invalid characters.");
        }

        if (RequireLocalHost && !IsLocalHost(Host))
        {
            throw new InvalidOperationException(
                "Database host must be localhost unless RequireLocalHost is disabled.");
        }

        if (!SslMode && !IsLocalHost(Host))
        {
            throw new InvalidOperationException("Non-local database connections require SslMode.");
        }
        if (UsesClientCertificate && !SslMode)
        {
            throw new InvalidOperationException("A client certificate requires SslMode to be enabled.");
        }
    }

    /// <summary>
    /// Returns the folder of the sealed password, or the default folder when none is configured.
    /// </summary>
    public string ResolveSecretDirectory()
    {
        if (!string.IsNullOrWhiteSpace(SecretDirectoryPath))
        {
            return SecretDirectoryPath;
        }

        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "Valmet",
            "CertificateHandler",
            "Database");
    }

    /// <summary>
    /// Builds a single-use connection string (no pooling) for the given database, user and password.
    /// Used to set up the database with the administrator account.
    /// </summary>
    public string BuildSetupConnectionString(string database, string username, string password)
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder(CreateConnectionString(database, username, password))
        {
            Pooling = false
        };
        return builder.ConnectionString;
    }

    /// <summary>
    /// Builds the application connection string from these options.
    /// </summary>
    public string BuildConnectionString()
    {
        return CreateConnectionString(Database, Username, ResolvePasswordFromEnvironmentOrConfig());
    }

    /// <summary>
    /// Builds the administrator connection string used for database bootstrap.
    /// </summary>
    public string BuildAdminConnectionString()
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder(BuildConnectionString())
        {
            Database = DatabaseConstants.AdminDatabaseName
        };
        return builder.ConnectionString;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Builds a connection string for the given database, user and password with the settings of these options.
    /// </summary>
    private string CreateConnectionString(string database, string username, string password)
    {
        var builder = new Npgsql.NpgsqlConnectionStringBuilder
        {
            Host = Host,
            Port = Port,
            Database = database,
            Username = username,
            Password = password,
            IncludeErrorDetail = false,
            MaxPoolSize = DatabaseConstants.MaxPoolSize,
            Timeout = DatabaseConstants.ConnectionTimeoutSeconds,
            CommandTimeout = DatabaseConstants.CommandTimeoutSeconds,
            Options = $"-c search_path={DatabaseConstants.SchemaName},public"
        };

        builder.SslMode = SslMode ? Npgsql.SslMode.Require : Npgsql.SslMode.Disable;

        return builder.ConnectionString;
    }

    /// <summary>
    /// Returns the password from the CH_DB_PASSWORD environment variable.
    /// Uses the configured Password when the variable is not set.
    /// </summary>
    private string ResolvePasswordFromEnvironmentOrConfig()
    {
        string? plain = Environment.GetEnvironmentVariable(DatabaseConstants.PasswordEnvironmentVariable);
        if (!string.IsNullOrEmpty(plain))
        {
            return plain;
        }

        string? protectedEnv = Environment.GetEnvironmentVariable(DatabasePasswordProtector.ProtectedPasswordEnvironmentVariable);
        if (DatabasePasswordProtector.TryUnprotectFromBase64(protectedEnv, out string fromEnv))
        {
            return fromEnv;
        }

        if (DatabasePasswordProtector.TryUnprotectFromBase64(ProtectedPassword, out string fromConfig))
        {
            return fromConfig;
        }

        return Password;
    }

    /// <summary>
    /// Returns true when the host is localhost, 127.0.0.1 or ::1.
    /// </summary>
    private static bool IsLocalHost(string host)
    {
        if (string.IsNullOrWhiteSpace(host))
        {
            return false;
        }

        return host.Equals("localhost", StringComparison.OrdinalIgnoreCase)
            || host == "127.0.0.1"
            || host == "::1";
    }

    /// <summary>
    /// Pattern that a valid database user name must match.
    /// </summary>
    [GeneratedRegex("^[a-zA-Z_][a-zA-Z0-9_.$-]{0,62}$", RegexOptions.CultureInvariant)]
    private static partial Regex UsernamePattern();

    #endregion
}