// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Options;

/// <summary>
/// Where the encrypted local trust store database and its sealed key file are kept.
/// By default both files are in a Valmet folder under the common application data folder of the computer.
/// </summary>
public sealed class TrustStoreOptions
{
    #region Public Properties

    /// <summary>Name of the configuration section.</summary>
    public const string SectionName = "CertificateHandler:TrustStore";

    /// <summary>File name of the encrypted database.</summary>
    public const string DATABASE_FILE_NAME = "trust-store.db";

    /// <summary>File name of the sealed database key.</summary>
    public const string KEY_FILE_NAME = "trust-store.key";

    /// <summary>
    /// Folder of the two files. Leave empty to use the default folder under the common application data folder.
    /// </summary>
    public string DirectoryPath { get; set; } = string.Empty;

    /// <summary>
    /// When true (default), the trust store folder is created for administrators, the system and the running
    /// account only, so other users of the computer cannot read the database or the sealed key.
    /// </summary>
    public bool RestrictFolderAccess { get; set; } = true;

    /// <summary>
    /// Extra Windows accounts or groups (for example DOMAIN\Group) that may change the files, when
    /// other users than the one that created the folder must run Certificate Handler.
    /// </summary>
    public List<string> AdditionalAccounts { get; set; } = new();

    /// <summary>Full path of the encrypted database file.</summary>
    public string DatabasePath => Path.Combine(ResolveDirectory(), DATABASE_FILE_NAME);

    /// <summary>Full path of the sealed key file.</summary>
    public string KeyFilePath => Path.Combine(ResolveDirectory(), KEY_FILE_NAME);

    #endregion

    #region Member Variables

    /// <summary>
    /// Name of the company folder.
    /// </summary>
    private const string COMPANY_FOLDER = "Valmet";

    /// <summary>
    /// Name of the app folder.
    /// </summary>
    private const string APPLICATION_FOLDER = "CertificateHandler";

    /// <summary>
    /// Name of the trust store folder.
    /// </summary>
    private const string TRUST_STORE_FOLDER = "TrustStore";

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns the configured folder, or the default folder when none is configured.
    /// </summary>
    public string ResolveDirectory()
    {
        if (!string.IsNullOrWhiteSpace(DirectoryPath))
        {
            return DirectoryPath;
        }

        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            COMPANY_FOLDER,
            APPLICATION_FOLDER,
            TRUST_STORE_FOLDER);
    }

    #endregion
}
