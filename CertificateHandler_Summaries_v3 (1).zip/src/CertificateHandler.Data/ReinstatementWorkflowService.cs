// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Reinstatement orchestration (RS_14–17): dual approval then whitelist restore.
/// </summary>
public sealed class ReinstatementWorkflowService : IReinstatementWorkflowService
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the reinstatement service.
    /// </summary>
    public ReinstatementWorkflowService(NpgsqlDataSource dataSource)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Creates a pending reinstatement request for the certificate. The request expires after 24 hours.
    /// </summary>
    public async Task<Guid> RequestReinstatementAsync(string thumbprintSha256, string requesterIdentity, CancellationToken cancellationToken = default)
    {
        Guid requestId = Guid.NewGuid();
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_pending_request " +
            "(request_id, request_type, certificate_id, device_id, requested_by, status, expires_at) " +
            "SELECT @requestId, 'REINSTATEMENT', c.certificate_id, c.device_id, @requester, 'PENDING', now() + interval '24 hours' " +
            $"FROM {DatabaseConstants.SchemaName}.ch_certificate c WHERE c.thumbprint_sha256 = @thumbprint LIMIT 1",
            connection);
        command.Parameters.AddWithValue("requestId", requestId);
        command.Parameters.AddWithValue("requester", requesterIdentity);
        command.Parameters.AddWithValue("thumbprint", thumbprintSha256);
        int rows = await command.ExecuteNonQueryAsync(cancellationToken);
        if (rows == 0)
        {
            throw new InvalidOperationException("Certificate not found for reinstatement.");
        }

        return requestId;
    }

    /// <summary>
    /// Saves an approval or a rejection of the reinstatement request.
    /// </summary>
    public async Task RecordApprovalAsync(Guid requestId, string approverIdentity, bool approved, string? comments, CancellationToken cancellationToken = default)
    {
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var requestorCommand = new NpgsqlCommand(
            $"SELECT requested_by FROM {DatabaseConstants.SchemaName}.ch_pending_request WHERE request_id = @requestId",
            connection);
        requestorCommand.Parameters.AddWithValue("requestId", requestId);
        object? requestor = await requestorCommand.ExecuteScalarAsync(cancellationToken);
        if (requestor is string requestedBy
            && string.Equals(requestedBy.Trim(), approverIdentity.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("The requester cannot approve their own reinstatement request.");
        }

        await using var count = new NpgsqlCommand(
            $"SELECT COUNT(*) FROM {DatabaseConstants.SchemaName}.ch_reinstatement_approval WHERE request_id = @requestId",
            connection);
        count.Parameters.AddWithValue("requestId", requestId);
        int sequence = Convert.ToInt32(await count.ExecuteScalarAsync(cancellationToken)) + 1;
        if (sequence > 2)
        {
            throw new InvalidOperationException("Reinstatement already has two approvals.");
        }

        await using var insert = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_reinstatement_approval " +
            "(request_id, approval_sequence, approver_identity, decision, comments) " +
            "VALUES (@requestId, @seq, @approver, @decision, @comments)",
            connection);
        insert.Parameters.AddWithValue("requestId", requestId);
        insert.Parameters.AddWithValue("seq", (short)sequence);
        insert.Parameters.AddWithValue("approver", approverIdentity);
        insert.Parameters.AddWithValue("decision", approved ? "APPROVED" : "REJECTED");
        insert.Parameters.AddWithValue("comments", (object?)comments ?? DBNull.Value);
        await insert.ExecuteNonQueryAsync(cancellationToken);
    }

    /// <summary>
    /// Finishes the reinstatement after two approvals.
    /// The request is marked as APPROVED, the active list entries of the certificate are turned off, and the certificate is added to the whitelist.
    /// </summary>
    public async Task CompleteReinstatementAsync(Guid requestId, string actorIdentity, CancellationToken cancellationToken = default)
    {
        await using NpgsqlConnection connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var approvals = new NpgsqlCommand(
            $"SELECT COUNT(*) FROM {DatabaseConstants.SchemaName}.ch_reinstatement_approval " +
            "WHERE request_id = @requestId AND decision = 'APPROVED'",
            connection);
        approvals.Parameters.AddWithValue("requestId", requestId);
        int approvedCount = Convert.ToInt32(await approvals.ExecuteScalarAsync(cancellationToken));
        if (approvedCount < 2)
        {
            throw new InvalidOperationException("Two approvals are required before reinstatement.");
        }

        await using var transaction = await connection.BeginTransactionAsync(cancellationToken);
        await using var update = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_pending_request SET status = 'APPROVED', decided_at = now(), decided_by = @actor " +
            "WHERE request_id = @requestId",
            connection,
            transaction);
        update.Parameters.AddWithValue("actor", actorIdentity);
        update.Parameters.AddWithValue("requestId", requestId);
        await update.ExecuteNonQueryAsync(cancellationToken);

        await using (var deactivateTrust = new NpgsqlCommand(
            $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_list_entry t SET is_active = FALSE, deactivated_at = now(), deactivated_by = @actor " +
            "FROM certificate_handler.ch_pending_request pr " +
            "JOIN certificate_handler.ch_certificate c ON c.certificate_id = pr.certificate_id " +
            "WHERE pr.request_id = @requestId AND t.thumbprint_sha256 = c.thumbprint_sha256 AND t.is_active",
            connection,
            transaction))
        {
            deactivateTrust.Parameters.AddWithValue("actor", actorIdentity);
            deactivateTrust.Parameters.AddWithValue("requestId", requestId);
            await deactivateTrust.ExecuteNonQueryAsync(cancellationToken);
        }

        await using var activate = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_list_entry " +
            "(list_kind, certificate_id, thumbprint_sha256, device_id, added_by, comment, is_active) " +
            "SELECT CAST('WHITELIST' AS certificate_handler.trust_list_kind), c.certificate_id, c.thumbprint_sha256, c.device_id, @actor, 'Reinstated', TRUE " +
            $"FROM {DatabaseConstants.SchemaName}.ch_pending_request pr JOIN {DatabaseConstants.SchemaName}.ch_certificate c ON c.certificate_id = pr.certificate_id " +
            "WHERE pr.request_id = @requestId",
            connection,
            transaction);
        activate.Parameters.AddWithValue("actor", actorIdentity);
        activate.Parameters.AddWithValue("requestId", requestId);
        await activate.ExecuteNonQueryAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    #endregion
}
