﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// Stored details of one active local certificate, as read from the database.
/// </summary>
public sealed record StoredCertificateInfo
{
    #region Public Properties

    /// <summary>Role of the certificate: local SBC or local MIB.</summary>
    public CertificateRole Role { get; init; }

    /// <summary>Subject distinguished name.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>Issuer distinguished name.</summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>SHA-256 thumbprint.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>End of the validity period.</summary>
    public DateTimeOffset NotAfter { get; init; }

    /// <summary>Public key algorithm label when stored.</summary>
    public string PublicKeyAlgorithm { get; init; } = string.Empty;

    /// <summary>PEM-encoded public key when stored (RS_05).</summary>
    public string PublicKeyPem { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Certificate details shown on the read-only certificate view, including the calculated status.
/// </summary>
public sealed record CertificateDetails
{
    #region Public Properties

    /// <summary>Role of the certificate: local SBC or local MIB.</summary>
    public CertificateRole Role { get; init; }

    /// <summary>Subject distinguished name; empty when no certificate was found.</summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>Issuer distinguished name; empty when no certificate was found.</summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>SHA-256 thumbprint; empty when no certificate was found.</summary>
    public string Thumbprint { get; init; } = string.Empty;

    /// <summary>End of the validity period; null when no certificate was found.</summary>
    public DateTimeOffset? NotAfter { get; init; }

    /// <summary>Expiry status calculated from the not-after date and the current time.</summary>
    public CertificateExpiryStatus Status { get; init; }

    /// <summary>Type of the public key. Empty when no certificate was found.</summary>
    public string PublicKeyAlgorithm { get; init; } = string.Empty;

    /// <summary>The public key in PEM format. Empty when no certificate was found.</summary>
    public string PublicKeyPem { get; init; } = string.Empty;

    #endregion
}

/// <summary>
/// Outcome of a certificate information request. An unauthorized caller gets no certificate fields.
/// </summary>
public sealed record CertificateInformationResult
{
    #region Public Properties

    /// <summary>True when the caller is an authorized administrator.</summary>
    public bool IsAuthorized { get; init; }

    /// <summary>The SBC and MIB certificate details; empty when the caller is not authorized.</summary>
    public IReadOnlyList<CertificateDetails> Certificates { get; init; } = Array.Empty<CertificateDetails>();

    #endregion
}
