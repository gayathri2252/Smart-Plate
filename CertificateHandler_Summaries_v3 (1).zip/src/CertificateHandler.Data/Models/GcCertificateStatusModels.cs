// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Enums;

namespace CertificateHandler.Data.Models;

/// <summary>
/// MCC GC certificate snapshot for SBC and MIB (RS_25).
/// </summary>
public sealed class GcCertificateStatusSnapshot
{
    /// <summary>
    /// Time when the result was made, in UTC.
    /// </summary>
    public DateTimeOffset GeneratedAtUtc { get; init; }

    /// <summary>
    /// Status of the SBC and MIB certificates.
    /// </summary>
    public IReadOnlyList<GcCertificateRoleStatus> Certificates { get; init; } = Array.Empty<GcCertificateRoleStatus>();
}

/// <summary>
/// Certificate status for one certificate role.
/// </summary>
public sealed class GcCertificateRoleStatus
{
    /// <summary>
    /// Role of the certificate.
    /// </summary>
    public CertificateRole Role { get; init; }

    /// <summary>
    /// Display name of the role.
    /// </summary>
    public string RoleLabel { get; init; } = string.Empty;

    /// <summary>
    /// Subject name of the certificate.
    /// </summary>
    public string Subject { get; init; } = string.Empty;

    /// <summary>
    /// Issuer name of the certificate.
    /// </summary>
    public string Issuer { get; init; } = string.Empty;

    /// <summary>
    /// SHA256 thumbprint of the certificate.
    /// </summary>
    public string ThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>
    /// Date until which the certificate is valid. Null when no certificate was found.
    /// </summary>
    public DateTimeOffset? NotAfter { get; init; }

    /// <summary>
    /// Expiry status of the certificate.
    /// </summary>
    public CertificateExpiryStatus Status { get; init; }

    /// <summary>
    /// Display text of the expiry status.
    /// </summary>
    public string StatusLabel { get; init; } = string.Empty;
}
