// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

/// <summary>
/// Administrator notifier that does nothing. Used when there is no screen.
/// </summary>
public sealed class NoOpAdministratorNotifier : IAdministratorNotifier
{
    /// <summary>
    /// Does nothing.
    /// </summary>
    public void NotifyPublishFailed(string message)
    {
    }
}
