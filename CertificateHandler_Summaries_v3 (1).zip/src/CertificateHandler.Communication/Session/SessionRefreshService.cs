﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Communication.Constants;
using CertificateHandler.Communication.Interface;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Session;

/// <summary>
/// Refreshes the session token and keeps the user signed in when the network drops.
/// Network failures keep the session, notify the user and retry with back-off; on recovery the view is reloaded.
/// Only a refresh the server refuses ends the session and raises SessionExpired.
/// </summary>
public sealed class SessionRefreshService : IDisposable
{
    #region Public Properties

    /// <summary>
    /// Gets a value indicating whether the service is retrying a refresh after a network failure.
    /// </summary>
    public bool IsRecovering => Volatile.Read(ref _isRecovering) == 1;

    #endregion

    #region Member Variables

    /// <summary>
    /// Store that holds the current session token.
    /// </summary>
    private readonly ISessionStore _sessionStore;

    /// <summary>
    /// Client that asks the server for a new token.
    /// </summary>
    private readonly ITokenRefreshClient _refreshClient;

    /// <summary>
    /// Tells the screen about session changes.
    /// </summary>
    private readonly ISessionNotifier _notifier;

    /// <summary>
    /// Settings for the refresh and the retry times.
    /// </summary>
    private readonly SessionRefreshOptions _options;

    /// <summary>
    /// Gives the current time.
    /// </summary>
    private readonly TimeProvider _timeProvider;

    /// <summary>
    /// Makes sure only one refresh runs at a time.
    /// </summary>
    private readonly SemaphoreSlim _refreshGate = new(1, 1);

    /// <summary>
    /// Lock used when reading or changing the state of the service.
    /// </summary>
    private readonly object _stateLock = new();

    /// <summary>
    /// Used to stop the background tasks when the service stops.
    /// </summary>
    private CancellationTokenSource _lifetimeSource = new();

    /// <summary>
    /// Used to end the wait between two retries early. Null when no retry is waiting.
    /// </summary>
    private CancellationTokenSource? _retryWaitSource;

    /// <summary>
    /// True when a wake up was asked for, so the next retry does not wait.
    /// </summary>
    private bool _isWakeUpRequested;

    /// <summary>
    /// Task that keeps trying the refresh after a network failure. Null when it is not running.
    /// </summary>
    private Task? _recoveryTask;

    /// <summary>
    /// Task that refreshes the session before the token expires. Null when it is not running.
    /// </summary>
    private Task? _autoRefreshTask;

    /// <summary>
    /// Set to 1 while the recovery is running, otherwise 0.
    /// </summary>
    private int _isRecovering;

    /// <summary>
    /// True when the service is disposed.
    /// </summary>
    private bool _disposed;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the service with the session store, the refresh client, the notifier and the refresh settings.
    /// </summary>
    public SessionRefreshService(ISessionStore sessionStore, ITokenRefreshClient refreshClient, ISessionNotifier notifier, SessionRefreshOptions options, TimeProvider? timeProvider = null)
    {
        _sessionStore = sessionStore ?? throw new ArgumentNullException(nameof(sessionStore));
        _refreshClient = refreshClient ?? throw new ArgumentNullException(nameof(refreshClient));
        _notifier = notifier ?? throw new ArgumentNullException(nameof(notifier));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _timeProvider = timeProvider ?? TimeProvider.System;
    }

    #endregion

    #region Events

    /// <summary>
    /// Raised after every successful refresh, including a recovery.
    /// </summary>
    public event EventHandler? SessionRefreshed;

    /// <summary>
    /// Raised after a refresh succeeds following a network failure, so the open view can reload its data.
    /// </summary>
    public event EventHandler? ReloadRequested;

    /// <summary>
    /// Raised only when the server refuses the refresh. The UI shows the login page on this event.
    /// Network failures never raise it.
    /// </summary>
    public event EventHandler? SessionExpired;

    #endregion

    #region Public Methods

    /// <summary>
    /// Refreshes the session token once. On a network failure the session is kept,
    /// the user is notified and the retry loop starts in the background.
    /// </summary>
    public async Task<RefreshOutcome> RefreshAsync(CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (IsRecovering)
        {
            return RefreshOutcome.RecoveryInProgress;
        }
        await _refreshGate.WaitAsync(cancellationToken).ConfigureAwait(false);

        try
        {
            if (IsRecovering)
            {
                return RefreshOutcome.RecoveryInProgress;
            }
            SessionToken? current = _sessionStore.Current;
            if (current is null)
            {
                return RefreshOutcome.NoSession;
            }

            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_STARTED, current.UserName);
            return await TryRefreshAsync(current, cancellationToken).ConfigureAwait(false);
        }
        finally
        {
            _refreshGate.Release();
        }
    }

    /// <summary>
    /// Starts the background loop that refreshes the token shortly before it expires.
    /// Call it once after the user signs in.
    /// </summary>
    public void Start()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        lock (_stateLock)
        {
            if (_autoRefreshTask is { IsCompleted: false })
            {
                return;
            }

            CancellationToken token = _lifetimeSource.Token;
            _autoRefreshTask = Task.Run(() => RunAutoRefreshAsync(token));
        }
    }

    /// <summary>
    /// Stops the automatic refresh and any running recovery, for example when the user signs out.
    /// </summary>
    public void Stop()
    {
        CancellationTokenSource oldSource;
        lock (_stateLock)
        {
            oldSource = _lifetimeSource;
            _lifetimeSource = new CancellationTokenSource();
            _autoRefreshTask = null;
        }
        oldSource.Cancel();
    }

    /// <summary>
    /// Cuts the current retry wait short so the next retry runs at once.
    /// Call it when Windows reports that the network is available again.
    /// </summary>
    public void NotifyNetworkAvailable()
    {
        if (!IsRecovering)
        {
            return;
        }
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_NETWORK_AVAILABLE);
        CancellationTokenSource? waitSource;
        lock (_stateLock)
        {
            _isWakeUpRequested = true;
            waitSource = _retryWaitSource;
        }

        try
        {
            waitSource?.Cancel();
        }
        catch (ObjectDisposedException)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RETRY_WAIT_ALREADY_FINISHED);
        }
    }

    /// <summary>
    /// Completes when no recovery is running, or when the running recovery ends.
    /// </summary>
    public Task WaitForRecoveryAsync(CancellationToken cancellationToken = default)
    {
        Task? recoveryTask;

        lock (_stateLock)
        {
            recoveryTask = _recoveryTask;
        }

        return recoveryTask is null ? Task.CompletedTask : recoveryTask.WaitAsync(cancellationToken);
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Calls the refresh client once and turns the result into an outcome.
    /// Network failures keep the session and start recovery; a refused refresh ends the session.
    /// </summary>
    private async Task<RefreshOutcome> TryRefreshAsync(SessionToken current, CancellationToken cancellationToken)
    {
        try
        {
            SessionToken refreshed = await _refreshClient.RefreshAsync(current, cancellationToken).ConfigureAwait(false);
            return ApplyRefreshedToken(current, refreshed) ? RefreshOutcome.Succeeded : RefreshOutcome.SessionChanged;
        }
        catch (SessionRejectedException)
        {
            return HandleSessionRejected(current) ? RefreshOutcome.SessionRejected : RefreshOutcome.SessionChanged;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex) when (RefreshFailureClassifier.IsNetworkFailure(ex))
        {
            HandleNetworkFailure(current, ex);
            return RefreshOutcome.NetworkFailure;
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_UNEXPECTED_FAILURE, current.UserName, ex.Message);
            return RefreshOutcome.Failed;
        }
    }

    /// <summary>
    /// Stores the new tokens and raises SessionRefreshed, but only while the session is still the one
    /// the refresh started with. Returns false when the session changed and the result was ignored.
    /// </summary>
    private bool ApplyRefreshedToken(SessionToken current, SessionToken refreshed)
    {
        if (!_sessionStore.TryReplace(current, refreshed))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_STALE, current.UserName);
            return false;
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_SUCCEEDED, refreshed.UserName, refreshed.ExpiresAtUtc.ToString("O"));
        RaiseSafely(SessionRefreshed);
        return true;
    }

    /// <summary>
    /// Keeps the current session, logs the failure, notifies the user and starts the retry loop.
    /// </summary>
    private void HandleNetworkFailure(SessionToken current, Exception exception)
    {
        CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_NETWORK_FAILURE, current.UserName, exception.Message);
        NotifySafely(() => _notifier.NotifyRefreshFailed(SessionRefreshConstants.REFRESH_FAILED_NOTIFICATION));
        StartRecovery();
    }

    /// <summary>
    /// Ends the session and raises SessionExpired so the UI can show the login page. Returns false and
    /// does nothing when the session changed while the request ran.
    /// </summary>
    private bool HandleSessionRejected(SessionToken current)
    {
        if (!_sessionStore.TryEnd(current))
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_STALE, current.UserName);
            return false;
        }

        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_REJECTED, current.UserName);
        RaiseSafely(SessionExpired);
        return true;
    }

    /// <summary>
    /// Starts the retry loop when it is not already running.
    /// </summary>
    private void StartRecovery()
    {
        if (Interlocked.CompareExchange(ref _isRecovering, 1, 0) != 0)
        {
            return;
        }

        lock (_stateLock)
        {
            CancellationToken token = _lifetimeSource.Token;
            _recoveryTask = Task.Run(() => RunRecoveryAsync(token));
        }
    }

    /// <summary>
    /// Retries the refresh with a growing wait until it succeeds, the server refuses it or the service stops.
    /// The session is never cleared by a failed retry.
    /// </summary>
    private async Task RunRecoveryAsync(CancellationToken cancellationToken)
    {
        TimeSpan delay = TimeSpan.FromSeconds(_options.RetryInitialDelaySeconds);
        int attempt = 0;
        bool recovered = false;

        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RECOVERY_STARTED, delay.TotalSeconds);
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await WaitBeforeRetryAsync(delay, cancellationToken).ConfigureAwait(false);
                SessionToken? current = _sessionStore.Current;
                if (current is null)
                {
                    return;
                }

                attempt++;
                CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RECOVERY_ATTEMPT, attempt);
                try
                {
                    SessionToken refreshed = await _refreshClient.RefreshAsync(current, cancellationToken).ConfigureAwait(false);
                    recovered = true;
                    ProcessRecovery(current, refreshed, attempt);
                    return;
                }
                catch (SessionRejectedException)
                {
                    HandleSessionRejected(current);
                    return;
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    delay = GetNextDelay(delay);
                    CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RECOVERY_ATTEMPT_FAILED, attempt, delay.TotalSeconds, ex.Message);
                }
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RECOVERY_STOPPED);
        }
        finally
        {
            if (!recovered)
            {
                Interlocked.Exchange(ref _isRecovering, 0);
            }
        }
    }

    /// <summary>
    /// Handles the first successful refresh after a network failure: stores the tokens,
    /// notifies the user and asks the open view to reload. The user stays on the same page.
    /// A result for a session that changed meanwhile is ignored.
    /// </summary>
    private void ProcessRecovery(SessionToken current, SessionToken refreshed, int attempt)
    {
        bool isStored = _sessionStore.TryReplace(current, refreshed);
        Interlocked.Exchange(ref _isRecovering, 0);
        if (!isStored)
        {
            CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_REFRESH_STALE, current.UserName);
            return;
        }

        CertificateHandlerLogger.Success(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RECOVERY_SUCCEEDED, attempt, refreshed.UserName);
        NotifySafely(() => _notifier.NotifyRefreshRecovered(SessionRefreshConstants.REFRESH_RECOVERED_NOTIFICATION));
        RaiseSafely(SessionRefreshed);
        RaiseSafely(ReloadRequested);
    }

    /// <summary>
    /// Waits for the retry delay. NotifyNetworkAvailable ends the wait early.
    /// </summary>
    private async Task WaitBeforeRetryAsync(TimeSpan delay, CancellationToken cancellationToken)
    {
        CancellationTokenSource waitSource;
        lock (_stateLock)
        {
            if (_isWakeUpRequested)
            {
                _isWakeUpRequested = false;
                return;
            }

            waitSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            _retryWaitSource = waitSource;
        }

        try
        {
            await Task.Delay(delay, _timeProvider, waitSource.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_RETRY_WAIT_ENDED_EARLY);
        }
        finally
        {
            lock (_stateLock)
            {
                _retryWaitSource = null;
                _isWakeUpRequested = false;
            }

            waitSource.Dispose();
        }
        cancellationToken.ThrowIfCancellationRequested();
    }

    /// <summary>
    /// Doubles the retry wait up to the configured maximum.
    /// </summary>
    private TimeSpan GetNextDelay(TimeSpan currentDelay)
    {
        TimeSpan maxDelay = TimeSpan.FromSeconds(_options.RetryMaxDelaySeconds);
        TimeSpan nextDelay = currentDelay * SessionRefreshConstants.RETRY_BACKOFF_MULTIPLIER;
        return nextDelay > maxDelay ? maxDelay : nextDelay;
    }

    /// <summary>
    /// Refreshes the token shortly before it expires, for as long as the user is signed in.
    /// </summary>
    private async Task RunAutoRefreshAsync(CancellationToken cancellationToken)
    {
        try
        {
            RefreshOutcome lastOutcome = RefreshOutcome.NoSession;
            while (!cancellationToken.IsCancellationRequested)
            {
                SessionToken? current = _sessionStore.Current;

                if (current is null)
                {
                    return;
                }

                TimeSpan due = GetTimeUntilRefresh(current, lastOutcome);

                if (due > TimeSpan.Zero)
                {
                    await Task.Delay(due, _timeProvider, cancellationToken).ConfigureAwait(false);
                }

                lastOutcome = await RefreshAsync(cancellationToken).ConfigureAwait(false);

                if (lastOutcome is RefreshOutcome.SessionRejected or RefreshOutcome.NoSession)
                {
                    return;
                }

                if (lastOutcome is RefreshOutcome.NetworkFailure or RefreshOutcome.RecoveryInProgress)
                {
                    await WaitForRecoveryAsync(cancellationToken).ConfigureAwait(false);
                }
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            CertificateHandlerLogger.Information(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_AUTO_REFRESH_STOPPED);
        }
    }

    /// <summary>
    /// Returns the wait until the next refresh. After a failed or too-short refresh
    /// at least the retry delay is used so the loop never spins.
    /// </summary>
    private TimeSpan GetTimeUntilRefresh(SessionToken current, RefreshOutcome lastOutcome)
    {
        TimeSpan due = current.ExpiresAtUtc
            - _timeProvider.GetUtcNow()
            - TimeSpan.FromSeconds(_options.RefreshBeforeExpirySeconds);

        bool isFirstRun = lastOutcome == RefreshOutcome.NoSession;
        TimeSpan minimumWait = isFirstRun ? TimeSpan.Zero : TimeSpan.FromSeconds(_options.RetryInitialDelaySeconds);

        if (lastOutcome == RefreshOutcome.Failed)
        {
            minimumWait = TimeSpan.FromSeconds(_options.RetryMaxDelaySeconds);
        }

        return due > minimumWait ? due : minimumWait;
    }

    /// <summary>
    /// Raises an event and logs any handler error so the refresh flow keeps running.
    /// </summary>
    private void RaiseSafely(EventHandler? handler)
    {
        NotifySafely(() => handler?.Invoke(this, EventArgs.Empty));
    }

    /// <summary>
    /// Runs a UI callback and logs any error so the refresh flow keeps running.
    /// </summary>
    private static void NotifySafely(Action action)
    {
        try
        {
            action();
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(MessageIdGenerator.Next(), SessionRefreshConstants.LOG_CALLBACK_FAILED, ex.Message);
        }
    }

    #endregion

    #region Dispose Methods

    /// <summary>
    /// Stops all background work and releases the resources.
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }
        _disposed = true;
        _lifetimeSource.Cancel();
        _lifetimeSource.Dispose();
        _refreshGate.Dispose();
    }

    #endregion
}
