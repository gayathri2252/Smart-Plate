// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data;
using CertificateHandler.Data.Infrastructure;
using CertificateHandler.Data.Security;
using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.DeviceTrust.Tls;
using CertificateHandler.Shared.Models;
using DashboardCH.Models.Enums;
using DashboardCH.Services;
namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Composes validation, authorization, and TLS gating for the MAXUM listener (RS_03, RS_11).
/// </summary>
public sealed class PeerConnectionHostResources : IDisposable
{
    #region Member Variables

    /// <summary>
    /// Data access used by the pipeline.
    /// </summary>
    private readonly CertificateHandlerDataAccess _dataAccess;

    /// <summary>
    /// Database context used by the pipeline.
    /// </summary>
    private readonly CertificateHandlerDbContext _dbContext;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the host resources.
    /// </summary>
    private PeerConnectionHostResources(
        CertificateHandlerDataAccess dataAccess,
        CertificateHandlerDbContext dbContext,
        PeerConnectionPipeline pipeline,
        TlsHandshakeCoordinator handshakes)
    {
        _dataAccess = dataAccess;
        _dbContext = dbContext;
        Pipeline = pipeline;
        Handshakes = handshakes;
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the pipeline that checks and approves the peer certificates.
    /// </summary>
    public PeerConnectionPipeline Pipeline { get; }

    /// <summary>
    /// Gets the coordinator that holds and releases TLS handshakes.
    /// </summary>
    public TlsHandshakeCoordinator Handshakes { get; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Builds the listener pipeline on top of the application data access layer.
    /// </summary>
    public static PeerConnectionHostResources Create(CertificateHandlerDataAccess dataAccess)
    {
        ArgumentNullException.ThrowIfNull(dataAccess);

        CertificateHandlerDbContext dbContext = dataAccess.CreateDbContext();

        var certificateBlackList = new CertificateBlackList(dbContext);
        var certificateWhitelist = new CertificateWhitelist(dbContext);
        var blacklistOnFailure = new BlackListOnSecurityFailureService(certificateBlackList);
        var trustEngine = new TrustEngine(certificateBlackList, certificateWhitelist, blacklistOnFailure);
        var pendingStore = new PendingQueueStore(dbContext);
        var queueCapacity = new PendingQueueCapacityService(
            pendingStore,
            new PendingQueueOptions(),
            new TimeoutConfiguration());
        var blackListHistory = new BlackListHistory(dbContext);
        TlsHandshakeCoordinator handshakes = TlsHandshakeCoordinatorRegistry.Current;

        var authorization = new CertificateRequestAuthorizationService(
            trustEngine,
            queueCapacity,
            blackListHistory,
            handshakes);

        var storeAdapter = new CertificateStoreAdapterFactory()
            .Create(CertificateStorageMedium.WindowsCertificateStore);
        var validationEngine = new CertificateValidationEngine(
            storeAdapter,
            new SystemTimeVerificationService(),
            new ValidationResultWriter(dbContext));

        var tlsManager = new TlsConnectionManager(
            new ConnectionAdmissionService(certificateBlackList),
            handshakes);

        var pipeline = new PeerConnectionPipeline(validationEngine, authorization, tlsManager);

        return new PeerConnectionHostResources(dataAccess, dbContext, pipeline, handshakes);
    }

    /// <summary>
    /// Frees the database context and the data access.
    /// </summary>
    public void Dispose()
    {
        _dbContext.Dispose();
        _dataAccess.Dispose();
    }

    #endregion
}
