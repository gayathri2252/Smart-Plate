// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Models;
using CertificateHandler.DeviceTrust.Models;
using CertificateHandler.DeviceTrust.Services;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Entry point for MAXUM listener: validate, authorize, and gate TLS (RS_03, RS_11).
/// </summary>
public sealed class PeerConnectionPipeline : IPeerConnectionPipeline
{
    #region Member Variables

    /// <summary>
    /// Checks the certificate sent by the peer.
    /// </summary>
    private readonly CertificateValidationEngine _validationEngine;

    /// <summary>
    /// Decides if the certificate request is allowed.
    /// </summary>
    private readonly CertificateRequestAuthorizationService _authorizationService;

    /// <summary>
    /// Decides if the TLS session can start.
    /// </summary>
    private readonly TlsConnectionManager _tlsConnectionManager;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the connection pipeline.
    /// </summary>
    public PeerConnectionPipeline(
        CertificateValidationEngine validationEngine,
        CertificateRequestAuthorizationService authorizationService,
        TlsConnectionManager tlsConnectionManager)
    {
        _validationEngine = validationEngine ?? throw new ArgumentNullException(nameof(validationEngine));
        _authorizationService = authorizationService ?? throw new ArgumentNullException(nameof(authorizationService));
        _tlsConnectionManager = tlsConnectionManager ?? throw new ArgumentNullException(nameof(tlsConnectionManager));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks the peer certificate, decides if it is allowed, and tells if TLS can go on.
    /// TLS is allowed only when the request is allowed and the connection is let in.
    /// </summary>
    public async Task<PeerConnectionPipelineResult> ProcessAsync(
        CertificateRequest request,
        string? correlationId,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        string thumbprint = request.Peer?.ThumbprintSha256 ?? request.ValidationResult?.ThumbprintSha256 ?? string.Empty;
        TrustValidationResult validation = request.ValidationResult ?? await RunValidationAsync(request, thumbprint, cancellationToken);

        var enriched = new CertificateRequest
        {
            Peer = request.Peer,
            IsAuthenticated = request.IsAuthenticated,
            ValidationResult = validation,
            PresentedCertificateDer = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer
        };

        CertificateRequestAuthorizationResult auth = await _authorizationService.AuthorizeAsync(enriched, cancellationToken);
        bool tlsAllowed = await _tlsConnectionManager.MayStartTlsAsync(thumbprint, correlationId, cancellationToken);

        return new PeerConnectionPipelineResult
        {
            Validation = validation,
            Authorization = auth,
            TlsAllowed = tlsAllowed && auth.Decision == CertificateRequestDecision.Allowed
        };
    }

    /// <summary>
    /// Checks the certificate the peer sent. When no certificate data was sent, the certificate is read from the store by its thumbprint.
    /// </summary>
    private Task<TrustValidationResult> RunValidationAsync(
        CertificateRequest request,
        string thumbprint,
        CancellationToken cancellationToken)
    {
        byte[]? der = request.PresentedCertificateDer ?? request.Peer?.PresentedCertificateDer;
        if (der is { Length: > 0 })
        {
            return _validationEngine.ValidatePresentedCertificateAsync(der, expectedThumbprintSha256: thumbprint, deviceId: null, cancellationToken);
        }

        return _validationEngine.ValidateAsync(thumbprint, null, cancellationToken);
    }

    #endregion
}

/// <summary>
/// Result of the connection pipeline.
/// </summary>
public sealed class PeerConnectionPipelineResult
{
    /// <summary>
    /// Result of the certificate check.
    /// </summary>
    public TrustValidationResult Validation { get; init; } = new();

    /// <summary>
    /// Result of the request approval.
    /// </summary>
    public CertificateRequestAuthorizationResult Authorization { get; init; } = new();

    /// <summary>
    /// True when the TLS session is allowed.
    /// </summary>
    public bool TlsAllowed { get; init; }
}
