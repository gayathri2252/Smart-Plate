// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Coordinates inbound listener and outbound connector for MAXUM-to-MAXUM TLS (RS_11).
/// </summary>
public interface IMaxumConnectionManager : IDisposable
{
    /// <summary>
    /// True when the listener is running.
    /// </summary>
    bool IsListening { get; }

    /// <summary>
    /// Starts listening for connections from other devices.
    /// </summary>
    void StartListener();

    /// <summary>
    /// Stops listening for connections from other devices.
    /// </summary>
    void StopListener();

    /// <summary>
    /// Connects to another MAXUM device over TLS.
    /// </summary>
    Task<PeerTlsConnection?> ConnectToPeerAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default);
}
