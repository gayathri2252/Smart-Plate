// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Models;
namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Maps an authenticated TLS client certificate to a <see cref="CertificateRequest"/> for the peer pipeline.
/// </summary>
public static class DevPeerTlsRequestFactory
{
    #region Public Methods

    /// <summary>
    /// Creates a certificate request from the certificate the peer sent.
    /// </summary>
    public static DeviceTrust.Models.CertificateRequest FromClientCertificate(
        X509Certificate2 clientCertificate,
        string? remoteIp,
        bool isMutuallyAuthenticated)
    {
        ArgumentNullException.ThrowIfNull(clientCertificate);

        string deviceCode = ResolveDeviceCode(clientCertificate);
        PeerOnboardingRequest peer = PeerOnboardingRequest.FromCertificate(clientCertificate, deviceCode, remoteIp);

        return new DeviceTrust.Models.CertificateRequest
        {
            Peer = peer,
            IsAuthenticated = isMutuallyAuthenticated,
            PresentedCertificateDer = clientCertificate.RawData
        };
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Gets the device code of the peer.
    /// In debug builds the code can come from an environment variable. Otherwise the common name of the certificate is used, or the first 16 characters of the SHA256 thumbprint when there is no common name.
    /// </summary>
    private static string ResolveDeviceCode(X509Certificate2 certificate)
    {
#if DEBUG
        string? fromEnv = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_DEVICE_CODE");
        if (!string.IsNullOrWhiteSpace(fromEnv))
        {
            return fromEnv.Trim();
        }
#endif

        string subject = certificate.Subject;
        const string prefix = "CN=";
        int index = subject.IndexOf(prefix, StringComparison.OrdinalIgnoreCase);
        if (index >= 0)
        {
            int start = index + prefix.Length;
            int comma = subject.IndexOf(',', start);
            string commonName = comma < 0 ? subject[start..] : subject[start..comma];
            if (!string.IsNullOrWhiteSpace(commonName))
            {
                return commonName.Trim();
            }
        }

        return certificate.GetCertHashString(HashAlgorithmName.SHA256)[..16];
    }

    #endregion
}
