// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.CertificateManagement.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Drops exported CSR PEM files under <c>CH_MCC_EXPORT_PATH</c> for MCC collection.
/// </summary>
public sealed class MccRenewalExportWriter : IMccRenewalExportWriter
{
    /// <summary>
    /// Writes the certificate signing request to the MCC export folder.
    /// Does nothing when the export folder is not set.
    /// </summary>
    /// <param name="keyId">Id of the key used for the request.</param>
    /// <param name="csrPem">The certificate signing request in PEM format.</param>
    /// <exception cref="ArgumentException">Thrown when the request text is null or empty.</exception>
    public void ExportCsrPem(Guid keyId, string csrPem)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(csrPem);
        string? root = Environment.GetEnvironmentVariable("CH_MCC_EXPORT_PATH");
        if (string.IsNullOrWhiteSpace(root))
        {
            return;
        }

        Directory.CreateDirectory(root);
        string path = Path.Combine(root, $"renewal-{keyId:N}.csr.pem");
        File.WriteAllText(path, csrPem);
        CertificateHandlerLogger.Information(MessageIdGenerator.Next(), "MCC renewal CSR exported to {0}", path);
    }
}
