// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Text;
using CertificateHandler.CertificateManagement.Interfaces;

namespace CertificateHandler.CertificateManagement.Services;

/// <summary>
/// Dev/test CSR PEM export when <c>CH_SIMULATE_TPM_CSR=1</c> (RS_04/RS_26).
/// </summary>
public sealed class SimulatedTpmCsrExportService : ITpmCsrExportService
{
    /// <summary>
    /// Creates a dummy certificate signing request for testing.
    /// </summary>
    /// <param name="keyId">Id of the key used for the request.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A dummy certificate signing request in PEM format.</returns>
    public Task<string> ExportCsrPemAsync(Guid keyId, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        string payload = Convert.ToBase64String(Encoding.UTF8.GetBytes($"CSR-STUB-{keyId:N}"));
        string pem = $"-----BEGIN CERTIFICATE REQUEST-----\n{payload}\n-----END CERTIFICATE REQUEST-----";
        return Task.FromResult(pem);
    }

    /// <summary>
    /// True when the test TPM request export is turned on.
    /// </summary>
    public static bool IsEnabled =>
        CertificateHandler.Shared.Security.DevelopmentBypassGuard.IsBypassEnabled("CH_SIMULATE_TPM_CSR");
}
