// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Shared.Constants;
using Microsoft.Extensions.Configuration;

namespace CertificateHandler.Data;

/// <summary>
/// Platform local Windows group used to authorize MAXUM device administrators (GC export, cert-info APIs).
/// </summary>
public sealed class AdministratorGroupOptions
{
    /// <summary>
    /// Name of the settings section for login.
    /// </summary>
    public const string SectionName = "CertificateHandler:Login";

    /// <summary>
    /// Windows group used when no administrator group is set.
    /// </summary>
    public const string DefaultAdministratorGroup = DeviceAdministratorConstants.DefaultWindowsGroup;

    /// <summary>
    /// Name of the Windows group whose members are device administrators.
    /// </summary>
    public string AdministratorGroup { get; set; } = DefaultAdministratorGroup;

    /// <summary>
    /// Loads the administrator group.
    /// It first looks at the platform environment variable, then the old environment variable, then the settings file.
    /// </summary>
    /// <returns>The administrator group settings.</returns>
    public static AdministratorGroupOptions Load()
    {
        string? fromPlatform = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.PlatformGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromPlatform))
        {
            return new AdministratorGroupOptions { AdministratorGroup = fromPlatform.Trim() };
        }

        string? fromLegacy = Environment.GetEnvironmentVariable(DeviceAdministratorConstants.LegacyGroupEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromLegacy))
        {
            return new AdministratorGroupOptions { AdministratorGroup = fromLegacy.Trim() };
        }

        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        AdministratorGroupOptions? options = configuration.GetSection(SectionName).Get<AdministratorGroupOptions>();
        if (options is null || string.IsNullOrWhiteSpace(options.AdministratorGroup))
        {
            return new AdministratorGroupOptions();
        }

        options.AdministratorGroup = options.AdministratorGroup.Trim();
        return options;
    }
}
