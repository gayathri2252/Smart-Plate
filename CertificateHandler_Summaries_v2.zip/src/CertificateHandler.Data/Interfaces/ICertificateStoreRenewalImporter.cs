// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Installs a renewed signed certificate into the Windows Certificate Store (RS_06).
/// </summary>
public interface ICertificateStoreRenewalImporter
{
    /// <summary>
    /// Adds the renewed certificate to the certificate store.
    /// </summary>
    /// <param name="certificate">The renewed certificate.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task ImportSignedCertificateAsync(X509Certificate2 certificate, CancellationToken cancellationToken = default);
}
