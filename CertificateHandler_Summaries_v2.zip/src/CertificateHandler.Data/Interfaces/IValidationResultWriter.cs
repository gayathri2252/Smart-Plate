// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

namespace CertificateHandler.Data.Interfaces;

/// <summary>
/// Persists certificate validation step outcomes (RS_03).
/// </summary>
public interface IValidationResultWriter
{
    /// <summary>
    /// Saves the result of one certificate validation step.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the certificate, or null if not known.</param>
    /// <param name="deviceId">Id of the device, or null if not known.</param>
    /// <param name="validationStep">Name of the validation step.</param>
    /// <param name="passed">True if the step passed.</param>
    /// <param name="failureReason">Why the step failed, or null if it passed.</param>
    /// <param name="timeVerified">True if the system time was trusted.</param>
    /// <param name="autoBlacklisted">True if the certificate was added to the blacklist by the system.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    Task WriteAsync(
        string? thumbprintSha256,
        Guid? deviceId,
        string validationStep,
        bool passed,
        string? failureReason,
        bool timeVerified,
        bool autoBlacklisted,
        CancellationToken cancellationToken = default);
}
