// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Delivers queued peer notifications with retry and audit (RS_10).
/// </summary>
public sealed class PeerNotificationDeliveryService : IPeerNotificationDeliveryService
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Channel used to send the notifications.
    /// </summary>
    private readonly IPeerNotificationChannel _channel;

    /// <summary>
    /// Most times a notification is tried.
    /// </summary>
    private readonly int _maxRetries;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the peer notification delivery service.
    /// </summary>
    /// <param name="dataSource">Data source used to connect to the database.</param>
    /// <param name="channel">Channel used to send the notifications, or null to use the default one.</param>
    /// <exception cref="ArgumentNullException">Thrown when the data source is null.</exception>
    public PeerNotificationDeliveryService(NpgsqlDataSource dataSource, IPeerNotificationChannel? channel = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _channel = channel ?? PeerNotificationChannelFactory.Create();
        _maxRetries = PeerNotificationConstants.ResolveMaxRetries();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Tries again to send the failed peer notifications and writes an audit row for each try.
    /// Up to 50 notifications are taken each time.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Number of notifications sent.</returns>
    public async Task<int> DeliverPendingAsync(CancellationToken cancellationToken = default)
    {
        int delivered = 0;
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var select = new NpgsqlCommand(
            $"SELECT notification_id, request_id, retry_count, notification_status::text FROM {DatabaseConstants.SchemaName}.ch_peer_notification " +
            "WHERE delivery_result = 'FAILED' AND retry_count < @maxRetries AND " +
            "last_error IS DISTINCT FROM @exhausted ORDER BY notification_id LIMIT 50",
            connection);
        select.Parameters.AddWithValue("maxRetries", _maxRetries);
        select.Parameters.AddWithValue("exhausted", PeerNotificationConstants.MaxRetriesExceeded);

        var pending = new List<(long Id, Guid RequestId, string Status)>();
        await using (var reader = await select.ExecuteReaderAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                pending.Add((reader.GetInt64(0), reader.GetGuid(1), reader.GetString(3)));
            }
        }

        foreach ((long id, Guid requestId, string status) in pending)
        {
            bool ok = await _channel.TryDeliverAsync(id, requestId, cancellationToken);
            if (ok)
            {
                await using var update = new NpgsqlCommand(
                    $"UPDATE {DatabaseConstants.SchemaName}.ch_peer_notification " +
                    "SET delivery_result = 'SUCCESS', retry_count = retry_count + 1, sent_at = now(), last_error = NULL " +
                    "WHERE notification_id = @id",
                    connection);
                update.Parameters.AddWithValue("id", id);
                await update.ExecuteNonQueryAsync(cancellationToken);
                await WriteDeliveryAuditAsync(connection, requestId, status, success: true, cancellationToken);
                delivered++;
                continue;
            }

            await using var failLookup = new NpgsqlCommand(
                $"SELECT retry_count FROM {DatabaseConstants.SchemaName}.ch_peer_notification WHERE notification_id = @id",
                connection);
            failLookup.Parameters.AddWithValue("id", id);
            int retryCount = Convert.ToInt32(await failLookup.ExecuteScalarAsync(cancellationToken));
            int next = retryCount + 1;
            string error = next >= _maxRetries
                ? PeerNotificationConstants.MaxRetriesExceeded
                : "Delivery to peer failed.";

            await using var fail = new NpgsqlCommand(
                $"UPDATE {DatabaseConstants.SchemaName}.ch_peer_notification " +
                "SET delivery_result = 'FAILED', retry_count = retry_count + 1, last_error = @error " +
                "WHERE notification_id = @id",
                connection);
            fail.Parameters.AddWithValue("error", error);
            fail.Parameters.AddWithValue("id", id);
            await fail.ExecuteNonQueryAsync(cancellationToken);
            await WriteDeliveryAuditAsync(connection, requestId, status, success: false, cancellationToken);
        }

        return delivered;
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Writes the audit row for one try to send a notification.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="requestId">Id of the certificate request.</param>
    /// <param name="notificationStatus">Status that was sent in the notification.</param>
    /// <param name="success">True if the send worked.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A task that ends when the row is written.</returns>
    private static async Task WriteDeliveryAuditAsync(
        NpgsqlConnection connection,
        Guid requestId,
        string notificationStatus,
        bool success,
        CancellationToken cancellationToken)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_audit_log " +
            "(event_type, event_timestamp, actor_identity, request_id, action_status, reason, result, source_component) " +
            "VALUES (@eventType, now(), 'system', @requestId, @status, @reason, @result, @source)",
            connection);
        command.Parameters.AddWithValue("eventType", success
            ? PeerNotificationConstants.AuditEventDelivered
            : PeerNotificationConstants.AuditEventFailed);
        command.Parameters.AddWithValue("requestId", requestId);
        command.Parameters.AddWithValue("status", notificationStatus);
        command.Parameters.AddWithValue("reason", success ? "Delivered" : "Delivery failed; will retry until max attempts.");
        command.Parameters.AddWithValue("result", success ? "SUCCESS" : "FAILED");
        command.Parameters.AddWithValue("source", PeerNotificationConstants.SourceComponent);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion
}
