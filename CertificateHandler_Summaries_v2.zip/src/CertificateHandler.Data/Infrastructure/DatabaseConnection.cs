﻿// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Data.Options;
using Npgsql;

namespace CertificateHandler.Data.Infrastructure;

/// <summary>
/// One open connection that uses the same TLS settings (client certificate, server validation) as the
/// application. Disposing it closes the connection and releases the data source and the certificate.
/// </summary>
internal sealed class DatabaseConnection : IDisposable
{
    #region Member Variables

    /// <summary>
    /// Data source of the connection.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Client certificate of the connection. Null when not used.
    /// </summary>
    private readonly X509Certificate2? _clientCertificate;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the database connection.
    /// </summary>
    /// <param name="dataSource">Data source of the connection.</param>
    /// <param name="connection">The open database connection.</param>
    /// <param name="clientCertificate">Client certificate of the connection, or null.</param>
    private DatabaseConnection(NpgsqlDataSource dataSource, NpgsqlConnection connection, X509Certificate2? clientCertificate)
    {
        _dataSource = dataSource;
        Connection = connection;
        _clientCertificate = clientCertificate;
    }

    #endregion

    #region Public Properties

    /// <summary>The open connection.</summary>
    public NpgsqlConnection Connection { get; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Opens a connection for the connection string with the TLS settings of the options.
    /// Throws NpgsqlException when the server cannot be reached or refuses the sign-in.
    /// </summary>
    public static DatabaseConnection Open(DatabaseOptions options, string connectionString)
    {
        ArgumentNullException.ThrowIfNull(options);

        var builder = new NpgsqlDataSourceBuilder(connectionString);
        X509Certificate2? clientCertificate = PostgresTlsConfiguration.Apply(builder, options);

        NpgsqlDataSource? dataSource = null;
        try
        {
            dataSource = builder.Build();
            NpgsqlConnection connection = DatabaseServerConnection.Open(dataSource);
            return new DatabaseConnection(dataSource, connection, clientCertificate);
        }
        catch
        {
            dataSource?.Dispose();
            clientCertificate?.Dispose();
            throw;
        }
    }

    #endregion

    #region Dispose Methods

    /// <summary>
    /// Closes the connection and releases the data source and the client certificate.
    /// </summary>
    public void Dispose()
    {
        Connection.Dispose();
        _dataSource.Dispose();
        _clientCertificate?.Dispose();
    }

    #endregion
}
