// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Stand-in peer channel that logs delivery until the MAXUM listener transport is wired.
/// </summary>
public sealed class LoggingPeerNotificationChannel : IPeerNotificationChannel
{
    #region Public Methods

    /// <summary>
    /// Delivers the notification by writing it to the log.
    /// </summary>
    /// <param name="notificationId">Id of the notification.</param>
    /// <param name="requestId">Id of the certificate request.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Always true.</returns>
    public Task<bool> TryDeliverAsync(long notificationId, Guid requestId, CancellationToken cancellationToken = default)
    {
        CertificateHandlerLogger.Information(
            MessageIdGenerator.Next(),
            $"Peer notification {notificationId} for request {requestId} delivered via log channel (RS_10 stub).");
        return Task.FromResult(true);
    }

    #endregion
}
