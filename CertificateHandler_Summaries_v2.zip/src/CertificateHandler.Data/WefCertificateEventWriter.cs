// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Data;

/// <summary>
/// Writes certificate expiry events to Windows Event Log for MCC / WEF pickup (RS_25).
/// </summary>
public sealed class WefCertificateEventWriter : IWefCertificateEventWriter
{
    #region Public Methods

    /// <summary>
    /// Writes a certificate expiry alert to the log.
    /// On Windows, when the event log setting is on, it is also written to the Windows event log so WEF can pick it up.
    /// </summary>
    /// <param name="certificateName">Name of the certificate.</param>
    /// <param name="thumbprint">Thumbprint of the certificate.</param>
    /// <param name="notAfter">Date until which the certificate is valid.</param>
    public void WriteExpiryAlert(string certificateName, string thumbprint, DateTimeOffset notAfter)
    {
        string message = $"WEF certificate expiry alert: {certificateName} thumbprint {thumbprint} notAfter {notAfter:u}";
        CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), message);

        if (OperatingSystem.IsWindows()
            && string.Equals(Environment.GetEnvironmentVariable("CH_WEF_EVENT_LOG"), "1", StringComparison.Ordinal))
        {
            try
            {
                const string source = "CertificateHandler";
                if (!System.Diagnostics.EventLog.SourceExists(source))
                {
                    System.Diagnostics.EventLog.CreateEventSource(source, "Application");
                }

                using var log = new System.Diagnostics.EventLog("Application") { Source = source };
                log.WriteEntry(message, System.Diagnostics.EventLogEntryType.Warning, 42501);
            }
            catch (Exception ex)
            {
                CertificateHandlerLogger.Warning(MessageIdGenerator.Next(), "WEF Event Log write failed: {0}", ex.Message);
            }
        }
    }

    #endregion
}
