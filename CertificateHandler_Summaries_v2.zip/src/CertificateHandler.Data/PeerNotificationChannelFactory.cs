// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Interfaces;

namespace CertificateHandler.Data;

/// <summary>
/// Selects peer notification transport (RS_10).
/// </summary>
public static class PeerNotificationChannelFactory
{
    /// <summary>
    /// Creates the peer notification channel.
    /// The HTTP channel is used when a notification address is set, otherwise the log channel is used.
    /// </summary>
    /// <returns>The peer notification channel.</returns>
    public static IPeerNotificationChannel Create()
    {
        if (!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("CH_PEER_NOTIFY_URL")))
        {
            return new HttpPeerNotificationChannel();
        }

        return new LoggingPeerNotificationChannel();
    }
}
