// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.Data.Constants;
using CertificateHandler.Data.Interfaces;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;
using Npgsql;

namespace CertificateHandler.Data;

/// <summary>
/// Retries pending trust-event deliveries to in-device subscribers (RS_27).
/// </summary>
public sealed class TrustEventDeliveryService
{
    #region Member Variables

    /// <summary>
    /// Data source used to connect to the database.
    /// </summary>
    private readonly NpgsqlDataSource _dataSource;

    /// <summary>
    /// Channel used to send the trust events.
    /// </summary>
    private readonly IInDeviceTrustSubscriberChannel _channel;

    /// <summary>
    /// Most times a trust event is tried.
    /// </summary>
    private const int MaxAttempts = 5;

    /// <summary>
    /// Name of the default subscriber in the device.
    /// </summary>
    private const string DefaultSubscriber = "MAXUM_IN_DEVICE";

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the trust event delivery service.
    /// </summary>
    /// <param name="dataSource">Data source used to connect to the database.</param>
    /// <param name="channel">Channel used to send the events, or null to use the log channel.</param>
    /// <exception cref="ArgumentNullException">Thrown when the data source is null.</exception>
    public TrustEventDeliveryService(NpgsqlDataSource dataSource, IInDeviceTrustSubscriberChannel? channel = null)
    {
        _dataSource = dataSource ?? throw new ArgumentNullException(nameof(dataSource));
        _channel = channel ?? new LoggingInDeviceTrustSubscriberChannel();
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Sends the waiting trust events to the subscribers and saves the result of each try.
    /// Up to 50 events are taken each time. After 5 failed tries the delivery is marked as FAILED.
    /// </summary>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>Number of events sent.</returns>
    public async Task<int> DeliverPendingAsync(CancellationToken cancellationToken = default)
    {
        int delivered = 0;
        await using var connection = await _dataSource.OpenConnectionAsync(cancellationToken);
        await using var select = new NpgsqlCommand(
            $"SELECT delivery_id, event_id, subscriber_name, attempt_count FROM {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
            "WHERE status IN ('PENDING', 'RETRYING', 'FAILED') AND attempt_count < @max ORDER BY delivery_id LIMIT 50",
            connection);
        select.Parameters.AddWithValue("max", MaxAttempts);

        var pending = new List<(long DeliveryId, Guid EventId, string Subscriber, int Attempts)>();
        await using (var reader = await select.ExecuteReaderAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                pending.Add((reader.GetInt64(0), reader.GetGuid(1), reader.GetString(2), reader.GetInt32(3)));
            }
        }

        foreach ((long deliveryId, Guid eventId, string subscriber, int attempts) in pending)
        {
            bool ok = await _channel.TryDeliverAsync(eventId, subscriber, cancellationToken);
            if (ok)
            {
                await using var update = new NpgsqlCommand(
                    $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
                    "SET status = 'DELIVERED', delivered_at = now(), last_attempt_at = now(), last_error = NULL, " +
                    "attempt_count = attempt_count + 1 WHERE delivery_id = @id",
                    connection);
                update.Parameters.AddWithValue("id", deliveryId);
                await update.ExecuteNonQueryAsync(cancellationToken);
                delivered++;
                continue;
            }

            int nextAttempts = attempts + 1;
            string status = nextAttempts >= MaxAttempts ? "FAILED" : "RETRYING";
            await using var fail = new NpgsqlCommand(
                $"UPDATE {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
                "SET status = CAST(@status AS certificate_handler.trust_event_delivery_status), last_attempt_at = now(), " +
                "attempt_count = attempt_count + 1, last_error = @error WHERE delivery_id = @id",
                connection);
            fail.Parameters.AddWithValue("status", status);
            fail.Parameters.AddWithValue("error", "Delivery to in-device subscriber failed.");
            fail.Parameters.AddWithValue("id", deliveryId);
            await fail.ExecuteNonQueryAsync(cancellationToken);

            if (nextAttempts >= MaxAttempts)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Trust event {0} delivery exhausted retries; notify administrator (RS_27).",
                    eventId);
            }
        }

        return delivered;
    }

    /// <summary>
    /// Queues the trust event for the default subscriber.
    /// </summary>
    /// <param name="connection">Open database connection.</param>
    /// <param name="eventId">Id of the trust event.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A task that ends when the event is queued.</returns>
    public static async Task QueueDefaultSubscriberAsync(
        NpgsqlConnection connection,
        Guid eventId,
        CancellationToken cancellationToken = default)
    {
        await using var command = new NpgsqlCommand(
            $"INSERT INTO {DatabaseConstants.SchemaName}.ch_trust_event_delivery " +
            "(event_id, subscriber_name, status) VALUES (@eventId, @subscriber, 'PENDING') " +
            "ON CONFLICT (event_id, subscriber_name) DO NOTHING",
            connection);
        command.Parameters.AddWithValue("eventId", eventId);
        command.Parameters.AddWithValue("subscriber", DefaultSubscriber);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    #endregion
}
