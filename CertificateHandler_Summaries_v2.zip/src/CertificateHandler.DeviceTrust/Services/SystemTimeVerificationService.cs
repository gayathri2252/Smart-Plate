// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.DeviceTrust.Interfaces;
using CertificateHandler.Shared.Security;
using Microsoft.Win32;

namespace CertificateHandler.DeviceTrust.Services;

/// <summary>
/// Fail-closed when Windows time service is unavailable or test bypass is enabled (DEBUG only).
/// </summary>
public sealed class SystemTimeVerificationService : ITimeVerificationService
{
    /// <summary>
    /// Registry key of the Windows time service settings.
    /// </summary>
    private const string W32TimeParametersKey =
        @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time\Parameters";

    /// <summary>
    /// Checks if the system time is kept in sync by the Windows time service.
    /// Returns false when the test bypass is on, the time service type is not set, or it is set to NoSync. Returns true when not running on Windows.
    /// </summary>
    /// <returns>True if the system time can be trusted, otherwise false.</returns>
    public bool IsTimeVerified()
    {
        if (DevelopmentBypassGuard.IsBypassEnabled("CH_TIME_UNVERIFIED"))
        {
            return false;
        }

        if (!OperatingSystem.IsWindows())
        {
            return true;
        }

        object? type = Registry.GetValue(W32TimeParametersKey, "Type", null);
        if (type is null)
        {
            return false;
        }

        string typeText = type.ToString()?.Trim() ?? string.Empty;
        return typeText is not ("NoSync" or "0");
    }
}
