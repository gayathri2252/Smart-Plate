// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Collections.Concurrent;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Inbound MAXUM TCP/TLS listener: mutual TLS, then trust gate via <see cref="PeerConnectionPipeline"/>.
/// </summary>
public sealed class PeerTlsListener : IDisposable
{
    #region Member Variables

    /// <summary>
    /// Checks and approves the peer certificate.
    /// </summary>
    private readonly IPeerConnectionPipeline _pipeline;

    /// <summary>
    /// Settings for the listener.
    /// </summary>
    private readonly MaxumConnectionManagerOptions _options;

    /// <summary>
    /// Certificate this device shows to the peers.
    /// </summary>
    private readonly X509Certificate2 _serverCertificate;

    /// <summary>
    /// Limits how many connections are handled at the same time.
    /// </summary>
    private readonly SemaphoreSlim _connectionLimit;

    /// <summary>
    /// Tasks of the connections being handled.
    /// </summary>
    private readonly ConcurrentBag<Task> _connectionTasks = new();

    /// <summary>
    /// Lock used when starting or stopping the listener.
    /// </summary>
    private readonly object _gate = new();

    /// <summary>
    /// TCP listener for incoming connections. Null when it is not running.
    /// </summary>
    private TcpListener? _listener;

    /// <summary>
    /// Used to stop the accept loop. Null when the listener is not running.
    /// </summary>
    private CancellationTokenSource? _cts;

    /// <summary>
    /// Task of the accept loop. Null when the listener is not running.
    /// </summary>
    private Task? _acceptLoop;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TLS listener.
    /// </summary>
    /// <param name="pipeline">Checks and approves the peer certificate.</param>
    /// <param name="options">Settings for the listener.</param>
    /// <param name="serverCertificate">Certificate this device shows to the peers.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    public PeerTlsListener(
        IPeerConnectionPipeline pipeline,
        MaxumConnectionManagerOptions options,
        X509Certificate2 serverCertificate)
    {
        _pipeline = pipeline ?? throw new ArgumentNullException(nameof(pipeline));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _serverCertificate = serverCertificate ?? throw new ArgumentNullException(nameof(serverCertificate));
        _connectionLimit = new SemaphoreSlim(_options.MaxConcurrentConnections, _options.MaxConcurrentConnections);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts the TCP listener and the accept loop. Does nothing when it is already running.
    /// </summary>
    public void Start()
    {
        lock (_gate)
        {
            if (_listener is not null)
            {
                return;
            }

            _cts = new CancellationTokenSource();
            _listener = new TcpListener(_options.BindAddress, _options.ListenPort);
            _listener.Start();
            _acceptLoop = AcceptConnectionsAsync(_cts.Token);
        }

        CertificateHandlerLogger.Success(
            MessageIdGenerator.Next(),
            "Peer TLS listener started on %s.",
            $"{_options.BindAddress}:{_options.ListenPort}");
    }

    /// <summary>
    /// Stops the listener and waits up to 30 seconds for open connections to finish.
    /// </summary>
    public void Stop()
    {
        lock (_gate)
        {
            _cts?.Cancel();
            _listener?.Stop();
        }

        try
        {
            _acceptLoop?.GetAwaiter().GetResult();
        }
        catch (OperationCanceledException)
        {
        }
        catch (AggregateException ex) when (ex.InnerException is OperationCanceledException)
        {
        }

        try
        {
            Task[] pending = _connectionTasks.Where(t => !t.IsCompleted).ToArray();
            if (pending.Length > 0)
            {
                Task.WaitAll(pending, TimeSpan.FromSeconds(30));
            }
        }
        catch (AggregateException)
        {
        }

        lock (_gate)
        {
            _acceptLoop = null;
            _listener = null;
            _cts?.Dispose();
            _cts = null;
        }
    }

    /// <summary>
    /// Stops the listener and frees its resources.
    /// </summary>
    public void Dispose()
    {
        Stop();
        _connectionLimit.Dispose();
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Accepts new connections until the listener is stopped.
    /// When the connection limit is full for 5 seconds, the new connection is closed.
    /// </summary>
    /// <param name="cancellationToken">Token that stops the loop.</param>
    /// <returns>A task that ends when the loop stops.</returns>
    private async Task AcceptConnectionsAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            TcpListener listener;
            lock (_gate)
            {
                listener = _listener!;
            }

            try
            {
                TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);
                if (!await _connectionLimit.WaitAsync(TimeSpan.FromSeconds(5), cancellationToken).ConfigureAwait(false))
                {
                    client.Dispose();
                    CertificateHandlerLogger.Warning(
                        MessageIdGenerator.Next(),
                        "Peer listener rejected connection (limit %s).",
                        _options.MaxConcurrentConnections.ToString());
                    continue;
                }

                Task handle = HandleClientAsync(client, cancellationToken);
                _connectionTasks.Add(handle);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (Exception ex)
            {
                CertificateHandlerLogger.Warning(
                    MessageIdGenerator.Next(),
                    "Peer listener accept failed: %s",
                    ex.Message);
            }
        }
    }

    /// <summary>
    /// Does the TLS handshake with the peer and runs the trust check for the connection.
    /// </summary>
    /// <param name="client">TCP client of the new connection.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>A task that ends when the connection is handled.</returns>
    private async Task HandleClientAsync(TcpClient client, CancellationToken cancellationToken)
    {
        string? remoteIp = (client.Client.RemoteEndPoint as IPEndPoint)?.Address.ToString();
        string correlationId = Guid.NewGuid().ToString();

        try
        {
            using (client)
            await using (NetworkStream networkStream = client.GetStream())
            await using (var sslStream = new SslStream(networkStream, leaveInnerStreamOpen: false))
            {
                await sslStream.AuthenticateAsServerAsync(
                    _serverCertificate,
                    clientCertificateRequired: true,
                    enabledSslProtocols: SslProtocols.Tls12 | SslProtocols.Tls13,
                    checkCertificateRevocation: _options.CheckCertificateRevocation).ConfigureAwait(false);

                _ = await PeerTlsSessionProcessor.ProcessInboundAsync(
                    sslStream,
                    _pipeline,
                    remoteIp,
                    correlationId,
                    sendStatusLine: true,
                    cancellationToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (AuthenticationException ex)
        {
            CertificateHandlerLogger.Warning(
                MessageIdGenerator.Next(),
                "Inbound peer TLS auth failed from %s: %s",
                remoteIp ?? "?",
                ex.Message);
        }
        catch (Exception ex)
        {
            CertificateHandlerLogger.Error(
                MessageIdGenerator.Next(),
                "Inbound peer connection %s failed: %s",
                correlationId,
                ex.Message);
        }
        finally
        {
            _connectionLimit.Release();
        }
    }

    #endregion
}
