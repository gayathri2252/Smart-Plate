// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.DeviceTrust.Models;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Trust gate entry point for inbound and outbound MAXUM TLS sessions.
/// </summary>
public interface IPeerConnectionPipeline
{
    /// <summary>
    /// Checks the peer certificate, decides if it is allowed, and tells if TLS can go on.
    /// </summary>
    /// <param name="request">The certificate request of the peer.</param>
    /// <param name="correlationId">Id of the connection, or null if not known.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The result of the check.</returns>
    Task<PeerConnectionPipelineResult> ProcessAsync(
        CertificateRequest request,
        string? correlationId,
        CancellationToken cancellationToken = default);
}
