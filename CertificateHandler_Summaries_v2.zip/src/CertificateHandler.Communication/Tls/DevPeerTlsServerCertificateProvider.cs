// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Legacy loader; use <see cref="PeerTlsCertificateProvider"/>.
/// </summary>
public static class DevPeerTlsServerCertificateProvider
{
    /// <summary>
    /// Loads the server certificate using the development listener settings.
    /// </summary>
    /// <param name="options">Development listener settings.</param>
    /// <returns>The server certificate with its private key.</returns>
    public static X509Certificate2 Load(DevPeerTlsListenerOptions options) =>
        PeerTlsCertificateProvider.LoadDeviceCertificate(options.ToConnectionManagerOptions());

    /// <summary>
    /// Loads the server certificate using the connection manager settings.
    /// </summary>
    /// <param name="options">Connection manager settings.</param>
    /// <returns>The server certificate with its private key.</returns>
    public static X509Certificate2 Load(MaxumConnectionManagerOptions options) =>
        PeerTlsCertificateProvider.LoadDeviceCertificate(options);
}
