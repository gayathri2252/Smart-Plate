// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Runtime options for the MAXUM Connection Manager (inbound listener + outbound connector).
/// </summary>
public sealed class MaxumConnectionManagerOptions
{
    #region Public Properties

    /// <summary>
    /// True when the listener is turned on.
    /// </summary>
    public bool ListenEnabled { get; init; } = true;

    /// <summary>
    /// IP address the listener uses.
    /// </summary>
    public IPAddress BindAddress { get; init; } = IPAddress.Loopback;

    /// <summary>
    /// Port the listener listens on.
    /// </summary>
    public int ListenPort { get; init; } = 17443;

    /// <summary>
    /// Port used when connecting to a peer and no port is given.
    /// </summary>
    public int DefaultPeerPort { get; init; } = 17443;

    /// <summary>
    /// SHA256 thumbprint of the device certificate.
    /// </summary>
    public string DeviceCertThumbprintSha256 { get; init; } = string.Empty;

    /// <summary>
    /// Certificate store location that has the device certificate.
    /// </summary>
    public StoreLocationName StoreLocation { get; init; } = StoreLocationName.LocalMachine;

    /// <summary>
    /// Most connections that can be handled at the same time.
    /// </summary>
    public int MaxConcurrentConnections { get; init; } = 32;

    /// <summary>
    /// True to check if certificates are revoked during the TLS handshake.
    /// </summary>
    public bool CheckCertificateRevocation { get; init; } = true;

    /// <summary>
    /// How long to wait when connecting to a peer.
    /// </summary>
    public TimeSpan ConnectTimeout { get; init; } = TimeSpan.FromSeconds(30);

    #endregion

    #region Public Methods

    /// <summary>
    /// Reads the settings from the environment variables.
    /// A value that is missing or not valid keeps its default.
    /// </summary>
    /// <returns>The connection manager settings.</returns>
    public static MaxumConnectionManagerOptions FromEnvironment()
    {
        bool listenEnabled = !string.Equals(
            Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_LISTEN"),
            "0",
            StringComparison.Ordinal);

        string? portRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_PORT")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_PORT");
        int listenPort = 17443;
        if (!string.IsNullOrWhiteSpace(portRaw) && int.TryParse(portRaw, out int parsed) && parsed is > 0 and < 65536)
        {
            listenPort = parsed;
        }

        int defaultPeerPort = listenPort;
        string? peerPortRaw = Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_PEER_PORT");
        if (!string.IsNullOrWhiteSpace(peerPortRaw) && int.TryParse(peerPortRaw, out int peerPort) && peerPort is > 0 and < 65536)
        {
            defaultPeerPort = peerPort;
        }

        IPAddress bindAddress = IPAddress.Loopback;
        string? bind = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_BIND")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_BIND");
        if (string.Equals(bind, "any", StringComparison.OrdinalIgnoreCase))
        {
            bindAddress = IPAddress.Any;
        }
        else if (!string.IsNullOrWhiteSpace(bind)
                 && IPAddress.TryParse(bind.Trim(), out IPAddress? parsedBind)
                 && parsedBind is not null)
        {
            bindAddress = parsedBind;
        }

        string thumbprint = Environment.GetEnvironmentVariable("CH_DEVICE_CERT_THUMBPRINT")?.Trim()
            ?? Environment.GetEnvironmentVariable("CH_PEER_LISTENER_SERVER_THUMBPRINT")?.Trim()
            ?? string.Empty;

        StoreLocationName location = StoreLocationName.LocalMachine;
        string? locationRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_STORE_LOCATION")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_STORE_LOCATION");
        if (string.Equals(locationRaw, "CurrentUser", StringComparison.OrdinalIgnoreCase))
        {
            location = StoreLocationName.CurrentUser;
        }

        int maxConnections = 32;
        string? maxRaw = Environment.GetEnvironmentVariable("CH_PEER_LISTENER_MAX_CONNECTIONS")
            ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_MAX_CONNECTIONS");
        if (!string.IsNullOrWhiteSpace(maxRaw) && int.TryParse(maxRaw, out int maxParsed) && maxParsed > 0)
        {
            maxConnections = Math.Min(maxParsed, 256);
        }

        bool checkRevocation = !string.Equals(
            Environment.GetEnvironmentVariable("CH_PEER_LISTENER_CHECK_REVOCATION")
                ?? Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_CHECK_REVOCATION"),
            "0",
            StringComparison.Ordinal);

        int connectTimeoutSeconds = 30;
        string? timeoutRaw = Environment.GetEnvironmentVariable("CH_CONNECTION_MANAGER_CONNECT_TIMEOUT_SEC");
        if (!string.IsNullOrWhiteSpace(timeoutRaw) && int.TryParse(timeoutRaw, out int seconds) && seconds > 0)
        {
            connectTimeoutSeconds = Math.Min(seconds, 300);
        }

        return new MaxumConnectionManagerOptions
        {
            ListenEnabled = listenEnabled,
            BindAddress = bindAddress,
            ListenPort = listenPort,
            DefaultPeerPort = defaultPeerPort,
            DeviceCertThumbprintSha256 = thumbprint,
            StoreLocation = location,
            MaxConcurrentConnections = maxConnections,
            CheckCertificateRevocation = checkRevocation,
            ConnectTimeout = TimeSpan.FromSeconds(connectTimeoutSeconds)
        };
    }

    /// <summary>Maps legacy dev listener env keys to connection manager options.</summary>
    public static MaxumConnectionManagerOptions FromLegacyDevListenerEnvironment() => FromEnvironment();

    #endregion
}
