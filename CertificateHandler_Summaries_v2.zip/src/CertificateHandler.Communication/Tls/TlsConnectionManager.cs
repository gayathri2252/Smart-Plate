// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using CertificateHandler.DeviceTrust.Services;
using CertificateHandler.DeviceTrust.Tls;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Applies admission, handshake suspension, and blacklist blocking at connection time (RS_11).
/// </summary>
public sealed class TlsConnectionManager
{
    #region Member Variables

    /// <summary>
    /// Checks if the connection is let in.
    /// </summary>
    private readonly ConnectionAdmissionService _admission;

    /// <summary>
    /// Holds and releases TLS handshakes.
    /// </summary>
    private readonly ITlsHandshakeCoordinator _handshakes;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TLS connection manager.
    /// </summary>
    /// <param name="admission">Checks if the connection is let in.</param>
    /// <param name="handshakes">Holds and releases TLS handshakes.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    public TlsConnectionManager(ConnectionAdmissionService admission, ITlsHandshakeCoordinator handshakes)
    {
        _admission = admission ?? throw new ArgumentNullException(nameof(admission));
        _handshakes = handshakes ?? throw new ArgumentNullException(nameof(handshakes));
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Checks if the TLS session can start.
    /// It cannot start when the connection is not let in or the handshake is on hold.
    /// </summary>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the peer certificate.</param>
    /// <param name="correlationId">Id of the connection, or null if not known.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>True if the TLS session can start, otherwise false.</returns>
    public async Task<bool> MayStartTlsAsync(string thumbprintSha256, string? correlationId, CancellationToken cancellationToken = default)
    {
        if (!await _admission.IsConnectionAllowedAsync(thumbprintSha256, cancellationToken))
        {
            return false;
        }

        if (!string.IsNullOrWhiteSpace(correlationId) && _handshakes.IsSuspended(correlationId))
        {
            return false;
        }

        return true;
    }

    /// <summary>
    /// Holds the TLS handshake while the certificate request waits for approval.
    /// </summary>
    /// <param name="correlationId">Id of the connection.</param>
    /// <param name="thumbprintSha256">SHA256 thumbprint of the peer certificate.</param>
    /// <returns>True if the handshake is now on hold, otherwise false.</returns>
    public bool SuspendPendingHandshake(string correlationId, string thumbprintSha256) =>
        _handshakes.TrySuspend(correlationId, thumbprintSha256);

    #endregion
}
