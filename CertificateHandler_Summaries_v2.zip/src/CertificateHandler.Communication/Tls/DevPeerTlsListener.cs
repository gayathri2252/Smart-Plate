// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// Back-compat name for <see cref="PeerTlsListener"/> (dev / legacy CLI).
/// </summary>
public sealed class DevPeerTlsListener : IDisposable
{
    #region Member Variables

    /// <summary>
    /// The listener that does the real work.
    /// </summary>
    private readonly PeerTlsListener _inner;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the listener using the development settings.
    /// </summary>
    /// <param name="pipeline">Checks and approves the peer certificate.</param>
    /// <param name="options">Development listener settings.</param>
    /// <param name="serverCertificate">Certificate this device shows to the peers.</param>
    public DevPeerTlsListener(
        IPeerConnectionPipeline pipeline,
        DevPeerTlsListenerOptions options,
        X509Certificate2 serverCertificate)
    {
        _inner = new PeerTlsListener(pipeline, options.ToConnectionManagerOptions(), serverCertificate);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts listening for peer connections.
    /// </summary>
    public void Start() => _inner.Start();

    /// <summary>
    /// Stops listening for peer connections.
    /// </summary>
    public void Stop() => _inner.Stop();

    /// <summary>
    /// Stops the listener and frees its resources.
    /// </summary>
    public void Dispose() => _inner.Dispose();

    #endregion
}
