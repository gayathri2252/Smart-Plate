// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Net.Security;
using System.Net.Sockets;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// An outbound mutual-TLS session that passed the trust gate and may carry application data.
/// </summary>
public sealed class PeerTlsConnection : IAsyncDisposable
{
    #region Member Variables

    /// <summary>
    /// TCP client of the connection.
    /// </summary>
    private readonly TcpClient _tcpClient;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the TLS connection.
    /// </summary>
    /// <param name="tcpClient">TCP client of the connection.</param>
    /// <param name="sslStream">TLS stream of the connection.</param>
    /// <param name="gateOutcome">Result of the trust check for the peer.</param>
    /// <param name="peerHost">Host name or IP address of the peer.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    internal PeerTlsConnection(
        TcpClient tcpClient,
        SslStream sslStream,
        PeerTlsGateOutcome gateOutcome,
        string peerHost)
    {
        _tcpClient = tcpClient ?? throw new ArgumentNullException(nameof(tcpClient));
        Stream = sslStream ?? throw new ArgumentNullException(nameof(sslStream));
        GateOutcome = gateOutcome ?? throw new ArgumentNullException(nameof(gateOutcome));
        PeerHost = peerHost ?? throw new ArgumentNullException(nameof(peerHost));
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// Gets the TLS stream of the connection.
    /// </summary>
    public SslStream Stream { get; }

    /// <summary>
    /// Gets the result of the trust check for the peer.
    /// </summary>
    public PeerTlsGateOutcome GateOutcome { get; }

    /// <summary>
    /// Gets the host name or IP address of the peer.
    /// </summary>
    public string PeerHost { get; }

    #endregion

    #region Public Methods

    /// <summary>
    /// Closes the TLS stream and the TCP client.
    /// </summary>
    /// <returns>A task that ends when the connection is closed.</returns>
    public async ValueTask DisposeAsync()
    {
        await Stream.DisposeAsync().ConfigureAwait(false);
        _tcpClient.Dispose();
    }

    #endregion
}
