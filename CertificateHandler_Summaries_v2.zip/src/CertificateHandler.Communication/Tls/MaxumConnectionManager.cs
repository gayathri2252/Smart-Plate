// The information contained herein is confidential and proprietary to Valmet and is not to be
// reproduced, disclosed to a third party, modified or used without prior permission of Valmet
// or its duly authorized representative. All rights reserved.
//
// This document is subject to the Export Administration Regulations (EAR).
// Diversion contrary to U.S. law is prohibited.
//
// History:

using System.Security.Cryptography.X509Certificates;
using CertificateHandler.Logger;
using CertificateHandler.Shared.Constants;

namespace CertificateHandler.Communication.Tls;

/// <summary>
/// MAXUM Connection Manager: TCP listener + TLS connector wired to <see cref="PeerConnectionHostResources"/>.
/// </summary>
public sealed class MaxumConnectionManager : IMaxumConnectionManager
{
    #region Member Variables

    /// <summary>
    /// Shared resources that give the connection pipeline.
    /// </summary>
    private readonly PeerConnectionHostResources _host;

    /// <summary>
    /// Settings for the listener and the outgoing connections.
    /// </summary>
    private readonly MaxumConnectionManagerOptions _options;

    /// <summary>
    /// Certificate of this device used for TLS.
    /// </summary>
    private readonly X509Certificate2 _deviceCertificate;

    /// <summary>
    /// Listener for incoming connections. Null when it is not running.
    /// </summary>
    private PeerTlsListener? _listener;

    /// <summary>
    /// Makes outgoing connections. Null after the manager is disposed.
    /// </summary>
    private PeerTlsConnector? _connector;

    /// <summary>
    /// True when the manager is disposed.
    /// </summary>
    private bool _disposed;

    #endregion

    #region Constructor

    /// <summary>
    /// Creates the connection manager.
    /// </summary>
    /// <param name="host">Shared resources that give the connection pipeline.</param>
    /// <param name="options">Settings for the listener and the outgoing connections.</param>
    /// <param name="deviceCertificate">Certificate of this device used for TLS.</param>
    /// <exception cref="ArgumentNullException">Thrown when any parameter is null.</exception>
    public MaxumConnectionManager(
        PeerConnectionHostResources host,
        MaxumConnectionManagerOptions options,
        X509Certificate2 deviceCertificate)
    {
        _host = host ?? throw new ArgumentNullException(nameof(host));
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _deviceCertificate = deviceCertificate ?? throw new ArgumentNullException(nameof(deviceCertificate));
        _connector = new PeerTlsConnector(_host.Pipeline, _options, _deviceCertificate);
    }

    /// <summary>
    /// Creates a connection manager and loads the device certificate.
    /// </summary>
    /// <param name="host">Shared resources that give the connection pipeline.</param>
    /// <param name="options">Settings to use, or null to read them from the environment.</param>
    /// <returns>The new connection manager.</returns>
    /// <exception cref="ArgumentNullException">Thrown when the host resources are null.</exception>
    public static MaxumConnectionManager Create(
        PeerConnectionHostResources host,
        MaxumConnectionManagerOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(host);
        MaxumConnectionManagerOptions resolved = options ?? MaxumConnectionManagerOptions.FromEnvironment();
        X509Certificate2 certificate = PeerTlsCertificateProvider.LoadDeviceCertificate(resolved);
        return new MaxumConnectionManager(host, resolved, certificate);
    }

    #endregion

    #region Public Properties

    /// <summary>
    /// True when the listener is running.
    /// </summary>
    public bool IsListening => _listener is not null;

    #endregion

    #region Public Methods

    /// <summary>
    /// Starts listening for connections from other devices.
    /// Does nothing when the listener is turned off or is already running.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Thrown when the manager is disposed.</exception>
    public void StartListener()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (!_options.ListenEnabled)
        {
            CertificateHandlerLogger.Information(
                MessageIdGenerator.Next(),
                "Connection Manager listener disabled (CH_CONNECTION_MANAGER_LISTEN=0).");
            return;
        }

        if (_listener is not null)
        {
            return;
        }

        _listener = new PeerTlsListener(_host.Pipeline, _options, _deviceCertificate);
        _listener.Start();
    }

    /// <summary>
    /// Stops listening for connections from other devices.
    /// </summary>
    public void StopListener()
    {
        _listener?.Dispose();
        _listener = null;
    }

    /// <summary>
    /// Connects to another MAXUM device over TLS.
    /// </summary>
    /// <param name="host">Host name or IP address of the peer.</param>
    /// <param name="port">Port of the peer, or null to use the default port.</param>
    /// <param name="cancellationToken">Token to cancel the work.</param>
    /// <returns>The connection, or null when the peer is not trusted.</returns>
    /// <exception cref="ObjectDisposedException">Thrown when the manager is disposed.</exception>
    /// <exception cref="InvalidOperationException">Thrown when outgoing connections are not available.</exception>
    public Task<PeerTlsConnection?> ConnectToPeerAsync(
        string host,
        int? port = null,
        CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        PeerTlsConnector connector = _connector ?? throw new InvalidOperationException("Connector is not available.");
        return connector.ConnectAsync(host, port, cancellationToken);
    }

    /// <summary>
    /// Stops the listener and frees the device certificate.
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        StopListener();
        _connector = null;
        _deviceCertificate.Dispose();
        _disposed = true;
    }

    #endregion
}
